﻿Scripts for re-import + swap (current versions, 17 Nov 2026). Replace any older copies from the earlier zip.

Order per repo:
1. pr-preload.ps1 -Repo <repo> -KeepCommitIds         re-imports fin-tcm/<repo> into tcm-pilot/<repo>-pr2 with full PR history
2. secrets-transfer.ps1 -Pairs '<repo>=><repo>-pr2'   (dry run first, then -Apply) copies repo + environment secrets into the copy
3. swap-checked.ps1 -Repos <repo> -Suffix pr2 -Stamp <yyyyMMdd of the pr-preload run>
      checks run.log, PRs opened only in tcm-pilot (live-only-prs.py), LFS, branches (swap-precheck.ps1),
      then calls repo-swap.ps1 -Apply (live -> <repo>-old archived, copy -> <repo>, settings copied), carries over branches
4. verify-swap.ps1 -Repos <repo>                      read-only report: PRs, authors, teams, collaborators, settings, autolinks, LFS

Already swapped and secrets missing: secrets-transfer.ps1 -Pairs '<repo>-old=><repo>' -Apply
  (unarchives -old for the run and archives it again; Dependabot secrets are listed as owner action)
lfs-copy-between-repos.ps1: copies missing LFS objects from one repo to another (used for ARC-almonde).
Tokens are read from C:\development\pats.txt (GH_TGT_PAT / GH_SRC_PAT). Python: C:\kon-migration\tools\python\python.exe -I
