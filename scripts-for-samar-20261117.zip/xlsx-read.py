# Minimal .xlsx reader (stdlib only): prints each sheet's name, size and first rows; --csv <dir> writes every sheet as CSV.
import zipfile, re, sys, csv, os, xml.etree.ElementTree as ET
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main', 'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
path = sys.argv[1]; out = sys.argv[sys.argv.index('--csv') + 1] if '--csv' in sys.argv else None
z = zipfile.ZipFile(path)
shared = []
if 'xl/sharedStrings.xml' in z.namelist():
    for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', NS):
        shared.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
wb = ET.fromstring(z.read('xl/workbook.xml'))
rels = {r.get('Id'): r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
def col(ref):
    c = re.match(r'[A-Z]+', ref).group(0); n = 0
    for ch in c: n = n * 26 + ord(ch) - 64
    return n - 1
for sh in wb.find('m:sheets', NS):
    name = sh.get('name'); target = rels[sh.get('{%s}id' % NS['r'])]; target = target.lstrip('/'); target = target if target.startswith('xl/') else 'xl/' + target
    rows = []
    for row in ET.fromstring(z.read(target)).iter('{%s}row' % NS['m']):
        vals = {}
        for c in row.findall('m:c', NS):
            v = c.find('m:v', NS); t = c.get('t'); txt = ''
            if t == 's' and v is not None: txt = shared[int(v.text)]
            elif t == 'inlineStr': txt = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
            elif v is not None: txt = v.text
            vals[col(c.get('r'))] = txt
        if vals: rows.append([vals.get(i, '') for i in range(max(vals) + 1)])
    print(f'=== sheet "{name}": {len(rows)} rows')
    for r in rows[:6]: print('   ', ' | '.join(str(x)[:40] for x in r[:12]))
    if out:
        os.makedirs(out, exist_ok=True)
        with open(os.path.join(out, re.sub(r'[^\w-]+', '_', name) + '.csv'), 'w', newline='', encoding='utf-8-sig') as f: csv.writer(f).writerows(rows)
