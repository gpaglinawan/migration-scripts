# PRs that existed only in the old live tcm-pilot repo (<repo>-old): not recreated from Finastra (no "Migrated from fin-tcm" marker)
import json, os, sys, urllib.request, time, collections
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
T = os.environ['GH_TGT_PAT']
def prs(repo):
    out, cur = [], None
    q = 'query($n:String!,$c:String){repository(owner:"tcm-pilot",name:$n){pullRequests(first:100,after:$c){pageInfo{hasNextPage endCursor} nodes{number title state createdAt author{login} body headRefName}}}}'
    while True:
        r = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': {'n': repo, 'c': cur}}).encode(), headers={'Authorization': 'Bearer ' + T})
        d = json.load(urllib.request.urlopen(r, timeout=120))['data']['repository']['pullRequests']
        out += d['nodes']
        if not d['pageInfo']['hasNextPage']: return out
        cur = d['pageInfo']['endCursor']
if sys.argv[1] == '--pre':   # before a swap: live <repo> vs copy <repo>-pr2; prints the number of PRs by people (not bots) missing in the copy
    repo = sys.argv[2]; cp = {(p['title'], p['createdAt']) for p in prs(repo + '-pr2')}   # 17 Nov: author ignored (live shows 'ghost' where the copy shows the real person)
    human = [p for p in prs(repo) if not (p['body'] or '').lstrip('> ').startswith('Migrated from fin-tcm')
             and (p['title'], p['createdAt']) not in cp
             and ((p['author'] or {}).get('login') or '') not in ('dependabot', 'Copilot', 'github-actions', 'renovate')]
    print(f'HUMAN_ONLY={len(human)} ' + '; '.join(f"#{p['number']} {(p['author'] or {}).get('login')} {p['state']} {p['title'][:50]}" for p in human[:5])); sys.exit()
for repo in sys.argv[1:]:
    old = prs(repo + '-old'); new = {(p['title'], (p['author'] or {}).get('login'), p['createdAt']) for p in prs(repo)}
    only = [p for p in old if not (p['body'] or '').lstrip('> ').startswith('Migrated from fin-tcm') and (p['title'], (p['author'] or {}).get('login'), p['createdAt']) not in new]
    by = collections.Counter(((p['author'] or {}).get('login') or 'ghost', p['state']) for p in only)
    print(f"{repo}: PRs only in the old tcm-pilot repo: {len(only)} -> " + ', '.join(f'{a} {s} x{c}' for (a, s), c in by.most_common(8)))
    for p in sorted(only, key=lambda x: x['createdAt'], reverse=True)[:4]: print(f"   #{p['number']} {p['state']} {p['createdAt'][:10]} {(p['author'] or {}).get('login')}: {p['title'][:70]}")
