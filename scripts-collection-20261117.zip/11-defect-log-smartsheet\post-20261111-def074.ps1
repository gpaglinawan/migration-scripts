# 11 Nov 2026 (Gareth: "ok post"). Comment only - status (Deferred) not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-074' = 'Re-checked tonight (~22:00 CET), branch by branch, fin-tcm vs tcm-pilot. FABCOM-regulatory: 47 branches in fin-tcm, 78 in tcm-pilot; 45 identical; 2 differ (develop and feature/KTAC-26455-activate-frtb-contextId-uuid-master) only by 1 commit each made in fin-tcm today, fast-forward, copied by tonight''s nightly sync; all tags match. The other 31 branches exist only in tcm-pilot - they were deleted in fin-tcm after the migration and the sync never deletes; this is the "more branches in Teciem than in Finastra" count (75 vs 48 on 11/9). They are only removed if DEF-188 is decided as "delete at cutover" (after listing branches with unique commits for their owners) - until then the branch count will keep differing. THIRD-idakdb: 126 of 129 branches identical, all tags match; enhancement/pq differs only by 12 commits made today (fast-forward) and 1 branch was created today - both copied tonight; feature/KTAC-16017-work-on-odbc-win2022 was rewritten in fin-tcm and is set to the fin-tcm state at the final cutover sync. Remains Deferred for the retest after the final sync.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
