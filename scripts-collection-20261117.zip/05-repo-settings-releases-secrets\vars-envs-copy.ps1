param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Compare = "C:\kon-migration\actions\repo-actions-compare.csv",
  [string]$Out = "C:\kon-migration\actions\vars-envs-copy.log",
  [switch]$Apply
)
# Copies Actions VARIABLES (repo + environment) and ENVIRONMENTS (wait timer, required reviewers mapped to target
# teams/users, prevent self-review, deployment branch policy + custom branch/tag patterns) that are missing in the
# target. Never touches secrets. Existing target variables/environments are left unchanged.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $Out -Value $line -Encoding utf8 }
function Get-Json($uri, $hdr) { try { Invoke-RestMethod $uri -Headers $hdr } catch { $null } }
function Send($method, $uri, $body) { Invoke-RestMethod -Method $method -Uri $uri -Headers $tgtHdr -Body ($body | ConvertTo-Json -Depth 10 -Compress) -ContentType application/json }
function Items($resp, $prop) { $acc = New-Object System.Collections.ArrayList; if ($resp) { foreach ($x in $resp.$prop) { if ($x) { [void]$acc.Add($x) } } }; , $acc }
$teamCache = @{}; $userCache = @{}
function TgtTeamId($slug) { if (-not $teamCache.ContainsKey($slug)) { $t = Get-Json "https://api.github.com/orgs/$TgtOrg/teams/$slug" $tgtHdr; $teamCache[$slug] = $t.id }; $teamCache[$slug] }
function TgtUserId($login) { $tl = $login -replace '_finastra$', '_tciem'; if (-not $userCache.ContainsKey($tl)) { $u = Get-Json "https://api.github.com/users/$tl" $tgtHdr; $userCache[$tl] = $u.id }; $userCache[$tl] }

$rows = @(Import-Csv $Compare | Where-Object { $_.InTarget -eq 'True' -and ([int]$_.TgtVariables -lt [int]$_.SrcVariables -or [int]$_.TgtEnvironments -lt [int]$_.SrcEnvironments) })
Log "=== vars/envs copy: $($rows.Count) repos, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="
foreach ($row in $rows) {
  $repo = $row.Repo; $s = "https://api.github.com/repos/$SrcOrg/$repo"; $t = "https://api.github.com/repos/$TgtOrg/$repo"
  # repo variables
  $haveVars = @{}; foreach ($v in (Items (Get-Json "$t/actions/variables?per_page=30" $tgtHdr) 'variables')) { $haveVars[$v.name] = $true }
  foreach ($v in (Items (Get-Json "$s/actions/variables?per_page=30" $srcHdr) 'variables')) {
    if ($haveVars[$v.name]) { continue }
    if ($Apply) { try { Send POST "$t/actions/variables" @{ name = $v.name; value = $v.value } | Out-Null; Log "  $repo : variable $($v.name)" } catch { Log "  $repo : variable $($v.name) FAILED $($_.ErrorDetails.Message)" } }
    else { Log "  $repo : would add variable $($v.name)" }
  }
  # environments
  $haveEnv = @{}; foreach ($e in (Items (Get-Json "$t/environments?per_page=100" $tgtHdr) 'environments')) { $haveEnv[$e.name] = $true }
  foreach ($e in (Items (Get-Json "$s/environments?per_page=100" $srcHdr) 'environments')) {
    $en = [uri]::EscapeDataString($e.name); $notes = @()
    if (-not $haveEnv[$e.name]) {
      $body = @{}
      $wait = @($e.protection_rules | Where-Object { $_.type -eq 'wait_timer' }) | Select-Object -First 1; if ($wait) { $body.wait_timer = $wait.wait_timer }
      $rev = @($e.protection_rules | Where-Object { $_.type -eq 'required_reviewers' }) | Select-Object -First 1
      if ($rev) {
        $body.prevent_self_review = [bool]$rev.prevent_self_review
        $body.reviewers = @(foreach ($r in $rev.reviewers) {
          if ($r.type -eq 'Team') { $id = TgtTeamId $r.reviewer.slug; if ($id) { @{ type = 'Team'; id = $id } } else { $notes += "team $($r.reviewer.slug) missing" } }
          else { $id = TgtUserId $r.reviewer.login; if ($id) { @{ type = 'User'; id = $id } } else { $notes += "user $($r.reviewer.login) missing" } } })
      }
      if ($e.deployment_branch_policy) { $body.deployment_branch_policy = @{ protected_branches = [bool]$e.deployment_branch_policy.protected_branches; custom_branch_policies = [bool]$e.deployment_branch_policy.custom_branch_policies } }
      if ($Apply) {
        try { Send PUT "$t/environments/$en" $body | Out-Null; Log "  $repo : environment '$($e.name)' $($notes -join '; ')" } catch { Log "  $repo : environment '$($e.name)' FAILED $($_.ErrorDetails.Message)"; continue }
        if ($e.deployment_branch_policy.custom_branch_policies) {
          foreach ($bp in (Items (Get-Json "$s/environments/$en/deployment-branch-policies?per_page=100" $srcHdr) 'branch_policies')) {
            try { Send POST "$t/environments/$en/deployment-branch-policies" @{ name = $bp.name; type = $(if ($bp.type) { $bp.type } else { 'branch' }) } | Out-Null } catch {} }
        }
      } else { Log "  $repo : would create environment '$($e.name)' reviewers=$(@($body.reviewers | Where-Object { $_ }).Count) $($notes -join '; ')" }
    }
    # environment variables (new or existing environment)
    $haveEv = @{}; foreach ($v in (Items (Get-Json "$t/environments/$en/variables?per_page=30" $tgtHdr) 'variables')) { $haveEv[$v.name] = $true }
    foreach ($v in (Items (Get-Json "$s/environments/$en/variables?per_page=30" $srcHdr) 'variables')) {
      if ($haveEv[$v.name]) { continue }
      if ($Apply) { try { Send POST "$t/environments/$en/variables" @{ name = $v.name; value = $v.value } | Out-Null; Log "  $repo/$($e.name) : variable $($v.name)" } catch { Log "  $repo/$($e.name) : variable $($v.name) FAILED" } }
      else { Log "  $repo/$($e.name) : would add variable $($v.name)" }
    }
  }
}
Log "=== done ==="
