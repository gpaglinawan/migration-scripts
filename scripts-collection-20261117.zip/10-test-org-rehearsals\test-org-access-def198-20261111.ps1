# DEF-198 (approved by Gareth 2026-11-11: "grant", scope as proposed: write on the Kondor repos, not admin).
# Gives Octavian-Humita_tciem, Ioan-Acristei_tciem, Ion-Ciubotaru_tciem write (push) on every KON-* repo in tcm-pilot-test.
# All three are already members of tcm-pilot-test. Log: C:\kon-migration\rules\test-org-access-def198-20261111.log
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$logFile = 'C:\kon-migration\rules\test-org-access-def198-20261111.log'
function Write-Log($m) { $l = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $logFile $l -Encoding utf8 }
$users = 'Octavian-Humita_tciem', 'Ioan-Acristei_tciem', 'Ion-Ciubotaru_tciem'
$all = @(); $c = $null
do { $a = if ($c) { ', after:"' + $c + '"' } else { '' }
  $q = '{ organization(login:"tcm-pilot-test") { repositories(first:100' + $a + ') { pageInfo { hasNextPage endCursor } nodes { name } } } }'
  $p = (Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT" } -ContentType application/json -Body (@{ query = $q } | ConvertTo-Json)).data.organization.repositories
  $all += $p.nodes; $c = $p.pageInfo.endCursor } while ($p.pageInfo.hasNextPage)
$repos = @($all | Where-Object { $_.name -like 'KON-*' } | ForEach-Object name | Sort-Object)
Write-Log "=== DEF-198: write for $($users -join ', ') on $($repos.Count) KON-* repos in tcm-pilot-test ==="
$ok = 0; $fail = 0
foreach ($r in $repos) { foreach ($u in $users) {
  try { Invoke-RestMethod -Method PUT "https://api.github.com/repos/tcm-pilot-test/$r/collaborators/$u" -Headers $t -ContentType application/json -Body '{"permission":"push"}' | Out-Null
        $perm = (Invoke-RestMethod "https://api.github.com/repos/tcm-pilot-test/$r/collaborators/$u/permission" -Headers $t).role_name
        if ($perm -in 'write', 'maintain', 'admin') { $ok++ } else { $fail++; Write-Log "  $r $u : role now '$perm'" } }
  catch { $fail++; Write-Log "  $r $u : FAILED $($_.Exception.Message)" } } }
Write-Log "=== done: $ok of $($repos.Count * $users.Count) grants at write or above, $fail problems ==="
