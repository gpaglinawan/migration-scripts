﻿param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out    = "C:\kon-migration\teams"
)
# Read-only: compares all teams (incl. secret), members, team roles, team->repo permissions and org owner roles.
# Users are matched by login with the EMU suffix (_finastra / _tciem) removed, case-insensitive.
# Collected data is cached in $Out\collected.clixml; delete it to force a fresh read.
# NB: PowerShell variable names are case-insensitive - keep names distinct ($srcData vs $team etc.).
$ErrorActionPreference = "Stop"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$AuthByOrg = @{ $SrcOrg = @{Authorization="Bearer $env:GH_SRC_PAT";Accept="application/vnd.github+json"}
                $TgtOrg = @{Authorization="Bearer $env:GH_TGT_PAT";Accept="application/vnd.github+json"} }
New-Item -ItemType Directory -Force $Out | Out-Null

function Invoke-Retry($uri, $hdr) {
  for ($a = 1; ; $a++) {
    try { return Invoke-RestMethod -Uri $uri -Headers $hdr }
    catch { $code = $_.Exception.Response.StatusCode.value__
            if ($a -ge 5 -or $code -eq 404) { throw }
            Start-Sleep -Seconds (5 * $a) }
  }
}
function Get-All($url, $hdr) {
  $acc = New-Object System.Collections.ArrayList; $page = 1
  do { $r = Invoke-Retry "$url$(if($url -match '\?'){'&'}else{'?'})per_page=100&page=$page" $hdr
       foreach ($x in $r) { [void]$acc.Add($x) }; $page++ } while ($r.Count -eq 100)
  ,$acc
}
function Base($login) { ($login -replace '_(finastra|tciem)$','').ToLower() }

# ---- collect (or load cache) ----
$cache = Join-Path $Out "collected.clixml"
$data = @{}
if (Test-Path $cache) { $data = Import-Clixml $cache; "using cached data: $cache" }
foreach ($org in @($SrcOrg, $TgtOrg)) {
  if ($data.ContainsKey($org)) { continue }
  $hdr = $AuthByOrg[$org]
  $teams = Get-All "https://api.github.com/orgs/$org/teams" $hdr
  $mem = @{}    # "team|base" -> role
  $perm = @{}   # "team|repo" -> permission
  $unreadable = New-Object System.Collections.ArrayList
  foreach ($tm in $teams) {
    try {
      foreach ($role in 'maintainer','member') {
        foreach ($m in (Get-All "https://api.github.com/orgs/$org/teams/$($tm.slug)/members?role=$role" $hdr)) { $mem["$($tm.slug)|$(Base $m.login)"] = $role }
      }
      foreach ($rp in (Get-All "https://api.github.com/orgs/$org/teams/$($tm.slug)/repos" $hdr)) { $perm["$($tm.slug)|$($rp.name.ToLower())"] = $rp.role_name }
    } catch {
      $err = ("{0} {1}" -f $_.Exception.Response.StatusCode.value__, $_.ErrorDetails.Message) -replace '\s+', ' '
      [void]$unreadable.Add([pscustomobject]@{ Org = $org; Team = $tm.slug; Privacy = $tm.privacy; Error = $err })
    }
  }
  $unreadable | Export-Csv "$Out\unreadable-teams-$org.csv" -NoTypeInformation -Encoding utf8
  if ($unreadable.Count) { "  $org : $($unreadable.Count) team(s) could not be read - see unreadable-teams-$org.csv" }
  $owners = @{};  foreach ($m in (Get-All "https://api.github.com/orgs/$org/members?role=admin" $hdr)) { $owners[(Base $m.login)] = $m.login }
  $members = @{}; foreach ($m in (Get-All "https://api.github.com/orgs/$org/members" $hdr)) { $members[(Base $m.login)] = $m.login }
  $repos = @{};   foreach ($rp in (Get-All "https://api.github.com/orgs/$org/repos?type=all" $hdr)) { $repos[$rp.name.ToLower()] = $rp.name }
  $teamList = @($teams | ForEach-Object { [pscustomobject]@{ slug = $_.slug; name = $_.name; privacy = $_.privacy } })
  $data[$org] = @{ Teams = $teamList; Mem = $mem; Perm = $perm; Owners = $owners; Members = $members; Repos = $repos }
  "{0}: teams={1} (secret={2}) memberships={3} team-repo-grants={4} owners={5} members={6}" -f $org, $teamList.Count, @($teamList | Where-Object privacy -eq 'secret').Count, $mem.Count, $perm.Count, $owners.Count, $members.Count
  $data | Export-Clixml $cache -Depth 6
}
$srcData = $data[$SrcOrg]; $tgtData = $data[$TgtOrg]

# ---- teams ----
$tgtTeamIdx = @{}; foreach ($tm in $tgtData.Teams) { $tgtTeamIdx[$tm.slug] = $tm }
$teamRows = foreach ($tm in $srcData.Teams) {
  $x = $tgtTeamIdx[$tm.slug]
  [pscustomobject]@{ Team=$tm.slug; SrcPrivacy=$tm.privacy; TgtPrivacy=$x.privacy; InTarget=[bool]$x
    SrcMembers=@($srcData.Mem.Keys | Where-Object { $_ -like "$($tm.slug)|*" }).Count
    TgtMembers=@($tgtData.Mem.Keys | Where-Object { $_ -like "$($tm.slug)|*" }).Count }
}
$teamRows | Export-Csv "$Out\teams.csv" -NoTypeInformation -Encoding utf8

# ---- memberships ----
$privacy = @{}; foreach ($tm in $srcData.Teams) { $privacy[$tm.slug] = $tm.privacy }; foreach ($tm in $tgtData.Teams) { if (-not $privacy[$tm.slug]) { $privacy[$tm.slug] = $tm.privacy } }
$diff = New-Object System.Collections.ArrayList
foreach ($k in ($srcData.Mem.Keys + $tgtData.Mem.Keys | Sort-Object -Unique)) {
  $team, $user = $k.Split('|'); $sr = $srcData.Mem[$k]; $tr = $tgtData.Mem[$k]
  if ($sr -eq $tr) { continue }
  $status = if (-not $tr) { if ($tgtData.Members[$user]) { 'MISSING_IN_TARGET' } else { 'USER_NOT_IN_TARGET_ORG' } } elseif (-not $sr) { 'EXTRA_IN_TARGET' } else { 'ROLE_DIFFERS' }
  [void]$diff.Add([pscustomobject]@{ Status=$status; Team=$team; Privacy=$privacy[$team]; User=$user; SrcLogin=$srcData.Members[$user]; TgtLogin=$tgtData.Members[$user]; SrcRole=$sr; TgtRole=$tr })
}
$diff | Sort-Object Status, Team, User | Export-Csv "$Out\membership-diff.csv" -NoTypeInformation -Encoding utf8

# ---- team -> repo permissions (repos missing in target are a migration gap, not a permission gap) ----
$permDiff = New-Object System.Collections.ArrayList
foreach ($k in ($srcData.Perm.Keys + $tgtData.Perm.Keys | Sort-Object -Unique)) {
  $team, $repo = $k.Split('|'); $sp = $srcData.Perm[$k]; $tp = $tgtData.Perm[$k]
  if ($sp -eq $tp) { continue }
  $status = if (-not $tgtData.Repos[$repo]) { 'REPO_NOT_IN_TARGET' } elseif (-not $tp) { 'MISSING_IN_TARGET' } elseif (-not $sp) { 'EXTRA_IN_TARGET' } else { 'PERMISSION_DIFFERS' }
  [void]$permDiff.Add([pscustomobject]@{ Status=$status; Team=$team; Repo=$(if ($tgtData.Repos[$repo]) { $tgtData.Repos[$repo] } else { $srcData.Repos[$repo] }); SrcPermission=$sp; TgtPermission=$tp })
}
$permDiff | Sort-Object Status, Team, Repo | Export-Csv "$Out\team-repo-diff.csv" -NoTypeInformation -Encoding utf8

# ---- org owners ----
$ownerRows = foreach ($u in ($srcData.Owners.Keys + $tgtData.Owners.Keys | Sort-Object -Unique)) {
  [pscustomobject]@{ User=$u; OwnerInSource=[bool]$srcData.Owners[$u]; OwnerInTarget=[bool]$tgtData.Owners[$u]; InTargetOrg=[bool]$tgtData.Members[$u]; TgtLogin=$tgtData.Members[$u] }
}
$ownerRows | Export-Csv "$Out\owners.csv" -NoTypeInformation -Encoding utf8

"--- teams ---"
"source teams missing in target: $(@($teamRows | Where-Object { -not $_.InTarget }).Count)"
"privacy differs: $(@($teamRows | Where-Object { $_.InTarget -and $_.SrcPrivacy -ne $_.TgtPrivacy }).Count)"
"--- membership differences ---"
$diff | Group-Object Status | ForEach-Object { "{0,-24} {1}" -f $_.Name, $_.Count }
"by privacy (MISSING_IN_TARGET): " + (($diff | Where-Object Status -eq 'MISSING_IN_TARGET' | Group-Object Privacy | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' ')
"--- team -> repo permission differences ---"
$permDiff | Group-Object Status | ForEach-Object { "{0,-24} {1}" -f $_.Name, $_.Count }
"--- owners ---"
"owner in source but not target: $(@($ownerRows | Where-Object { $_.OwnerInSource -and -not $_.OwnerInTarget }).Count); owner in target but not source: $(@($ownerRows | Where-Object { $_.OwnerInTarget -and -not $_.OwnerInSource }).Count)"
