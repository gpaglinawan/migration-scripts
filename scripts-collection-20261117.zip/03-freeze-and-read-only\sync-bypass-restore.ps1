# Undo for sync-bypass-add.ps1 (run at cutover): puts every backed-up ruleset's bypass list back exactly as it was
# before, from C:\kon-migration\rules\bypass-backup\*.json. Run by the org owner.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$n = 0
foreach ($f in (Get-ChildItem C:\kon-migration\rules\bypass-backup -Filter *.json) + (Get-ChildItem C:\kon-migration\rules -Filter 'bypass-backup-MCH-mch-*.json')) {
  $b = Get-Content $f.FullName -Raw | ConvertFrom-Json
  $repo = if ($f.Name -like 'bypass-backup-*') { 'MCH-mch' } else { $f.BaseName -replace '-\d+$', '' }
  $orig = @($b.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } })
  Invoke-RestMethod -Method PUT "https://api.github.com/repos/tcm-pilot/$repo/rulesets/$($b.id)" -Headers $h -ContentType application/json -Body (@{ bypass_actors = $orig } | ConvertTo-Json -Depth 5) | Out-Null
  $n++; "{0,-42} ruleset {1}: restored" -f $repo, $b.id
}
"done: $n rulesets restored"
