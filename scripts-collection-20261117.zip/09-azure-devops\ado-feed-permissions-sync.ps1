# 12 Nov 2026 (Gareth: "grant feed permissions"). Mirrors feed permissions from TreasuryCapitalMarkets to tcm-staging.
# Identities are mapped by name: groups "[<org or project>]\<group>", project build service "<project> Build Service",
# users by their Teciem address (<local part>@teciem.com). Adds or raises a role only; never lowers or removes
# one. Identities that can't be mapped are listed, not guessed. Dry run unless -Apply.
# Usage: .\ado-feed-permissions-sync.ps1 [-Feeds databases,fusion-risk] [-Apply]
param([string[]]$Feeds, [switch]$Apply, [string]$Src = 'TreasuryCapitalMarkets', [string]$Tgt = 'tcm-staging',
      [string[]]$OutOfScopeProjects = @('TaskFactory', 'TreasuryKondor', 'Test - OE'),
      [string]$Out = "C:\kon-migration\feeds-tmp\feed-permissions-sync-$(Get-Date -Format yyyyMMdd-HHmm).csv")
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_SOURCE_PAT|AZDO_PAT|AZDO_PKG_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-AuthHeader($p) { @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$p")) } }
$hs = Get-AuthHeader $env:AZDO_SOURCE_PAT; $ht = Get-AuthHeader $env:AZDO_PAT
$rank = @{ none = 0; reader = 1; collaborator = 2; contributor = 3; administrator = 4 }
$cache = @{}
function Find-TargetIdentity($filter, $value) {
  $k = "$filter|$value"; if ($cache.ContainsKey($k)) { return $cache[$k] }
  $r = try { @((Invoke-RestMethod "https://vssps.dev.azure.com/$Tgt/_apis/identities?searchFilter=$filter&filterValue=$([uri]::EscapeDataString($value))&queryMembership=None&api-version=7.1" -Headers $ht).value) } catch { @() }
  $hit = @($r | Where-Object { $_.providerDisplayName -eq $value -or $_.properties.Mail.'$value' -eq $value -or $_.properties.Account.'$value' -eq $value }) | Select-Object -First 1
  $cache[$k] = $hit; $hit
}
# build service accounts: not findable by name search; map Build:<source project or collection id> -> target by name
$srcInstance = (Invoke-RestMethod "https://dev.azure.com/$Src/_apis/connectionData" -Headers $hs).instanceId
$srcProjects = @{}; (Invoke-RestMethod "https://dev.azure.com/$Src/_apis/projects?api-version=7.1&`$top=500" -Headers $hs).value | ForEach-Object { $srcProjects[$_.id] = $_.name }
$tgtSvc = @{}
foreach ($u in (Invoke-RestMethod "https://vssps.dev.azure.com/$Tgt/_apis/graph/users?subjectTypes=svc&api-version=7.1-preview.1" -Headers $ht).value | Where-Object displayName -like '* Build Service (*') {
  $idn = (Invoke-RestMethod "https://vssps.dev.azure.com/$Tgt/_apis/identities?subjectDescriptors=$($u.descriptor)&api-version=7.1" -Headers $ht).value[0]
  $tgtSvc[$u.displayName] = [pscustomobject]@{ descriptor = $idn.descriptor; providerDisplayName = $u.displayName }
}
function Get-Feeds($org, $hd) { (Invoke-RestMethod "https://feeds.dev.azure.com/$org/_apis/packaging/feeds?api-version=7.1" -Headers $hd).value }
$tFeeds = @{}; Get-Feeds $Tgt $ht | ForEach-Object { $tFeeds["$($_.project.name)|$($_.name)".ToLower()] = $_ }
$log = foreach ($sf in Get-Feeds $Src $hs) {
  if ($Feeds -and $sf.name -notin $Feeds) { continue }
  if ($sf.project -and $sf.project.name -in $OutOfScopeProjects) { continue }
  $proj = $sf.project.name
  $tf = $tFeeds["$proj|$($sf.name)".ToLower()]
  $sb = if ($sf.project) { "https://feeds.dev.azure.com/$Src/$($sf.project.id)" } else { "https://feeds.dev.azure.com/$Src" }
  if (-not $tf) { [pscustomobject]@{ Feed = "$proj/$($sf.name)"; Identity = ''; SourceRole = ''; TargetRole = ''; Result = 'SKIPPED: feed not in tcm-staging (yet)' }; continue }
  $tb = if ($tf.project) { "https://feeds.dev.azure.com/$Tgt/$($tf.project.id)" } else { "https://feeds.dev.azure.com/$Tgt" }
  $tp = @{}; (Invoke-RestMethod "$tb/_apis/packaging/feeds/$($tf.id)/permissions?api-version=7.1&includeIds=true" -Headers $ht).value | ForEach-Object { $tp[$_.identityDescriptor.ToLower()] = $_.role }
  $sp = (Invoke-RestMethod "$sb/_apis/packaging/feeds/$($sf.id)/permissions?api-version=7.1&includeIds=true" -Headers $hs).value
  $patch = @()
  foreach ($p in $sp) {
    $si = try { (Invoke-RestMethod "https://vssps.dev.azure.com/$Src/_apis/identities?descriptors=$([uri]::EscapeDataString($p.identityDescriptor))&api-version=7.1" -Headers $hs).value[0] } catch { $null }
    $name = "$($si.providerDisplayName)"; $ti = $null; $label = $name
    if ($p.identityDescriptor -like 'Microsoft.TeamFoundation.ServiceIdentity;*:Build:*') {
      $bid = $p.identityDescriptor.Split(':')[-1]
      $label = if ($bid -eq $srcInstance) { "Project Collection Build Service ($Tgt)" } elseif ($srcProjects[$bid]) { "$($srcProjects[$bid]) Build Service ($Tgt)" } else { "build service $bid" }
      $ti = $tgtSvc[$label]
    } elseif ($p.identityDescriptor -like 'Microsoft.TeamFoundation.Identity;*') {
      $label = $name -replace "^\[$Src\]", "[$Tgt]"; $ti = Find-TargetIdentity 'General' $label
    } elseif ($si.properties.Mail.'$value' -or $name) {
      $mail = "$($si.properties.Mail.'$value')"; if (-not $mail -and $p.identityDescriptor -match '\\([^\\]+@[^\\]+)$') { $mail = $Matches[1] }
      $label = ($mail -split '@')[0] + '@teciem.com'; $ti = Find-TargetIdentity 'MailAddress' $label
    }
    $row = [pscustomobject]@{ Feed = "$proj/$($sf.name)"; Identity = $label; SourceRole = $p.role; TargetRole = ''; Result = '' }
    if (-not $ti) { $row.Result = 'NOT MAPPED: no matching identity in tcm-staging'; $row; continue }
    $cur = $tp[$ti.descriptor.ToLower()]; $row.TargetRole = "$cur"
    if ($cur -and $rank[$cur] -ge $rank[$p.role]) { $row.Result = 'ok'; $row; continue }
    if ($p.role -eq 'none' -and -not $cur) { $row.Result = 'ok (none)'; $row; continue }
    $row.Result = if ($Apply) { 'GRANT' } else { 'would grant' }
    $patch += @{ role = $p.role; identityDescriptor = $ti.descriptor }; $row
  }
  if ($Apply -and $patch.Count) {
    $body = ConvertTo-Json -InputObject @($patch) -Depth 4
    try { $null = Invoke-RestMethod -Method Patch "$tb/_apis/packaging/feeds/$($tf.id)/permissions?api-version=7.1" -Headers (Get-AuthHeader $env:AZDO_PKG_PAT) -ContentType 'application/json' -Body $body }
    catch { [pscustomobject]@{ Feed = "$proj/$($sf.name)"; Identity = '(all above)'; SourceRole = ''; TargetRole = ''; Result = "FAILED: $($_.Exception.Message)" } }
  }
}
$log | Export-Csv $Out -NoTypeInformation -Encoding utf8
$log | Format-Table Feed, Identity, SourceRole, TargetRole, Result -AutoSize | Out-String -Width 220
"detail: $Out"
