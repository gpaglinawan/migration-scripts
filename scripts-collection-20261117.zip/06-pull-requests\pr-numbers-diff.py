# Which PR numbers fin-tcm has that a tcm-pilot copy lacks, and what they have in common (read-only).
import sys, os, json, urllib.request, collections
src_repo, tgt_repo = sys.argv[1], sys.argv[2]
Q = '''query($o:String!,$n:String!,$a:String){ repository(owner:$o,name:$n){ pullRequests(first:100,after:$a){ pageInfo{hasNextPage endCursor}
 nodes{ number state createdAt isCrossRepository headRepository{ nameWithOwner } author{ login } } } } }'''
def prs(token, repo):
    o, n = repo.split('/'); out, a = {}, None
    while True:
        req = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': Q, 'variables': {'o': o, 'n': n, 'a': a}}).encode(),
                                     headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'})
        d = json.load(urllib.request.urlopen(req, timeout=120))['data']['repository']['pullRequests']
        for p in d['nodes']: out[p['number']] = p
        if not d['pageInfo']['hasNextPage']: return out
        a = d['pageInfo']['endCursor']
s = prs(os.environ['GH_SRC_PAT'], src_repo); t = prs(os.environ['GH_TGT_PAT'], tgt_repo)
miss = [s[k] for k in sorted(set(s) - set(t))]
print(f'{src_repo}: {len(s)} PRs; {tgt_repo}: {len(t)}; missing {len(miss)}')
c = collections.Counter()
for p in miss:
    c['state ' + p['state']] += 1; c['cross-repo (fork)' if p['isCrossRepository'] else 'same repo'] += 1
    c['head repo gone' if not p['headRepository'] else 'head repo exists'] += 1; c['year ' + p['createdAt'][:4]] += 1
for k, v in sorted(c.items()): print(f'  {k}: {v}')
print('sample:', [(p['number'], p['state'], p['createdAt'][:10]) for p in miss[:8]])
