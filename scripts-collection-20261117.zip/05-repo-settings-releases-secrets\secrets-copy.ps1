param(
  [Parameter(Mandatory)][string[]]$Repos,
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Inventory = "C:\kon-migration\actions\repo-actions-source.json",
  [string]$Out = "C:\kon-migration\actions\secrets-copy",
  [string]$Branch = "migration-secrets-copy",
  [string]$TokenSecret = "TCMPILOT_MIGRATION_TOKEN",
  [int]$TimeoutMin = 20
)
# Copies repo Actions secret VALUES fin-tcm -> tcm-pilot with a one-time workflow (values can't be read via API).
# Per repo: an ORPHAN branch holding only .github/workflows/secrets-copy.yml is created through the Git Data API, so
# the repo's own workflows are not in that commit and cannot trigger. The workflow pipes each secret into
# `gh secret set` for the target repo (values never echoed). The target token is exposed to the batch as a
# selected-repos org secret for the duration of the run only, then deleted together with the branches.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "secrets-copy.log"; $resFile = Join-Path $Out "secrets-copy-results.csv"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Api($method, $uri, $hdr, $body) { if ($body) { Invoke-RestMethod -Method $method -Uri $uri -Headers $hdr -Body ($body | ConvertTo-Json -Depth 10 -Compress) -ContentType application/json } else { Invoke-RestMethod -Method $method -Uri $uri -Headers $hdr } }

if (-not (Test-Path $Inventory)) { Log "FATAL: inventory not found: $Inventory"; return }
$inv = Get-Content $Inventory -Raw | ConvertFrom-Json
$plan = foreach ($r in $Repos) {
  $names = @($inv.$r.Secrets | Where-Object { $_ -and $_ -ne $TokenSecret -and $_ -notlike 'GITHUB_*' })
  if ($names.Count) { [pscustomobject]@{ Repo = $r; Names = $names } } else { Log "skip $r - no repo secrets" }
}
$plan = @($plan | Where-Object { $_ -and $_.Names.Count -gt 0 })
if (-not $plan.Count) { Log "nothing to do - no repo in -Repos has secrets in the inventory"; return }
Log "=== secrets copy: $($plan.Count) repos, $(($plan | ForEach-Object { $_.Names.Count } | Measure-Object -Sum).Sum) secrets ==="

# 1. target token -> selected-repos org secret in the source org (gh does the sealed-box encryption)
$env:GH_TOKEN = $env:GH_SRC_PAT
# --body, not stdin: piping from PowerShell appends a newline that would become part of the token
gh secret set $TokenSecret --org $SrcOrg --visibility selected --repos (($plan.Repo) -join ',') --body $env:GH_TGT_PAT 2>&1 | ForEach-Object { Log "  gh: $_" }
if ($LASTEXITCODE -ne 0) { Log "FATAL: could not stage the token secret"; return }
$results = New-Object System.Collections.ArrayList
try {
  # 2. orphan branch with only the copy workflow, per repo
  foreach ($p in $plan) {
    $envLines = ($p.Names | ForEach-Object { "          S_$($_): `${{ secrets.$($_) }}" }) -join "`n"
    $yml = @"
name: secrets-copy (one-time migration)
on: push
permissions: {}
jobs:
  copy:
    runs-on: ubuntu-latest
    steps:
      - name: copy secrets to $TgtOrg/$($p.Repo)
        env:
          GH_TOKEN: `${{ secrets.$TokenSecret }}
$envLines
        run: |
          set -euo pipefail
          for n in $($p.Names -join ' '); do
            v="S_`$n"
            if [ -z "`${!v:-}" ]; then echo "empty or unreadable: `$n"; continue; fi
            printf '%s' "`${!v}" | gh secret set "`$n" --repo "$TgtOrg/$($p.Repo)"
            echo "copied: `$n"
          done
"@
    try {
      $blob = Api POST "https://api.github.com/repos/$SrcOrg/$($p.Repo)/git/blobs" $srcHdr @{ content = $yml; encoding = "utf-8" }
      $tree = Api POST "https://api.github.com/repos/$SrcOrg/$($p.Repo)/git/trees" $srcHdr @{ tree = @(@{ path = ".github/workflows/secrets-copy.yml"; mode = "100644"; type = "blob"; sha = $blob.sha }) }
      $commit = Api POST "https://api.github.com/repos/$SrcOrg/$($p.Repo)/git/commits" $srcHdr @{ message = "one-time secrets migration to $TgtOrg (temporary branch, deleted after run)"; tree = $tree.sha; parents = @() }
      Api POST "https://api.github.com/repos/$SrcOrg/$($p.Repo)/git/refs" $srcHdr @{ ref = "refs/heads/$Branch"; sha = $commit.sha } | Out-Null
      Log "  started $($p.Repo) ($($p.Names.Count) secrets)"
      $p | Add-Member -NotePropertyName Started -NotePropertyValue (Get-Date) -Force
    } catch { Log "  FAILED to start $($p.Repo): $($_.ErrorDetails.Message)"; [void]$results.Add([pscustomobject]@{ Repo = $p.Repo; Result = "FAILED start"; Copied = 0; Expected = $p.Names.Count }) }
  }

  # 3. wait for runs
  $deadline = (Get-Date).AddMinutes($TimeoutMin)
  $pending = @($plan | Where-Object { $_.Started })
  while ($pending.Count -and (Get-Date) -lt $deadline) {
    Start-Sleep 20
    foreach ($p in @($pending)) {
      $runs = Api GET "https://api.github.com/repos/$SrcOrg/$($p.Repo)/actions/runs?branch=$Branch&per_page=5" $srcHdr
      $run = @($runs.workflow_runs | Where-Object { $_ }) | Select-Object -First 1
      if ($run -and $run.status -eq 'completed') {
        $tgt = @((Api GET "https://api.github.com/repos/$TgtOrg/$($p.Repo)/actions/secrets?per_page=100" $tgtHdr).secrets | Where-Object { $_ })
        $fresh = @($tgt | Where-Object { $_.name -in $p.Names -and [datetime]$_.updated_at -ge $p.Started.ToUniversalTime().AddMinutes(-1) }).Count
        Log ("  {0,-40} run={1} copied {2}/{3}" -f $p.Repo, $run.conclusion, $fresh, $p.Names.Count)
        [void]$results.Add([pscustomobject]@{ Repo = $p.Repo; Result = $run.conclusion; Copied = $fresh; Expected = $p.Names.Count; RunUrl = $run.html_url })
        $pending = @($pending | Where-Object { $_.Repo -ne $p.Repo })
      }
    }
  }
  foreach ($p in $pending) { Log "  TIMEOUT $($p.Repo) - run not completed (no hosted runner available?)"; [void]$results.Add([pscustomobject]@{ Repo = $p.Repo; Result = "timeout"; Copied = 0; Expected = $p.Names.Count }) }
}
finally {
  # 4. cleanup: token secret first, then the temporary branches
  $env:GH_TOKEN = $env:GH_SRC_PAT
  gh secret delete $TokenSecret --org $SrcOrg 2>&1 | ForEach-Object { Log "  cleanup: $_" }
  foreach ($p in $plan) { try { Api DELETE "https://api.github.com/repos/$SrcOrg/$($p.Repo)/git/refs/heads/$Branch" $srcHdr | Out-Null } catch {} }
  Remove-Item Env:GH_TOKEN -ErrorAction SilentlyContinue
  Log "  cleanup done: token secret deleted, temporary branches removed"
  $results | Export-Csv $resFile -NoTypeInformation -Encoding utf8 -Append
}
Log ("=== done: " + (($results | Group-Object Result | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' ') + " ===")
