# 9 Nov 2026 (Gareth: "update the status that are ready for retest"): DEF-140 and DEF-143 -> Status "Ready for Retest",
# plus their 11/9 comments. Only these two rows; nothing else changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-143' = 'MAFQA-ffc-core-samples: DanielGabriel-Cotoi_tciem is admin in tcm-pilot (same as DanielGabriel-Cotoi_finastra in fin-tcm). Ready for retest by Leon.'
  'DEF-140' = 'Team FFC in tcm-pilot now has the name "FFC" (in capitals, as in fin-tcm) and the same description as in fin-tcm. The team picture cannot be set through GitHub''s API, so a team maintainer needs to upload it again in the team settings. Ready for retest by Leon.'
}
$newStatus = 'Ready for Retest'
$sheetId = 3761521504348036
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$ssAuth = @{ Authorization = "Bearer $tok" }
$sheet = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sheetId" -Headers $ssAuth
$idCol = ($sheet.columns | Where-Object title -eq 'Defect ID').id; $stCol = ($sheet.columns | Where-Object title -eq 'Status')
$allowed = @($stCol.options); if ($allowed.Count -and $allowed -notcontains $newStatus) { throw "Status '$newStatus' not in the column's options: $($allowed -join ', ')" }
$rows = foreach ($defect in $comments.Keys) {
  $row = $sheet.rows | Where-Object { ($_.cells | Where-Object columnId -eq $idCol).displayValue -eq $defect }
  if (-not $row) { Write-Warning "$defect not found"; continue }
  $old = ($row.cells | Where-Object columnId -eq $stCol.id).displayValue
  "--- $defect status: '$old' -> '$newStatus'" | Out-Host
  @{ id = $row.id; cells = @(@{ columnId = $stCol.id; value = $newStatus }) }
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
if ($DryRun -or -not $rows) { return }
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sheetId/rows" -Headers $ssAuth -ContentType 'application/json; charset=utf-8' `
       -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @($rows) -Depth 6)))
"status rows updated: $(@($res.result).Count) (resultCode $($res.resultCode))"
