param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$SvcMap = "C:\kon-migration\service-accounts\svc-account-map.csv",
  [string]$Out = "C:\kon-migration\teams",
  [switch]$Apply
)
# Restores the team hierarchy (parent/child) of the source org in the target org, then removes the direct parent-team
# memberships that only exist because inherited members were copied as direct members when the teams were set up.
# A direct membership is removed only when, in the source, the person is NOT a direct member of that team but IS a
# direct member of one of its child teams, and in the target they are a direct member of that same child team - so
# their access is unchanged (they inherit it through the child). Nobody else is touched. Writes a plan CSV.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$ht = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
function P($u, $h) { $acc = @(); $p = 1; do { $r = @(Invoke-RestMethod "https://api.github.com/$u$(if($u -match '\?'){'&'}else{'?'})per_page=100&page=$p" -Headers $h) | ForEach-Object { $_ }; $acc += $r; $p++ } while ($r.Count -eq 100); $acc }
function Direct($org, $slug, $h) {   # immediate (non-inherited) members, lower-cased logins
  $q = 'query($o:String!,$s:String!,$c:String){ organization(login:$o){ team(slug:$s){ members(first:100, membership:IMMEDIATE, after:$c){ pageInfo{hasNextPage endCursor} nodes{ login } } } } }'
  $set = @{}; $c = $null
  do { $b = @{ query = $q; variables = @{ o = $org; s = $slug; c = $c } } | ConvertTo-Json -Depth 4
       $m = (Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers @{ Authorization = $h.Authorization } -Body $b -ContentType application/json).data.organization.team.members
       if (-not $m) { break }; $m.nodes | ForEach-Object { $set[$_.login.ToLower()] = $_.login }; $c = $m.pageInfo.endCursor } while ($m.pageInfo.hasNextPage)
  $set }
# source login -> target login: same name with the _tciem suffix, or the service-account map
$svc = @{}; if (Test-Path $SvcMap) { Import-Csv $SvcMap | Where-Object Target | ForEach-Object { $svc[$_.Source.ToLower()] = $_.Target.ToLower() } }
function ToTgt($l) { if ($svc[$l]) { $svc[$l] } else { ($l -replace '_finastra$', '') + '_tciem' } }

$st = P "orgs/$SrcOrg/teams" $hs; $tt = P "orgs/$TgtOrg/teams" $ht
$tByS = @{}; $tt | ForEach-Object { $tByS[$_.slug] = $_ }
$children = @{}; $st | Where-Object parent | ForEach-Object { $children[$_.parent.slug] += @($_.slug) }
function Desc($slug) { foreach ($c in $children[$slug]) { $c; Desc $c } }
$plan = New-Object System.Collections.Generic.List[object]
"source teams: $($st.Count) ($(@($st | Where-Object parent).Count) with a parent); target teams: $($tt.Count)"

# 1. nesting
foreach ($s in ($st | Where-Object parent)) {
  $t = $tByS[$s.slug]; $tp = $tByS[$s.parent.slug]
  if (-not $t -or -not $tp) { $plan.Add([pscustomobject]@{ Step = 'nest'; Team = $s.slug; Detail = "parent $($s.parent.slug)"; Result = 'skipped: team missing in target' }); continue }
  if ($t.parent.slug -eq $s.parent.slug) { continue }
  $plan.Add([pscustomobject]@{ Step = 'nest'; Team = $s.slug; Detail = "parent $($s.parent.slug) (target now: $(if ($t.parent) { $t.parent.slug } else { 'none' }); privacy $($t.privacy)/$($tp.privacy))"; Result = '' })
}
# 2. flattened direct memberships on parent teams
$i = 0
foreach ($ps in $children.Keys) {
  $i++; if ($i % 25 -eq 0) { "   parents checked: $i/$($children.Keys.Count)" }
  if (-not $tByS[$ps]) { continue }
  $srcDirect = Direct $SrcOrg $ps $hs; $tgtDirect = Direct $TgtOrg $ps $ht
  $srcDirectT = @{}; $srcDirect.Keys | ForEach-Object { $srcDirectT[(ToTgt $_)] = $true }
  $desc = @(Desc $ps | Where-Object { $tByS[$_] })
  $srcChild = @{}; $tgtChild = @{}
  foreach ($d in $desc) { (Direct $SrcOrg $d $hs).Keys | ForEach-Object { $srcChild[(ToTgt $_)] += @($d) }; (Direct $TgtOrg $d $ht).Keys | ForEach-Object { $tgtChild[$_] += @($d) } }
  foreach ($u in $tgtDirect.Keys) {
    if ($srcDirectT[$u]) { continue }                      # direct in source too: keep
    if (-not $srcChild[$u]) { continue }                   # not from a child team in source: added on purpose, keep
    $keep = @($srcChild[$u] | Where-Object { $tgtChild[$u] -contains $_ })
    if (-not $keep) { $plan.Add([pscustomobject]@{ Step = 'unflatten'; Team = $ps; Detail = "$($tgtDirect[$u]) (child $($srcChild[$u] -join ',') not set in target)"; Result = 'skipped: would lose access' }); continue }
    $plan.Add([pscustomobject]@{ Step = 'unflatten'; Team = $ps; Detail = $tgtDirect[$u]; Result = ''; Via = ($keep -join ',') })
  }
}

if ($Apply) {
  foreach ($r in ($plan | Where-Object { $_.Step -eq 'nest' -and -not $_.Result })) {
    try { $pid_ = $tByS[($r.Detail -split ' ')[1]].id
          Invoke-RestMethod -Method PATCH "https://api.github.com/orgs/$TgtOrg/teams/$($r.Team)" -Headers $ht -ContentType application/json -Body (@{ parent_team_id = $pid_ } | ConvertTo-Json) | Out-Null; $r.Result = 'done' }
    catch { $r.Result = "FAILED $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" } }
  $nestFailed = @{}; $plan | Where-Object { $_.Step -eq 'nest' -and $_.Result -like 'FAILED*' } | ForEach-Object { $nestFailed[$_.Team] = $true }
  foreach ($r in ($plan | Where-Object { $_.Step -eq 'unflatten' -and -not $_.Result })) {
    if (@($r.Via -split ',' | Where-Object { $nestFailed[$_] }).Count) { $r.Result = 'skipped: child nesting failed'; continue }
    try { Invoke-RestMethod -Method DELETE "https://api.github.com/orgs/$TgtOrg/teams/$($r.Team)/memberships/$($r.Detail)" -Headers $ht | Out-Null; $r.Result = 'done' }
    catch { $r.Result = "FAILED $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" } }
}
$f = Join-Path $Out ("team-nesting-" + $(if ($Apply) { 'applied' } else { 'plan' }) + "-" + (Get-Date -Format yyyyMMdd-HHmm) + ".csv")
$plan | Export-Csv $f -NoTypeInformation
$plan | Group-Object Step, { ($_.Result -split ':')[0] } | Select-Object Count, Name | Format-Table -AutoSize
"people affected: $(@($plan | Where-Object Step -eq 'unflatten' | Select-Object -ExpandProperty Detail -Unique).Count)"
"file: $f"
