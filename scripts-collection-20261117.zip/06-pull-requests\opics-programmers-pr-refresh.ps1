# Refresh of tcm-pilot/OPICS-programmers-pr (approved by Gareth 2026-11-10: "refresh OPICS-programmers"). pr-copy-check found
# 1 new commit on master in fin-tcm since the copy was made (8 Nov). Steps:
#   1. delete tcm-pilot/OPICS-programmers-pr (access saved in pr-preload\OPICS-programmers-pr-access-before-refresh.json)
#   2. move the old work folder to pr-preload\OPICS-programmers-20261108 (kept: logs, state, commit-map)
#   3. exclude ONLY OPICS-programmers-pr from the read-only org rulesets, run pr-preload.ps1 (export, LFS rewrite, remap,
#      import, LFS, verify, cleanup), put the rulesets back (finally block)
#   4. give back the team access it had (jellyfish-fin-tcm, security-manager: pull)
# Log: C:\kon-migration\pr-preload\OPICS-programmers\refresh.log (+ the preload's own run.log)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ghAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$target = 'OPICS-programmers-pr'; $work = 'C:\kon-migration\pr-preload\OPICS-programmers'; $old = 'C:\kon-migration\pr-preload\OPICS-programmers-20261108'
$backupFile = 'C:\kon-migration\pr-preload\OPICS-programmers-pr-access-before-refresh.json'
$logFile = 'C:\kon-migration\pr-preload\OPICS-programmers-refresh.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
if (-not (Test-Path $backupFile)) { Write-Log 'STOP: access backup missing'; exit 1 }
$backup = Get-Content $backupFile -Raw | ConvertFrom-Json
Write-Log "=== refresh tcm-pilot/$target ==="

# 1. delete
$exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$target" -Headers $ghAuth; $true } catch { $false }
if ($exists) {
  try { Invoke-RestMethod -Method DELETE "https://api.github.com/repos/tcm-pilot/$target" -Headers $ghAuth | Out-Null; Write-Log "  deleted tcm-pilot/$target (repo id $($backup.id))" }
  catch { Write-Log "STOP: could not delete tcm-pilot/$target - $($_.Exception.Message)"; exit 1 }
} else { Write-Log "  tcm-pilot/$target not there (already deleted)" }
# 2. keep the old work folder
if ((Test-Path $work) -and -not (Test-Path $old)) { Move-Item $work $old; Write-Log "  old work folder kept as $old" }

# 3. import with only this repo excluded from the read-only rulesets
$rulesets = @(Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets?per_page=100" -Headers $ghAuth | ForEach-Object { $_ } | Where-Object { $_.name -like 'Migration read-only until cutover*' })
$saved = @{}
function Set-Exclude($rs, $list) {
  $full = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
  $cond = @{ ref_name = @{ include = @($full.conditions.ref_name.include); exclude = @($full.conditions.ref_name.exclude | Where-Object { $_ }) }
             repository_name = @{ include = @($full.conditions.repository_name.include); exclude = @($list); protected = [bool]$full.conditions.repository_name.protected } }
  Invoke-RestMethod -Method PUT "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth -ContentType application/json -Body (@{ conditions = $cond } | ConvertTo-Json -Depth 6) | Out-Null
  @((Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth).conditions.repository_name.exclude)
}
$preloadOk = $false
try {
  foreach ($rs in $rulesets) {
    $full = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
    $saved[$rs.id] = @($full.conditions.repository_name.exclude | Where-Object { $_ })
    $now = Set-Exclude $rs (@($saved[$rs.id] + $target | Select-Object -Unique))
    Write-Log "  read-only ruleset $($rs.id): $target excluded for the import (excluded now: $($now -join ','))"
  }
  & powershell -NoProfile -ExecutionPolicy Bypass -File C:\kon-migration\scripts\pr-preload\pr-preload.ps1 -Repo OPICS-programmers -TargetName $target
  $preloadOk = $LASTEXITCODE -eq 0
  Write-Log "  pr-preload finished: exit $LASTEXITCODE"
}
finally {
  foreach ($rs in $rulesets) {
    try { $now = Set-Exclude $rs $saved[$rs.id]
          Write-Log ("  read-only ruleset {0} restored: excluded [{1}] {2}" -f $rs.id, ($now -join ','), $(if ($now -contains $target) { '!! STILL EXCLUDED - CHECK' } else { '(ok)' })) }
    catch { Write-Log "  !! could not restore ruleset $($rs.id): $($_.Exception.Message) - run readonly-ruleset.ps1 -Org tcm-pilot -Apply" }
  }
}
# 4. team access back
$exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$target" -Headers $ghAuth; $true } catch { $false }
if ($exists) {
  foreach ($t in $backup.teams) {
    try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/tcm-pilot/teams/$($t.slug)/repos/tcm-pilot/$target" -Headers $ghAuth -ContentType application/json -Body (@{ permission = $t.permission } | ConvertTo-Json) | Out-Null; Write-Log "  team $($t.slug) = $($t.permission)" }
    catch { Write-Log "  !! team $($t.slug): $($_.Exception.Message)" }
  }
}
$st = if (Test-Path "$work\state.json") { Get-Content "$work\state.json" -Raw | ConvertFrom-Json } else { $null }
Write-Log ("=== done: preload {0}; PRs {1}/{2} (identical {3})" -f $(if ($preloadOk) { 'OK' } else { 'NOT OK - see run.log' }), $st.prTarget, $st.prSource, $st.prIdentical)
