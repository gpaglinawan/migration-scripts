param(
  [double]$Target   = 98,
  [int]$MaxRounds   = 3,
  [int]$StopHourCET = 23,     # don't start new work after this hour, so the 00:00 nightly run has the machine
  [string[]]$SkipResync = @() # rewritten repos being resynced separately
)
# Repeats snapshot -> compare -> delta sync (bypass-aware) -> LFS resync of rewritten repos until the share of migrated
# repos in sync reaches $Target %. No force-push anywhere: rebased branches stay as they are. Log: <root>\run.log
$ErrorActionPreference = "Continue"
$here = Split-Path $MyInvocation.MyCommand.Path
$root = "C:\kon-migration\sync-to-target\" + (Get-Date -Format yyyyMMdd-HHmm); New-Item -ItemType Directory -Force $root | Out-Null
$log = "$root\run.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Late { (Get-Date).Hour -ge $StopHourCET }
$rewritten = 'SFX-netcore-common', 'KON-doc-kondor-archive', 'FWK-utfinstaller', 'OPICS-programmers', 'MAFTP-fpp-fusioncapital',
             'FCGC-pricing-analytics', 'RISK-cmr', 'FCBO-fusion-detect-core', 'KON-kplus-front'   # roughly smallest first
# ARC-almonde was never rewritten (already LFS in Finastra) - it needs the normal delta sync, not this
function Snapshot($dir) {
  $a = Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$here\refs-dump.ps1`" -Org fin-tcm -PatVar GH_SRC_PAT -Out `"$dir`"" -PassThru -WindowStyle Hidden
  $b = Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$here\refs-dump.ps1`" -Org tcm-pilot -PatVar GH_TGT_PAT -Out `"$dir`"" -PassThru -WindowStyle Hidden
  $a.WaitForExit(); $b.WaitForExit()
  & powershell -NoProfile -ExecutionPolicy Bypass -File "$here\refs-compare.ps1" -Refs $dir | ForEach-Object { Log "  $_" }
  $s = Import-Csv "$dir\compare-summary.csv"; $m = @($s | Where-Object Status -ne 'NOT_IN_TARGET')
  $ok = @($m | Where-Object { $_.Status -in 'IN_SYNC', 'IN_SYNC_REWRITTEN' }).Count
  $pct = [math]::Round(100 * $ok / $m.Count, 2); Log "  IN SYNC: $pct% ($ok of $($m.Count))"; $pct
}

while (Test-Path "C:\kon-migration\nightly\running.lock") { Start-Sleep 60 }
Log "=== sync to $Target% - nightly run finished ==="
$resynced = @{}
for ($round = 1; $round -le $MaxRounds; $round++) {
  $dir = "$root\round$round"
  Log "--- round ${round}: snapshot"
  $pct = Snapshot "$dir\before" | Select-Object -Last 1
  if ($pct -ge $Target) { Log "target reached: $pct%"; break }
  if (Late) { Log "stopping: too close to the nightly run"; break }
  Log "--- round ${round}: delta sync"
  & "$here\delta-sync.ps1" -Summary "$dir\before\compare-summary.csv" -Work "$dir\sync" -Exclude $rewritten -Apply | Out-Null
  Get-Content "$dir\sync\sync.log" | Select-Object -Last 1 | ForEach-Object { Log "  $_" }
  $sum = Import-Csv "$dir\before\compare-summary.csv"
  foreach ($r in $rewritten) {
    if (Late) { Log "  stopping resyncs: too close to the nightly run"; break }
    $row = $sum | Where-Object Repo -eq $r
    if (-not $row -or $row.Status -in 'IN_SYNC', 'IN_SYNC_REWRITTEN' -or $resynced[$r] -or $r -in $SkipResync) { continue }
    Log "  resync $r (trunk $($row.SrcDefault))"
    & powershell -NoProfile -ExecutionPolicy Bypass -File "$here\rewrite-resync.ps1" -Name $r -Trunk $row.SrcDefault | Select-Object -Last 3 | ForEach-Object { Log "    $_" }
    $resynced[$r] = $true
    # keep logs, drop the bulky mirrors
    Get-ChildItem C:\kon-migration\resync -Directory -Filter "$r-*" | Sort-Object Name | Select-Object -Last 1 | ForEach-Object { Get-ChildItem $_.FullName -Directory -Filter *.git | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue }
  }
  & "$here\enforce-admins-restore.ps1" | Where-Object { $_ -notmatch ': ok$' } | ForEach-Object { Log "  protection check: $_" }
}
if ($round -gt $MaxRounds) { Log "--- final snapshot"; $pct = Snapshot "$root\final" | Select-Object -Last 1 }
Log "=== end: $pct% in sync ==="
