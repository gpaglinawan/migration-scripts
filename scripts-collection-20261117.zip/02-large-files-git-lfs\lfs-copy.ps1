param(
  [string]$SrcOrg  = "fin-tcm",
  [string]$TgtOrg  = "tcm-pilot",
  [string]$Results = "C:\kon-migration\gei\results.csv",
  [string[]]$Extra = @("IMP-Aspirations-AWS-Scaffolding"),
  [string]$Work    = "C:\kon-migration\lfs"
)
# Copies Git LFS objects for repos GEI migrated (GEI does not carry LFS). Adds objects only; creates no commits.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"([^"]*)"') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function B64($p) { [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$p")) }

# auth via env config (not persisted, not on the command line); switched per phase, since both orgs share github.com
$srcAuth = "AUTHORIZATION: basic $(B64 $env:GH_SRC_PAT)"
$tgtAuth = "AUTHORIZATION: basic $(B64 $env:GH_TGT_PAT)"
$env:GIT_CONFIG_COUNT   = "2"
$env:GIT_CONFIG_KEY_0   = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = $srcAuth
$env:GIT_CONFIG_KEY_1   = "lfs.allowincompletepush"
$env:GIT_CONFIG_VALUE_1 = "true"
$env:GIT_TERMINAL_PROMPT = "0"

New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work "lfs-copy.log"
$outCsv = Join-Path $Work "lfs-results.csv"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

$repos = @(Import-Csv $Results | Where-Object State -eq 'SUCCEEDED' | ForEach-Object Name) + $Extra | Where-Object { $_ } | Sort-Object -Unique
$prev = @{}; if (Test-Path $outCsv) { Import-Csv $outCsv | Where-Object Status -in 'no-lfs','copied' | ForEach-Object { $prev[$_.Name] = $_ } }
$rows = New-Object System.Collections.ArrayList
$prev.Values | ForEach-Object { [void]$rows.Add($_) }
Log "=== LFS copy: $($repos.Count) repos ($($prev.Count) already done) ==="

foreach ($r in $repos) {
  if ($prev[$r]) { continue }
  $dir = Join-Path $Work "$r.git"
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  git init --bare -q --ref-format=reftable $dir
  git -C $dir config remote.origin.url "https://github.com/$SrcOrg/$r.git"
  git -C $dir config remote.origin.fetch "+refs/heads/*:refs/heads/*"
  git -C $dir config --add remote.origin.fetch "+refs/tags/*:refs/tags/*"
  git -C $dir fetch -q origin 2>$null
  if ($LASTEXITCODE -ne 0) { Log "FETCH FAILED $r"; [void]$rows.Add([pscustomobject]@{Name=$r;Status='fetch-failed';Objects=0;Missing=0;MB=0}); continue }
  $oids = @(git -C $dir lfs ls-files --all --long 2>$null | ForEach-Object { if ($_ -match '^([0-9a-f]{64})\s') { $Matches[1] } } | Sort-Object -Unique)
  if ($oids.Count -eq 0) {
    [void]$rows.Add([pscustomobject]@{Name=$r;Status='no-lfs';Objects=0;Missing=0;MB=0})
  } else {
    git -C $dir config lfs.url "https://github.com/$SrcOrg/$r.git/info/lfs"
    git -C $dir lfs fetch --all origin *>&1 | Out-Null
    $lfsDir = Join-Path $dir "lfs\objects"
    $missing = @($oids | Where-Object { -not (Test-Path (Join-Path $lfsDir "$($_.Substring(0,2))\$($_.Substring(2,2))\$_")) })
    $mb = [math]::Round(((Get-ChildItem $lfsDir -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum)/1MB, 1)
    if ($missing.Count -lt $oids.Count) {
      $env:GIT_CONFIG_VALUE_0 = $tgtAuth
      git -C $dir -c "lfs.url=https://github.com/$TgtOrg/$r.git/info/lfs" lfs push --all "https://github.com/$TgtOrg/$r.git" *>&1 | Out-Null   # lfs.url above points at the source
      $rc = $LASTEXITCODE
      $env:GIT_CONFIG_VALUE_0 = $srcAuth
    } else { $rc = 0 }
    # 'source-missing' = every LFS object is absent on the source server (nothing exists to copy)
    $st = if ($missing.Count -eq $oids.Count) { 'source-missing' } elseif ($rc -ne 0) { 'push-failed' } elseif ($missing.Count) { 'copied-partial' } else { 'copied' }
    Log ("{0,-12} {1}  objects={2} missing-on-source={3} {4} MB" -f $st, $r, $oids.Count, $missing.Count, $mb)
    if ($missing.Count) { $missing | Out-File (Join-Path $Work "$r-missing.txt") -Encoding utf8 }
    [void]$rows.Add([pscustomobject]@{Name=$r;Status=$st;Objects=$oids.Count;Missing=$missing.Count;MB=$mb})
  }
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  $rows | Export-Csv $outCsv -NoTypeInformation -Encoding utf8
}
$rows | Export-Csv $outCsv -NoTypeInformation -Encoding utf8
Log ("=== done: " + (($rows | Group-Object Status | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' ') + " ===")
