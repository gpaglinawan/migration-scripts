param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out = "C:\kon-migration\teams\direct-collab"
)
# Read-only: compares DIRECT repository collaborators (people added to a repo, not through a team) in every repo.
# GEI doesn't migrate these. Users matched by login without the _finastra / _tciem suffix, case-insensitive.
# Output: diff.csv (one row per repo/user that differs), repos.csv (per-repo counts). Resumable via collected-*.csv.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
New-Item -ItemType Directory -Force $Out | Out-Null
function Base($login) { ($login -replace '_(finastra|tciem)$', '').ToLower() }
function Collabs($org, $hdr, $repo) {
  $acc = @(); $page = 1
  do {
    $ok = $false; $n = 0
    for ($try = 1; $try -le 5 -and -not $ok; $try++) {
      try { $resp = Invoke-RestMethod "https://api.github.com/repos/$org/$repo/collaborators?affiliation=direct&per_page=100&page=$page" -Headers $hdr; $ok = $true }
      catch { $code = $_.Exception.Response.StatusCode.value__; if ($code -eq 404) { return $null }; Start-Sleep $(if ($code -in 403, 429) { 90 } else { 10 * $try }) }
    }
    if (-not $ok) { return $null }
    foreach ($x in $resp) { if ($x) { $acc += [pscustomobject]@{ Login = $x.login; Role = $x.role_name }; $n++ } }; $page++
  } while ($n -eq 100)
  , $acc
}

# repo list from the source org
# NB: never wrap Invoke-RestMethod in @(): PS 5.1 then yields ONE element holding the whole page. Count with foreach.
$repos = @(); $page = 1
do { $n = 0; foreach ($x in (Invoke-RestMethod "https://api.github.com/orgs/$SrcOrg/repos?per_page=100&page=$page&type=all" -Headers $srcHdr)) { $repos += $x.name; $n++ }; $page++ } while ($n -eq 100)
# Teciem members, to tell "no account yet" from "account exists but access missing"
$tgtMembers = @{}; $page = 1
do { $n = 0; foreach ($m in (Invoke-RestMethod "https://api.github.com/orgs/$TgtOrg/members?per_page=100&page=$page" -Headers $tgtHdr)) { $tgtMembers[(Base $m.login)] = $m.login; $n++ }; $page++ } while ($n -eq 100)
Write-Host "repos: $($repos.Count); Teciem members: $($tgtMembers.Count)"

$cache = Join-Path $Out "collected.csv"
$done = @{}; if (Test-Path $cache) { foreach ($c in (Import-Csv $cache)) { $done[$c.Repo] = $true } }
$i = 0
foreach ($repo in $repos) {
  $i++; if ($done[$repo]) { continue }
  $s = Collabs $SrcOrg $srcHdr $repo; $t = Collabs $TgtOrg $tgtHdr $repo
  $rows = @()
  if ($null -eq $t) { $rows += [pscustomobject]@{ Repo = $repo; Org = 'tgt'; Login = ''; Role = 'REPO_NOT_IN_TARGET' } }
  foreach ($x in @($s)) { if ($x) { $rows += [pscustomobject]@{ Repo = $repo; Org = 'src'; Login = $x.Login; Role = $x.Role } } }
  foreach ($x in @($t)) { if ($x) { $rows += [pscustomobject]@{ Repo = $repo; Org = 'tgt'; Login = $x.Login; Role = $x.Role } } }
  if (-not $rows.Count) { $rows += [pscustomobject]@{ Repo = $repo; Org = 'none'; Login = ''; Role = '' } }
  $rows | Export-Csv $cache -Append -NoTypeInformation -Encoding utf8
  if ($i % 100 -eq 0) { Write-Host ("[{0:HH:mm:ss}] {1}/{2}" -f (Get-Date), $i, $repos.Count) }
}

# diff
$rank = @{ read = 1; triage = 2; write = 3; maintain = 4; admin = 5 }
$all = Import-Csv $cache
$diff = New-Object System.Collections.ArrayList; $perRepo = New-Object System.Collections.ArrayList
foreach ($g in ($all | Group-Object Repo)) {
  $src = @{}; $tgt = @{}; $missingRepo = $false
  foreach ($x in $g.Group) {
    if ($x.Role -eq 'REPO_NOT_IN_TARGET') { $missingRepo = $true; continue }
    if (-not $x.Login) { continue }
    if ($x.Org -eq 'src') { $src[(Base $x.Login)] = $x } elseif ($x.Org -eq 'tgt') { $tgt[(Base $x.Login)] = $x }
  }
  if ($missingRepo) { continue }
  $miss = 0; $lower = 0; $noAcct = 0
  foreach ($k in $src.Keys) {
    $sr = $src[$k].Role; $tr = if ($tgt[$k]) { $tgt[$k].Role } else { '' }
    if ($tr -eq $sr) { continue }
    $hasAcct = [bool]$tgtMembers[$k]
    $status = if (-not $tr) { if ($hasAcct) { 'MISSING' } else { 'NO_TECIEM_ACCOUNT' } } elseif ($rank[$tr] -lt $rank[$sr]) { 'LOWER_ROLE' } else { 'DIFFERENT_ROLE' }
    if ($status -eq 'MISSING') { $miss++ } elseif ($status -eq 'NO_TECIEM_ACCOUNT') { $noAcct++ } else { $lower++ }
    [void]$diff.Add([pscustomobject]@{ Repo = $g.Name; User = $k; FinastraLogin = $src[$k].Login; TeciemLogin = $tgtMembers[$k]; FinastraRole = $sr; TeciemRole = $tr; Status = $status })
  }
  foreach ($k in $tgt.Keys) { if (-not $src[$k]) { [void]$diff.Add([pscustomobject]@{ Repo = $g.Name; User = $k; FinastraLogin = ''; TeciemLogin = $tgt[$k].Login; FinastraRole = ''; TeciemRole = $tgt[$k].Role; Status = 'EXTRA_IN_TECIEM' }) } }
  [void]$perRepo.Add([pscustomobject]@{ Repo = $g.Name; FinastraDirect = $src.Count; TeciemDirect = $tgt.Count; Missing = $miss; NoTeciemAccount = $noAcct; RoleDiffers = $lower })
}
$diff | Sort-Object Status, Repo, User | Export-Csv (Join-Path $Out "diff.csv") -NoTypeInformation -Encoding utf8
$perRepo | Export-Csv (Join-Path $Out "repos.csv") -NoTypeInformation -Encoding utf8
Write-Host "=== done ==="
$diff | Group-Object Status | ForEach-Object { "{0,-20} {1,6} rows, {2,5} repos, {3,5} people" -f $_.Name, $_.Count, @($_.Group.Repo | Sort-Object -Unique).Count, @($_.Group.User | Sort-Object -Unique).Count }
