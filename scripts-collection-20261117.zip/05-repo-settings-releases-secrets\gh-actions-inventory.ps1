param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out    = "C:\kon-migration\actions"
)
# Read-only. Inventories, in both orgs: org secrets + variables (and which repos they're shared with), per-repo
# Actions secrets / variables / environments (+ env secrets/variables), Dependabot secrets, self-hosted runners
# and runner groups, and org members. Secret VALUES are never readable through the API - names only.
# Variable values ARE readable and are saved for the copy step.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$Hdr = @{ $SrcOrg = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
          $TgtOrg = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" } }
New-Item -ItemType Directory -Force $Out | Out-Null
function Rest($org, $uri) {
  for ($a = 1; ; $a++) {
    try { return Invoke-RestMethod $uri -Headers $Hdr[$org] }
    catch { $code = $_.Exception.Response.StatusCode.value__
            if ($code -in 403, 429 -and $a -lt 6) { Start-Sleep (30 * $a); continue }   # secondary rate limit
            return $null }
  }
}
function Paged($org, $uri, $prop) {
  $acc = @(); $page = 1
  do { $r = Rest $org "$uri$(if($uri -match '\?'){'&'}else{'?'})per_page=100&page=$page"; $items = @($(if ($prop) { $r.$prop } else { $r }) | Where-Object { $_ }); $acc += $items; $page++ } while ($items.Count -eq 100)
  , $acc
}

$summary = @{}
foreach ($org in $SrcOrg, $TgtOrg) {
  $o = @{}
  $o.OrgSecrets   = Paged $org "https://api.github.com/orgs/$org/actions/secrets" "secrets"
  $o.OrgVariables = Paged $org "https://api.github.com/orgs/$org/actions/variables" "variables"
  $o.DependabotSecrets = Paged $org "https://api.github.com/orgs/$org/dependabot/secrets" "secrets"
  foreach ($s in $o.OrgSecrets + $o.OrgVariables) {
    if ($s.visibility -eq 'selected') {
      $kind = if ($s.PSObject.Properties.Name -contains 'value') { 'variables' } else { 'secrets' }
      $s | Add-Member -NotePropertyName selected_repos -NotePropertyValue ((Paged $org "https://api.github.com/orgs/$org/actions/$kind/$($s.name)/repositories" "repositories") | ForEach-Object { $_.name }) -Force
    }
  }
  $o.Runners      = Paged $org "https://api.github.com/orgs/$org/actions/runners" "runners"
  $o.RunnerGroups = Paged $org "https://api.github.com/orgs/$org/actions/runner-groups" "runner_groups"
  $o.Members      = Paged $org "https://api.github.com/orgs/$org/members" ""
  "{0}: org secrets={1} org variables={2} dependabot secrets={3} runners={4} runner groups={5}" -f $org, $o.OrgSecrets.Count, $o.OrgVariables.Count, $o.DependabotSecrets.Count, $o.Runners.Count, $o.RunnerGroups.Count
  $o | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $Out "org-$org.json") -Encoding utf8
  $summary[$org] = $o
}

# per repo (source repos, and the same name in target)
$repos = (Import-Csv "C:\kon-migration\refs\$SrcOrg-repos.csv").Name
$tgtRepos = @{}; (Import-Csv "C:\kon-migration\refs\$TgtOrg-repos.csv").Name | ForEach-Object { $tgtRepos[$_.ToLower()] = $_ }
$rows = New-Object System.Collections.ArrayList; $detail = @{}; $i = 0
foreach ($r in $repos) {
  $i++; if ($i % 250 -eq 0) { "  ...$i/$($repos.Count)" }
  $s = @{ Secrets = (Paged $SrcOrg "https://api.github.com/repos/$SrcOrg/$r/actions/secrets" "secrets").name
          Variables = Paged $SrcOrg "https://api.github.com/repos/$SrcOrg/$r/actions/variables" "variables"
          Environments = (Paged $SrcOrg "https://api.github.com/repos/$SrcOrg/$r/environments" "environments") }
  if (-not ($s.Secrets.Count + $s.Variables.Count + $s.Environments.Count)) { continue }
  $envDetail = foreach ($e in $s.Environments) {
    $en = [uri]::EscapeDataString($e.name)
    @{ name = $e.name; protection_rules = $e.protection_rules; deployment_branch_policy = $e.deployment_branch_policy
       secrets = (Paged $SrcOrg "https://api.github.com/repos/$SrcOrg/$r/environments/$en/secrets" "secrets").name
       variables = Paged $SrcOrg "https://api.github.com/repos/$SrcOrg/$r/environments/$en/variables" "variables" }
  }
  $s.Environments = @($envDetail)
  $tn = $tgtRepos[$r.ToLower()]; $t = $null
  if ($tn) { $t = @{ Secrets = (Paged $TgtOrg "https://api.github.com/repos/$TgtOrg/$tn/actions/secrets" "secrets").name
                     Variables = (Paged $TgtOrg "https://api.github.com/repos/$TgtOrg/$tn/actions/variables" "variables").name
                     Environments = (Paged $TgtOrg "https://api.github.com/repos/$TgtOrg/$tn/environments" "environments").name } }
  $detail[$r] = $s
  [void]$rows.Add([pscustomobject]@{ Repo = $r; InTarget = [bool]$tn
    SrcSecrets = $s.Secrets.Count; TgtSecrets = $(if ($t) { @($t.Secrets).Count })
    SrcVariables = $s.Variables.Count; TgtVariables = $(if ($t) { @($t.Variables).Count })
    SrcEnvironments = $s.Environments.Count; TgtEnvironments = $(if ($t) { @($t.Environments).Count })
    SrcEnvSecrets = ($s.Environments | ForEach-Object { @($_.secrets).Count } | Measure-Object -Sum).Sum
    MissingSecretNames = $(if ($t) { (@($s.Secrets) | Where-Object { $_ -notin @($t.Secrets) }) -join ';' }) })
}
$rows | Export-Csv (Join-Path $Out "repo-actions-compare.csv") -NoTypeInformation -Encoding utf8
$detail | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $Out "repo-actions-source.json") -Encoding utf8
"repos with secrets/variables/environments in source: $($rows.Count)"
"  repo secrets: source=$(($rows | Measure-Object SrcSecrets -Sum).Sum) target=$(($rows | Measure-Object TgtSecrets -Sum).Sum)"
"  repo variables: source=$(($rows | Measure-Object SrcVariables -Sum).Sum) target=$(($rows | Measure-Object TgtVariables -Sum).Sum)"
"  environments: source=$(($rows | Measure-Object SrcEnvironments -Sum).Sum) target=$(($rows | Measure-Object TgtEnvironments -Sum).Sum)  env secrets(source)=$(($rows | Measure-Object SrcEnvSecrets -Sum).Sum)"
