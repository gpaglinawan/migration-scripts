param(
  [string]$Orig = "C:\kon-migration\kon-kplus-front.git",
  [string]$Copy = "C:\kon-migration\kon-kplus-front-lfs.git",
  [string]$Out  = "C:\kon-migration\kon-bigfiles"
)
# Moves blobs >100MB into LFS on a copy of the clone. The original clone is never modified.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
$log = Join-Path $Out "rewrite.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

Log "=== copy $Orig -> $Copy ==="
if (Test-Path $Copy) { Log "FATAL: $Copy already exists - remove it first"; exit 1 }
robocopy $Orig $Copy /E /NFL /NDL /NJH /NJS /NP /MT:8 | Out-Null
if ($LASTEXITCODE -ge 8) { Log "FATAL: copy failed (robocopy $LASTEXITCODE)"; exit 1 }
# record ref list before rewrite (names only; SHAs will change)
git -C $Copy for-each-ref --format="%(refname)" | Sort-Object | Out-File (Join-Path $Out "refs-before.txt") -Encoding utf8
Log ("refs before: {0}" -f (Get-Content (Join-Path $Out "refs-before.txt")).Count)

Log "git lfs migrate import --everything --above=100mb ..."
$t = Get-Date
git -C $Copy lfs migrate import --everything --above=100mb --yes *>&1 | ForEach-Object { "$_" } | Where-Object { $_ -notmatch '^\s*(migrate: (Sorting|Rewriting) commits|  \S+\s+\S+ -> \S+$)' } | Add-Content $log -Encoding utf8
$rc = $LASTEXITCODE
Log ("migrate exit={0} in {1:N0} min" -f $rc, ((Get-Date)-$t).TotalMinutes)
if ($rc -ne 0) { Log "FATAL: migrate failed"; exit 1 }

git -C $Copy for-each-ref --format="%(refname)" | Sort-Object | Out-File (Join-Path $Out "refs-after.txt") -Encoding utf8
Log ("refs after: {0}" -f (Get-Content (Join-Path $Out "refs-after.txt")).Count)
$lfsFiles = @(Get-ChildItem (Join-Path $Copy "lfs\objects") -Recurse -File -ErrorAction SilentlyContinue)
Log ("LFS objects now in copy: {0} ({1:N2} GB)" -f $lfsFiles.Count, (($lfsFiles | Measure-Object Length -Sum).Sum/1GB))
Log "=== done ==="
