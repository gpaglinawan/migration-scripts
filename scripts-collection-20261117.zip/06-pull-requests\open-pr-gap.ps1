# Read-only. Counts the OPEN pull requests in fin-tcm that tcm-pilot does not have, because they were opened after the repo
# was imported into tcm-pilot (the nightly sync copies branches and tags, not PRs). These are what the proposed cutover step
# "recreate open PRs" would recreate. For each one: is its head branch and base branch in tcm-pilot (needed to recreate it)?
# Skips: archived repos, repos not in tcm-pilot, KON-kplus-front and the 9 repos with -pr copies (their PRs are handled by
# the preload), and TAAS-tms (re-imported as TAAS-tms-pr).
# Output: C:\kon-migration\open-pr-gap\<date>\open-pr-gap.csv (one row per PR) + summary.md
param([string]$Refs = (Get-ChildItem C:\kon-migration\nightly -Directory | Where-Object Name -match '^\d{4}-\d\d-\d\d$' | Sort-Object Name | Select-Object -Last 1).FullName + '\after',
      [string]$Out = "C:\kon-migration\open-pr-gap\$(Get-Date -Format yyyy-MM-dd)", [int]$Batch = 10)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Out | Out-Null
$logFile = "$Out\run.log"; function Write-Log($msg) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
function Invoke-Gql($tok, $query) {
  for ($try = 1; ; $try++) {
    try { $resp = Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body (@{ query = $query } | ConvertTo-Json) -ContentType 'application/json'
          if ($resp.errors -and -not $resp.data) { throw ($resp.errors | ConvertTo-Json -Compress) }; return $resp.data }
    catch { if ($try -ge 5) { Write-Log "  GraphQL failed: $($_.Exception.Message)"; return $null }; Start-Sleep (15 * $try) }
  }
}
function Get-RefSet($file) { $set = @{}; if (Test-Path $file) { foreach ($line in [IO.File]::ReadAllLines($file)) { $parts = $line -split "`t"; if ($parts.Count -eq 2) { $set[$parts[1]] = $true } } }; $set }

$skip = 'KON-kplus-front', 'SFX-netcore-common', 'FCBO-fusion-detect-core', 'MAFTP-fpp-fusioncapital', 'MAFTP-fpp-vaas-che', 'OPICS-programmers',
        'FWK-utfinstaller', 'TO-treasury-installer', 'RISK-cmr', 'FCGC-pricing-analytics', 'TAAS-tms'
$srcRepos = Import-Csv "$Refs\fin-tcm-repos.csv"; $tgtIdx = @{}; Import-Csv "$Refs\tcm-pilot-repos.csv" | ForEach-Object { $tgtIdx[$_.Name.ToLower()] = $_ }
$todo = @($srcRepos | Where-Object { $_.Archived -ne 'True' -and $tgtIdx[$_.Name.ToLower()] -and $_.Name -notin $skip } | ForEach-Object { $_.Name })
Write-Log "=== open PR gap: $($todo.Count) repos (refs from $Refs)"

$rows = New-Object System.Collections.ArrayList
for ($i = 0; $i -lt $todo.Count; $i += $Batch) {
  $chunk = @($todo[$i..([Math]::Min($i + $Batch, $todo.Count) - 1)])
  # tcm-pilot: when was each repo imported
  $qt = '{ ' + (($chunk | ForEach-Object -Begin { $n = 0 } -Process { "r$n" + ': repository(owner:"tcm-pilot", name:"' + $_ + '") { createdAt }'; $n++ }) -join ' ') + ' }'
  $tgtData = Invoke-Gql $env:GH_TGT_PAT $qt
  # fin-tcm: open PRs (newest first; repos with more than 100 open PRs are paged below)
  $qs = '{ ' + (($chunk | ForEach-Object -Begin { $n = 0 } -Process { "r$n" + ': repository(owner:"fin-tcm", name:"' + $_ + '") { pullRequests(states:OPEN, first:100, orderBy:{field:CREATED_AT, direction:DESC}) { totalCount pageInfo { hasNextPage endCursor } nodes { number createdAt isDraft headRefName baseRefName title author { login } } } }'; $n++ }) -join ' ') + ' }'
  $srcData = Invoke-Gql $env:GH_SRC_PAT $qs
  for ($k = 0; $k -lt $chunk.Count; $k++) {
    $repo = $chunk[$k]; $imported = $tgtData."r$k".createdAt; $prConn = $srcData."r$k".pullRequests
    if (-not $imported -or -not $prConn) { Write-Log "  $repo : no data"; continue }
    $importedAt = ([datetime]$imported).ToUniversalTime()
    $nodes = @($prConn.nodes)
    $cursor = $prConn.pageInfo.endCursor; $more = $prConn.pageInfo.hasNextPage
    while ($more -and ([datetime]$nodes[-1].createdAt).ToUniversalTime() -gt $importedAt) {
      $page = (Invoke-Gql $env:GH_SRC_PAT ('{ repository(owner:"fin-tcm", name:"' + $repo + '") { pullRequests(states:OPEN, first:100, after:"' + $cursor + '", orderBy:{field:CREATED_AT, direction:DESC}) { pageInfo { hasNextPage endCursor } nodes { number createdAt isDraft headRefName baseRefName title author { login } } } } }')).repository.pullRequests
      $nodes += @($page.nodes); $cursor = $page.pageInfo.endCursor; $more = $page.pageInfo.hasNextPage
    }
    $newOpen = @($nodes | Where-Object { ([datetime]$_.createdAt).ToUniversalTime() -gt $importedAt })
    if (-not $newOpen.Count) { continue }
    $tgtRefs = Get-RefSet "$Refs\tcm-pilot\$($tgtIdx[$repo.ToLower()].Name).txt"
    foreach ($pr in $newOpen) {
      [void]$rows.Add([pscustomobject]@{ Repo = $repo; Number = $pr.number; Created = $pr.createdAt; Draft = $pr.isDraft; Author = $pr.author.login
        Head = $pr.headRefName; Base = $pr.baseRefName; HeadInTcmPilot = [bool]$tgtRefs["refs/heads/$($pr.headRefName)"]; BaseInTcmPilot = [bool]$tgtRefs["refs/heads/$($pr.baseRefName)"]
        ImportedToTcmPilot = $imported; Title = $pr.title })
    }
  }
  if (($i / $Batch) % 20 -eq 0) { Write-Log "  $([Math]::Min($i + $Batch, $todo.Count))/$($todo.Count) repos, $($rows.Count) open PRs so far" }
}
$rows | Export-Csv "$Out\open-pr-gap.csv" -NoTypeInformation -Encoding utf8
$byRepo = $rows | Group-Object Repo | Sort-Object Count -Descending
$ready = @($rows | Where-Object { $_.HeadInTcmPilot -and $_.BaseInTcmPilot })
$md = @("# Open PRs in fin-tcm missing from tcm-pilot - $(Get-Date -Format 'yyyy-MM-dd HH:mm') CET", '',
        "Opened in fin-tcm after the repo was imported into tcm-pilot, still open. Repos checked: $($todo.Count) (archived, KON-kplus-front, the 9 -pr repos and TAAS-tms excluded).", '',
        "- **Open PRs to recreate: $($rows.Count)** in $(@($byRepo).Count) repos ($(@($rows | Where-Object Draft -eq $true).Count) drafts)",
        "- Head and base branch both in tcm-pilot (can be recreated as is): $($ready.Count)",
        "- Head branch missing in tcm-pilot: $(@($rows | Where-Object { -not $_.HeadInTcmPilot }).Count) (usually a fork or a branch deleted after the nightly snapshot)",
        "- Base branch missing in tcm-pilot: $(@($rows | Where-Object { -not $_.BaseInTcmPilot }).Count)", '',
        '| Repo | Open PRs | Head missing |', '|---|---|---|')
$md += $byRepo | Select-Object -First 40 | ForEach-Object { "| $($_.Name) | $($_.Count) | $(@($_.Group | Where-Object { -not $_.HeadInTcmPilot }).Count) |" }
if (@($byRepo).Count -gt 40) { $md += "| ... $(@($byRepo).Count - 40) more repos | $(($byRepo | Select-Object -Skip 40 | Measure-Object Count -Sum).Sum) | |" }
$md += '', "Detail: $Out\open-pr-gap.csv"
$md | Set-Content "$Out\summary.md" -Encoding utf8
Write-Log "=== done: $($rows.Count) open PRs in $(@($byRepo).Count) repos; $($ready.Count) recreatable as is"
