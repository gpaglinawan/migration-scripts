# 14 Nov 2026 (Gareth: "copy direct collaborators"). Gives every fin-tcm direct collaborator who has a Teciem account the
# same repository permission on the same-named tcm-pilot repo. Only adds or raises; never lowers or removes. People with
# no Teciem account are listed, not guessed. Input: the tracksheet access CSVs (C:\kon-migration\tracksheet).
# Dry run unless -Apply. Results: C:\kon-migration\teams\direct-collab-copy-<stamp>.csv
param([switch]$Apply, [string[]]$ExcludeLevels = @())   # 14 Nov: Gareth "apply without admin" -> -ExcludeLevels ADMIN (admin grants listed for owners)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$map = @{}; Import-Csv C:\kon-migration\rules\member-names-20261111.csv | Where-Object Tgt | ForEach-Object { $map[$_.Src.ToLower()] = $_.Tgt }
$rank = @{ READ = 1; TRIAGE = 2; WRITE = 3; MAINTAIN = 4; ADMIN = 5 }; $api = @{ READ = 'pull'; TRIAGE = 'triage'; WRITE = 'push'; MAINTAIN = 'maintain'; ADMIN = 'admin' }
function Split-Logins($s) { $h = @{}; foreach ($x in ("$s" -split ';')) { if ($x -match '^(.+):([A-Z]+)$') { $h[$Matches[1].ToLower()] = $Matches[2] } }; $h }
$src = Import-Csv C:\kon-migration\tracksheet\access-fin-tcm.csv; $tgt = @{}; Import-Csv C:\kon-migration\tracksheet\access-tcm-pilot.csv | ForEach-Object { $tgt[$_.Repo] = $_ }
$tgtNames = @{}; Get-Content C:\kon-migration\tracksheet\tcm-pilot-names.txt | ForEach-Object { $tgtNames[$_] = 1 }
$plan = foreach ($r in $src) {
  if (-not $tgtNames[$r.Repo]) { continue }
  $s = Split-Logins $r.CollaboratorLogins; $t = Split-Logins $tgt[$r.Repo].CollaboratorLogins
  foreach ($login in $s.Keys) {
    if ($login -eq 'ghost') { continue }
    $to = $map[$login]
    if (-not $to) { [pscustomobject]@{ Repo = $r.Repo; Finastra = $login; Teciem = ''; Permission = $s[$login]; Current = ''; Action = 'SKIP: no Teciem account' }; continue }
    $cur = $t[$to.ToLower()]
    if ($cur -and $rank[$cur] -ge $rank[$s[$login]]) { continue }
    if ($s[$login] -in $ExcludeLevels) { [pscustomobject]@{ Repo = $r.Repo; Finastra = $login; Teciem = $to; Permission = $s[$login]; Current = "$cur"; Action = "HELD: $($s[$login]) - for owners to confirm" }; continue }
    [pscustomobject]@{ Repo = $r.Repo; Finastra = $login; Teciem = $to; Permission = $s[$login]; Current = "$cur"; Action = $(if ($Apply) { 'ADD' } else { 'would add' }) }
  }
}
$todo = @($plan | Where-Object { $_.Action -in 'ADD', 'would add' })
if ($Apply) {
  $n = 0
  foreach ($p in $todo) {
    for ($try = 1; $try -le 5; $try++) {
      try { $null = Invoke-RestMethod -Method Put "https://api.github.com/repos/tcm-pilot/$($p.Repo)/collaborators/$($p.Teciem)" -Headers $gh -ContentType application/json -Body (@{ permission = $api[$p.Permission] } | ConvertTo-Json); $p.Action = 'ADDED'; break }
      catch { $code = $_.Exception.Response.StatusCode.value__; $msg = "$($_.ErrorDetails.Message)"; if ($msg -match 'archived') { $p.Action = 'SKIP: repo archived (read-only)'; break } elseif ($code -in 403, 429) { Start-Sleep (60 * $try) } else { $p.Action = "FAILED: $code $msg"; break } }
    }
    $n++; if ($n % 100 -eq 0) { "  $n / $($todo.Count)" }; Start-Sleep -Milliseconds 700
  }
}
$f = "C:\kon-migration\teams\direct-collab-copy-$(Get-Date -Format yyyyMMdd-HHmm).csv"; New-Item -ItemType Directory -Force (Split-Path $f) | Out-Null; $plan | Export-Csv $f -NoTypeInformation -Encoding utf8
"grants: $($todo.Count) on $(@($todo.Repo | Sort-Object -Unique).Count) repos for $(@($todo.Teciem | Sort-Object -Unique).Count) people; by level: " + (($todo | Group-Object Permission | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ', ')
"raising existing access: $(@($todo | Where-Object Current).Count); skipped (no Teciem account): $(@($plan | Where-Object Action -like 'SKIP*').Count) entries, $(@(($plan | Where-Object Action -like 'SKIP*').Finastra | Sort-Object -Unique).Count) people"
if ($Apply) { "results: " + (($todo | Group-Object { ($_.Action -split ':')[0] } | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ', ') }
"detail: $f"
