# Read-only. Compares GitHub releases fin-tcm vs tcm-pilot for every live repo (DEF-186). The nightly sync copies tags, not
# releases, so releases created after the import are missing; GEI also mangled some release notes (lost "}" etc.).
# Per release: MISSING (in fin-tcm, not in tcm-pilot), NOTES_DIFFER (same tag, notes differ), TAG_MISSING (tag absent in
# tcm-pilot - comes with the next sync). Output: C:\kon-migration\release-gap\<date>\releases.csv + summary.md
param([string]$Refs = 'C:\kon-migration\nightly\2026-11-10\before', [string]$Out = "C:\kon-migration\release-gap\$(Get-Date -Format yyyy-MM-dd)", [int]$Batch = 10)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Out | Out-Null
$logFile = "$Out\run.log"; function Write-Log($msg) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
function Invoke-Gql($tok, $query) {
  for ($try = 1; ; $try++) {
    try { $resp = Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body (@{ query = $query } | ConvertTo-Json) -ContentType 'application/json'
          if ($resp.errors -and -not $resp.data) { throw ($resp.errors | ConvertTo-Json -Compress) }; return $resp.data }
    catch { if ($try -ge 5) { Write-Log "  GraphQL failed: $($_.Exception.Message)"; return $null }; Start-Sleep (15 * $try) }
  }
}
function Get-AllReleases($tok, $owner, $repo, $first) {
  $list = @($first.nodes); $cursor = $first.pageInfo.endCursor; $more = $first.pageInfo.hasNextPage
  while ($more) { $p = (Invoke-Gql $tok ('{ repository(owner:"' + $owner + '", name:"' + $repo + '") { releases(first:100, after:"' + $cursor + '") { pageInfo { hasNextPage endCursor } nodes { tagName name description isDraft isPrerelease createdAt tag { name } } } } }')).repository.releases
    if (-not $p) { break }; $list += @($p.nodes); $cursor = $p.pageInfo.endCursor; $more = $p.pageInfo.hasNextPage }
  $list }
$norm = { param($s) ("$s" -replace "`r", '').TrimEnd() }
$srcRepos = Import-Csv "$Refs\fin-tcm-repos.csv"; $tgtIdx = @{}; Import-Csv "$Refs\tcm-pilot-repos.csv" | ForEach-Object { $tgtIdx[$_.Name.ToLower()] = $_ }
$todo = @($srcRepos | Where-Object { $_.Archived -ne 'True' -and $tgtIdx[$_.Name.ToLower()] } | ForEach-Object { $_.Name })
Write-Log "=== release gap: $($todo.Count) repos"
$relFields = 'pageInfo { hasNextPage endCursor } nodes { tagName name description isDraft isPrerelease createdAt tag { name } }'
$rows = New-Object System.Collections.ArrayList
for ($i = 0; $i -lt $todo.Count; $i += $Batch) {
  $chunk = @($todo[$i..([Math]::Min($i + $Batch, $todo.Count) - 1)])
  $q = { param($owner) '{ ' + (($chunk | ForEach-Object -Begin { $n = 0 } -Process { "r$n" + ': repository(owner:"' + $owner + '", name:"' + $_ + '") { releases(first:100) { totalCount ' + $relFields + ' } }'; $n++ }) -join ' ') + ' }' }
  $srcData = Invoke-Gql $env:GH_SRC_PAT (& $q 'fin-tcm'); $tgtData = Invoke-Gql $env:GH_TGT_PAT (& $q 'tcm-pilot')
  for ($k = 0; $k -lt $chunk.Count; $k++) {
    $repo = $chunk[$k]; $s = $srcData."r$k".releases; $t = $tgtData."r$k".releases
    if (-not $s -or -not $t) { Write-Log "  $repo : no data"; continue }
    if ($s.totalCount -eq 0) { continue }
    $srcRel = Get-AllReleases $env:GH_SRC_PAT 'fin-tcm' $repo $s; $tgtRel = Get-AllReleases $env:GH_TGT_PAT 'tcm-pilot' $repo $t
    $tIdx = @{}; foreach ($r in $tgtRel) { $tIdx["$($r.tagName)"] = $r }
    foreach ($r in $srcRel) {
      $tr = $tIdx["$($r.tagName)"]
      $state = if (-not $tr) { 'MISSING' } elseif ((& $norm $r.description) -ne (& $norm $tr.description) -or "$($r.name)" -ne "$($tr.name)") { 'NOTES_DIFFER' } else { continue }
      [void]$rows.Add([pscustomobject]@{ Repo = $repo; Tag = $r.tagName; Name = $r.name; State = $state; Draft = $r.isDraft; Prerelease = $r.isPrerelease; Created = $r.createdAt
        SrcLen = "$($r.description)".Length; TgtLen = $(if ($tr) { "$($tr.description)".Length } else { '' }) })
    }
  }
  if (($i / $Batch) % 25 -eq 0) { Write-Log "  $([Math]::Min($i + $Batch, $todo.Count))/$($todo.Count) repos, $($rows.Count) findings" }
}
$rows | Export-Csv "$Out\releases.csv" -NoTypeInformation -Encoding utf8
$miss = @($rows | Where-Object State -eq 'MISSING'); $diff = @($rows | Where-Object State -eq 'NOTES_DIFFER')
$md = @("# Releases fin-tcm vs tcm-pilot - $(Get-Date -Format 'yyyy-MM-dd HH:mm') CET", '', "Repos checked: $($todo.Count) (live, in both orgs).", '',
  "- **Releases missing in tcm-pilot: $($miss.Count)** in $(@($miss | Group-Object Repo).Count) repos",
  "- **Releases whose name/notes differ: $($diff.Count)** in $(@($diff | Group-Object Repo).Count) repos", '',
  '| Repo | Missing | Notes differ |', '|---|---|---|')
$md += $rows | Group-Object Repo | Sort-Object Count -Descending | Select-Object -First 40 | ForEach-Object { "| $($_.Name) | $(@($_.Group | Where-Object State -eq 'MISSING').Count) | $(@($_.Group | Where-Object State -eq 'NOTES_DIFFER').Count) |" }
$md += '', "Detail: $Out\releases.csv"
$md | Set-Content "$Out\summary.md" -Encoding utf8
Write-Log "=== done: $($miss.Count) missing, $($diff.Count) notes differ"
