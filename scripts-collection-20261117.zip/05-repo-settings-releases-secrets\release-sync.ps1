# DEF-186: copies GitHub releases fin-tcm -> tcm-pilot (the nightly sync copies tags, not releases; GEI also damaged some notes).
# Input: release-gap.ps1 output. Per finding:
#   MISSING      -> create the release on the existing tag (same name, notes, draft/prerelease flags) and copy its asset files
#   NOTES_DIFFER -> re-copy name and notes from fin-tcm
# Skips repos replaced at cutover by a -pr copy / re-import (their copies already hold the releases), and any release whose tag
# is not in tcm-pilot yet (comes with the next sync - re-run after it). Dry run by default; -Apply to write.
# Also usable at cutover (after the final sync) for releases created up to the freeze. Log: C:\kon-migration\rules\release-sync.log
param([string]$Gap = (Join-Path (Get-ChildItem C:\kon-migration\release-gap -Directory | Sort-Object Name | Select-Object -Last 1).FullName 'releases.csv'),
      [switch]$Apply, [string[]]$Repos)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcAuth = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }
$tgtAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$logFile = 'C:\kon-migration\rules\release-sync.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}{2}" -f (Get-Date), $(if ($Apply) { '' } else { 'DRY ' }), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
$replaced = 'KON-kplus-front', 'RISK-cmr', 'FCGC-pricing-analytics', 'TO-treasury-installer', 'MAFTP-fpp-fusioncapital', 'MAFTP-fpp-vaas-che',
            'FCBO-fusion-detect-core', 'SFX-netcore-common', 'OPICS-programmers', 'FWK-utfinstaller', 'TAAS-tms'
$work = @(Import-Csv $Gap | Where-Object { $_.Repo -notin $replaced -and (-not $Repos -or $_.Repo -in $Repos) })
Write-Log "=== release sync: $($work.Count) findings from $Gap"
$tmp = Join-Path $env:TEMP 'release-sync'; New-Item -ItemType Directory -Force $tmp | Out-Null
$done = 0; $skipped = 0; $failed = 0
foreach ($f in $work) {
  $tagEsc = [uri]::EscapeDataString($f.Tag)
  try {
    # source release (drafts are not reachable by tag: look them up in the list)
    $src = try { Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$($f.Repo)/releases/tags/$tagEsc" -Headers $srcAuth } catch {
      Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$($f.Repo)/releases?per_page=100" -Headers $srcAuth | ForEach-Object { $_ } | Where-Object tag_name -eq $f.Tag | Select-Object -First 1 }
    if (-not $src) { Write-Log "  $($f.Repo) $($f.Tag): source release not found - skipped"; $skipped++; continue }
    $tagThere = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$($f.Repo)/git/ref/tags/$tagEsc" -Headers $tgtAuth; $true } catch { $false }
    if (-not $tagThere) { Write-Log "  $($f.Repo) $($f.Tag): tag not in tcm-pilot yet - skipped (next sync brings it)"; $skipped++; continue }
    $tgt = try { Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$($f.Repo)/releases/tags/$tagEsc" -Headers $tgtAuth } catch { $null }
    if ($tgt -and $f.State -eq 'MISSING') { Write-Log "  $($f.Repo) $($f.Tag): already present - nothing to do"; continue }
    $assets = @($src.assets)
    if ($f.State -eq 'MISSING') {
      Write-Log ("  $($f.Repo) $($f.Tag): CREATE release '{0}' draft={1} prerelease={2}, {3} asset(s) {4:N1} MB" -f $src.name, $src.draft, $src.prerelease, $assets.Count, (($assets | Measure-Object size -Sum).Sum / 1MB))
      if (-not $Apply) { continue }
      $body = @{ tag_name = $src.tag_name; name = $src.name; body = "$($src.body)"; draft = [bool]$src.draft; prerelease = [bool]$src.prerelease } | ConvertTo-Json
      $new = Invoke-RestMethod -Method POST "https://api.github.com/repos/tcm-pilot/$($f.Repo)/releases" -Headers $tgtAuth -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
      foreach ($a in $assets) {
        $file = Join-Path $tmp $a.name
        Invoke-WebRequest $a.url -Headers @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/octet-stream' } -OutFile $file -UseBasicParsing
        $up = ($new.upload_url -replace '\{.*\}$', '') + '?name=' + [uri]::EscapeDataString($a.name) + $(if ($a.label) { '&label=' + [uri]::EscapeDataString($a.label) } else { '' })
        Invoke-RestMethod -Method POST $up -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' } -ContentType $(if ($a.content_type) { $a.content_type } else { 'application/octet-stream' }) -InFile $file | Out-Null
        Remove-Item $file -Force
      }
      Write-Log "    created release id $($new.id) with $($assets.Count) asset(s)"; $done++
    } else {
      Write-Log ("  $($f.Repo) $($f.Tag): FIX notes (source {0} chars, tcm-pilot {1} chars)" -f "$($src.body)".Length, "$($tgt.body)".Length)
      if (-not $Apply) { continue }
      $body = @{ name = $src.name; body = "$($src.body)" } | ConvertTo-Json
      Invoke-RestMethod -Method PATCH "https://api.github.com/repos/tcm-pilot/$($f.Repo)/releases/$($tgt.id)" -Headers $tgtAuth -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)) | Out-Null
      Write-Log "    notes re-copied"; $done++
    }
  } catch { Write-Log "  !! $($f.Repo) $($f.Tag): $($_.Exception.Message)"; $failed++ }
}
Write-Log "=== done: $done changed, $skipped skipped, $failed failed$(if (-not $Apply) { ' (dry run - nothing changed)' })"
