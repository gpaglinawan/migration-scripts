# Gives the DevOps Infra team access to the Jenkins repositories in tcm-pilot-test (Huy-Chu Kuoy's request, 26 Oct 2026).
# Creates team "devops-infra-test" once, adds the members of buil-tcm-devops-infra (= mailing list TCM-DevOps-Infra)
# and grants the team admin on every repo of the list that has already been copied. Safe to re-run.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$org = "tcm-pilot-test"; $team = "devops-infra-test"
# the 11 members of tcm-pilot team buil-tcm-devops-infra (26 Oct 2026), agreed by Gareth as the TCM-DevOps-Infra list
$members = 'Adrian-Stankiewicz_tciem','Dariusz-Dyjak_tciem','Frederic-NICOLAS_tciem','huychu-kuoy_tciem','Lukasz-Cymanowski_tciem',
           'Lukasz-Kruczek_tciem','Marcin-Karaczewski_tciem','NIZAR-SLAMASEFI_tciem','Paul-Jouet_tciem','rafal-prasal_tciem',
           'Wesley-VianadeSouza_tciem'
$repos = 'MD-jenkins-pipeline-library','MD-jpl-sample-ctx','MD-jpl-sample-codeql-maven-project','MD-jpl-sample-maven-project-with-sonar-status-jdk17',
         'MD-jpl-sample-maven-project-with-sonar-status','MD-jpl-sample-dockerfile','BUIL-jaas-jenkins','BUIL-jaas-jenkins-tools',
         'MD-jaas-sample-maven-project','MD-jenkins-jobs-configuration'

try { $null = Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$team" -Headers $h }
catch { Invoke-RestMethod -Method POST "https://api.github.com/orgs/$org/teams" -Headers $h -ContentType application/json -Body (@{ name = $team; description = "DevOps Infra - Jenkins integration test (TCM-DevOps-Infra)"; privacy = "closed" } | ConvertTo-Json) | Out-Null; "team $team created" }
foreach ($m in $members) {
  try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$team/memberships/$m" -Headers $h -ContentType application/json -Body '{"role":"member"}' | Out-Null }
  catch { "  $m : $($_.ErrorDetails.Message)" }
}
# keep the team equal to the list: remove anyone not on it (except the token owner, who GitHub adds as creator)
foreach ($x in (Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$team/members?per_page=100" -Headers $h)) {
  if ($members -notcontains $x.login -and $x.login -ne 'Gareth-Cabrera_tciem') { Invoke-RestMethod -Method DELETE "https://api.github.com/orgs/$org/teams/$team/memberships/$($x.login)" -Headers $h | Out-Null; "removed $($x.login) (not on the list)" }
}
"members: $($members.Count)"
$done = 0; $later = @()
foreach ($r in $repos) {
  try { $null = Invoke-RestMethod "https://api.github.com/repos/$org/$r" -Headers $h } catch { $later += $r; continue }
  # a repo that GEI is still importing exists but is locked: count it as not ready yet
  try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$team/repos/$org/$r" -Headers $h -ContentType application/json -Body '{"permission":"admin"}' | Out-Null; $done++ }
  catch { if ("$($_.ErrorDetails.Message)" -match 'locked') { $later += "$r (importing)" } else { "  $r : $($_.ErrorDetails.Message)" } }
}
"team has admin on $done repos; not ready yet ($($later.Count)): $($later -join ', ')"
