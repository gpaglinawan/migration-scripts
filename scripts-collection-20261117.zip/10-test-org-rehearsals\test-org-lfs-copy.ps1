param(
  [Parameter(Mandatory)][string]$Repo,
  [string]$SrcOrg = "tcm-pilot",
  [string]$TgtOrg = "tcm-pilot-test",
  [string]$Work = "C:\kon-migration\testorg-lfs"
)
# Copies every Git LFS object of a repo from tcm-pilot into its tcm-pilot-test copy (GEI does not migrate LFS).
# Uploads only; existing objects are skipped by LFS. Never writes to the source, never touches refs.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GIT_TERMINAL_PROMPT = "0"; $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work "$Repo-lfs.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
$dir = Join-Path $Work "$Repo.git"
Log "=== LFS copy $SrcOrg/$Repo -> $TgtOrg/$Repo ==="
if (-not (Test-Path $dir)) { git clone -q --mirror "https://github.com/$SrcOrg/$Repo.git" $dir 2>&1 | ForEach-Object { Log "   $_" } }
else { git -C $dir fetch -q --prune origin 2>&1 | ForEach-Object { Log "   $_" } }
Log "refs: $(@(git -C $dir for-each-ref refs/heads refs/tags).Count)"
git -C $dir lfs fetch --all origin 2>&1 | Select-Object -Last 2 | ForEach-Object { Log "   fetch: $_" }
$oids = @(Get-ChildItem (Join-Path $dir "lfs\objects") -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^[0-9a-f]{64}$' } | ForEach-Object Name)
Log "LFS objects in $SrcOrg : $($oids.Count) ($([math]::Round((Get-ChildItem (Join-Path $dir 'lfs\objects') -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1GB, 2)) GB)"
if ($oids.Count) {
  $tgt = "https://github.com/$TgtOrg/$Repo.git"
  for ($i = 0; $i -lt $oids.Count; $i += 200) {
    $chunk = $oids[$i..([Math]::Min($i + 199, $oids.Count - 1))]
    git -C $dir lfs push --object-id $tgt @chunk 2>&1 | Select-Object -Last 1 | ForEach-Object { Log "   push $($i + 1)-$($i + $chunk.Count): $_" }
  }
}
$env:GIT_CONFIG_COUNT = "0"
Log "=== done ==="
