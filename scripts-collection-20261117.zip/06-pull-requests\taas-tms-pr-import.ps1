# TAAS-tms in tcm-pilot has all branches but 0 of its 192 PRs (the first import carried the code only). Approved by Gareth
# 2026-11-09: re-import it from fin-tcm with GitHub Enterprise Importer as tcm-pilot/TAAS-tms-pr (PRs, reviews, comments),
# the same way as the 9 -pr copies; it replaces TAAS-tms at cutover. No large files / LFS in this repo.
# tcm-pilot is read-only (org rulesets "Migration read-only until cutover"): ONLY TAAS-tms-pr is excluded from them while
# it imports and put back straight after (finally block), so the new copy is read-only like everything else.
# Creates one new repo; changes no existing repo. Log: C:\kon-migration\pr-preload\TAAS-tms\run.log
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GH_SOURCE_PAT = $env:GH_SRC_PAT; $env:GH_PAT = $env:GH_TGT_PAT
$ghAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$work = 'C:\kon-migration\pr-preload\TAAS-tms'; New-Item -ItemType Directory -Force $work | Out-Null; Set-Location $work
$logFile = "$work\run.log"; function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
$target = 'TAAS-tms-pr'
function Get-Count($owner, $tok) { $q = '{ repository(owner:"' + $owner + '", name:"' + $(if ($owner -eq 'fin-tcm') { 'TAAS-tms' } else { $target }) + '") { pullRequests { totalCount } issues { totalCount } refs(refPrefix:"refs/heads/", first:1) { totalCount } } }'
  (Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body (@{ query = $q } | ConvertTo-Json) -ContentType application/json).data.repository }

$already = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$target" -Headers $ghAuth; $true } catch { $false }
if ($already) { Write-Log "$target already exists - nothing done"; return }
Write-Log "=== fin-tcm/TAAS-tms -> tcm-pilot/$target ==="
$rulesets = @(Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets?per_page=100" -Headers $ghAuth | ForEach-Object { $_ } | Where-Object { $_.name -like 'Migration read-only until cutover*' })
$saved = @{}
try {
  foreach ($rs in $rulesets) {
    $full = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
    $saved[$rs.id] = @($full.conditions.repository_name.exclude | Where-Object { $_ })
    $cond = @{ ref_name = @{ include = @($full.conditions.ref_name.include); exclude = @($full.conditions.ref_name.exclude | Where-Object { $_ }) }
               repository_name = @{ include = @($full.conditions.repository_name.include); exclude = @($saved[$rs.id] + $target | Select-Object -Unique); protected = [bool]$full.conditions.repository_name.protected } }
    Invoke-RestMethod -Method PUT "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth -ContentType application/json -Body (@{ conditions = $cond } | ConvertTo-Json -Depth 6) | Out-Null
    Write-Log "  read-only ruleset $($rs.id): $target excluded for the import"
  }
  $t0 = Get-Date
  $geiOut = gh gei migrate-repo --github-source-org fin-tcm --source-repo TAAS-tms --github-target-org tcm-pilot --target-repo $target --target-repo-visibility private 2>&1 | ForEach-Object { "$_" }
  $geiOk = $LASTEXITCODE -eq 0
  $geiOut | Select-String 'State|SUCCEEDED|FAILED|warning|ERROR' | Select-Object -Last 6 | ForEach-Object { Write-Log "  gei: $($_.Line)" }
  Write-Log ("  import {0} in {1:N1} min" -f $(if ($geiOk) { 'SUCCEEDED' } else { 'FAILED' }), ((Get-Date) - $t0).TotalMinutes)
}
finally {
  foreach ($rs in $rulesets) {
    try {
      $full = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
      $cond = @{ ref_name = @{ include = @($full.conditions.ref_name.include); exclude = @($full.conditions.ref_name.exclude | Where-Object { $_ }) }
                 repository_name = @{ include = @($full.conditions.repository_name.include); exclude = @($saved[$rs.id]); protected = [bool]$full.conditions.repository_name.protected } }
      Invoke-RestMethod -Method PUT "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth -ContentType application/json -Body (@{ conditions = $cond } | ConvertTo-Json -Depth 6) | Out-Null
      $back = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
      Write-Log ("  read-only ruleset {0} restored: excluded repos now [{1}] {2}" -f $rs.id, (@($back.conditions.repository_name.exclude) -join ','), $(if (@($back.conditions.repository_name.exclude) -contains $target) { '!! STILL EXCLUDED - CHECK' } else { '(ok)' }))
    } catch { Write-Log "  !! could not restore ruleset $($rs.id): $($_.Exception.Message) - run readonly-ruleset.ps1 -Org tcm-pilot -Apply" }
  }
}
if (-not $geiOk) { return }
$srcCount = Get-Count 'fin-tcm' $env:GH_SRC_PAT; $tgtCount = Get-Count 'tcm-pilot' $env:GH_TGT_PAT
Write-Log ("  verify: PRs {0}/{1}, branches {2}/{3}, issues {4}/{5} (tcm-pilot/{6} vs fin-tcm/TAAS-tms)" -f $tgtCount.pullRequests.totalCount, $srcCount.pullRequests.totalCount, $tgtCount.refs.totalCount, $srcCount.refs.totalCount, $tgtCount.issues.totalCount, $srcCount.issues.totalCount, $target)
@{ exportStarted = $t0.ToString('s'); prSource = $srcCount.pullRequests.totalCount; prTarget = $tgtCount.pullRequests.totalCount; plainCopy = $true } | ConvertTo-Json | Set-Content "$work\state.json" -Encoding utf8
Write-Log '=== done'
