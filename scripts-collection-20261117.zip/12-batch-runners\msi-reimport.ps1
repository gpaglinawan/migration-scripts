﻿$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GH_SOURCE_PAT = $env:GH_SRC_PAT; $env:GH_PAT = $env:GH_TGT_PAT
$t0 = Get-Date
$o = gh gei migrate-repo --github-source-org fin-tcm --source-repo msi-simple-springboot-blueprint --github-target-org tcm-pilot --target-repo msi-simple-springboot-blueprint-pr2 --target-repo-visibility private 2>&1 | ForEach-Object { "$_" -replace 'gh[spuo]_[A-Za-z0-9]+','[redacted]' }
"exit $LASTEXITCODE in $([int]((Get-Date)-$t0).TotalMinutes) min"; $o | Select-Object -Last 12
