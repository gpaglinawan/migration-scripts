param(
  [string]$SrcOrg   = "fin-tcm",
  [string]$TgtOrg   = "tcm-pilot",
  [string]$Preflight = "C:\kon-migration\preflight.csv",
  [string]$Out      = "C:\kon-migration\gei",
  [int]$Pilot       = 3,
  [int]$MaxInFlight = 25
)
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"([^"]*)"') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GH_SOURCE_PAT = $env:GH_SRC_PAT
$env:GH_PAT        = $env:GH_TGT_PAT
$hT = @{Authorization="Bearer $env:GH_TGT_PAT"}

New-Item -ItemType Directory -Force $Out | Out-Null
Set-Location $Out
$log = Join-Path $Out "gei-run.log"
$resFile = Join-Path $Out "results.csv"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line | Tee-Object -FilePath $log -Append }

# only repos that exist in source and not in target
$todo = @(Import-Csv $Preflight | Where-Object { $_.InSource -eq 'True' -and $_.InTarget -ne 'True' } | ForEach-Object Name)
# resume support: skip repos already recorded as SUCCEEDED
$done = @{}
if (Test-Path $resFile) { Import-Csv $resFile | Where-Object State -eq 'SUCCEEDED' | ForEach-Object { $done[$_.Name] = $true } }
$todo = @($todo | Where-Object { -not $done[$_] })
Log "=== GEI $SrcOrg -> $TgtOrg : $($todo.Count) repos to migrate (pilot=$Pilot, maxInFlight=$MaxInFlight) ==="

$results = @{}   # name -> object
function Save { $results.Values | Sort-Object Name | Export-Csv $resFile -NoTypeInformation -Encoding utf8 }

function Queue($name) {
  $o = gh gei migrate-repo --github-source-org $SrcOrg --source-repo $name --github-target-org $TgtOrg --target-repo $name --target-repo-visibility private --queue-only 2>&1 | ForEach-Object { "$_" }
  $o | Out-File (Join-Path $Out "queue-$name.log") -Encoding utf8
  # case-sensitive and anchored on "(ID: " - a plain RM_ match also hits repo names like "..._rm_template"
  $id = ($o | Select-String -Pattern '\(ID: (RM_[A-Za-z0-9_\-]+)\)' -CaseSensitive | Select-Object -First 1).Matches.Groups[1].Value
  if ($id) { $results[$name] = [pscustomobject]@{Name=$name; Id=$id; State='QUEUED'; Failure=''}; Log "queued  $name ($id)" }
  else     { $err = ($o | Where-Object { $_ -match 'ERROR' } | Select-Object -Last 1); $results[$name] = [pscustomobject]@{Name=$name; Id=''; State='QUEUE_FAILED'; Failure="$err"}; Log "QUEUE FAILED $name : $err" }
}

function Poll {
  $active = @($results.Values | Where-Object { $_.Id -and $_.State -notin 'SUCCEEDED','FAILED','FAILED_VALIDATION' })
  for ($i = 0; $i -lt $active.Count; $i += 50) {
    $chunk = $active[$i..([Math]::Min($i+49, $active.Count-1))]
    $ids = ($chunk | ForEach-Object { '"' + $_.Id + '"' }) -join ','
    $body = @{ query = "query{nodes(ids:[$ids]){... on RepositoryMigration{id repositoryName state failureReason}}}" } | ConvertTo-Json -Compress
    try { $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hT -Body $body -ContentType application/json } catch { Log "poll error: $($_.Exception.Message)"; return }
    foreach ($n in $r.data.nodes) {
      $x = $results.Values | Where-Object Id -eq $n.id
      if ($x -and $x.State -ne $n.state) {
        $x.State = $n.state; $x.Failure = "$($n.failureReason)"
        if ($n.state -in 'SUCCEEDED','FAILED','FAILED_VALIDATION') { Log ("{0,-9} {1} {2}" -f $n.state, $x.Name, $x.Failure) }
      }
    }
  }
  Save
}

function InFlight { @($results.Values | Where-Object { $_.Id -and $_.State -notin 'SUCCEEDED','FAILED','FAILED_VALIDATION' }).Count }

# --- pilot ---
$pilotSet = @($todo | Select-Object -First $Pilot)
foreach ($n in $pilotSet) { Queue $n }
Save
do { Start-Sleep 20; Poll } while ((InFlight) -gt 0)
$pilotOk = @($results.Values | Where-Object State -eq 'SUCCEEDED').Count
Log "pilot: $pilotOk/$($pilotSet.Count) succeeded"
if ($pilotOk -eq 0) { Log "FATAL: pilot had no successes - stopping. See queue-*.log and results.csv"; exit 1 }

# --- rest, bounded concurrency ---
$queue = New-Object System.Collections.Queue
$todo | Select-Object -Skip $Pilot | ForEach-Object { $queue.Enqueue($_) }
while ($queue.Count -gt 0 -or (InFlight) -gt 0) {
  while ($queue.Count -gt 0 -and (InFlight) -lt $MaxInFlight) { Queue ($queue.Dequeue()) }
  Save
  Start-Sleep 20
  Poll
  $s = $results.Values | Group-Object State | ForEach-Object { "$($_.Name)=$($_.Count)" }
  Log ("progress: remaining=$($queue.Count) " + ($s -join ' '))
}
Save
Log ("=== done: " + (($results.Values | Group-Object State | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' ') + " ===")
