# PR pre-load (approved by Gareth 2026-11-11, "1. yes"): recreate in tcm-pilot, ahead of cutover, the PRs created in fin-tcm
# after each repo's import that are already MERGED or CLOSED there (they no longer change). Open + stale PRs and anything
# merged/closed after today stay for the night (GIT-020). Uses pr-recreate.ps1 -States MERGED,CLOSED -NoStale -Apply.
# Held back (listed in held-back.csv, not touched):
#   - the 22 big repos (5 largest + 17 more with over 1,000 PRs): may be re-imported instead - Thursday's decision
#   - repos with GitHub Actions workflows (PR creation / branch pushes would start runs) - waiting for Gareth
#   - repos with an active webhook (OPICS-opics4plus -> Finastra pre-prod Jenkins)
# Smallest repos first. Log: C:\kon-migration\pr-recreate\run.log; per repo: C:\kon-migration\pr-recreate\<repo>\done.csv
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$out = 'C:\kon-migration\pr-recreate'; New-Item -ItemType Directory -Force $out | Out-Null
$per = @(Import-Csv C:\kon-migration\pr-activity\2026-11-10\per-repo.csv | Where-Object { [int]$_.MissingMerged + [int]$_.MissingClosed -gt 0 })
$big5 = 'SUM-summit', 'OPICS-opics4plus', 'SPH-sophis', 'KON-kplus-back', 'ARC-almonde'
$allActive = @(Import-Csv C:\kon-migration\pr-activity\2026-11-10\per-repo.csv | Where-Object { [int]$_.MissingOpen + [int]$_.MissingMerged + [int]$_.MissingClosed + [int]$_.StaleState -gt 0 })
$big = @($big5) + @($allActive | Where-Object { $_.Repo -notin $big5 -and [int]$_.PrsTotal -gt 1000 } | ForEach-Object Repo)
$wf = @{}
for ($i = 0; $i -lt $per.Count; $i += 25) {
  $chunk = @($per[$i..([Math]::Min($i + 24, $per.Count - 1))])
  $q = '{ ' + (($chunk | ForEach-Object -Begin { $n = 0 } -Process { "r$n" + ': repository(owner:"tcm-pilot", name:"' + $_.Repo + '") { name wf: object(expression:"HEAD:.github/workflows") { ... on Tree { entries { name } } } }'; $n++ }) -join ' ') + ' }'
  $d = (Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT" } -ContentType application/json -Body (@{ query = $q } | ConvertTo-Json)).data
  for ($k = 0; $k -lt $chunk.Count; $k++) { $x = $d."r$k"; if ($x -and @($x.wf.entries | Where-Object { $_ }).Count) { $wf[$x.name] = $true } } }
$rows = foreach ($r in $per) {
  $hooks = @(try { Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$($r.Repo)/hooks" -Headers $t } catch { }) | ForEach-Object { $_ } | Where-Object { $_.id -and $_.active }
  $why = @(); if ($r.Repo -in $big) { $why += 'big repo (Thursday decision)' }; if ($wf[$r.Repo]) { $why += 'has Actions workflows' }; if (@($hooks).Count) { $why += 'active webhook' }
  [pscustomobject]@{ Repo = $r.Repo; PRs = [int]$r.MissingMerged + [int]$r.MissingClosed; HeldBack = ($why -join '; ') } }
$rows | Where-Object HeldBack | Sort-Object PRs -Descending | Export-Csv "$out\held-back.csv" -NoTypeInformation -Encoding utf8
$go = @($rows | Where-Object { -not $_.HeldBack } | Sort-Object PRs)
$go | Export-Csv "$out\preload-repos.csv" -NoTypeInformation -Encoding utf8
"pre-load: $($go.Count) repos, $(($go | Measure-Object PRs -Sum).Sum) PRs; held back: $(@($rows | Where-Object HeldBack).Count) repos, $((@($rows | Where-Object HeldBack) | Measure-Object PRs -Sum).Sum) PRs" | Tee-Object -FilePath "$out\preload-plan.txt"
& C:\kon-migration\scripts\pr-recreate.ps1 -Repos @($go | ForEach-Object Repo) -TargetOrg tcm-pilot -States MERGED, CLOSED -NoStale -Work $out -Apply
