param(
  [Parameter(Mandatory=$true)][string]$NewBase,           # e.g. "https://teciem.atlassian.net/browse/"
  [string]$OldHost = "jira.finastra.com",
  [string]$Org = "tcm-pilot",
  [string[]]$OnlyPrefixes,                                # optional: limit to these key prefixes (e.g. KPL-,BMT-)
  [switch]$Apply
)
# Repoints repository autolinks from the Finastra Jira to the Teciem Jira. GitHub can't edit an autolink, so each
# matching one is recreated with the new URL (same key prefix and alphanumeric setting) and then the old one deleted.
# Preview by default. Every change is logged so it can be reversed.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$logF = "C:\kon-migration\autolinks-repoint-$(Get-Date -Format yyyyMMdd-HHmmss).csv"
$repos = @(); $pg = 1; do { $r = @(Invoke-RestMethod "https://api.github.com/orgs/$Org/repos?per_page=100&page=$pg" -Headers $hdr) | ForEach-Object { $_ }; $repos += $r; $pg++ } while ($r.Count -eq 100)
$changes = New-Object Collections.ArrayList; $n = 0
foreach ($repo in $repos) {
  $als = @(Invoke-RestMethod "https://api.github.com/repos/$Org/$($repo.name)/autolinks" -Headers $hdr) | ForEach-Object { $_ }
  foreach ($al in ($als | Where-Object { $_.url_template -match [regex]::Escape($OldHost) })) {
    if ($OnlyPrefixes -and $OnlyPrefixes -notcontains $al.key_prefix) { continue }
    $newUrl = $NewBase + $al.key_prefix + "<num>"
    $n++
    if (-not $Apply) { "would repoint  {0,-40} {1,-8} {2} -> {3}" -f $repo.name, $al.key_prefix, $al.url_template, $newUrl; continue }
    try {
      Invoke-RestMethod -Method DELETE "https://api.github.com/repos/$Org/$($repo.name)/autolinks/$($al.id)" -Headers $hdr | Out-Null
      Invoke-RestMethod -Method POST "https://api.github.com/repos/$Org/$($repo.name)/autolinks" -Headers $hdr -ContentType application/json -Body (@{ key_prefix = $al.key_prefix; url_template = $newUrl; is_alphanumeric = [bool]$al.is_alphanumeric } | ConvertTo-Json) | Out-Null
      [void]$changes.Add([pscustomobject]@{ Repo = $repo.name; Prefix = $al.key_prefix; OldUrl = $al.url_template; NewUrl = $newUrl; Alphanumeric = $al.is_alphanumeric })
      "repointed {0} {1}" -f $repo.name, $al.key_prefix
    } catch {
      [void]$changes.Add([pscustomobject]@{ Repo = $repo.name; Prefix = $al.key_prefix; OldUrl = $al.url_template; NewUrl = "FAILED: $($_.ErrorDetails.Message)"; Alphanumeric = $al.is_alphanumeric })
      "FAILED {0} {1} (old URL {2}): {3}" -f $repo.name, $al.key_prefix, $al.url_template, $_.ErrorDetails.Message
    }
  }
}
if ($Apply) { $changes | Export-Csv $logF -NoTypeInformation; "log: $logF" }
"$n autolinks $(if ($Apply) {'repointed'} else {'would be repointed'})"
