param(
  [string[]]$Repos = @("SUM-summit-web-services","FCGC-pricing-analytics","RISK-cmr","TO-treasury-installer","SFX-fusion-risk-adaptor","KON-kplus-front"),
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [switch]$Apply
)
# Copies repository autolink references (Jira key -> URL) that exist in the source repo but not in the target repo.
# Only adds; never changes or deletes existing target autolinks.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $(if ($SrcOrg -eq 'fin-tcm') { $env:GH_SRC_PAT } else { $env:GH_TGT_PAT })"; Accept = "application/vnd.github+json" }   # Teciem orgs use the Teciem token
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$logF = "C:\kon-migration\autolinks-copy-missing.log"
foreach ($repo in $Repos) {
  $src = @(Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$repo/autolinks" -Headers $srcHdr) | ForEach-Object { $_ }
  $tgt = @(Invoke-RestMethod "https://api.github.com/repos/$TgtOrg/$repo/autolinks" -Headers $tgtHdr) | ForEach-Object { $_ }
  foreach ($al in $src) {
    if (@($tgt | Where-Object { $_.key_prefix -eq $al.key_prefix }).Count) { continue }
    $msg = "$repo : $($al.key_prefix) -> $($al.url_template)"
    if (-not $Apply) { "would add  $msg"; continue }
    try {
      Invoke-RestMethod -Method POST "https://api.github.com/repos/$TgtOrg/$repo/autolinks" -Headers $tgtHdr -ContentType application/json -Body (@{ key_prefix = $al.key_prefix; url_template = $al.url_template; is_alphanumeric = [bool]$al.is_alphanumeric } | ConvertTo-Json) | Out-Null
      "added      $msg"; Add-Content $logF "$(Get-Date -Format s) added $msg"
    } catch { "FAILED     $msg : $($_.ErrorDetails.Message)" }
  }
}
