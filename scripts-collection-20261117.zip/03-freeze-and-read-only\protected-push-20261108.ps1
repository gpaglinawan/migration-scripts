# One-off (approved by Gareth 2026-11-08: "bypass the protected ones"). Brings the branches that branch protection or
# rulesets refused (nightly sync + corrective sync) in tcm-pilot into line with fin-tcm. KQ-qarc is excluded on purpose
# (secret push protection - not bypassed).
#   Rulesets: "Organization admin" is added as a bypass actor, the same way as sync-bypass-add.ps1, so the nightly sync
#             can keep these branches current until cutover. Each ruleset is backed up first and added to
#             C:\kon-migration\rules\sync-blocking-rulesets.csv, so sync-bypass-restore.ps1 puts it back at cutover.
#   Classic protection (force pushes not allowed): "allow force pushes" is switched on for that one branch, the push
#             is made, and the protection is set back straight away (finally block) and checked.
# Each ref is re-read live and only pushed if tcm-pilot's current commit is one fin-tcm has (so no Teciem-only work is
# overwritten); the push uses --force-with-lease on that commit; the old tcm-pilot commit of every ref is bundled first.
# Dry run unless -Apply.
param([switch]$Apply)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$api = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$apiSrc = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }
$srcHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))
$tgtHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'; $env:GIT_CONFIG_COUNT = '1'
$root = "C:\kon-migration\protected-push\" + (Get-Date -Format yyyyMMdd-HHmm); New-Item -ItemType Directory -Force "$root\backup" | Out-Null
$log = "$root\run.log"; function Write-Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Host $l; Add-Content $log $l -Encoding utf8 }

# repo, branch, blocking rulesets, classic protection that refuses force pushes
$items = @(
  @{ Repo = 'ffc-qa-dockers';               Branch = 'master';             Rulesets = @(25038594); Classic = $true  }
  @{ Repo = 'MAFQA-ffc-core-api';           Branch = 'develop-divest';     Rulesets = @(25038105); Classic = $false }
  @{ Repo = 'MAFQA-ffc-core-filesystem';    Branch = 'develop-divest';     Rulesets = @(25038112); Classic = $false }
  @{ Repo = 'PTP-ptp_technical';            Branch = 'master';             Rulesets = @(25038193); Classic = $false }
  @{ Repo = 'SUM-documentation';            Branch = 'sum-specs';          Rulesets = @(25804160); Classic = $false }
  @{ Repo = 'SUM-summit-snowflake-scripts'; Branch = 'master';             Rulesets = @(25038886); Classic = $false }
  @{ Repo = 'FNX-report-viewer';            Branch = 'develop';            Rulesets = @(25038311); Classic = $true  }
  @{ Repo = 'FNX-report-viewer';            Branch = 'master';             Rulesets = @(25038311); Classic = $true  }
  @{ Repo = 'OPICS-opics4plus';             Branch = '2026.4.0.0_Develop'; Rulesets = @();         Classic = $true  }
)
function Get-Tip($url, $hdr, $ref) { $env:GIT_CONFIG_VALUE_0 = $hdr; $l = git ls-remote $url $ref 2>$null | Where-Object { ($_ -split "`t")[1] -eq $ref } | Select-Object -First 1; if ($l) { ($l -split "`t")[0] } else { '' } }
# classic protection as returned by GET -> body for PUT (same settings; allow_force_pushes as given)
function Get-Names($set) { if (-not $set) { return $null }
  [ordered]@{ users = @($set.users | Where-Object { $_ } | ForEach-Object { $_.login }); teams = @($set.teams | Where-Object { $_ } | ForEach-Object { $_.slug }); apps = @($set.apps | Where-Object { $_ } | ForEach-Object { $_.slug }) } }
function Get-ProtBody($prot, [bool]$force) {
  $sc = $prot.required_status_checks; $rv = $prot.required_pull_request_reviews
  $checks = $null; if ($sc) { $checks = [ordered]@{ strict = [bool]$sc.strict; checks = @($sc.checks | Where-Object { $_ } | ForEach-Object { $c = [ordered]@{ context = $_.context }; if ($null -ne $_.app_id) { $c.app_id = $_.app_id }; $c }) } }
  $reviews = $null
  if ($rv) { $reviews = [ordered]@{ dismiss_stale_reviews = [bool]$rv.dismiss_stale_reviews; require_code_owner_reviews = [bool]$rv.require_code_owner_reviews
                                    required_approving_review_count = [int]$rv.required_approving_review_count; require_last_push_approval = [bool]$rv.require_last_push_approval }
    if ($rv.dismissal_restrictions) { $reviews.dismissal_restrictions = Get-Names $rv.dismissal_restrictions }
    if ($rv.bypass_pull_request_allowances) { $reviews.bypass_pull_request_allowances = Get-Names $rv.bypass_pull_request_allowances } }
  [ordered]@{ required_status_checks = $checks; enforce_admins = [bool]$prot.enforce_admins.enabled; required_pull_request_reviews = $reviews
              restrictions = (Get-Names $prot.restrictions); required_linear_history = [bool]$prot.required_linear_history.enabled
              allow_force_pushes = $force; allow_deletions = [bool]$prot.allow_deletions.enabled; block_creations = [bool]$prot.block_creations.enabled
              required_conversation_resolution = [bool]$prot.required_conversation_resolution.enabled; lock_branch = [bool]$prot.lock_branch.enabled
              allow_fork_syncing = [bool]$prot.allow_fork_syncing.enabled }
}
function Test-InFinastra($repo, $sha) { try { $null = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$repo/git/commits/$sha" -Headers $apiSrc; $true } catch { $false } }

Write-Log "=== protected push, mode=$(if ($Apply) { 'APPLY' } else { 'DRY RUN' }) ==="
# ---- plan (live state)
$plan = foreach ($it in $items) {
  $ref = "refs/heads/$($it.Branch)"
  $src = Get-Tip "https://github.com/fin-tcm/$($it.Repo).git" $srcHdr $ref
  $tgt = Get-Tip "https://github.com/tcm-pilot/$($it.Repo).git" $tgtHdr $ref
  $action = if (-not $src) { 'SKIP (no longer in fin-tcm)' } elseif ($src -eq $tgt) { 'SKIP (already in sync)' } elseif (-not $tgt) { 'CREATE' }
            elseif (Test-InFinastra $it.Repo $tgt) { 'UPDATE' } else { 'SKIP (tcm-pilot has a commit fin-tcm never had)' }
  [pscustomobject]@{ Repo = $it.Repo; Branch = $it.Branch; Ref = $ref; Source = $src; Target = $tgt; Action = $action; Rulesets = $it.Rulesets; Classic = $it.Classic }
}
foreach ($p in $plan) { Write-Log ("  {0,-30} {1,-20} {2}  {3} -> {4}" -f $p.Repo, $p.Branch, $p.Action, $(if ($p.Target) { $p.Target.Substring(0,10) } else { '(none)' }), $(if ($p.Source) { $p.Source.Substring(0,10) } else { '' })) }
$plan | Select-Object Repo, Branch, Action, Source, Target, Classic, @{ n = 'Rulesets'; e = { $_.Rulesets -join ' ' } } | Export-Csv "$root\plan.csv" -NoTypeInformation -Encoding utf8
if (-not $Apply) { Write-Log "dry run - nothing changed; plan: $root\plan.csv"; return }

# ---- rulesets: org-admin bypass until cutover (backup + restore list), only for repos with something to push
$todo = @($plan | Where-Object { $_.Action -in 'CREATE', 'UPDATE' })
$bk = 'C:\kon-migration\rules\bypass-backup'; New-Item -ItemType Directory -Force $bk | Out-Null
$restoreList = 'C:\kon-migration\rules\sync-blocking-rulesets.csv'
foreach ($rsId in @($todo | ForEach-Object { foreach ($i in $_.Rulesets) { "$($_.Repo)|$i" } } | Sort-Object -Unique)) {
  $repo, $id = $rsId -split '\|'; $u = "https://api.github.com/repos/tcm-pilot/$repo/rulesets/$id"
  try {
    $rs = Invoke-RestMethod $u -Headers $api
    $file = Join-Path $bk "$repo-$id.json"; if (-not (Test-Path $file)) { $rs | ConvertTo-Json -Depth 10 | Set-Content $file -Encoding utf8 }
    if (-not (Import-Csv $restoreList | Where-Object { $_.Repo -eq $repo -and $_.RulesetId -eq $id })) {
      [pscustomobject]@{ Repo = $repo; Branch = ''; RulesetId = $id; Source = 'Repository'; Types = 'added 2026-11-08 protected-push' } | Export-Csv $restoreList -Append -NoTypeInformation -Encoding utf8 }
    if ($rs.bypass_actors | Where-Object { $_.actor_type -eq 'OrganizationAdmin' }) { Write-Log "  ruleset $repo#$id '$($rs.name)': bypass already there"; continue }
    $actors = @($rs.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } }) + @{ actor_id = 1; actor_type = 'OrganizationAdmin'; bypass_mode = 'always' }
    Invoke-RestMethod -Method PUT $u -Headers $api -ContentType application/json -Body (@{ bypass_actors = $actors } | ConvertTo-Json -Depth 5) | Out-Null
    Write-Log "  ruleset $repo#$id '$($rs.name)': org-admin bypass added (backup $file; restored by sync-bypass-restore.ps1 at cutover)"
  } catch { Write-Log "  ERROR ruleset $repo#$id : $($_.Exception.Message) - its branch will be refused" }
}

# ---- push, one ref at a time
$results = foreach ($p in $todo) {
  $r = $p.Repo; $dir = "$root\work\$r-$($p.Branch -replace '\W','_').git"; Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue; git init --bare -q $dir
  $env:GIT_CONFIG_VALUE_0 = $srcHdr; git -C $dir fetch -q "https://github.com/fin-tcm/$r.git" "+$($p.Ref):$($p.Ref)" 2>&1 | Out-Null
  if ($p.Target) {
    $env:GIT_CONFIG_VALUE_0 = $tgtHdr; git -C $dir fetch -q "https://github.com/tcm-pilot/$r.git" "+$($p.Ref):refs/backup/$($p.Branch)" 2>&1 | Out-Null
    git -C $dir bundle create -q "$root\backup\$r-$($p.Branch -replace '\W','_').bundle" "refs/backup/$($p.Branch)" 2>&1 | Out-Null
    if (-not (Test-Path "$root\backup\$r-$($p.Branch -replace '\W','_').bundle")) { Write-Log "STOP $r $($p.Branch): backup failed, not pushed"; [pscustomobject]@{ Repo = $r; Branch = $p.Branch; Result = 'FAILED backup' }; continue }
  }
  # LFS objects of the new commits
  $env:GIT_CONFIG_VALUE_0 = $srcHdr; git -C $dir -c "lfs.url=https://github.com/fin-tcm/$r.git/info/lfs" lfs fetch "https://github.com/fin-tcm/$r.git" $p.Ref 2>&1 | Out-Null
  $env:GIT_CONFIG_VALUE_0 = $tgtHdr; git -C $dir -c "lfs.url=https://github.com/tcm-pilot/$r.git/info/lfs" -c lfs.allowincompletepush=true lfs push "https://github.com/tcm-pilot/$r.git" $p.Ref 2>&1 | Out-Null
  # GitHub has no endpoint for "allow force pushes" alone: the whole protection is PUT back with only that flag changed
  $protUrl = "https://api.github.com/repos/tcm-pilot/$r/branches/$([uri]::EscapeDataString($p.Branch))/protection"
  $opened = $false; $out = @(); $saved = $null
  try {
    if ($p.Classic -and $p.Target) {
      $saved = Invoke-RestMethod $protUrl -Headers $api
      $saved | ConvertTo-Json -Depth 8 | Set-Content "$root\backup\$r-$($p.Branch -replace '\W','_').protection.json" -Encoding utf8
      if ($saved.required_signatures.enabled) { throw "signed commits required - not changed (the PUT would not keep it)" }
      if (-not $saved.allow_force_pushes.enabled) {
        Invoke-RestMethod -Method PUT $protUrl -Headers $api -ContentType application/json -Body (ConvertTo-Json (Get-ProtBody $saved $true) -Depth 8) | Out-Null; $opened = $true }
    }
    $lease = if ($p.Target) { "--force-with-lease=$($p.Ref):$($p.Target)" } else { "--force-with-lease=$($p.Ref):" }
    $env:GIT_CONFIG_VALUE_0 = $tgtHdr
    $out = @(git -C $dir push --porcelain "https://github.com/tcm-pilot/$r.git" $lease "+$($p.Ref):$($p.Ref)" 2>&1 | ForEach-Object { "$_" })
  } catch { Write-Log "  ERROR $r $($p.Branch): $($_.Exception.Message)" }
  finally {
    if ($opened) {
      $want = ConvertTo-Json (Get-ProtBody $saved ([bool]$saved.allow_force_pushes.enabled)) -Depth 8 -Compress
      for ($try = 1; $try -le 3; $try++) {
        try { Invoke-RestMethod -Method PUT $protUrl -Headers $api -ContentType application/json -Body $want | Out-Null; break }
        catch { Write-Log "  !! restore attempt $try on $r $($p.Branch): $($_.Exception.Message)"; Start-Sleep 5 } }
      Start-Sleep 3
      $back = Invoke-RestMethod $protUrl -Headers $api
      $same = (ConvertTo-Json (Get-ProtBody $back ([bool]$back.allow_force_pushes.enabled)) -Depth 8 -Compress) -eq $want
      Write-Log ("  classic protection on {0} {1} restored: {2}" -f $r, $p.Branch, $(if ($same -and -not $back.allow_force_pushes.enabled) { 'yes - identical to before, force pushes off' } else { 'NO - CHECK (saved copy in backup\*.protection.json)' }))
    }
  }
  $out | Where-Object { $_ -match '^(error|fatal|remote:)' } | Select-Object -First 4 | ForEach-Object { Write-Log "  git: $_" }
  $ok = [bool]($out | Where-Object { $_ -match '^[ +*]\t' }); $now = Get-Tip "https://github.com/tcm-pilot/$r.git" $tgtHdr $p.Ref
  $res = if ($ok -and $now -eq $p.Source) { 'OK' } else { 'REJECTED' }
  Write-Log ("{0,-30} {1,-20} {2} {3}" -f $r, $p.Branch, $p.Action, $res)
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  [pscustomobject]@{ Repo = $r; Branch = $p.Branch; Result = $res }
}
$results | Export-Csv "$root\results.csv" -NoTypeInformation -Encoding utf8
Write-Log ("=== done: {0} OK, {1} refused; backups in {2}\backup ===" -f @($results | Where-Object Result -eq 'OK').Count, @($results | Where-Object Result -ne 'OK').Count, $root)
