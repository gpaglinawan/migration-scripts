# 12 Nov 2026 (Gareth: "rebuild databases"). DEF-213: the tcm-staging Treasury/databases feed was deleted and purged
# 16:0x CET; Azure DevOps keeps the name reserved for a while. Retry the copy (which creates the feed) every 5 min
# until the feed exists, max 3 h, then copy every version with the source descriptions.
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_SOURCE_PAT|AZDO_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
Set-Location C:\development\ADO-migration\ado-tcm-migration\ado-tcm-migration\scripts
$hd = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT")) }
$t0 = Get-Date
while ($true) {
  .\ado-feeds-copy.ps1 -Inventory .\ado-export\feeds-20261112-def213\feeds-inventory.csv -Feeds databases -Pass all -Log .\ado-export\feeds-copy-log-def213-databases-20261112.csv -Apply *>&1 | Select-Object -Last 3 | ForEach-Object { "[{0:HH:mm}] {1}" -f (Get-Date), $_ }
  $exists = try { $null = Invoke-RestMethod "https://feeds.dev.azure.com/tcm-staging/Treasury/_apis/packaging/feeds/databases?api-version=7.1" -Headers $hd; $true } catch { $false }
  if ($exists) { "[{0:HH:mm}] feed exists - copy pass finished" -f (Get-Date); break }
  if (((Get-Date) - $t0).TotalHours -ge 3) { "[{0:HH:mm}] STOP: name still reserved after 3 h" -f (Get-Date); exit 1 }
  Start-Sleep 300
}
