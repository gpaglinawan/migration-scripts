param(
  [string]$MapFile = "C:\kon-migration\service-accounts\svc-account-map.csv",
  [hashtable]$Orgs = @{ 'fin-tcm' = 'tcm-pilot'; 'fin-tcm-archive' = 'fin-tcm-archive-pilot' },
  [string]$Out = "C:\kon-migration\service-accounts",
  [switch]$Apply
)
# Gives the Teciem service accounts the same GitHub access their Finastra originals have: org membership, team
# membership (same team slug in the Teciem org) and direct repo permissions. Writes the plan to a CSV; with -Apply it
# also makes the changes. Only adds; never removes access. Org owner role is reported, not granted.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$ht = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
function P($u, $h) { $acc = @(); $p = 1; do { $r = @(Invoke-RestMethod "https://api.github.com/$u$(if($u -match '\?'){'&'}else{'?'})per_page=100&page=$p" -Headers $h) | ForEach-Object { $_ }; $acc += $r; $p++ } while ($r.Count -eq 100); $acc }
$perm = @{ read = 'pull'; triage = 'triage'; write = 'push'; maintain = 'maintain'; admin = 'admin' }

$map = @{}; Import-Csv $MapFile | ForEach-Object { $map[$_.Source.ToLower()] = $_.Target }
$plan = New-Object System.Collections.Generic.List[object]
function Add-Plan($org, $src, $tgt, $kind, $what, $level) { $plan.Add([pscustomobject]@{ Org = $org; Source = $src; Target = $tgt; Kind = $kind; What = $what; Level = $level; Result = '' }) }

foreach ($so in $Orgs.Keys) {
  $to = $Orgs[$so]
  # 1. org membership (members + admins)
  $admins = @{}; P "orgs/$so/members?role=admin" $hs | ForEach-Object { $admins[$_.login.ToLower()] = $true }
  $members = P "orgs/$so/members" $hs | Where-Object { $map.ContainsKey($_.login.ToLower()) }
  foreach ($m in $members) { Add-Plan $to $m.login $map[$m.login.ToLower()] 'org' $to $(if ($admins[$m.login.ToLower()]) { 'owner (not granted)' } else { 'member' }) }
  if (-not $members) { continue }
  $want = @{}; $members | ForEach-Object { $want[$_.login.ToLower()] = $true }
  # 2. teams
  $teams = P "orgs/$so/teams" $hs
  "${so}: $($members.Count) service accounts, scanning $($teams.Count) teams"
  foreach ($t in $teams) {
    foreach ($tm in (P "orgs/$so/teams/$($t.slug)/members" $hs)) {
      if ($want[$tm.login.ToLower()]) {
        $role = (Invoke-RestMethod "https://api.github.com/orgs/$so/teams/$($t.slug)/memberships/$($tm.login)" -Headers $hs).role
        Add-Plan $to $tm.login $map[$tm.login.ToLower()] 'team' $t.slug $role } } }
  # 3. direct repo permissions
  $repos = P "orgs/$so/repos" $hs
  "${so}: scanning $($repos.Count) repos for direct access"
  $i = 0
  foreach ($r in $repos) {
    $i++; if ($i % 250 -eq 0) { "   $i/$($repos.Count)" }
    try { foreach ($c in (P "repos/$so/$($r.name)/collaborators?affiliation=direct" $hs)) {
      if ($want[$c.login.ToLower()]) { Add-Plan $to $c.login $map[$c.login.ToLower()] 'repo' $r.name $c.role_name } } } catch { }
  }
}

if ($Apply) {
  foreach ($row in $plan) {
    if (-not $row.Target) { $row.Result = 'skipped: no Teciem account'; continue }
    try {
      switch ($row.Kind) {
        'org'  { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$($row.Org)/memberships/$($row.Target)" -Headers $ht -ContentType application/json -Body '{"role":"member"}' | Out-Null }
        'team' { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$($row.Org)/teams/$($row.What)/memberships/$($row.Target)" -Headers $ht -ContentType application/json -Body (@{ role = $row.Level } | ConvertTo-Json) | Out-Null }
        'repo' { $lv = $perm[$row.Level]; if (-not $lv) { $lv = $row.Level }
                 Invoke-RestMethod -Method PUT "https://api.github.com/repos/$($row.Org)/$($row.What)/collaborators/$($row.Target)" -Headers $ht -ContentType application/json -Body (@{ permission = $lv } | ConvertTo-Json) | Out-Null }
      }
      $row.Result = 'done'
    } catch { $row.Result = "FAILED $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" }
  }
}
$f = Join-Path $Out ("svc-access-" + $(if ($Apply) { 'applied' } else { 'plan' }) + "-" + (Get-Date -Format yyyyMMdd-HHmm) + ".csv")
$plan | Export-Csv $f -NoTypeInformation
$plan | Group-Object Org, Kind | Select-Object Count, Name | Format-Table -AutoSize
"no Teciem account: " + (($plan | Where-Object { -not $_.Target } | Select-Object -ExpandProperty Source -Unique) -join ', ')
if ($Apply) { $plan | Group-Object { ($_.Result -split ' ')[0] } | Select-Object Count, Name | Format-Table -AutoSize }
"file: $f"
