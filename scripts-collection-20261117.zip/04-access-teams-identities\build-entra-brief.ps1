# Fills entra-brief-template.html with the current data and writes entra-brief.html (UTF-8 in and out).
$dir = Split-Path $MyInvocation.MyCommand.Path
function E($s) { [System.Net.WebUtility]::HtmlEncode("$s") }
$all = Import-Csv C:\kon-migration\teams\users-missing-in-teciem.csv
$svc = @($all | Where-Object Category -eq 'service account'); $ppl = @($all | Where-Object Category -eq 'person'); $dep = @($all | Where-Object { $_.Category -like 'departed*' })
function Purpose($login) {
  $x = $login.ToLower()
  if ($x -match 'svc-jenkins') { return @('P1', 'Jenkins CI, builds across product lines') }
  switch -regex ($x) {
    'github-jira'      { return @('P2', 'Jira integration (org owner in Finastra)') }
    'jellyfish'        { return @('P2', 'Jellyfish engineering metrics') }
    'appsoc'           { return @('P2', 'Security scanning (security-manager team)') }
    'tktbuild'         { return @('P2', 'Fusion Invest builds and runner (GH-021)') }
    'opicsbuild'       { return @('P2', 'Opics builds') }
    'ptp-user'         { return @('P2', 'Summit / FCBO automation') }
    'summit-dev-auto'  { return @('P2', 'Summit CI automation') }
    'deliv'            { return @('P2', 'FCBO / Summit delivery') }
    'fnxteam'          { return @('P2', 'FNX team automation') }
    'kplustp'          { return @('P2', 'Kondor+ automation') }
    'qa-jenkins'       { return @('P2', 'QA Jenkins (Kondor, Treasury)') }
    'ffc-jenkins'      { return @('P2', 'FFC / MAFQA Jenkins') }
    'jenkins-sophis'   { return @('P2', 'Sophis Jenkins') }
    '^ci-|fbl-jenkins' { return @('P2', 'Product CI (Jenkins)') }
    default            { return @('P3', 'No team access; confirm with owner') } } }
function TeamList($teams) {
  $list = @($teams -split '; ' | Where-Object { $_ } | ForEach-Object { $_ -replace '\((member|maintainer)\)', '' })
  $txt = ($list | Select-Object -First 6) -join ', '; if ($list.Count -gt 6) { $txt += " +$($list.Count - 6) more" }; $txt }
$pri = @{ P1 = 1; P2 = 2; P3 = 3 }
$svcRows = $svc | ForEach-Object { $p = Purpose $_.FinastraLogin; [pscustomobject]@{ P = $p[0]; Use = $p[1]; R = $_ } } | Sort-Object { $pri[$_.P] }, { -[int]$_.R.ReposViaTeams } | ForEach-Object {
  "<tr><td><span class=`"pill $($_.P.ToLower())`">$($_.P)</span></td><td class=`"login`">$(E $_.R.FinastraLogin)</td><td class=`"login`">$(E $_.R.ExpectedTeciemLogin)</td><td>$(E $_.Use)</td><td class=`"num`">$(([int]$_.R.ReposViaTeams).ToString('N0'))</td><td class=`"teams`">$(E (TeamList $_.R.Teams))</td></tr>" }
$pplRows = $ppl | Sort-Object { if ($_.FinastraOrgOwner -eq 'True') { 0 } else { 1 } }, Name, FinastraLogin | ForEach-Object {
  $name = if ($_.Name) { E $_.Name } else { '<span style="color:var(--muted)">(no name in GitHub)</span>' }
  $own = if ($_.FinastraOrgOwner -eq 'True') { ' <span class="pill owner">owner</span>' } else { '' }
  "<tr><td>$name$own</td><td class=`"login`">$(E $_.FinastraLogin)</td><td class=`"login`">$(E $_.ExpectedTeciemLogin)</td><td class=`"num`">$(([int]$_.ReposViaTeams).ToString('N0'))</td><td class=`"teams`">$(E (TeamList $_.Teams))</td></tr>" }
$logs = Get-ChildItem C:\development\ADO-migration\ado-tcm-migration\ado-tcm-migration\scripts\ado-export\runs\*.log
$ado = @(foreach ($f in $logs) { Select-String -Path $f.FullName -Pattern 'not in Teciem tenant: (\S+) -> (\S+)' | ForEach-Object { [pscustomobject]@{ Project = ($f.BaseName -replace '_-_', ' - '); Source = $_.Matches.Groups[1].Value; Target = $_.Matches.Groups[2].Value } } })
$ado += @(
  [pscustomobject]@{ Project = 'Fusion Invest'; Source = 'Hui.Zheng@dh.com'; Target = 'hui.zheng@teciem.com' },
  [pscustomobject]@{ Project = 'Opics'; Source = 'Hui.Zheng@dh.com'; Target = 'hui.zheng@teciem.com' },
  [pscustomobject]@{ Project = 'TreasuryKondor'; Source = 'Hui.Zheng@dh.com'; Target = 'hui.zheng@teciem.com' },
  [pscustomobject]@{ Project = 'TreasuryKondor'; Source = 'Erwan.Queinnec@dh.com'; Target = 'erwan.queinnec@teciem.com' },
  [pscustomobject]@{ Project = 'TreasuryKondor'; Source = 'Josh.Vermast@dh.com'; Target = 'josh.vermast@teciem.com' },
  [pscustomobject]@{ Project = 'TreasuryKondor'; Source = 'dariusz.dyjak@dh.com'; Target = 'dariusz.dyjak@teciem.com' },
  [pscustomobject]@{ Project = 'TreasuryKondor'; Source = 'azr-qa-317-001.service@dh.com'; Target = 'azr-qa-317-001.service@teciem.com' },
  [pscustomobject]@{ Project = 'TreasuryKondor'; Source = 'OIDCONFLICT_UpnReuse_...Hasan.Mohamadally@dh.com'; Target = 'oidconflict' })
$adoG = $ado | Group-Object { $_.Target.ToLower() } | Sort-Object Name
$adoRows = $adoG | ForEach-Object {
  $src = $_.Group[0].Source; $tgt = $_.Group[0].Target; if ($tgt -like 'oidconflict*') { $tgt = '(stale identity, create clean)' }
  "<tr><td class=`"login`">$(E $src)</td><td class=`"login`">$(E $tgt)</td><td>$(E (($_.Group.Project | Sort-Object -Unique) -join ', '))</td></tr>" }
$d = Get-ChildItem C:\kon-migration\teams\collected*.clixml | Sort-Object LastWriteTime | Select-Object -Last 1 | ForEach-Object { Import-Clixml $_.FullName }
$both = @($d['fin-tcm'].Members.Keys | Where-Object { $d['tcm-pilot'].Members.ContainsKey($_) }).Count
$html = Get-Content (Join-Path $dir "entra-brief-template.html") -Raw -Encoding UTF8
$html = $html.Replace('{{SVC_ROWS}}', ($svcRows -join "`n")).Replace('{{PEOPLE_ROWS}}', ($pplRows -join "`n")).Replace('{{ADO_ROWS}}', ($adoRows -join "`n"))
$html = $html.Replace('{{SRC_MEMBERS}}', "$($d['fin-tcm'].Members.Count)").Replace('{{BOTH}}', "$both").Replace('{{PEOPLE}}', "$($ppl.Count)").Replace('{{SVC}}', "$($svc.Count)").Replace('{{DEPARTED}}', "$($dep.Count)").Replace('{{ADO}}', "$(@($adoG).Count)").Replace('{{DATE}}', (Get-Date).ToString('d MMMM yyyy'))
[IO.File]::WriteAllText((Join-Path $dir "entra-brief.html"), $html, (New-Object System.Text.UTF8Encoding $false))
"svc=$($svc.Count) people=$($ppl.Count) departed=$($dep.Count) ado=$(@($adoG).Count) both=$both placeholders-left=$([regex]::Matches($html, '\{\{\w+\}\}').Count) mojibake=$($html.Split([char]0x00E2).Count - 1)"   # 0xE2 = first char of UTF-8-read-as-ANSI garbage
