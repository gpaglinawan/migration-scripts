# 15 Nov 2026 - read-only: live PR counts fin-tcm vs tcm-pilot (GraphQL totalCount, all states) for a list of repos,
# next to the tracksheet status. Usage: pr-gap-recheck.py <csv with Repo column> <out.csv>
import csv, json, os, sys, time, urllib.request
S, T = os.environ['GH_SRC_PAT'], os.environ['GH_TGT_PAT']
def gql(tok, q, v):
    for a in range(5):
        try:
            r = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v}).encode(),
                                       headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
            return json.load(urllib.request.urlopen(r, timeout=60))['data']
        except Exception: time.sleep(5 * (a + 1))
Q = 'query($o:String!,$n:String!){ repository(owner:$o,name:$n){ o:pullRequests(states:OPEN){totalCount} m:pullRequests(states:MERGED){totalCount} c:pullRequests(states:CLOSED){totalCount} } }'
def cnt(tok, org, n):
    d = gql(tok, Q, {'o': org, 'n': n}); r = (d or {}).get('repository')
    return None if not r else (r['o']['totalCount'], r['m']['totalCount'], r['c']['totalCount'])
sheet = {r['Repo']: r for r in csv.DictReader(open(r'C:\kon-migration\tracksheet\GitHub-migration-tracksheet-latest.csv', encoding='utf-8-sig'))}
rows = []
for r in csv.DictReader(open(sys.argv[1], encoding='utf-8-sig')):
    n = r['Repo']; s, t = cnt(S, 'fin-tcm', n), cnt(T, 'tcm-pilot', n)
    st, tt = (sum(s) if s else None), (sum(t) if t else None)
    sh = sheet.get(n, {})
    rows.append({'Repo': n, 'Samar source': r.get('PRs source'), 'Samar target': r.get('PRs target'),
                 'Live fin-tcm': st, 'Live tcm-pilot': tt, 'Live missing': (st - tt) if st is not None and tt is not None else '',
                 'fin-tcm open/merged/closed': '/'.join(map(str, s)) if s else '', 'tcm-pilot open/merged/closed': '/'.join(map(str, t)) if t else '',
                 'Sheet PRs': sh.get('PRs', ''), 'Sheet overall': sh.get('Overall status', ''), 'Route': sh.get('Migration route', '')})
    print(f"{n:42} live {st}/{tt} missing {rows[-1]['Live missing']:>6}  sheet: {sh.get('PRs','')}")
with open(sys.argv[2], 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
