# 15 Nov 2026 - read-only: fuzzy-match name parts against every Teciem GitHub enterprise account (login + display name,
# accents ignored). Usage: fuzzy-person.py <name part> [<name part> ...]
import json, os, sys, urllib.request, difflib, unicodedata, re
tok = os.environ['GH_TGT_PAT']; parts = [p.lower() for p in sys.argv[1:]]
def gql(q, v):
    r = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v}).encode(), headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
    return json.load(urllib.request.urlopen(r, timeout=120))['data']
members, after = [], None
Q = 'query($a:String){ enterprise(slug:"tcm-enterprise"){ members(first:100, after:$a){ pageInfo{hasNextPage endCursor} nodes{ ... on EnterpriseUserAccount { login name } } } } }'
while True:
    d = gql(Q, {'a': after})['enterprise']['members']; members += d['nodes']
    if not d['pageInfo']['hasNextPage']: break
    after = d['pageInfo']['endCursor']
def norm(s): return re.sub(r'[^a-z ]', ' ', unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode().lower()).split()
scored = []
for u in members:
    words = norm((u.get('login') or '').replace('_tciem', '').replace('-', ' ') + ' ' + (u.get('name') or ''))
    s = sorted((max((difflib.SequenceMatcher(None, p, w).ratio() for w in words), default=0) for p in parts), reverse=True)
    scored.append((s[0], s[1] if len(s) > 1 else 0, u['login'], u.get('name')))
print(f'accounts scanned: {len(members)}; looking for: {" ".join(parts)}')
for a, b, l, n in sorted(scored, reverse=True)[:10]: print(f'  best part {a:.2f}  second part {b:.2f}  {l}  [{n}]')
