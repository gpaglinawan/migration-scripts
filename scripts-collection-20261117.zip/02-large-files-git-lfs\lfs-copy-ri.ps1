# 14 Nov 2026 (cutover night, GIT-020B/019B follow-up). pr-preload.ps1 pushes only the LFS objects its own rewrite
# created; LFS objects the repo ALREADY had in fin-tcm are not in GitHub's export/import, so a <repo>-ri / <repo>-pr2
# copy lacks them (found on ARC-almonde-ri: 0 pushed, fin-tcm has ~13,800). This copies every LFS object of the
# fin-tcm repo into the copy. Adds LFS objects only - no refs, no commits. Idempotent; a repo is marked done in
# <Work>\done.csv. Skips copies that do not exist yet (import not finished) - re-run later.
# Usage: .\lfs-copy-ri.ps1 -Repos ARC-almonde,SPH-sophis -Suffix ri
param([Parameter(Mandatory)][string[]]$Repos, [Parameter(Mandatory)][string]$Suffix, [string]$Work = 'C:\kon-migration\lfs-ri')
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-B64($p) { [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$p")) }
$srcAuth = "AUTHORIZATION: basic $(Get-B64 $env:GH_SRC_PAT)"; $tgtAuth = "AUTHORIZATION: basic $(Get-B64 $env:GH_TGT_PAT)"
$env:GIT_CONFIG_COUNT = '2'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'; $env:GIT_CONFIG_KEY_1 = 'lfs.allowincompletepush'; $env:GIT_CONFIG_VALUE_1 = 'true'; $env:GIT_TERMINAL_PROMPT = '0'
$api = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work 'lfs-copy-ri.log'; $doneFile = Join-Path $Work 'done.csv'
function Write-CopyLog($m) { $l = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
$done = @{}; if (Test-Path $doneFile) { Import-Csv $doneFile | ForEach-Object { $done["$($_.Repo)|$($_.Target)"] = $_.Result } }
foreach ($r in $Repos) {
  $t = "$r-$Suffix"; if ($done["$r|$t"]) { continue }
  $tr = try { Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$t" -Headers $api } catch { $null }
  if (-not $tr) { Write-CopyLog "$t : not in tcm-pilot yet - later"; continue }
  $d = Join-Path $Work "$r.git"; $t0 = Get-Date
  $env:GIT_CONFIG_VALUE_0 = $srcAuth
  if (-not (Test-Path $d)) { git clone --bare --quiet "https://github.com/fin-tcm/$r.git" $d 2>&1 | Out-Null; if ($LASTEXITCODE) { Write-CopyLog "$r : clone FAILED"; continue } }
  $n = @(git -C $d lfs ls-files --all --long 2>$null | ForEach-Object { ($_ -split ' ')[0] } | Sort-Object -Unique).Count
  if ($n -eq 0) { $res = 'no LFS' }
  else {
    git -C $d lfs fetch --all "https://github.com/fin-tcm/$r.git" 2>&1 | Select-Object -Last 1 | ForEach-Object { Write-CopyLog "  $r fetch: $_" }
    $fe = $LASTEXITCODE; $env:GIT_CONFIG_VALUE_0 = $tgtAuth
    $got = @(Get-ChildItem (Join-Path $d 'lfs\objects') -Recurse -File -ErrorAction SilentlyContinue).Count
    if ($got -eq 0) { $res = "nothing to copy: fin-tcm holds none of its $n LFS objects (copy matches source)" }   # 14 Nov: ARC-almonde_Sept19 case
    else {
      git -C $d lfs push --all "https://github.com/tcm-pilot/$t.git" 2>&1 | Select-Object -Last 1 | ForEach-Object { Write-CopyLog "  $t push: $_" }
      $pe = $LASTEXITCODE
      $res = if ($pe -eq 0) { "copied $got of $n LFS objects$(if ($got -lt $n) { " ($($n - $got) not on fin-tcm either)" })" } else { "PUSH FAILED (exit $pe) - retry" }
    }
  }
  Write-CopyLog ("{0} -> {1}: {2} in {3:N0} min" -f $r, $t, $res, ((Get-Date) - $t0).TotalMinutes)
  if ($res -notlike 'PUSH FAILED*') {
    [pscustomobject]@{ Repo = $r; Target = $t; Objects = $n; Result = $res; Time = (Get-Date).ToString('s') } | Export-Csv $doneFile -Append -NoTypeInformation -Encoding utf8
    try { [IO.Directory]::Delete($d, $true) } catch { }   # local working clone only
  }
}
$env:GIT_CONFIG_COUNT = '0'
