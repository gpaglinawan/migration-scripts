# 14 Nov 2026 (Gareth: "5. bypass"). Pushes the 6 GIT-007 refs that repo rules / classic protection refused, then puts
# every rule back exactly as it was. Backups in C:\kon-migration\corrective-sync\blocked-20261114\.
# Each push keeps the lease (only overwrites if tcm-pilot still has the commit recorded in the GIT-007 plan).
$ErrorActionPreference = 'Stop'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $A = 'https://api.github.com'
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'
$bk = 'C:\kon-migration\corrective-sync\blocked-20261114'; New-Item -ItemType Directory -Force $bk | Out-Null
$log = "$bk\run.log"; function Write-RunLog($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
function Invoke-Gql($q, $v) { $r = Invoke-RestMethod -Method Post "$A/graphql" -Headers $gh -ContentType application/json -Body (@{ query = $q; variables = $v } | ConvertTo-Json -Depth 8); if ($r.errors) { throw ($r.errors | ConvertTo-Json -Compress) }; $r.data }
$plan = Import-Csv C:\kon-migration\corrective-sync\20261114-0603\plan.csv
$refs = @(@('FNX-BO-bank-account-balance','refs/heads/feat/KTAC-31439/display-other-bank-accounts'), @('FNX-BO-bank-account-balance','refs/heads/feat/KTAC-31441/manual-refresh-of-the-data'),
          @('FNX-BO-bank-account-balance','refs/heads/feat/KTAC-32084/display-bank-account-balance'), @('FNX-fusion-risk-cmr','refs/heads/develop'),
          @('SUM-snowflake-client-application-scripts','refs/heads/master'), @('THIRD-idakdb','refs/heads/feature/KTAC-16017-work-on-odbc-win2022'))
$rulesets = @(@('SUM-snowflake-client-application-scripts', 25038940), @('THIRD-idakdb', 25038245))
$migTeam = 20591252   # the team that bypasses the org read-only rulesets (migration account)

# ---- 1. back up and open the rules
$opened = @()
try {
  foreach ($r in $rulesets) {
    $d = Invoke-RestMethod "$A/repos/tcm-pilot/$($r[0])/rulesets/$($r[1])" -Headers $gh; $d | ConvertTo-Json -Depth 12 | Out-File "$bk\ruleset-$($r[0])-$($r[1]).json" -Encoding utf8
    $by = @($d.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } }) + @(@{ actor_id = $migTeam; actor_type = 'Team'; bypass_mode = 'always' })
    $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$($r[0])/rulesets/$($r[1])" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = $by } | ConvertTo-Json -Depth 6)
    $opened += ,@('ruleset', $r[0], $r[1]); Write-RunLog "opened ruleset $($r[1]) on $($r[0]) (migration team bypass added)" }
  $ea = "$A/repos/tcm-pilot/FNX-fusion-risk-cmr/branches/develop/protection/enforce_admins"
  if ((Invoke-RestMethod $ea -Headers $gh).enabled) { $null = Invoke-RestMethod -Method Delete $ea -Headers $gh; $opened += ,@('enforce_admins', 'FNX-fusion-risk-cmr', 'develop'); Write-RunLog "opened FNX-fusion-risk-cmr develop: include administrators OFF" }
  $q = 'query{ repository(owner:"tcm-pilot",name:"FNX-BO-bank-account-balance"){ branchProtectionRules(first:50){ nodes { id pattern allowsForcePushes matchingRefs(first:100){ nodes { name } } } } } }'
  $bpr = @((Invoke-Gql $q @{}).repository.branchProtectionRules.nodes | Where-Object { -not $_.allowsForcePushes -and ($_.matchingRefs.nodes.name | Where-Object { $_ -in 'feat/KTAC-31439/display-other-bank-accounts','feat/KTAC-31441/manual-refresh-of-the-data','feat/KTAC-32084/display-bank-account-balance' }) })
  $bpr | ConvertTo-Json -Depth 6 | Out-File "$bk\fnx-bo-branch-rules.json" -Encoding utf8
  foreach ($b in $bpr) { $null = Invoke-Gql 'mutation($i:ID!){ updateBranchProtectionRule(input:{branchProtectionRuleId:$i, allowsForcePushes:true}){ branchProtectionRule { id } } }' @{ i = $b.id }; $opened += ,@('forcepush', 'FNX-BO-bank-account-balance', $b.id); Write-RunLog "opened FNX-BO rule '$($b.pattern)': force pushes allowed" }

  # ---- 2. push with lease (git writes progress to stderr: don't treat it as an error)
  $ErrorActionPreference = 'Continue'
  foreach ($x in $refs) {
    $row = $plan | Where-Object { $_.Repo -eq $x[0] -and $_.Ref -eq $x[1] } | Select-Object -First 1
    $d = "$bk\work-$($x[0]).git"; if (-not (Test-Path $d)) { git init --bare -q $d }
    git -C $d -c "http.extraHeader=Authorization: Basic $sb" fetch -q "https://github.com/fin-tcm/$($x[0]).git" "+$($x[1]):$($x[1])" 2>&1 | Out-Null
    git -C $d -c "http.extraHeader=Authorization: Basic $tb" fetch -q "https://github.com/tcm-pilot/$($x[0]).git" "+$($x[1]):refs/backup/$($x[1] -replace '^refs/','')" 2>&1 | Out-Null
    $o = @(git -C $d -c "http.extraHeader=Authorization: Basic $tb" push --porcelain "--force-with-lease=$($x[1]):$($row.Teciem)" "https://github.com/tcm-pilot/$($x[0]).git" "+$($x[1]):$($x[1])" 2>&1 | ForEach-Object { "$_" })
    $now = (git -C $d -c "http.extraHeader=Authorization: Basic $tb" ls-remote "https://github.com/tcm-pilot/$($x[0]).git" $x[1] 2>$null | Select-Object -First 1) -split "`t" | Select-Object -First 1
    $want = git -C $d rev-parse $x[1]
    $res = if ($o | Where-Object { $_ -match '^\+\t|^ \t|^\*\t' }) { 'PUSHED' } elseif ($now -eq $want) { 'already matches fin-tcm' } else { 'REJECTED: ' + (($o | Where-Object { $_ -match '^remote: - |^!' }) -join ' ') }
    Write-RunLog "$($x[0]) $($x[1]): $res"
  }
  Get-ChildItem $bk -Directory -Filter 'work-*' | ForEach-Object { git -C $_.FullName bundle create -q "$bk\$($_.Name -replace '^work-','' -replace '\.git$','').bundle" --all 2>$null }
}
finally {
  # ---- 3. put every rule back
  foreach ($o in $opened) {
    try {
      switch ($o[0]) {
        'ruleset' { $orig = Get-Content "$bk\ruleset-$($o[1])-$($o[2]).json" -Raw | ConvertFrom-Json
                    $by = @($orig.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } })
                    $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$($o[1])/rulesets/$($o[2])" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = $by } | ConvertTo-Json -Depth 6) }
        'enforce_admins' { $null = Invoke-RestMethod -Method Post "$A/repos/tcm-pilot/$($o[1])/branches/$($o[2])/protection/enforce_admins" -Headers $gh }
        'forcepush' { $null = Invoke-Gql 'mutation($i:ID!){ updateBranchProtectionRule(input:{branchProtectionRuleId:$i, allowsForcePushes:false}){ branchProtectionRule { id } } }' @{ i = $o[2] } }
      }
      Write-RunLog "restored $($o[0]) $($o[1]) $($o[2])"
    } catch { Write-RunLog "!! RESTORE FAILED $($o[0]) $($o[1]) $($o[2]): $($_.Exception.Message)" }
  }
}
