# PR-preserving import of a large-file repo (approved by Gareth 2026-11-06: preload under a temporary name).
# Generalised from C:\kon-migration\kplus-front-pr-remap (KON-kplus-front -> tcm-pilot-test/KON-kplus-front-pr, 5 Nov).
# Stages (each recorded in <Work>\state.json, so a re-run continues where it stopped):
#   export   fin-tcm org migration export of the repo (read-only on Finastra, repo NOT locked) + download
#   extract  unpack the archive
#   rewrite  blobs over 100 MB -> Git LFS with git-filter-repo (lfs-rewrite.ps1), then fix ref names + check them
#   remap    rewrite commit ids in the PR data with the commit map; add back the empty "changes requested" reviews
#   archive  build the git + metadata archives in GitHub's export layout (refuses if any blob over 100 MB is left)
#   import   upload both to GitHub-owned storage, startRepositoryMigration (GITHUB_ARCHIVE) into a NEW private repo
#            <TargetOrg>/<TargetName>; refuses if that repo already exists. GitHub gives it no team access.
#   lfs      push the LFS objects
#   verify   PR totals, refs, random PR sample vs Finastra (read-only)
#   cleanup  delete this run's own big intermediates (archives, unpacked export, rewritten copy); keeps logs,
#            state, commit-map, missing-reviews.csv
# Usage: .\pr-preload.ps1 -Repo RISK-cmr [-TargetOrg tcm-pilot] [-TargetName RISK-cmr-pr] [-PathRename 'a/:b/'] [-StopAfter import]
param(
  [Parameter(Mandatory)][string]$Repo,
  [string]$TargetOrg = 'tcm-pilot',
  [string]$TargetName = "$Repo-pr",
  [string[]]$PathRename = @(),
  [switch]$DropNullGitlinks,
  [string]$Work = "C:\kon-migration\pr-preload\$Repo",
  [ValidateSet('export','extract','rewrite','remap','archive','import','lfs','verify','cleanup')][string]$StopAfter = 'cleanup',
  [int]$Sample = 30,
  # 16 Nov 2026 (DEF-114 / DEF-238, Gareth: "go"): no rewrite - the exported git data is imported unchanged, so commit IDs
  # stay identical to Finastra (the 14 Nov -ri copies got new IDs because filter-repo always ran). Refuses if any blob is
  # over 100 MB (that repo needs the LFS rewrite and cannot keep its IDs).
  [switch]$KeepCommitIds
)
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$py = 'C:\kon-migration\tools\python\python.exe'; $here = Split-Path $MyInvocation.MyCommand.Path
New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work 'run.log'; $stateFile = Join-Path $Work 'state.json'
function Write-Log($m) { $l = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Host $l; try { Add-Content $log $l -Encoding utf8 -ErrorAction Stop } catch { } }
$state = if (Test-Path $stateFile) { Get-Content $stateFile -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
function Set-State($k, $v) { $state | Add-Member -NotePropertyName $k -NotePropertyValue $v -Force; $state | ConvertTo-Json | Set-Content $stateFile -Encoding utf8 }
function Test-Done($stage) { [bool]$state."done_$stage" }
function Complete-Stage($stage) { Set-State "done_$stage" (Get-Date).ToString('s'); Write-Log "--- stage $stage done"; if ($stage -eq $StopAfter) { Write-Log "=== stopped after $stage as asked ==="; exit 0 } }
function Stop-Run($m) { Write-Log "STOP: $m"; exit 1 }
$srcApi = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }
$tgtApi = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
function Invoke-Gql($hdr, $q, $vars) {
  $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hdr -ContentType application/json -Body (@{ query = $q; variables = $vars } | ConvertTo-Json -Depth 6)
  if ($r.errors) { throw "GraphQL: $($r.errors | ConvertTo-Json -Depth 4 -Compress)" }; $r.data }
$exportTar = Join-Path $Work 'export.tar.gz'; $exportDir = Join-Path $Work 'export'; $remapDir = Join-Path $Work 'export-remapped'
$origGit = Join-Path $exportDir "repositories\fin-tcm\$Repo.git"; $rwGit = Join-Path $Work 'rewritten.git'
$cmap = Join-Path $rwGit 'filter-repo\commit-map'; $cmapKeep = Join-Path $Work 'commit-map'
Write-Log "=== $Repo -> $TargetOrg/$TargetName (work $Work) ==="

# ---- export
if (-not (Test-Done 'export')) {
  if (-not $state.exportId) {
    $body = @{ repositories = @("fin-tcm/$Repo"); lock_repositories = $false; exclude_attachments = $false } | ConvertTo-Json
    $m = Invoke-RestMethod -Method Post https://api.github.com/orgs/fin-tcm/migrations -Headers $srcApi -Body $body -ContentType application/json
    Set-State exportId $m.id; Set-State exportStarted (Get-Date).ToString('s'); Write-Log "export started: id $($m.id)"
  }
  $t0 = [datetime]$state.exportStarted; $last = ''
  while ($true) {
    $s = (Invoke-RestMethod "https://api.github.com/orgs/fin-tcm/migrations/$($state.exportId)" -Headers $srcApi).state
    if ($s -ne $last) { Write-Log ("  export state {0} after {1:N0} min" -f $s, ((Get-Date) - $t0).TotalMinutes); $last = $s }
    if ($s -eq 'exported') { break }; if ($s -eq 'failed') { Stop-Run 'export failed' }
    Start-Sleep 60
  }
  # the archive URL redirects to signed storage; follow it without sending the GitHub token there
  $r = Invoke-WebRequest "https://api.github.com/orgs/fin-tcm/migrations/$($state.exportId)/archive" -Headers $srcApi -MaximumRedirection 0 -ErrorAction SilentlyContinue -UseBasicParsing
  if (-not $r.Headers.Location) { Stop-Run "no archive redirect (status $($r.StatusCode))" }
  $ProgressPreference = 'SilentlyContinue'; Invoke-WebRequest $r.Headers.Location -OutFile $exportTar -UseBasicParsing
  Write-Log ("  downloaded {0:N2} GB" -f ((Get-Item $exportTar).Length / 1GB))
  Complete-Stage 'export'
}
# ---- extract
if (-not (Test-Done 'extract')) {
  Remove-Item $exportDir -Recurse -Force -ErrorAction SilentlyContinue; New-Item -ItemType Directory -Force $exportDir | Out-Null
  tar -xzf $exportTar -C $exportDir 2>&1 | Select-Object -First 5 | ForEach-Object { Write-Log "  tar: $_" }
  if (-not (Test-Path $origGit)) { Stop-Run "no git repo in the export at $origGit" }
  Write-Log ("  PR files: {0}" -f @(Get-ChildItem $exportDir -Filter 'pull_requests_*.json').Count)
  Complete-Stage 'extract'
}
# ---- rewrite (large blobs -> LFS), fix + check refs
if (-not (Test-Done 'rewrite') -and $KeepCommitIds) {
  # GitHub's importer accepts files up to 400 MB (the live repos were imported that way with their original IDs); above that the LFS rewrite is needed
  $big = @(git -C $origGit rev-list --objects --all | git -C $origGit cat-file --batch-check='%(objecttype) %(objectsize) %(rest)' | Where-Object { $_ -match '^blob (\d+)' -and [long]$Matches[1] -gt 400MB })
  if ($big.Count) { Stop-Run "KeepCommitIds: $($big.Count) blob(s) over 400 MB - this repo needs the LFS rewrite" }
  $mid = @(git -C $origGit rev-list --objects --all | git -C $origGit cat-file --batch-check='%(objecttype) %(objectsize) %(rest)' | Where-Object { $_ -match '^blob (\d+)' -and [long]$Matches[1] -gt 100MB }).Count
  if ($mid) { Write-Log "  KeepCommitIds: $mid blob(s) between 100 and 400 MB - kept as they are (importer limit 400 MB)"; Set-State keepLargeBlobs $mid }
  Remove-Item $rwGit -Recurse -Force -ErrorAction SilentlyContinue
  robocopy $origGit $rwGit /E /NFL /NDL /NJH /NJS /NP | Out-Null; if ($LASTEXITCODE -ge 8) { Stop-Run "robocopy failed ($LASTEXITCODE)" }
  New-Item -ItemType Directory -Force (Split-Path $cmap) | Out-Null
  $ids = @(git -C $origGit rev-list --all); [IO.File]::WriteAllLines($cmap, @('old                                      new') + @($ids | ForEach-Object { "$_ $_" }))
  Copy-Item $cmap $cmapKeep -Force
  Write-Log "  KeepCommitIds: no rewrite; identity commit map with $($ids.Count) commits (IDs unchanged)"
  # repos that already use Git LFS: the export has only the pointers - fetch every LFS object from fin-tcm so the lfs stage pushes them
  $env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'
  $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $env:GIT_CONFIG_COUNT = '1'
  git -C $rwGit lfs fetch --all "https://github.com/fin-tcm/$Repo.git" 2>&1 | Select-Object -Last 2 | ForEach-Object { Write-Log "  lfs fetch: $_" }
  $env:GIT_CONFIG_COUNT = '0'
  Write-Log ("  LFS objects fetched from fin-tcm: {0}" -f @(Get-ChildItem (Join-Path $rwGit 'lfs\objects') -Recurse -File -ErrorAction SilentlyContinue).Count)
  Complete-Stage 'rewrite'
}
if (-not (Test-Done 'rewrite')) {
  $rwArgs = @{ Orig = $origGit; Copy = $rwGit; Out = (Join-Path $Work 'rewrite') }; if ($PathRename) { $rwArgs.PathRename = $PathRename }; if ($DropNullGitlinks) { $rwArgs.DropNullGitlinks = $true }
  & C:\kon-migration\scripts\lfs-rewrite.ps1 @rwArgs | ForEach-Object { Write-Log "  $_" }
  if (-not (Test-Path $cmap)) { Stop-Run 'rewrite produced no commit-map' }
  Copy-Item $cmap $cmapKeep -Force
  & $py -I "$here\fix_refs.py" $origGit $rwGit $cmap 2>&1 | ForEach-Object { Write-Log "  fix_refs: $_" }
  & $py -I "$here\check_refs.py" $origGit $rwGit $cmap 2>&1 | Select-Object -First 15 | ForEach-Object { Write-Log "  check_refs: $_" }
  Complete-Stage 'rewrite'
}
# ---- remap PR data + add back dropped reviews
if (-not (Test-Done 'remap')) {
  Remove-Item $remapDir -Recurse -Force -ErrorAction SilentlyContinue
  & $py -I "$here\remap_pr_shas.py" $exportDir $cmapKeep $remapDir 2>&1 | ForEach-Object { Write-Log "  remap: $_" }
  if (-not (Test-Path (Join-Path $remapDir 'schema.json'))) { Stop-Run 'remap produced no output' }
  & $py -I "$here\add_missing_reviews.py" $remapDir $cmapKeep "fin-tcm/$Repo" 2>&1 | Where-Object { "$_" -notmatch 'fetched \d+/' } | ForEach-Object { Write-Log "  reviews: $_" }
  # DEF-106: add the placeholder accounts the export left out, so their PRs are not imported as "ghost"
  & $py -I "$here\add_missing_users.py" $remapDir 2>&1 | ForEach-Object { Write-Log "  users: $_" }
  Complete-Stage 'remap'
}
# ---- archives
if (-not (Test-Done 'archive')) {
  $lim = if ($KeepCommitIds) { 400MB } else { 100MB }
  $big = @(git -C $rwGit rev-list --objects --all | git -C $rwGit cat-file --batch-check='%(objecttype) %(objectsize) %(rest)' | Where-Object { $_ -match '^blob (\d+)' -and [long]$Matches[1] -gt $lim })
  if ($big.Count) { Stop-Run "blobs over $($lim/1MB) MB left: $($big -join '; ')" }
  $stage = Join-Path $Work 'import-git-stage'; Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
  $repoDir = Join-Path $stage "repositories\fin-tcm\$Repo.git"; New-Item -ItemType Directory -Force $repoDir | Out-Null
  Copy-Item (Join-Path $remapDir 'schema.json'), (Join-Path $remapDir 'repositories_000001.json') $stage
  # an archived source would be imported archived (read-only: the LFS push is refused). Import it unarchived and
  # archive it again after verify, so it ends up like Finastra.
  $wasArchived = & $py -I -c "import json,sys; p=sys.argv[1]; d=json.load(open(p,encoding='utf-8')); a=bool(d[0].get('is_archived')); d[0]['is_archived']=False; json.dump(d,open(p,'w',encoding='utf-8')); print(a)" (Join-Path $stage 'repositories_000001.json')
  & $py -I -c "import json,sys; p=sys.argv[1]; d=json.load(open(p,encoding='utf-8')); d[0]['is_archived']=False; json.dump(d,open(p,'w',encoding='utf-8'))" (Join-Path $remapDir 'repositories_000001.json')
  Set-State sourceArchived (($wasArchived -eq 'True') -or [bool]$state.sourceArchived); if ($state.sourceArchived) { Write-Log '  source is archived: importing unarchived, will archive after verify' }
  robocopy $rwGit $repoDir /E /XD filter-repo lfs hooks /XF "packed-refs.bak-*" /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -ge 8) { Stop-Run "robocopy failed ($LASTEXITCODE)" }
  $gitTar = Join-Path $Work 'import-git.tar.gz'; $metaTar = Join-Path $Work 'import-metadata.tar.gz'
  tar -czf $gitTar -C $stage .; if ($LASTEXITCODE) { Stop-Run 'tar (git) failed' }
  Remove-Item $stage -Recurse -Force
  tar -czf $metaTar -C $remapDir .; if ($LASTEXITCODE) { Stop-Run 'tar (metadata) failed' }
  Write-Log ("  archives: git {0:N2} GB, metadata {1:N2} GB" -f ((Get-Item $gitTar).Length / 1GB), ((Get-Item $metaTar).Length / 1GB))
  Complete-Stage 'archive'
}
# ---- import
if (-not (Test-Done 'import')) {
  $exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/$TargetOrg/$TargetName" -Headers $tgtApi; $true } catch { $false }
  if ($exists -and -not $state.migrationId) { Stop-Run "$TargetOrg/$TargetName already exists - nothing imported" }
  $org =(Invoke-Gql $tgtApi 'query($l:String!){ organization(login:$l){ id databaseId } }' @{ l = $TargetOrg }).organization
  function Send-Archive($path) {
    $name = Split-Path $path -Leaf; $size = (Get-Item $path).Length; $up = 'https://uploads.github.com'
    $start = Invoke-WebRequest -Method POST "$up/organizations/$($org.databaseId)/gei/archive/blobs/uploads" -Headers $tgtApi -ContentType application/json `
             -Body (@{ content_type = 'application/octet-stream'; name = "$Repo-$name"; size = $size } | ConvertTo-Json) -UseBasicParsing
    $next = $start.Headers.Location; $guid = [regex]::Match($next, 'guid=([^&]+)').Groups[1].Value
    if (-not $guid) { throw "no upload guid for $name" }
    $chunk = 100MB; $buf = New-Object byte[] $chunk; $fs = [IO.File]::OpenRead($path); $part = 0
    try {
      while (($n = $fs.Read($buf, 0, $chunk)) -gt 0) {
        $part++; $payload = $buf
        if ($n -lt $chunk) { $payload = New-Object byte[] $n; [Array]::Copy($buf, $payload, $n) }
        for ($try = 1; ; $try++) {
          try { $resp = Invoke-WebRequest -Method PATCH "$up$next" -Headers $tgtApi -ContentType application/octet-stream -Body $payload -UseBasicParsing; break }
          catch { if ($try -ge 5) { throw }; Write-Log "    part $part retry $try : $($_.Exception.Message)"; Start-Sleep (10 * $try) }
        }
        $next = $resp.Headers.Location
      }
    } finally { $fs.Close() }
    $null = Invoke-WebRequest -Method PUT "$up$next" -Headers $tgtApi -ContentType application/octet-stream -Body ([byte[]]@()) -UseBasicParsing
    Write-Log "  uploaded $name ($part parts)"
    "gei://archive/$guid"
  }
  foreach ($p in 'git', 'metadata') { $k = "${p}Url"; if (-not $state.$k) { Set-State $k (Send-Archive (Join-Path $Work "import-$p.tar.gz")) } }
  if (-not $state.migrationId) {
    $srcId = (Invoke-Gql $tgtApi 'mutation($o:ID!,$n:String!){ createMigrationSource(input:{name:$n, url:"https://github.com", ownerId:$o, type:GITHUB_ARCHIVE}){ migrationSource { id } } }' @{ o = $org.id; n = "$Repo hand-built archive" }).createMigrationSource.migrationSource.id
    $q = 'mutation($s:ID!,$o:ID!,$u:URI!,$n:String!,$g:String!,$m:String!,$a:String!,$p:String!){ startRepositoryMigration(input:{sourceId:$s, ownerId:$o, sourceRepositoryUrl:$u, repositoryName:$n, continueOnError:true, gitArchiveUrl:$g, metadataArchiveUrl:$m, accessToken:$a, githubPat:$p, targetRepoVisibility:"private"}){ repositoryMigration { id state } } }'
    $mig = (Invoke-Gql $tgtApi $q @{ s = $srcId; o = $org.id; u = "https://github.com/fin-tcm/$Repo"; n = $TargetName; g = $state.gitUrl; m = $state.metadataUrl; a = $env:GH_SRC_PAT; p = $env:GH_TGT_PAT }).startRepositoryMigration.repositoryMigration
    Set-State migrationId $mig.id; Set-State importStarted (Get-Date).ToString('s'); Write-Log "  migration queued: $($mig.id)"
  }
  $t0 = [datetime]$state.importStarted; $last = ''
  while ($true) {
    $mr = (Invoke-Gql $tgtApi 'query($i:ID!){ node(id:$i){ ... on RepositoryMigration { state failureReason migrationLogUrl warningsCount } } }' @{ i = $state.migrationId }).node
    if ($mr.state -ne $last) { Write-Log ("  import state {0} after {1:N0} min" -f $mr.state, ((Get-Date) - $t0).TotalMinutes); $last = $mr.state }
    if ($mr.state -in 'SUCCEEDED', 'FAILED') { break }
    Start-Sleep 60
  }
  Write-Log "  import $($mr.state) in $([int]((Get-Date) - $t0).TotalMinutes) min; warnings $($mr.warningsCount); $($mr.failureReason)"
  if ($mr.migrationLogUrl) { try { Invoke-WebRequest $mr.migrationLogUrl -OutFile (Join-Path $Work 'migration-log.txt') -UseBasicParsing } catch { } }
  if ($mr.state -ne 'SUCCEEDED') { Stop-Run 'import failed - see migration-log.txt' }
  Complete-Stage 'import'
}
# ---- LFS objects
if (-not (Test-Done 'lfs')) {
  # the importer can still archive the new repo (the metadata archive carries the source's archived flag); the LFS
  # push needs it writable. It is archived again after verify when the source is archived.
  $tr = Invoke-RestMethod "https://api.github.com/repos/$TargetOrg/$TargetName" -Headers $tgtApi
  if ($tr.archived) {
    $null = Invoke-RestMethod -Method Patch "https://api.github.com/repos/$TargetOrg/$TargetName" -Headers $tgtApi -Body '{"archived":false}' -ContentType application/json
    Write-Log '  imported repo was archived: unarchived it for the LFS push'; Start-Sleep 10
  }
  $oids =@(Get-ChildItem (Join-Path $rwGit 'lfs\objects') -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^[0-9a-f]{64}$' } | ForEach-Object Name)
  $env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'
  $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT")); $env:GIT_CONFIG_COUNT = '1'
  if ($oids.Count) { git -C $rwGit lfs push --object-id "https://github.com/$TargetOrg/$TargetName.git" @oids 2>&1 | Select-Object -Last 2 | ForEach-Object { Write-Log "  lfs: $_" } }
  $lfsRc = $LASTEXITCODE; $env:GIT_CONFIG_COUNT = '0'
  Write-Log "  LFS objects pushed: $($oids.Count) (exit $lfsRc)"
  if ($oids.Count -and $lfsRc) { Stop-Run 'LFS push failed' }
  Complete-Stage 'lfs'
}
# ---- verify (read-only)
if (-not (Test-Done 'verify')) {
  $tot = foreach ($x in @(@('fin-tcm', $Repo, $srcApi), @($TargetOrg, $TargetName, $tgtApi))) {
    $d = (Invoke-Gql $x[2] "{ repository(owner:`"$($x[0])`", name:`"$($x[1])`") { o:pullRequests(states:OPEN){totalCount} m:pullRequests(states:MERGED){totalCount} c:pullRequests(states:CLOSED){totalCount} } }").repository
    $line = "{0,-45} open {1,5} merged {2,6} closed {3,6}" -f "$($x[0])/$($x[1])", $d.o.totalCount, $d.m.totalCount, $d.c.totalCount; Write-Log "  $line"
    $d.o.totalCount + $d.m.totalCount + $d.c.totalCount }
  Set-State prSource $tot[0]; Set-State prTarget $tot[1]
  $env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'
  $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT")); $env:GIT_CONFIG_COUNT = '1'
  $tg = @{}; git ls-remote --heads --tags "https://github.com/$TargetOrg/$TargetName.git" | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notlike '*^{}') { $tg[$p[1]] = $p[0] } }
  $env:GIT_CONFIG_COUNT = '0'
  $rw = @{}; git -C $rwGit for-each-ref --format="%(objectname)`t%(refname)" refs/heads refs/tags | ForEach-Object { $p = $_ -split "`t"; $rw[$p[1]] = $p[0] }
  $miss = @($rw.Keys | Where-Object { -not $tg.ContainsKey($_) }).Count; $diff = @($rw.Keys | Where-Object { $tg.ContainsKey($_) -and $tg[$_] -ne $rw[$_] }).Count
  Write-Log "  refs: rewritten $($rw.Count), in target $($tg.Count), missing $miss, different $diff"
  # every PR, both sides: state + review / comment / review-thread counts
  function Get-PrStats($owner, $name, $hdr) {
    $all = @{}; $cursor = $null
    do {
      $after = if ($cursor) { ", after:`"$cursor`"" } else { '' }
      $page = (Invoke-Gql $hdr "{ repository(owner:`"$owner`", name:`"$name`") { pullRequests(first:100$after){ pageInfo{hasNextPage endCursor} nodes { number state reviews{totalCount} comments{totalCount} reviewThreads{totalCount} } } } }").repository.pullRequests
      $page.nodes | ForEach-Object { $all[[int]$_.number] = "$($_.state) rev=$($_.reviews.totalCount) com=$($_.comments.totalCount) thr=$($_.reviewThreads.totalCount)" }
      $cursor = $page.pageInfo.endCursor
    } while ($page.pageInfo.hasNextPage)
    $all }
  $sideA = Get-PrStats 'fin-tcm' $Repo $srcApi; $sideB = Get-PrStats $TargetOrg $TargetName $tgtApi
  $diffPr = @($sideA.Keys | Where-Object { $sideB[$_] -ne $sideA[$_] } | Sort-Object)
  $diffPr | Select-Object -First 25 | ForEach-Object { Write-Log "  PR #$_  fin: $($sideA[$_]) | tcm: $(if ($sideB.ContainsKey($_)) { $sideB[$_] } else { 'MISSING' })" }
  Write-Log "  PRs identical (state, reviews, comments, threads): $($sideA.Count - $diffPr.Count) of $($sideA.Count)"
  Set-State prIdentical ($sideA.Count - $diffPr.Count)
  if ($state.sourceArchived) {
    $null = Invoke-RestMethod -Method Patch "https://api.github.com/repos/$TargetOrg/$TargetName" -Headers $tgtApi -Body '{"archived":true}' -ContentType application/json
    Write-Log "  archived $TargetOrg/$TargetName (as in Finastra)"
  }
  Complete-Stage 'verify'
}
# ---- cleanup: only this run's own big intermediates
if (-not (Test-Done 'cleanup')) {
  foreach ($p in $exportTar, (Join-Path $Work 'import-git.tar.gz'), (Join-Path $Work 'import-metadata.tar.gz'), $exportDir, $rwGit) { if (Test-Path $p) { Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue } }
  Write-Log ("  cleaned; work folder now {0:N2} GB" -f ((Get-ChildItem $Work -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1GB))
  Complete-Stage 'cleanup'
}
Write-Log "=== $Repo done: PRs Finastra $($state.prSource), $TargetOrg/$TargetName $($state.prTarget) ==="
