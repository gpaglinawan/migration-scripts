﻿Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
for ($i = 0; $i -lt 60; $i++) {
  try { $null = Invoke-RestMethod -Method Put "https://api.github.com/orgs/tcm-pilot/teams/kon_r/repos/tcm-pilot/KON-kplus-front" -Headers $gh -ContentType application/json -Body '{"permission":"pull"}'; "UNLOCKED $(Get-Date -Format HH:mm)"; exit 0 }
  catch { if ("$($_.ErrorDetails.Message)" -notmatch 'locked') { "OTHER $(Get-Date -Format HH:mm) $($_.ErrorDetails.Message)"; exit 1 } }
  Start-Sleep 120
}
"STILL LOCKED after 2h"
