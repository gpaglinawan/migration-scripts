﻿# 10 Nov 2026 (Gareth: "restore"): add to tcm-pilot the team->repo grants that fin-tcm has and tcm-pilot lacks (DEF-116 prep).
# Input grant-gaps.csv. Only adds/raises to the fin-tcm permission; never lowers or removes. Base permission NOT changed.
param([switch]$Apply)
$d = 'C:\kon-migration\rules\def116-impact-20261110'; $log = "$d\restore-grants.log"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$api = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$map = @{ read = 'pull'; write = 'push'; admin = 'admin'; maintain = 'maintain'; triage = 'triage' }
function W($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
W "=== restore grants, mode=$(if ($Apply) {'APPLY'} else {'DRY RUN'}) ==="
$res = foreach ($g in (Import-Csv "$d\grant-gaps.csv")) {
  $perm = if ($map.ContainsKey($g.SrcPerm)) { $map[$g.SrcPerm] } else { $g.SrcPerm }
  $u = "https://api.github.com/orgs/tcm-pilot/teams/$([uri]::EscapeDataString($g.Team))/repos/tcm-pilot/$($g.Repo)"
  $r = 'DRYRUN'
  if ($Apply) { try { Invoke-RestMethod -Method PUT $u -Headers $api -ContentType application/json -Body (@{ permission = $perm } | ConvertTo-Json) | Out-Null; $r = 'OK' }
               catch { $r = "ERROR $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" } }
  if ($r -ne 'OK') { W "$($g.Team) $($g.Repo) $perm : $r" }
  [pscustomobject]@{ Team = $g.Team; Repo = $g.Repo; Perm = $perm; Result = $r }
}
$res | Export-Csv "$d\restore-grants-results.csv" -NoTypeInformation -Encoding utf8
W "=== done: $(@($res | ? Result -eq 'OK').Count) OK, $(@($res | ? { $_.Result -like 'ERROR*' }).Count) errors of $(@($res).Count) ==="
