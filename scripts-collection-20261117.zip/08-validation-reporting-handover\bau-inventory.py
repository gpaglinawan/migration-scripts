# 16 Nov 2026 - BAU handover pack (Vamsi Thenneti's request). READ-ONLY inventory of a GitHub org into CSV/JSON:
#   org-settings.json, org-runners.csv, org-rulesets.csv, members.csv, teams.csv, team-members.csv,
#   repos.csv (settings, CODEOWNERS, branch protection, rulesets, environments, security, webhooks), repo-team-access.csv, repo-collaborators.csv
# Usage: python -I bau-inventory.py <org> <token-env-var> <out-dir>
import sys, os, json, csv, time, urllib.request, urllib.error
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ORG, TOKVAR, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
TOK = os.environ[TOKVAR]; os.makedirs(OUT, exist_ok=True)
def call(url, method='GET', body=None, accept='application/vnd.github+json', ok404=False):
    for att in range(10):
        try:
            r = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body is not None else None,
                                       headers={'Authorization': f'Bearer {TOK}', 'Accept': accept, 'Content-Type': 'application/json', 'X-GitHub-Api-Version': '2022-11-28'})
            t = urllib.request.urlopen(r, timeout=120).read(); return json.loads(t) if t else None
        except urllib.error.HTTPError as e:
            if e.code in (404, 410) and ok404: return None
            if e.code in (403, 409, 422) and ok404: return None
            if e.code in (403, 429, 502, 503, 504) and att < 9:
                ra = e.headers.get('Retry-After') if e.headers else None
                time.sleep(int(ra) + 5 if ra and ra.isdigit() else 30 * (att + 1)); continue
            raise
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
            if att < 9: time.sleep(60); continue
            raise
def pages(path, key=None, ok404=True):
    out, p = [], 1
    while True:
        b = call(f'https://api.github.com{path}{"&" if "?" in path else "?"}per_page=100&page={p}', ok404=ok404)
        if b is None: return out
        items = b.get(key, []) if key else b
        out += items
        if len(items) < 100: return out
        p += 1
def gql(q, v):
    d = call('https://api.github.com/graphql', 'POST', {'query': q, 'variables': v})
    return d.get('data') or {}
def write(name, rows, fields):
    with open(os.path.join(OUT, name), 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore'); w.writeheader(); w.writerows(rows)
    print(f'{name}: {len(rows)} rows', flush=True)
RESUME = os.path.exists(os.path.join(OUT, 'repo-team-access.csv'))   # 16 Nov: org/members/teams already collected -> repos only
if RESUME: print('resume: org, members and teams already collected', flush=True)
def head():
# ---- org
    org = call(f'https://api.github.com/orgs/{ORG}')
    settings = {k: org.get(k) for k in ('login', 'name', 'created_at', 'plan', 'default_repository_permission', 'members_can_create_repositories',
                'members_can_create_public_repositories', 'members_can_create_private_repositories', 'members_can_create_internal_repositories',
                'members_can_fork_private_repositories', 'two_factor_requirement_enabled', 'web_commit_signoff_required', 'members_can_create_pages',
                'advanced_security_enabled_for_new_repositories', 'dependabot_alerts_enabled_for_new_repositories', 'secret_scanning_enabled_for_new_repositories',
                'secret_scanning_push_protection_enabled_for_new_repositories', 'public_repos', 'total_private_repos', 'owned_private_repos')}
    settings['actions_permissions'] = call(f'https://api.github.com/orgs/{ORG}/actions/permissions', ok404=True)
    settings['actions_workflow_permissions'] = call(f'https://api.github.com/orgs/{ORG}/actions/permissions/workflow', ok404=True)
    settings['actions_selected_actions'] = call(f'https://api.github.com/orgs/{ORG}/actions/permissions/selected-actions', ok404=True)
    settings['copilot_billing'] = call(f'https://api.github.com/orgs/{ORG}/copilot/billing', ok404=True)
    settings['custom_repository_roles'] = (call(f'https://api.github.com/orgs/{ORG}/custom-repository-roles', ok404=True) or {}).get('custom_roles')
    settings['security_manager_teams'] = [t.get('slug') for t in (call(f'https://api.github.com/orgs/{ORG}/security-managers', ok404=True) or [])]
    settings['org_webhooks'] = [{'url': (h.get('config') or {}).get('url'), 'events': h.get('events'), 'active': h.get('active')} for h in pages(f'/orgs/{ORG}/hooks')]
    ip = gql('query($o:String!){organization(login:$o){ipAllowListEnabledSetting ipAllowListForInstalledAppsEnabledSetting ipAllowListEntries(first:100){totalCount nodes{allowListValue name isActive}}}}', {'o': ORG})
    settings['ip_allow_list'] = (ip.get('organization') or {})
    rg = (call(f'https://api.github.com/orgs/{ORG}/actions/runner-groups?per_page=100', ok404=True) or {}).get('runner_groups', [])
    settings['runner_groups'] = [{'name': g.get('name'), 'visibility': g.get('visibility'), 'default': g.get('default'), 'allows_public_repositories': g.get('allows_public_repositories')} for g in rg]
    runners = pages(f'/orgs/{ORG}/actions/runners', key='runners')
    write('org-runners.csv', [{'name': r.get('name'), 'os': r.get('os'), 'status': r.get('status'), 'busy': r.get('busy'),
          'labels': ';'.join(l.get('name') for l in r.get('labels', []))} for r in runners], ['name', 'os', 'status', 'busy', 'labels'])
    orgrs = []
    for rs in pages(f'/orgs/{ORG}/rulesets'):
        d = call(f'https://api.github.com/orgs/{ORG}/rulesets/{rs["id"]}', ok404=True) or rs
        orgrs.append({'id': d.get('id'), 'name': d.get('name'), 'target': d.get('target'), 'enforcement': d.get('enforcement'),
                      'refs_include': ';'.join(((d.get('conditions') or {}).get('ref_name') or {}).get('include', [])),
                      'repos_include': ';'.join(((d.get('conditions') or {}).get('repository_name') or {}).get('include', [])),
                      'repos_exclude': ';'.join(((d.get('conditions') or {}).get('repository_name') or {}).get('exclude', [])),
                      'rules': ';'.join(x.get('type') for x in d.get('rules', [])),
                      'bypass': ';'.join(f"{b.get('actor_type')}:{b.get('actor_id')}/{b.get('bypass_mode')}" for b in d.get('bypass_actors', []) or [])})
    write('org-rulesets.csv', orgrs, list(orgrs[0].keys()) if orgrs else ['name'])
    json.dump(settings, open(os.path.join(OUT, 'org-settings.json'), 'w', encoding='utf-8'), indent=2, default=str); print('org-settings.json written', flush=True)
    # ---- members
    mem = []
    for role in ('admin', 'member'):
        for m in pages(f'/orgs/{ORG}/members?role={role}'): mem.append({'login': m['login'], 'org_role': role})
    names, cur = {}, None
    while True:
        d = gql('query($o:String!,$c:String){organization(login:$o){membersWithRole(first:100,after:$c){pageInfo{hasNextPage endCursor} nodes{login name}}}}', {'o': ORG, 'c': cur})
        mw = (d.get('organization') or {}).get('membersWithRole') or {}
        for n in mw.get('nodes', []): names[n['login']] = n.get('name') or ''
        if not (mw.get('pageInfo') or {}).get('hasNextPage'): break
        cur = mw['pageInfo']['endCursor']
    for m in mem: m['name'] = names.get(m['login'], '')
    write('members.csv', mem, ['login', 'name', 'org_role'])
    # ---- teams
    teams = pages(f'/orgs/{ORG}/teams'); trows, tmem, tacc = [], [], []
    for t in teams:
        s = t['slug']; maint = {m['login'] for m in pages(f'/orgs/{ORG}/teams/{s}/members?role=maintainer')}
        allm = pages(f'/orgs/{ORG}/teams/{s}/members?role=all')
        for m in allm: tmem.append({'team': s, 'login': m['login'], 'team_role': 'maintainer' if m['login'] in maint else 'member'})
        repos = pages(f'/orgs/{ORG}/teams/{s}/repos')
        for r in repos:
            p = r.get('role_name') or next((k for k in ('admin', 'maintain', 'push', 'triage', 'pull') if (r.get('permissions') or {}).get(k)), '')
            tacc.append({'repo': r['name'], 'team': s, 'permission': p})
        trows.append({'team': s, 'name': t.get('name'), 'parent': (t.get('parent') or {}).get('slug', ''), 'privacy': t.get('privacy'),
                      'notification': t.get('notification_setting'), 'members': len(allm), 'maintainers': len(maint), 'repos': len(repos), 'description': t.get('description') or ''})
    write('teams.csv', trows, ['team', 'name', 'parent', 'privacy', 'notification', 'members', 'maintainers', 'repos', 'description'])
    write('team-members.csv', tmem, ['team', 'login', 'team_role'])
    write('repo-team-access.csv', tacc, ['repo', 'team', 'permission'])
if not RESUME: head()
# ---- repos (REST list for security settings, GraphQL batches for the rest)
rest = {r['name']: r for r in pages(f'/orgs/{ORG}/repos?type=all')}
names_ = sorted(rest)
FR = '''visibility isArchived diskUsage createdAt pushedAt defaultBranchRef{name} repositoryTopics(first:20){nodes{topic{name}}}
 c1:object(expression:"HEAD:.github/CODEOWNERS"){id} c2:object(expression:"HEAD:CODEOWNERS"){id} c3:object(expression:"HEAD:docs/CODEOWNERS"){id}
 branchProtectionRules(first:30){nodes{pattern requiresApprovingReviews requiredApprovingReviewCount requiresCodeOwnerReviews isAdminEnforced allowsForcePushes allowsDeletions requiresStatusChecks}}
 rulesets(first:20){nodes{name enforcement target}} environments{totalCount}
 collaborators(affiliation:DIRECT,first:100){edges{permission node{login}}}'''
rrows, crows = [], []
for i in range(0, len(names_), 20):
    chunk = names_[i:i + 20]
    q = 'query{' + ' '.join(f'r{j}:repository(owner:"{ORG}",name:{json.dumps(n)}){{{FR}}}' for j, n in enumerate(chunk)) + '}'
    try: d = gql(q, {})
    except Exception as e: print('batch error', e, flush=True); d = {}
    for j, n in enumerate(chunk):
        g = d.get(f'r{j}') or {}; r = rest[n]; sa = r.get('security_and_analysis') or {}
        co = '.github/CODEOWNERS' if g.get('c1') else 'CODEOWNERS' if g.get('c2') else 'docs/CODEOWNERS' if g.get('c3') else ''
        bp = [b for b in ((g.get('branchProtectionRules') or {}).get('nodes') or []) if b]
        rrows.append({'repo': n, 'visibility': r.get('visibility'), 'archived': r.get('archived'), 'default_branch': r.get('default_branch'),
            'size_mb': round((r.get('size') or 0) / 1024, 1), 'created': (r.get('created_at') or '')[:10], 'last_push': (r.get('pushed_at') or '')[:10],
            'topics': ';'.join(r.get('topics') or []), 'description': (r.get('description') or '').replace('\n', ' '),
            'codeowners': co, 'branch_protection_rules': len(bp),
            'branch_protection_patterns': ';'.join(f"{b['pattern']}(reviews={b['requiredApprovingReviewCount'] if b['requiresApprovingReviews'] else 0}{',codeowners' if b['requiresCodeOwnerReviews'] else ''}{',checks' if b['requiresStatusChecks'] else ''}{',admins' if b['isAdminEnforced'] else ''})" for b in bp),
            'repo_rulesets': ';'.join(f"{x['name']}({x['target']},{x['enforcement']})" for x in ((g.get('rulesets') or {}).get('nodes') or []) if x),
            'environments': (g.get('environments') or {}).get('totalCount', ''),
            'code_security': (sa.get('code_security') or sa.get('advanced_security') or {}).get('status', ''),
            'secret_scanning': (sa.get('secret_scanning') or {}).get('status', ''), 'push_protection': (sa.get('secret_scanning_push_protection') or {}).get('status', ''),
            'dependabot_updates': (sa.get('dependabot_security_updates') or {}).get('status', ''),
            'direct_collaborators': len([e for e in ((g.get('collaborators') or {}).get('edges') or []) if e]), 'webhooks': ''})
        for e in ((g.get('collaborators') or {}).get('edges') or []):
            if e and e.get('node'): crows.append({'repo': n, 'login': e['node']['login'], 'permission': (e.get('permission') or '').lower()})
    if i % 200 == 0: print(f'repos {i}/{len(names_)}', flush=True)
# webhooks per active (non-archived) repo
for row in rrows:
    if row['archived']: continue
    hooks = call(f'https://api.github.com/repos/{ORG}/{row["repo"]}/hooks?per_page=100', ok404=True) or []
    row['webhooks'] = ';'.join((h.get('config') or {}).get('url', '') for h in hooks)
write('repos.csv', rrows, list(rrows[0].keys()))
write('repo-collaborators.csv', crows, ['repo', 'login', 'permission'])
print('=== done ===', flush=True)
