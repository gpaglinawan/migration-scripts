param(
  [string[]]$Repos = @('SFX-netcore-common','KON-doc-kondor-archive','FWK-utfinstaller','OPICS-programmers','MAFTP-fpp-fusioncapital',
                       'FCGC-pricing-analytics','RISK-cmr','FCBO-fusion-detect-core','KON-kplus-front'),
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out    = "C:\verify-rewritten",
  [switch]$IncludeTags
)
# READ-ONLY content check of the repos that were rewritten for large files (their commit SHAs differ from Finastra by design).
# For every branch (and tag with -IncludeTags) present in both orgs, compares the tip's full file tree:
#   - every path must exist on both sides with the same blob, OR
#   - the Teciem side is a Git LFS pointer whose sha256/size equal the Finastra file, AND that LFS object is downloadable from Teciem.
# Tips whose commit metadata differ (Teciem not yet resynced) are reported as TARGET_BEHIND, not compared.
# Writes nothing to GitHub. Needs: Git for Windows 2.45+, env vars GH_SRC_PAT (read on fin-tcm) and GH_TGT_PAT (read on tcm-pilot).
# Resumable: repos already in summary.csv are skipped. Split the -Repos list across machines.
$ErrorActionPreference = "Continue"
if (-not $env:GH_SRC_PAT -or -not $env:GH_TGT_PAT) { throw "set `$env:GH_SRC_PAT and `$env:GH_TGT_PAT first" }
[Console]::OutputEncoding = [Text.Encoding]::UTF8
function Basic($p) { [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$p")) }
$srcHdr = "AUTHORIZATION: basic $(Basic $env:GH_SRC_PAT)"; $tgtHdr = "AUTHORIZATION: basic $(Basic $env:GH_TGT_PAT)"
$env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = $srcHdr; $env:GIT_TERMINAL_PROMPT = "0"
# same path renames the rewrite used (committed .git folders GitHub rejects)
$renames = @{ 'SFX-netcore-common' = @('QuickFixn/.git/:QuickFixn/_git/') }

New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "verify.log"; $sumFile = Join-Path $Out "summary.csv"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
$done = @{}; if (Test-Path $sumFile) { Import-Csv $sumFile | ForEach-Object { $done[$_.Repo] = $true } }

function Fetch($dir, $url, $hdr) {
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  git init --bare -q --ref-format=reftable $dir; git -C $dir config core.longpaths true; git -C $dir config core.protectNTFS false
  $env:GIT_CONFIG_VALUE_0 = $hdr
  $specs = @('+refs/heads/*:refs/heads/*'); if ($IncludeTags) { $specs += '+refs/tags/*:refs/tags/*' }
  git -C $dir fetch -q --depth 1 --no-tags $url @specs 2>$null   # tips only: history is not needed for a content check
  return ($LASTEXITCODE -eq 0)
}
function Tree($dir, $ref) {
  $t = @{}
  $raw = (git -C $dir ls-tree -r -z --full-tree $ref) -join "`n"
  foreach ($e in $raw -split "`0") { if ($e -match '^(\d+) (\w+) ([0-9a-f]+)\t(.+)$') { $t[$Matches[4]] = $Matches[3] } }
  return $t
}
function Meta($dir, $ref) { (git -C $dir log -1 --format="%an|%ae|%at|%ct|%s" $ref) -join '' }
function Sha256Blob($dir, $oid) {   # streams the blob, so GB-sized files never sit in memory
  $psi = New-Object Diagnostics.ProcessStartInfo "git", "-C `"$dir`" cat-file blob $oid"
  $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true
  $p = [Diagnostics.Process]::Start($psi)
  $sha = [Security.Cryptography.SHA256]::Create(); $h = $sha.ComputeHash($p.StandardOutput.BaseStream); $p.WaitForExit()
  ([BitConverter]::ToString($h) -replace '-', '').ToLower()
}
function LfsMissing($repo, $objs) {   # asks the Teciem LFS server which pointer objects it cannot serve
  $miss = @()
  $hdr = @{ Authorization = "Basic $(Basic $env:GH_TGT_PAT)"; Accept = "application/vnd.git-lfs+json" }
  for ($i = 0; $i -lt $objs.Count; $i += 100) {
    $chunk = @($objs[$i..([Math]::Min($i + 99, $objs.Count - 1))])
    $body = @{ operation = "download"; transfers = @("basic"); objects = @($chunk | ForEach-Object { @{ oid = $_.oid; size = [long]$_.size } }) } | ConvertTo-Json -Depth 4
    try { $r = Invoke-RestMethod -Method POST "https://github.com/$TgtOrg/$repo.git/info/lfs/objects/batch" -Headers $hdr -Body $body -ContentType "application/vnd.git-lfs+json"
          $miss += @($r.objects | Where-Object { -not $_.actions } | ForEach-Object oid) }
    catch { Log "  LFS batch call failed: $($_.Exception.Message)"; $miss += @($chunk | ForEach-Object oid) }
  }
  $miss
}

foreach ($repo in $Repos) {
  if ($done[$repo]) { Log "skip $repo (already in summary)"; continue }
  Log "=== $repo ==="
  $src = Join-Path $Out "work\$repo-src.git"; $tgt = Join-Path $Out "work\$repo-tgt.git"
  if (-not (Fetch $src "https://github.com/$SrcOrg/$repo.git" $srcHdr)) { Log "FETCH FAILED source"; continue }
  if (-not (Fetch $tgt "https://github.com/$TgtOrg/$repo.git" $tgtHdr)) { Log "FETCH FAILED target"; continue }
  $detail = Join-Path $Out "$repo-problems.txt"; Remove-Item $detail -ErrorAction SilentlyContinue
  $srcRefs = @(git -C $src for-each-ref --format="%(refname)"); $tgtRefs = @(git -C $tgt for-each-ref --format="%(refname)")
  $hashCache = @{}; $ptrCache = @{}; $lfsObjs = @{}
  $c = [ordered]@{ Repo = $repo; Refs = 0; OK = 0; TargetBehind = 0; ContentDiff = 0; MissingInTarget = @($srcRefs | Where-Object { $_ -notin $tgtRefs }).Count; LfsPointers = 0; LfsMissing = 0 }
  foreach ($ref in @($srcRefs | Where-Object { $_ -in $tgtRefs })) {
    $c.Refs++
    if ((Meta $src $ref) -ne (Meta $tgt $ref)) { $c.TargetBehind++; Add-Content $detail "TARGET_BEHIND $ref" -Encoding utf8; continue }
    $s = Tree $src $ref; $t = Tree $tgt $ref
    if ($renames[$repo]) { $s2 = @{}; foreach ($k in $s.Keys) { $nk = $k; foreach ($rn in $renames[$repo]) { $f, $to = $rn -split ':', 2; if ($nk.StartsWith($f)) { $nk = $to + $nk.Substring($f.Length) } }; $s2[$nk] = $s[$k] }; $s = $s2 }
    $bad = @()
    foreach ($p in $s.Keys) {
      if (-not $t.ContainsKey($p)) { $bad += "missing in target: $p"; continue }
      if ($s[$p] -eq $t[$p]) { continue }
      $to = $t[$p]
      if (-not $ptrCache.ContainsKey($to)) {
        $txt = if ([long](git -C $tgt cat-file -s $to) -lt 1024) { (git -C $tgt cat-file -p $to) -join "`n" } else { "" }
        $ptrCache[$to] = if ($txt -match 'oid sha256:([0-9a-f]{64})\s+size (\d+)') { @{ oid = $Matches[1]; size = $Matches[2] } } else { $null }
      }
      $ptr = $ptrCache[$to]
      if (-not $ptr) { $bad += "content differs (not an LFS pointer): $p"; continue }
      if (-not $hashCache.ContainsKey($s[$p])) { $hashCache[$s[$p]] = @{ sha = (Sha256Blob $src $s[$p]); size = (git -C $src cat-file -s $s[$p]) } }
      $h = $hashCache[$s[$p]]
      if ($h.sha -ne $ptr.oid -or "$($h.size)" -ne "$($ptr.size)") { $bad += "LFS pointer does not match Finastra file: $p"; continue }
      $lfsObjs[$ptr.oid] = $ptr
    }
    foreach ($p in $t.Keys) { if (-not $s.ContainsKey($p)) { $bad += "extra in target: $p" } }
    if ($bad.Count) { $c.ContentDiff++; Add-Content $detail "CONTENT_DIFF $ref ($($bad.Count))" -Encoding utf8; $bad | Select-Object -First 50 | ForEach-Object { Add-Content $detail "    $_" -Encoding utf8 } }
    else { $c.OK++ }
  }
  $c.LfsPointers = $lfsObjs.Count
  if ($lfsObjs.Count) { $miss = @(LfsMissing $repo @($lfsObjs.Values)); $c.LfsMissing = $miss.Count; $miss | ForEach-Object { Add-Content $detail "LFS_NOT_ON_TECIEM $_" -Encoding utf8 } }
  $c.MissingInTarget | Out-Null
  @($srcRefs | Where-Object { $_ -notin $tgtRefs }) | ForEach-Object { Add-Content $detail "REF_MISSING_IN_TARGET $_" -Encoding utf8 }
  Log ("{0}: refs={1} ok={2} behind={3} diff={4} missing-refs={5} lfs={6} lfs-missing={7}" -f $repo, $c.Refs, $c.OK, $c.TargetBehind, $c.ContentDiff, $c.MissingInTarget, $c.LfsPointers, $c.LfsMissing)
  [pscustomobject]$c | Export-Csv $sumFile -Append -NoTypeInformation -Encoding utf8
  Remove-Item $src, $tgt -Recurse -Force -ErrorAction SilentlyContinue
}
Log "=== done - results: $sumFile, per-repo *-problems.txt ==="
