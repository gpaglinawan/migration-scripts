# TO-treasury-installer: adds the Finastra commits that tcm-pilot doesn't have yet on top of tcm-pilot's existing
# (LFS-rewritten, 18 Oct) history, so every branch can move forward without a force push.
# LOCAL ONLY - nothing is pushed. Output: refs/out/* in graft.git, plan.csv, lfs-oids.txt, graft.log.
#   1. fetch Finastra originals (orig\), our git-lfs-migrate rewrite (rewrite\) and tcm-pilot into graft.git
#   2. match rewrite commits to tcm-pilot commits by author + committer + message + (matched) parents
#   3. every unmatched commit is recreated with the rewrite's tree (ui/core as LFS pointer) on matched parents
#   4. check each recreated commit differs from its Finastra original only in .gitattributes and ui/core
#   5. plan per branch/tag: create / fast-forward / same / skip (diverged, target ahead, only in tcm-pilot)
# Run with: C:\kon-migration\tools\python\python.exe -I graft-onto-target.py
import base64, collections, csv, datetime, os, re, subprocess, sys

G = r"C:\Users\u739260\AppData\Local\Programs\Git\cmd\git.exe"
W = os.environ.get("GRAFT_W", r"C:\kon-migration\bigfiles-TO-treasury-installer")   # work dir (orig\, rewrite\, graft.git)
R = os.path.join(W, "graft.git")
TGT_URL = "https://github.com/tcm-pilot/TO-treasury-installer.git"
LOG = os.path.join(W, "graft.log")
ALLOWED = {b".gitattributes", b"ui/core"}


def log(m):
    line = "[%s] %s" % (datetime.datetime.now().strftime("%H:%M:%S"), m)
    print(line, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def git(*a, inp=None, env=None):
    r = subprocess.run([G, "-C", R, *a], input=inp, capture_output=True, env=env)
    if r.returncode:
        log("FATAL: git %s: %s" % (" ".join(a[:4]), r.stderr.decode(errors="replace").strip()))
        sys.exit(1)
    return r.stdout


def git_rc(*a):
    return subprocess.run([G, "-C", R, *a], capture_output=True).returncode


def target_env():
    pats = {}
    for line in open(r"C:\development\pats.txt", encoding="utf-8-sig"):
        m = re.match(r'^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$', line)
        if m:
            pats[m.group(1)] = m.group(2)
    tok = base64.b64encode(("x-access-token:" + pats["GH_TGT_PAT"]).encode()).decode()
    return dict(os.environ, GIT_TERMINAL_PROMPT="0", GIT_CONFIG_COUNT="1",
                GIT_CONFIG_KEY_0="http.https://github.com/.extraheader",
                GIT_CONFIG_VALUE_0="AUTHORIZATION: basic " + tok)


def read_objects(shas):
    p = subprocess.Popen([G, "-C", R, "cat-file", "--batch"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    out = {}
    for s in shas:
        p.stdin.write(s.encode() + b"\n")
        p.stdin.flush()
        size = int(p.stdout.readline().split()[2])
        out[s] = p.stdout.read(size)
        p.stdout.read(1)
    p.stdin.close()
    p.wait()
    return out


Commit = collections.namedtuple("Commit", "tree parents author committer extra msg")


def parse_commit(raw):
    head, _, msg = raw.partition(b"\n\n")
    hdrs = []
    for line in head.split(b"\n"):
        if line.startswith(b" ") and hdrs:          # continuation (gpgsig / mergetag)
            hdrs[-1][1] += b"\n" + line
        else:
            k, _, v = line.partition(b" ")
            hdrs.append([k, v])
    get = lambda k: [v for kk, v in hdrs if kk == k]
    # encoding is kept; signatures (gpgsig, mergetag) can't survive a rewrite and are dropped
    extra = b"".join(k + b" " + v + b"\n" for k, v in hdrs if k == b"encoding")
    return Commit(get(b"tree")[0].decode(), [p.decode() for p in get(b"parent")],
                  get(b"author")[0], get(b"committer")[0], extra, msg)


def commits(glob):
    order = git("rev-list", "--topo-order", "--reverse", "--glob=" + glob).decode().split()
    raw = read_objects(order)
    return order, {c: parse_commit(raw[c]) for c in order}


def struct_map(src_order, src, dst, crlf=False):
    """src commit -> dst commit with the same author, committer, message and (already matched) parents.
    crlf=True: compare messages the way git lfs migrate writes them (CRLF -> LF, always ending in a newline)."""
    norm = (lambda b: b.replace(b"\r\n", b"\n").rstrip(b"\n")) if crlf else (lambda b: b)
    idx = {}
    for c, i in dst.items():
        idx.setdefault((i.author, i.committer, norm(i.msg), tuple(i.parents)), c)
    m = {}
    for c in src_order:
        i = src[c]
        ps = tuple(m.get(p) for p in i.parents)
        if None in ps:
            continue
        hit = idx.get((i.author, i.committer, norm(i.msg), ps))
        if hit:
            m[c] = hit
    return m


def refs(prefix):
    out = {}
    for line in git("for-each-ref", "--format=%(objectname) %(objecttype) %(refname)", prefix).decode().splitlines():
        sha, typ, name = line.split(" ", 2)
        out[name[len(prefix):]] = (sha, typ)
    return out


def peel(ref):
    return git("rev-parse", ref + "^{commit}").decode().strip()


def when(i):
    return datetime.datetime.fromtimestamp(int(i.committer.rsplit(b" ", 2)[1])).strftime("%Y-%m-%d")


# 1. fetch
os.makedirs(W, exist_ok=True)
log("=== graft TO-treasury-installer (local only) ===")
if not os.path.isdir(R):
    subprocess.run([G, "init", "--bare", "-q", R], check=True)
git("fetch", "-q", "--no-tags", os.path.join(W, "orig"), "+refs/heads/*:refs/orig/heads/*", "+refs/tags/*:refs/orig/tags/*")
git("fetch", "-q", "--no-tags", os.path.join(W, "rewrite"), "+refs/heads/*:refs/rw/heads/*", "+refs/tags/*:refs/rw/tags/*")
git("fetch", "-q", "--no-tags", TGT_URL, "+refs/heads/*:refs/tgt/heads/*", "+refs/tags/*:refs/tgt/tags/*", env=target_env())
stale = git("for-each-ref", "--format=delete %(refname)", "refs/out/")
if stale:
    git("update-ref", "--stdin", inp=stale)

# 2. match
rw_order, rw = commits("refs/rw/*")
_, tgt = commits("refs/tgt/*")
orig_order, orig = commits("refs/orig/*")
m = struct_map(rw_order, rw, tgt)
rw2orig = {v: k for k, v in struct_map(orig_order, orig, rw, crlf=True).items()}
log("Finastra originals matched to rewrite: %d of %d" % (len(rw2orig), len(orig_order)))
log("commits: Finastra(rewritten) %d, tcm-pilot %d, matched %d, to create %d"
    % (len(rw_order), len(tgt), len(m), len(rw_order) - len(m)))
same_tree = sum(1 for c, t in m.items() if rw[c].tree == tgt[t].tree)
log("matched commits with identical files: %d of %d (older ones differ only by the .gitattributes line)" % (same_tree, len(m)))

# 3. recreate
created = []
for c in rw_order:
    if c in m:
        continue
    i = rw[c]
    raw = (b"tree " + i.tree.encode() + b"\n" + b"".join(b"parent " + m[p].encode() + b"\n" for p in i.parents)
           + b"author " + i.author + b"\ncommitter " + i.committer + b"\n" + i.extra + b"\n" + i.msg)
    m[c] = git("hash-object", "-t", "commit", "-w", "--stdin", inp=raw).decode().strip()
    created.append(c)
by_day = collections.Counter(when(rw[c]) for c in created)
log("created %d commits, by commit date: %s" % (len(created), ", ".join("%s=%d" % kv for kv in sorted(by_day.items()))))

# 4. verify against Finastra originals + collect LFS objects
bad = 0
lfs = set()
for c in created:
    o = rw2orig.get(c)
    if not o:
        log("  VERIFY: no Finastra original found for %s" % c); bad += 1; continue
    paths = set(git("diff-tree", "-r", "--name-only", "--no-commit-id", o, m[c]).split(b"\n")) - {b""}
    if paths - ALLOWED:
        log("  VERIFY: %s differs from Finastra %s in %s" % (m[c], o, sorted(p.decode(errors="replace") for p in paths - ALLOWED)))
        bad += 1
    for line in git("diff-tree", "-r", "-m", "--root", "--no-commit-id", m[c]).decode(errors="replace").splitlines():
        f = line.split()
        if len(f) >= 5 and f[3] != "0" * 40 and f[0] != ":160000":
            blob = f[3]
            if int(git("cat-file", "-s", blob)) < 300:
                b = git("cat-file", "blob", blob)
                if b.startswith(b"version https://git-lfs"):
                    lfs.add(re.search(rb"oid sha256:([0-9a-f]{64})", b).group(1).decode())
log("verify: %d of %d created commits differ from Finastra only in .gitattributes/ui/core" % (len(created) - bad, len(created)))
lfs_dir = os.path.join(W, "rewrite", ".git", "lfs", "objects")
missing = [o for o in lfs if not os.path.isfile(os.path.join(lfs_dir, o[:2], o[2:4], o))]
open(os.path.join(W, "lfs-oids.txt"), "w").write("\n".join(sorted(lfs)) + "\n")
log("LFS objects referenced by new commits: %d (missing locally: %d)" % (len(lfs), len(missing)))

# 5. plan
rows, upd = [], []
src_heads, tgt_heads = refs("refs/rw/heads/"), refs("refs/tgt/heads/")
for b, (sha, _) in sorted(src_heads.items()):
    new = m[sha]
    t = tgt_heads.get(b, (None,))[0]
    if not t:
        act = "create"
    elif t == new:
        act = "same"
    elif git_rc("merge-base", "--is-ancestor", t, new) == 0:
        act = "fast-forward"
    elif git_rc("merge-base", "--is-ancestor", new, t) == 0:
        act = "skip: tcm-pilot ahead"
    else:
        act = "skip: diverged"
    n = len(git("rev-list", new, "--not", "--glob=refs/tgt/*").split()) if act in ("create", "fast-forward") else 0
    rows.append(["refs/heads/" + b, t or "", new, act, n])
    if act in ("create", "fast-forward"):
        upd.append("update refs/out/heads/%s %s\n" % (b, new))
for b, (t, _) in sorted(tgt_heads.items()):
    if b not in src_heads:
        rows.append(["refs/heads/" + b, t, "", "leave: only in tcm-pilot", 0])
src_tags, tgt_tags = refs("refs/rw/tags/"), refs("refs/tgt/tags/")
for name, (sha, typ) in sorted(src_tags.items()):
    pc = m.get(peel("refs/rw/tags/" + name))
    if name in tgt_tags:
        act = "same" if peel("refs/tgt/tags/" + name) == pc else "skip: tag differs in tcm-pilot"
        rows.append(["refs/tags/" + name, tgt_tags[name][0], "", act, 0])
        continue
    if typ == "tag":                                   # annotated: recreate the tag object (signature dropped)
        raw = read_objects([sha])[sha]
        head, _, msg = raw.partition(b"\n\n")
        msg = msg.split(b"-----BEGIN PGP SIGNATURE-----")[0]
        head = b"\n".join(l for l in head.split(b"\n") if not l.startswith((b"object ", b"type ")))
        new = git("hash-object", "-t", "tag", "-w", "--stdin",
                  inp=b"object " + pc.encode() + b"\ntype commit\n" + head + b"\n\n" + msg).decode().strip()
    else:
        new = pc
    rows.append(["refs/tags/" + name, "", new, "create", 0])
    upd.append("update refs/out/tags/%s %s\n" % (name, new))
if upd:
    git("update-ref", "--stdin", inp="".join(upd).encode())
with open(os.path.join(W, "plan.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["Ref", "TcmPilot", "New", "Action", "NewCommits"])
    w.writerows(rows)
log("plan: " + ", ".join("%s=%d" % kv for kv in sorted(collections.Counter(r[3] for r in rows).items())))
log("=== done (nothing pushed) ===" if not bad and not missing else "=== done WITH PROBLEMS - do not push ===")
