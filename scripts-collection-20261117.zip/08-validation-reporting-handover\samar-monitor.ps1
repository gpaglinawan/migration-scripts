﻿# Read-only progress check for tonight (14 Nov 2026), for Samar while Gareth is out.
# Changes nothing. Needs a GitHub token that can read fin-tcm and tcm-pilot (classic PAT with repo + read:org, SSO-authorised).
# Usage:  $env:GH_TOKEN = '<tcm-pilot token>'; $env:GH_FINTCM_TOKEN = '<fin-tcm token>'; powershell -ExecutionPolicy Bypass -File .\samar-monitor.ps1
# Shows: (1) whether the KON-kplus-front rebuild copy has landed in tcm-pilot, (2) PR counts fin-tcm vs tcm-pilot for the
# repos still IN PROGRESS on the Smartsheet. Run it as often as you like (about 1-2 minutes, light on the API).
param([string]$Token = $env:GH_TOKEN, [string]$FinTcmToken = $env:GH_FINTCM_TOKEN)   # two accounts: Teciem (_tciem) for tcm-pilot, Finastra for fin-tcm
if (-not $Token) { Write-Host 'Set $env:GH_TOKEN (tcm-pilot token) first.'; return }
if (-not $FinTcmToken) { $FinTcmToken = $Token }
function Get-PrCount([string]$Org, [string]$Name) {
  $hdr = @{ Authorization = "Bearer $(if ($Org -eq 'fin-tcm') { $FinTcmToken } else { $Token })"; 'Content-Type' = 'application/json' }
  $q = @{ query = 'query($o:String!,$n:String!){ repository(owner:$o,name:$n){ createdAt pullRequests{ totalCount } } }'; variables = @{ o = $Org; n = $Name } } | ConvertTo-Json -Depth 4
  try { (Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers $hdr -Body $q).data.repository } catch { $null }
}
# 15 Nov 05:20 CET update: repos still short on PRs, with the number of PRs that cannot be copied because their code no
# longer exists in fin-tcm (GitHub dropped the PR head) - a repo is "done" when its gap is no bigger than that number.
$expect = [ordered]@{ 'ARC-almonde'=3; 'ARC-automation'=0; 'FCGC-pricing-analytics'=224; 'FRCP-pricing-engine-fusionrisk'=8; 'KON-kondor-enablement'=3; 'KON-kplus-back'=1; 'KON-kplus-front'=18; 'KON-mitra_claude'=0; 'MAFQA-ffc-regression'=0; 'MAFTP-reporting'=2; 'msi-simple-springboot-blueprint'=0; 'OPICS-opics4plus'=0; 'OPICS-opicsbat'=0; 'RISK-buildmasters'=0; 'RISK-cmr'=21; 'RISK-fusion-risk'=0; 'SPH-devops'=0; 'SPH-documentation'=0; 'SPH-jenkinspipeline'=0; 'SPH-live-environment'=0; 'SPH-log-mcp'=0; 'SPH-performance-tests'=0; 'SPH-sophis'=0; 'SUM-summit'=0; 'SUM-summit_cp'=0; 'SUMQA-flauirunner'=0; 'SUMQA-Jenkins_scripts'=0; 'SUMTF-QA-AgenticAI-Skills'=0; 'SUMTF-v99.x'=0; 'TCM-collateral'=0; 'TO-treasury-charts'=0; 'TO-treasury-compose'=0; 'TO-treasury-installer'=10 }
Write-Host "`n== Repos still getting PRs ==  (checked $(Get-Date -Format 'HH:mm'))"
$done = 0
foreach ($n in $expect.Keys) {
  $s = Get-PrCount 'fin-tcm' $n; $t = Get-PrCount 'tcm-pilot' $n
  $sc = if ($s) { $s.pullRequests.totalCount } else { '?' }; $tc = if ($t) { $t.pullRequests.totalCount } else { '?' }
  $gap = if ($s -and $t) { $sc - $tc } else { $null }
  $st = if ($null -ne $gap -and $gap -le $expect[$n]) { $done++; if ($expect[$n]) { "done ($($expect[$n]) not copyable)" } else { 'done' } } else { 'copying' }
  Write-Host ("  {0,-34} fin-tcm {1,6}   tcm-pilot {2,6}   {3}" -f $n, $sc, $tc, $st)
}
Write-Host "`n  $done of $($expect.Count) done. Big ones (SUM-summit, OPICS-opics4plus, TCM-collateral) finish last. Smartsheet refreshes every hour at :41."
Write-Host "  'copying' for hours is normal. Only worth a message if the tcm-pilot numbers stop moving for 2+ hours."
