param(
  [Parameter(Mandatory)][string]$Repo,
  [Parameter(Mandatory)][string]$List,      # lines "oid size"
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Work = "C:\kon-migration\lfscheck\objcopy"
)
# Copies specific LFS objects source -> target through the LFS batch API: download each object from the source,
# verify its sha256, upload it to the target (basic transfer, incl. the verify callback), log every result.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcB = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))
$tgtB = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work "$Repo-objcopy.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Batch($org, $b64, $op, $objs) {
  Invoke-RestMethod -Method POST "https://github.com/$org/$Repo.git/info/lfs/objects/batch" -Headers @{ Authorization = "Basic $b64"; Accept = "application/vnd.git-lfs+json" } `
    -Body (@{ operation = $op; transfers = @('basic'); objects = @($objs) } | ConvertTo-Json -Depth 5) -ContentType "application/vnd.git-lfs+json"
}
$objs = @(Get-Content $List | Where-Object { $_ } | ForEach-Object { $p = $_.Split(' '); @{ oid = $p[0]; size = [long]$p[1] } })
Log "=== copy $($objs.Count) LFS objects $SrcOrg/$Repo -> $TgtOrg/$Repo ==="
$ok = 0; $fail = 0
foreach ($o in $objs) {
  $file = Join-Path $Work $o.oid
  try {
    $d = (Batch $SrcOrg $srcB 'download' @($o)).objects[0]
    if ($d.error) { throw "source: $($d.error.message)" }
    # curl: far faster and more reliable than Invoke-WebRequest for multi-hundred-MB objects (resumes with -C -)
    $curlH = @(); if ($d.actions.download.header) { $d.actions.download.header.PSObject.Properties | ForEach-Object { $curlH += @('-H', "$($_.Name): $($_.Value)") } }
    & curl.exe -s -S -L --retry 5 --retry-delay 10 -C - --max-time 3600 @curlH -o $file $d.actions.download.href
    if ($LASTEXITCODE -ne 0) { throw "download failed (curl exit $LASTEXITCODE)" }
    $h = (Get-FileHash $file -Algorithm SHA256).Hash.ToLower()
    if ($h -ne $o.oid) { throw "sha256 mismatch after download" }
    $u = (Batch $TgtOrg $tgtB 'upload' @($o)).objects[0]
    if ($u.error) { throw "target: $($u.error.message)" }
    if ($u.actions.upload) {
      $curlU = @('-H', 'Content-Type: application/octet-stream'); if ($u.actions.upload.header) { $u.actions.upload.header.PSObject.Properties | ForEach-Object { $curlU += @('-H', "$($_.Name): $($_.Value)") } }
      $code = & curl.exe -s -S --retry 3 --max-time 3600 -X PUT @curlU -T $file -o NUL -w "%{http_code}" $u.actions.upload.href
      if ($LASTEXITCODE -ne 0 -or $code -notmatch '^2') { throw "upload failed (curl exit $LASTEXITCODE, http $code)" }
      if ($u.actions.verify) {
        $vh = @{ Accept = "application/vnd.git-lfs+json" }; if ($u.actions.verify.header) { $u.actions.verify.header.PSObject.Properties | ForEach-Object { $vh[$_.Name] = $_.Value } }
        Invoke-RestMethod -Method POST $u.actions.verify.href -Headers $vh -Body (@{ oid = $o.oid; size = $o.size } | ConvertTo-Json) -ContentType "application/vnd.git-lfs+json" | Out-Null
      }
      Log ("  uploaded {0} ({1:N1} MB)" -f $o.oid.Substring(0, 12), ($o.size / 1MB))
    } else { Log "  already on target $($o.oid.Substring(0,12))" }
    $ok++
  } catch { $fail++; Log "  FAILED $($o.oid.Substring(0,12)) : $($_.Exception.Message) $($_.ErrorDetails.Message)" }
  finally { Remove-Item $file -Force -ErrorAction SilentlyContinue }
}
# final check from the target
$miss = 0; for ($i = 0; $i -lt $objs.Count; $i += 100) { $r = Batch $TgtOrg $tgtB 'download' @($objs[$i..([Math]::Min($i + 99, $objs.Count - 1))]); $miss += @($r.objects | Where-Object { $_.error }).Count }
Log "=== done: ok=$ok failed=$fail; still missing on target: $miss ==="
