# 16 Nov 2026 - builds the BAU handover document (HTML, opens in Word) from the inventory CSVs in C:\kon-migration\bau-pack\
import csv, json, os, html, datetime, collections, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
P = r'C:\kon-migration\bau-pack'
def rd(org, name):
    f = os.path.join(P, f'inventory-{org}', name)
    return list(csv.DictReader(open(f, encoding='utf-8-sig'))) if os.path.exists(f) else []
def js(org):
    f = os.path.join(P, f'inventory-{org}', 'org-settings.json')
    return json.load(open(f, encoding='utf-8')) if os.path.exists(f) else {}
e = html.escape
def n(x): return f'{x:,}'
def tf(v): return {'True': 'yes', 'False': 'no', 'true': 'yes', 'false': 'no', True: 'yes', False: 'no', None: 'not set'}.get(v, e(str(v)))
st = {}
for org in ('tcm-pilot', 'fin-tcm'):
    repos = rd(org, 'repos.csv'); mem = rd(org, 'members.csv'); teams = rd(org, 'teams.csv'); tacc = rd(org, 'repo-team-access.csv'); col = rd(org, 'repo-collaborators.csv')
    act = [r for r in repos if r['archived'] != 'True']
    st[org] = dict(repos=len(repos), active=len(act), archived=len(repos) - len(act),
        vis=collections.Counter(r['visibility'] for r in repos), members=len(mem), admins=sum(1 for m in mem if m['org_role'] == 'admin'),
        teams=len(teams), parent_teams=sum(1 for t in teams if not t['parent']), team_grants=len(tacc), collab=len(col),
        collab_admin=sum(1 for c in col if c['permission'] == 'admin'), codeowners=sum(1 for r in act if r['codeowners']),
        bpr=sum(1 for r in act if r['branch_protection_rules'] not in ('', '0')), rrs=sum(1 for r in act if r['repo_rulesets']),
        env=sum(1 for r in act if r['environments'] not in ('', '0')), hooks=sum(1 for r in act if r['webhooks']),
        hooks_fin=sum(1 for r in act if 'finastra' in r['webhooks'].lower() or 'misys' in r['webhooks'].lower()),
        cs=sum(1 for r in act if r['code_security'] == 'enabled'), ss=sum(1 for r in act if r['secret_scanning'] == 'enabled'),
        size=round(sum(float(r['size_mb'] or 0) for r in repos) / 1024, 1), settings=js(org), runners=rd(org, 'org-runners.csv'), rulesets=rd(org, 'org-rulesets.csv'))
T, F = st['tcm-pilot'], st['fin-tcm']; S = T['settings']
cop = (S.get('copilot_billing') or {}).get('seat_breakdown') or {}
ip = S.get('ip_allow_list') or {}
ap = S.get('actions_permissions') or {}; wp = S.get('actions_workflow_permissions') or {}
today = datetime.date.today().strftime('%d %B %Y').lstrip('0')
def table(head, rows): return '<table><tr>' + ''.join(f'<th>{e(h)}</th>' for h in head) + '</tr>' + ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows) + '</table>'
H = []
add = H.append
add(f'''<!doctype html><html><head><meta charset="utf-8"><title>GitHub and Azure DevOps - BAU handover</title><style>
body{{font-family:Arial,Helvetica,sans-serif;font-size:10.5pt;line-height:1.45;color:#1a1a1a;max-width:960px;margin:24px auto;padding:0 16px}}
h1{{font-size:20pt;color:#1F3864;margin-bottom:2px}} h2{{font-size:14pt;color:#1F3864;border-bottom:2px solid #1F3864;padding-bottom:3px;margin-top:28px}}
h3{{font-size:11.5pt;color:#2E5597;margin-top:18px}} table{{border-collapse:collapse;margin:8px 0 14px;width:100%}}
th,td{{border:1px solid #b7c3d7;padding:4px 7px;text-align:left;vertical-align:top;font-size:9.5pt}} th{{background:#DCE3EF}}
code{{font-family:Consolas,monospace;font-size:9pt;background:#f2f4f8;padding:0 3px}} .note{{background:#FFF4CE;border-left:4px solid #E0B000;padding:6px 10px;margin:10px 0}}
.meta{{color:#555;font-size:9.5pt}} li{{margin:2px 0}}</style></head><body>
<h1>GitHub and Azure DevOps &ndash; BAU handover</h1>
<p class="meta">Finastra &rarr; Teciem migration (Treasury &amp; Capital Markets) &middot; prepared by the migration team &middot; {today} &middot; inventory data collected {today}</p>
<div class="note">This document and its inventory files contain user lists, access rights and security settings. Share them only with the Teciem team that operates the platform.</div>''')
add('<h2>1. Purpose and how to use this pack</h2><p>This pack gives the Teciem BAU team what it needs to run GitHub and Azure DevOps after the migration: what exists, how it is configured, how it was migrated and validated, what is known to differ from Finastra, and how to carry out the common operational tasks. Section 11 lists the inventory files; each section refers to the file that holds the full detail.</p>')
add('<h2>2. Landscape</h2>' + table(['Platform', 'Organisation', 'Owner', 'Status (' + today + ')'], [
  ['GitHub', '<b>tcm-pilot</b>', 'Teciem (enterprise users managed by Teciem Entra ID; logins end in <code>_tciem</code>)', f'Target organisation. Read-only for code until go-live (org rulesets, see 4.2). Planned to be renamed to <b>fin-tcm</b> after go-live.'],
  ['GitHub', 'fin-tcm', 'Finastra (FinastraEnterprise)', 'Source organisation. All repositories archived by Finastra on 16 Nov 2026 (read-only). Planned to be renamed to <b>fin-tcm-old</b>; Teciem users need a Finastra account to open it.'],
  ['GitHub', 'tcm-pilot-test', 'Teciem', 'Test organisation used for rehearsals; not part of production.'],
  ['Azure DevOps', '<b>tcm-staging</b>', 'Teciem', 'Target organisation; Git repositories read-only until go-live (permission deny entries, see 8).'],
  ['Azure DevOps', 'TreasuryCapitalMarkets', 'Finastra', 'Source organisation; frozen (read-only).']]))
add('<h3>2.1 Size</h3>' + table(['', 'tcm-pilot (Teciem)', 'fin-tcm (Finastra)'], [
  ['Repositories', n(T['repos']), n(F['repos'])], ['&nbsp;&nbsp;active / archived', f"{n(T['active'])} / {n(T['archived'])}", f"{n(F['active'])} / {n(F['archived'])}"],
  ['&nbsp;&nbsp;visibility', ', '.join(f'{k} {n(v)}' for k, v in T['vis'].items()), ', '.join(f'{k} {n(v)}' for k, v in F['vis'].items())],
  ['Total size', f"{T['size']} GB", f"{F['size']} GB"], ['Organisation members (owners)', f"{n(T['members'])} ({T['admins']})", f"{n(F['members'])} ({F['admins']})"],
  ['Teams (top-level)', f"{n(T['teams'])} ({T['parent_teams']})", f"{n(F['teams'])} ({F['parent_teams']})"],
  ['Team-to-repository grants', n(T['team_grants']), n(F['team_grants'])], ['Direct collaborator grants (of which admin)', f"{n(T['collab'])} ({n(T['collab_admin'])})", f"{n(F['collab'])} ({n(F['collab_admin'])})"]]) +
  '<p>Archived repositories in tcm-pilot include migration working copies: <code>&lt;repo&gt;-ri</code> (re-import copies from 14 Nov, not used), <code>&lt;repo&gt;-old</code> / <code>-old2</code> (the previous version of a repository that was rebuilt and swapped in) and <code>-pr</code>/<code>-pr2</code> leftovers. They are kept read-only for reference and can be deleted after hypercare.</p>')
add(f'''<h2>3. Identity and access</h2><h3>3.1 Accounts</h3><ul>
<li>tcm-pilot uses GitHub Enterprise Managed Users: accounts are created and removed from Teciem Entra ID (owned by the Teciem identity team). Login format <code>Firstname-Lastname_tciem</code>. Users cannot create their own accounts.</li>
<li>Removing a user in Entra suspends the GitHub account; their commits, PRs and comments stay and keep showing their name.</li>
<li>Each Finastra login was matched to its Teciem login (mapping file <code>member-names.csv</code>). People with no Teciem account yet cannot be given access; they are tracked in the defect log (e.g. DEF-252).</li>
<li>Organisation owners in tcm-pilot: {T['admins']} (see <code>members.csv</code>, role <code>admin</code>). Base repository permission for members: <b>{e(str(S.get('default_repository_permission')))}</b>.</li></ul>
<h3>3.2 Teams</h3><p>Teams were recreated from fin-tcm with the same names, parent/child structure and repository permissions, and members were added by their Teciem accounts. Files: <code>teams.csv</code> (team, parent, members, maintainers, repositories), <code>team-members.csv</code>, <code>repo-team-access.csv</code> (repository, team, permission).</p>
<h3>3.3 Direct collaborators and admin rights</h3><p>Non-admin direct collaborator grants were copied from fin-tcm. <b>Individual admin grants were held at cutover</b> and are given only when the repository's owner or team lead confirms them (Summit/PTP, ARC and others have been confirmed). Requests for admin rights should therefore go through the repository owner. File: <code>repo-collaborators.csv</code>.</p>
<h3>3.4 Placeholder ("mannequin") authors</h3><p>GitHub's importer creates a placeholder for every Finastra author it cannot match. Placeholders were linked to Teciem accounts wherever one exists (790 of 1,949 at the time of writing), so historic PRs, reviews and comments show under the person's Teciem account. Placeholders for people without a Teciem account remain; they can be linked later with <code>gh gei reclaim-mannequin</code> once the account exists. Content from accounts that no longer existed in Finastra shows as <i>ghost</i> and cannot be linked.</p>
<h3>3.5 GitHub Copilot</h3><p>Copilot Business is assigned through team membership: members of the team <code>copilot</code> get a seat. Seats today: {cop.get('total', 'n/a')}. Rule agreed with the business (16 Nov): Finastra Copilot users who used it in the last 30 days were given a Teciem seat; others on request. List: <code>GitHub-Copilot-users-Finastra-to-Teciem.csv</code>.</p>''')
add(f'''<h2>4. Repository configuration</h2><h3>4.1 What was carried over</h3>{table(['Item', 'tcm-pilot (active repositories)', 'Notes'], [
  ['Default branch, description, topics, merge settings', 'all', 'From the import / copied at swap'],
  ['Branch protection rules', f"{n(T['bpr'])} repositories", 'Classic rules, copied with their patterns; see <code>repos.csv</code> column branch_protection_patterns'],
  ['Repository rulesets', f"{n(T['rrs'])} repositories", 'Column repo_rulesets'],
  ['CODEOWNERS file', f"{n(T['codeowners'])} repositories", 'Part of the code, migrated as-is. Owners referenced by Finastra login or team must be checked by each team; column codeowners gives the path'],
  ['Webhooks', f"{n(T['hooks'])} repositories ({n(T['hooks_fin'])} pointing at Finastra hosts)", 'Copied with their URLs. Hooks pointing at Finastra Jenkins/CI hosts need to be repointed or removed by the owning team. Webhook secrets cannot be read and must be re-entered'],
  ['Environments', f"{n(T['env'])} repositories", 'GitHub environments were <b>not</b> part of the import; where they exist they were created later. Comparison with fin-tcm is open (see 7.4)'],
  ['Actions secrets / variables', 'names only', 'Secret values cannot be read from GitHub; owners re-enter them (e.g. ARC-almonde DISPATCH_TOKEN)']])}
<h3>4.2 Organisation rulesets</h3>{table(['Name', 'Target', 'Enforcement', 'Rules', 'Repositories', 'Bypass'], [[e(r['name']), e(r['target']), e(r['enforcement']), e(r['rules']), e(r['repos_include']) + (f" (excluding {e(r['repos_exclude'])})" if r['repos_exclude'] else ''), e(r['bypass'])] for r in T['rulesets']])}
<p>The two "Migration read-only until cutover" rulesets block creating, updating and deleting branches and tags in every repository. They are removed at go-live (cutover step GIT-016B). The bypass team <code>migration-sync</code> (migration account only) is removed at GIT-016C.</p>''')
add(f'''<h2>5. Organisation-level settings (tcm-pilot)</h2>{table(['Setting', 'Value'], [
  ['Base permission for members', e(str(S.get('default_repository_permission')))], ['Members can create repositories', tf(S.get('members_can_create_repositories'))],
  ['&nbsp;&nbsp;public / private / internal', f"{tf(S.get('members_can_create_public_repositories'))} / {tf(S.get('members_can_create_private_repositories'))} / {tf(S.get('members_can_create_internal_repositories'))}"],
  ['Members can fork private repositories', tf(S.get('members_can_fork_private_repositories'))], ['Two-factor requirement', tf(S.get('two_factor_requirement_enabled')) + ' (sign-in is through Entra ID)'],
  ['Web commit sign-off required', tf(S.get('web_commit_signoff_required'))],
  ['IP allow list', f"{e(str(ip.get('ipAllowListEnabledSetting', 'n/a')))} ({(ip.get('ipAllowListEntries') or {}).get('totalCount', 0)} entries at organisation level; enterprise-level settings are managed by the enterprise owners)"],
  ['Single sign-on', 'Enterprise Managed Users with Teciem Entra ID (OIDC) at enterprise level, owned by the Teciem identity team'],
  ['Security manager teams', e(', '.join(S.get('security_manager_teams') or []) or 'none')],
  ['Custom repository roles', e(', '.join(r.get('name', '') for r in (S.get('custom_repository_roles') or [])) or 'none')],
  ['Organisation webhooks', str(len(S.get('org_webhooks') or []))],
  ['Code security / secret scanning for new repositories', f"{tf(S.get('advanced_security_enabled_for_new_repositories'))} / {tf(S.get('secret_scanning_enabled_for_new_repositories'))}"]])}
<p>Full values: <code>inventory-tcm-pilot/org-settings.json</code> (and the same for fin-tcm, for comparison).</p>''')
add(f'''<h2>6. GitHub Actions and runners</h2>{table(['Setting', 'tcm-pilot', 'fin-tcm'], [
  ['Actions enabled for', e(str(ap.get('enabled_repositories'))), e(str((F['settings'].get('actions_permissions') or {}).get('enabled_repositories')))],
  ['Allowed actions', e(str(ap.get('allowed_actions'))), e(str((F['settings'].get('actions_permissions') or {}).get('allowed_actions')))],
  ['Default workflow token permission', e(str(wp.get('default_workflow_permissions'))), e(str((F['settings'].get('actions_workflow_permissions') or {}).get('default_workflow_permissions')))],
  ['Organisation runner groups', str(len(S.get('runner_groups') or [])), str(len(F['settings'].get('runner_groups') or []))],
  ['Organisation self-hosted runners', str(len(T['runners'])), str(len(F['runners']))]])}
<ul><li>Workflow files are part of the code and were migrated; <b>workflow run history, logs and artifacts are not migrated</b> by GitHub (Insights &rarr; Actions metrics start from zero).</li>
<li>Self-hosted runners registered to Finastra repositories or the fin-tcm organisation must be re-registered against tcm-pilot by their owners (guide: <i>Reconnecting self-hosted runners</i>; runner list: <code>inventory-fin-tcm/org-runners.csv</code> and the repository runner list).</li>
<li>Actions minutes, storage and quotas are set at enterprise level by the enterprise owners.</li></ul>''')
add(f'''<h2>7. Security, compliance and migration specifics</h2><h3>7.1 Code security and secret scanning</h3><p>Code security is enabled on {n(T['cs'])} active repositories and secret scanning on {n(T['ss'])} (columns code_security, secret_scanning, push_protection in <code>repos.csv</code>). Code scanning results (CodeQL) and their dismissals were copied from fin-tcm for the repositories that had them. Rebuilt repositories (KON-kplus-front, FCGC-pricing-analytics, TO-treasury-installer) had code security re-enabled on 16 Nov; copying their earlier results is tracked under DEF-249.</p>
<h3>7.2 How the migration was done</h3><ol>
<li><b>Initial copy (Sep&ndash;Oct 2026)</b>: every repository imported with GitHub Enterprise Importer (code, branches, tags, PRs with reviews and comments, releases, issues). Commit IDs are identical to Finastra.</li>
<li><b>Delta syncs</b> until cutover: branches, tags and commits kept in line with fin-tcm nightly (branches deleted in Finastra were not deleted in tcm-pilot; cleaned up on 16 Nov with a backup).</li>
<li><b>Large files</b>: repositories with files over the importer's limit were rebuilt with those files in Git LFS: KON-kplus-front, KON-kondor-enablement, KON-doc-kondor-archive, FCGC-pricing-analytics, RISK-cmr, TO-treasury-installer. <b>In these repositories commit IDs differ from Finastra</b> (mapping files kept by the migration team).</li>
<li><b>Cutover (13&ndash;15 Nov)</b>: freeze of both platforms, final sync, then PRs created or changed in Finastra after a repository's initial copy were added through GitHub's API (7,364 PRs in 321 repositories). The API cannot set the author, number or merged state, so these PRs show the migration account, a new number and "closed"; the original author, number and dates are in each description, and the original discussion (comments, reviews with verdict, inline comments) is copied in as an "Archived discussion from Finastra GitHub" comment.</li>
<li><b>Re-imports (16 Nov onwards)</b>: where owners asked, repositories were re-imported with their full PR history (commit IDs unchanged) and swapped in under the same name, with teams, collaborators, settings and any Teciem-only branches carried over. Done: FCBO-swift-gateway, FCBO-action-service, FCBO-securities-inventory-service, FCBO-securities-inventory-summit-integration, FCBO-securities-inventory-product, ARC-almonde, SUM-summit-helm-charts, BUIL-summit_devops_scripts, TO-treasury-charts, SOLINT-technology, RISK-fr-cmr-tests; in progress: SUM-summit and the repositories under DEF-254/258/274/279. The replaced version is kept as <code>&lt;repo&gt;-old</code> (archived).</li></ol>
<h3>7.3 Validation</h3><p>Every repository was compared with fin-tcm on: pull request totals, branches and tags (same commit), size, teams, direct collaborators, releases, default branch, archived state, and LFS objects where used. Result per repository: migration tracksheet (<code>GitHub-migration-tracksheet.xlsx</code>, 2,662 repositories). Defects found by testers and their resolution: Smartsheet defect log.</p>
<h3>7.4 Known limitations and open items</h3><ul>
<li>PRs added through the API (see 7.2.4) show the migration account, a new number and "closed" unless the repository was re-imported.</li>
<li>Links in recreated PRs point to <code>fin-tcm-old</code>, which works only after the Finastra organisation is renamed, and needs a Finastra account.</li>
<li>Contributors / Insights pages: commits keep their Finastra e-mail addresses, which are not on Teciem accounts, so they are not linked to profiles (names are correct).</li>
<li>Not migrated by GitHub: Actions run history, deployments history, secret values, webhook secrets.</li>
<li>Environments: were not part of the import; inventory and re-creation to be agreed.</li>
<li>KON-kplus-front: some reviews and review comments could not be attached to the rewritten commits; they are being copied into the PRs as archived discussion (DEF-280 / DEF-107).</li>
<li>A small number of Finastra PRs could not be recreated because neither their PR reference nor their commits were available in Finastra GitHub (lists kept by the migration team).</li></ul>''')
add('''<h2>8. Azure DevOps (tcm-staging)</h2><ul>
<li>Repositories, branches and commits migrated from TreasuryCapitalMarkets. Azure DevOps cannot import pull request history between organisations: the PRs that were active in Finastra were recreated in tcm-staging (created by the migration account, original author and link in the description); completed and abandoned PRs remain in Finastra (read-only).</li>
<li>Freeze until go-live: in the 9 migrated projects, every group or user with write access has a <b>Deny</b> on push, force push, create branch, create tag, manage notes and contribute to PRs, plus Deny on <i>create repository</i> for Project Administrators. Project Collection Administrators and Project Collection Service Accounts are exempt. The freeze covers Git repositories only (not Boards, Pipelines, Wikis, Artifacts). It is lifted with the rollback of the saved permission snapshots (migration team).</li>
<li>Note: a Deny only applies to identities that existed when it was set; access granted directly on a repository afterwards overrides an inherited Deny. Re-run the freeze scan after any permission change until go-live.</li>
<li>Organisation-level Artifacts feeds and service connections are tracked in the defect log (e.g. DEF-227).</li></ul>''')
add('''<h2>9. Operational procedures</h2><h3>9.1 Common tasks</h3>''' + table(['Task', 'How'], [
  ['Give a new person GitHub access', 'Identity team creates the Entra account and assigns it to the GitHub enterprise app; the account appears in tcm-pilot. Add the person to their team(s) (team maintainers or org owners). Repository access then follows the team.'],
  ['Give repository access to one person', 'Prefer team membership. Direct collaborator only as an exception; admin only with the repository owner\'s agreement.'],
  ['Copilot seat', 'Add the person to team <code>copilot</code>.'],
  ['New repository', 'Create in tcm-pilot (after go-live), add the owning team(s), add CODEOWNERS and branch protection / ruleset as for the team\'s other repositories.'],
  ['Leaver', 'Remove in Entra; the GitHub account is suspended automatically. Check for direct admin grants and repository ownership first.'],
  ['Restore a branch deleted in the 16 Nov clean-up', 'Branches deleted because Finastra had deleted them are kept as git bundles per repository (<code>branch-cleanup/backup/&lt;repo&gt;.bundle</code>, migration team); restore with <code>git fetch &lt;bundle&gt; refs/heads/&lt;branch&gt;</code> and push.'],
  ['Check Git LFS files of a repository', 'Clone with Git LFS installed; or ask GitHub\'s LFS batch API for the object IDs from <code>git lfs ls-files</code>. LFS storage and bandwidth are enterprise-level quotas.'],
  ['Find the original of a recreated PR', 'First line of the PR description: original number, author, date and link; full number map: <code>recreated-pr-number-map.csv</code>.']]) +
  '''<h3>9.2 Go-live steps that change the platform</h3><ol><li>Lift the GitHub read-only org rulesets (GIT-016B), keeping individual repositories read-only where agreed (e.g. SUM-summit until its re-import is switched in).</li>
<li>Remove the migration bypass team <code>migration-sync</code> (GIT-016C).</li><li>Lift the Azure DevOps freeze (restore of the saved permission snapshots).</li>
<li>Rename organisations: fin-tcm &rarr; fin-tcm-old (Finastra), tcm-pilot &rarr; fin-tcm (Teciem); then update integrations (Jira links, CI hooks, Copilot/IDE settings) that use the organisation name.</li>
<li>After hypercare: delete the archived migration copies (<code>-ri</code>, <code>-old</code>, <code>-pr</code>) once owners confirm.</li></ol>''')
add('''<h2>10. Support model and contacts</h2><p>To be agreed by Teciem (owner of the platform after go-live). Proposed structure:</p>''' + table(['Area', 'Owner (to confirm)'], [
  ['GitHub enterprise (SSO, enterprise policies, licences, IP allow list)', 'Teciem enterprise owners / identity team'],
  ['tcm-pilot organisation administration (teams, access, org settings, rulesets)', 'Teciem BAU team'],
  ['Repository content, CODEOWNERS, workflows, runners, secrets', 'Owning product teams / team leads'],
  ['Azure DevOps tcm-staging administration', 'Teciem BAU team (Project Collection Administrators)'],
  ['Escalation to GitHub', 'GitHub Enterprise Support, opened by an enterprise owner'],
  ['Migration questions during hypercare', 'Migration team (Gareth Cabrera)']]))
add('''<h2>11. Files in this pack</h2>''' + table(['File', 'Content'], [
  ['inventory-tcm-pilot/ and inventory-fin-tcm/', 'Same set for each organisation'],
  ['&nbsp;&nbsp;org-settings.json', 'Organisation settings, Actions policy, runner groups, Copilot, IP allow list, org webhooks'],
  ['&nbsp;&nbsp;org-rulesets.csv, org-runners.csv', 'Organisation rulesets; organisation self-hosted runners'],
  ['&nbsp;&nbsp;members.csv', 'Members with name and organisation role'],
  ['&nbsp;&nbsp;teams.csv, team-members.csv', 'Teams (parent, privacy, counts) and their members (member / maintainer)'],
  ['&nbsp;&nbsp;repos.csv', 'Every repository: visibility, archived, default branch, size, topics, CODEOWNERS, branch protection, rulesets, environments, security settings, webhooks'],
  ['&nbsp;&nbsp;repo-team-access.csv, repo-collaborators.csv', 'Who has access to which repository and with which permission'],
  ['member-names.csv', 'Finastra login &rarr; Teciem login mapping'],
  ['GitHub-migration-tracksheet.xlsx', 'Per-repository validation result'],
  ['recreated-pr-number-map.csv', 'Finastra PR &rarr; tcm-pilot PR for the 7,364 recreated PRs'],
  ['GitHub-Copilot-users-Finastra-to-Teciem.csv', 'Copilot licence list and decision per person']]))
add('</body></html>')
out = os.path.join(P, 'GitHub-ADO-BAU-handover.html'); open(out, 'w', encoding='utf-8').write('\n'.join(H)); print(out)
