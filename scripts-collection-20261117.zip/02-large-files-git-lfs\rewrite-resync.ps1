param(
  [Parameter(Mandatory)][string]$Name,             # e.g. RISK-cmr
  [Parameter(Mandatory)][string]$Trunk,            # default branch, pushed in steps first (e.g. release/356)
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Root   = "C:\kon-migration\resync",
  [double]$MinUnchangedMatch = 0.95                # share of unchanged refs that must keep their tcm-pilot SHA
)
# Incremental sync for a repo that was rewritten for large files (LFS): fresh mirror from Finastra -> same
# deterministic rewrite (lfs-rewrite.ps1) -> safety check that refs untouched since the first rewrite still map to the
# exact SHAs already in tcm-pilot -> non-force push of what's new (kon-push.ps1). Stops before pushing if the check fails.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
# must repeat the options of each repo's FIRST rewrite exactly (see C:\kon-migration\bigfiles-<repo>\rewrite.log), or no SHA lines up
$rewriteArgs = @{}
switch ($Name) {
  'KON-doc-kondor-archive' { $rewriteArgs.ThresholdBytes = 5MB }
  'SFX-netcore-common'     { $rewriteArgs.PathRename = @('QuickFixn/.git/:QuickFixn/_git/') }
}
$day = Get-Date -Format yyyyMMdd-HHmm
$work = Join-Path $Root "$Name-$day"; New-Item -ItemType Directory -Force $work | Out-Null
$orig = Join-Path $work "$Name.git"; $copy = Join-Path $work "$Name-lfs.git"
$log = Join-Path $work "resync.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Auth($pat) { $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$pat")); $env:GIT_TERMINAL_PROMPT = "0" }
$tgtUrl = "https://github.com/$TgtOrg/$Name.git"

Log "=== rewrite-resync $SrcOrg/$Name -> $TgtOrg/$Name ==="
# 1. fresh mirror (branches + tags only, like the first rewrite)
Auth $env:GH_SRC_PAT
# reftable: ref names that differ only in case (SFX-netcore-common) or are longer than Windows paths (KON-kplus-front)
git init --bare -q --ref-format=reftable $orig
git -C $orig config core.longpaths true
git -C $orig fetch -q "https://github.com/$SrcOrg/$Name.git" "+refs/heads/*:refs/heads/*" "+refs/tags/*:refs/tags/*" 2>&1 | Select-Object -Last 3 | ForEach-Object { Log "   $_" }
if ($LASTEXITCODE -ne 0) { Log "FATAL: fetch failed"; exit 1 }
$srcRefs = @{}; git -C $orig for-each-ref --format="%(objectname) %(refname)" refs/heads refs/tags | ForEach-Object { $p = $_.Split(' '); $srcRefs[$p[1]] = $p[0] }
Log "1. mirror: $($srcRefs.Count) refs"

# 2. same rewrite as the first time
& "$PSScriptRoot\lfs-rewrite.ps1" -Orig $orig -Copy $copy -Out (Join-Path $work "rewrite") @rewriteArgs |Select-Object -Last 4 | ForEach-Object { Log "   $_" }
if ($LASTEXITCODE -ne 0) { Log "FATAL: rewrite failed"; exit 1 }

# 3. safety check: rewritten SHAs vs what tcm-pilot already has
Auth $env:GH_TGT_PAT
$tgt = @{}; git ls-remote $tgtUrl 'refs/heads/*' 'refs/tags/*' | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notmatch '\^\{\}$') { $tgt[$p[1]] = $p[0] } }
$new = @{}; git -C $copy for-each-ref --format="%(objectname) %(refname)" refs/heads refs/tags | ForEach-Object { $p = $_.Split(' '); $new[$p[1]] = $p[0] }
$same = @($new.Keys | Where-Object { $tgt[$_] -eq $new[$_] }).Count
$changed = @($new.Keys | Where-Object { $tgt[$_] -and $tgt[$_] -ne $new[$_] })
$added = @($new.Keys | Where-Object { -not $tgt[$_] })
# refs whose rewritten SHA differs: fine if the target's commit is an ancestor (new commits on top = fast-forward)
$ff = 0; $div = @(); foreach ($r in $changed) { git -C $copy merge-base --is-ancestor $tgt[$r] $new[$r] 2>$null; if ($LASTEXITCODE -eq 0) { $ff++ } else { $div += $r } }
Log "3. check: identical=$same fast-forward=$ff new=$($added.Count) diverged=$($div.Count) (of $($new.Count))"
if ($div.Count) { $div | Out-File (Join-Path $work "diverged.txt") -Encoding utf8 }
$known = $same + $ff + $div.Count
if ($known -and (($same + $ff) / $known) -lt $MinUnchangedMatch) { Log "STOP: only $([math]::Round(100*($same+$ff)/$known,1))% of existing refs line up - rewrite is not reproducing the first one; nothing pushed"; exit 2 }

# 4. non-force push of what's new (LFS objects first)
# classic protection with "include administrators" (rules\classic-bypass-branches.csv): off for the push only, then back on and checked
$apiT = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$toggled = @()
foreach ($c in @(Import-Csv "C:\kon-migration\rules\classic-bypass-branches.csv" | Where-Object { $_.Repo -eq $Name })) {
  $ea = "https://api.github.com/repos/$TgtOrg/$Name/branches/$($c.Branch)/protection/enforce_admins"
  try { if ((Invoke-RestMethod $ea -Headers $apiT).enabled) { Invoke-RestMethod -Method DELETE $ea -Headers $apiT | Out-Null; $toggled += $c.Branch } } catch { Log "   enforce_admins off FAILED $($c.Branch)" }
}
try { & "$PSScriptRoot\kon-push.ps1" -Repo $copy -Target $tgtUrl -Out (Join-Path $work "push") -Trunk $Trunk -Steps 5 | Select-Object -Last 6 | ForEach-Object { Log "   $_" } }
finally {
  foreach ($b in $toggled) {
    $ea = "https://api.github.com/repos/$TgtOrg/$Name/branches/$b/protection/enforce_admins"
    try { Invoke-RestMethod -Method POST $ea -Headers $apiT | Out-Null } catch {}
    $ok = try { (Invoke-RestMethod $ea -Headers $apiT).enabled } catch { $false }
    if ($ok) { Log "   $b protection bypassed for the push, restored" } else { Log "   WARNING $b enforce_admins NOT restored - run enforce-admins-restore.ps1" }
  }
}

# 5. if tcm-pilot now holds exactly the rewrite of this Finastra state, record that state: refs-compare.ps1 reports the
#    repo IN_SYNC_REWRITTEN for as long as Finastra still has these exact refs (SHAs can never match after a rewrite)
Auth $env:GH_TGT_PAT
$tgt = @{}; git ls-remote $tgtUrl 'refs/heads/*' 'refs/tags/*' | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notmatch '\^\{\}$') { $tgt[$p[1]] = $p[0] } }
$miss = @($new.Keys | Where-Object { $tgt[$_] -ne $new[$_] })
if ($miss.Count -eq 0) {
  $st = Join-Path $Root "state"; New-Item -ItemType Directory -Force $st | Out-Null
  $srcRefs.Keys | Sort-Object | ForEach-Object { "$($srcRefs[$_])`t$_" } | Set-Content (Join-Path $st "$Name.txt") -Encoding ascii
  Log "5. target matches the rewrite of all $($new.Count) refs - state recorded"
} else { Log "5. target differs on $($miss.Count) refs - state NOT recorded"; $miss | Out-File (Join-Path $work "target-mismatch.txt") -Encoding utf8 }
Log "=== done ==="
