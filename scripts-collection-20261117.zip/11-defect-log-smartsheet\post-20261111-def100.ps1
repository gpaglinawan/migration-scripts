# 11 Nov 2026 (Gareth: "post"). Comment only - status not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-100' = 'Checked 11 Nov: classic release pipelines are in place in tcm-staging for every in-scope project - Treasury "New release pipeline for devops-api-service" and Jenkins "New release pipeline" (the other 7 in-scope projects have none). The pipelines that needed Marketplace extensions not installed in tcm-staging belong to TreasuryKondor and Test - OE, which their owners took out of scope on 9 Nov (Darek; Lukasz Kruczek), so no extension decision is needed. Remaining: the Treasury team re-creates the service connections used by the devops-api-service release and runs it once in tcm-staging (cutover runbook ADO-009). Note: an extra empty "New release pipeline" exists in the Treasury project in tcm-staging (created 31 Oct, no source equivalent) - to be removed. Ready for retest.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
