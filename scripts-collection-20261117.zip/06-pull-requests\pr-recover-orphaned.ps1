# 16 Nov 2026 - recreate the 108 PRs whose PR reference (refs/pull/N/head) is gone in fin-tcm but whose head commit is
# still available (pr-gaps\pr-head-commit-check.csv). Repos were rewritten for files > 100 MB (Git LFS), so tcm-pilot
# commit IDs differ: the PR's base commit is located in tcm-pilot by the same author date + committer date + message
# (the rewrite keeps them), and the PR's changes are recreated as ONE commit: tree = the PR head's tree (large files
# converted to LFS pointers), parent = the located base. PR body: Samar's format (original author as Teciem login in
# plain text, original state + date, original branches, link labelled "Finastra account needed", note that commits
# are squashed). Then closed (GitHub cannot create merged PRs), temp branches deleted, archive comment added by
# pr-archive-comments.py. Dry run unless -Apply (dry run: locates base, fetches head, checks for large files).
param([string[]]$Repos, [int[]]$Only, [switch]$Apply)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$src = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }; $tgt = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$env:GIT_TERMINAL_PROMPT = '0'; $LFSMAX = 100MB
$map = @{}; Import-Csv C:\kon-migration\rules\member-names-20261111.csv | Where-Object Tgt | ForEach-Object { $map[$_.Src.ToLower()] = $_.Tgt }
$list = Import-Csv C:\kon-migration\pr-gaps\pr-head-commit-check.csv | Where-Object { $_.HeadCommitExists -eq 'True' }
if ($Repos) { $list = $list | Where-Object { $_.Repo -in $Repos } }; if ($Only) { $list = $list | Where-Object { [int]$_.PR -in $Only } }
$rows = New-Object System.Collections.ArrayList
$cmaps = @{}
function Find-TargetCommit($repo, $c) {   # 1) the LFS rewrite's commit-map (old -> new); 2) same dates + message on the default branch
  if (-not $cmaps.ContainsKey($repo)) {
    $cmaps[$repo] = @{}; $mf = "C:\kon-migration\pr-preload\$repo\commit-map"
    if (Test-Path $mf) { foreach ($l in [IO.File]::ReadLines($mf)) { $q = $l.Split(' '); if ($q.Count -eq 2 -and $q[0].Length -eq 40) { $cmaps[$repo][$q[0]] = $q[1] } } }
  }
  $m = $cmaps[$repo][$c.sha]
  if ($m -and $m -ne '0000000000000000000000000000000000000000') { $hit = try { Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$repo/commits/$m" -Headers $tgt -EA Stop } catch { $null }; if ($hit) { return $hit } }
  $d = [datetime]$c.commit.committer.date
  $since = $d.AddSeconds(-1).ToUniversalTime().ToString('s') + 'Z'; $until = $d.AddSeconds(1).ToUniversalTime().ToString('s') + 'Z'
  $cand = @(Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$repo/commits?since=$since&until=$until&per_page=100" -Headers $tgt -EA SilentlyContinue)
  @($cand | Where-Object { $_.commit.message -eq $c.commit.message -and $_.commit.author.date -eq $c.commit.author.date -and $_.commit.author.email -eq $c.commit.author.email }) | Select-Object -First 1
}
function Convert-Tree($w, $commit) {   # tree of $commit with files over 100 MB as Git LFS pointers, exactly like the repo's rewrite
  $tree = git -C $w rev-parse "$commit^{tree}"; $oids = @()
  $bigl = @(git -C $w ls-tree -r -l $commit | Where-Object { $_ -match '^\d+ blob ([0-9a-f]+)\s+(\d+)\t' -and [long]$Matches[2] -gt $LFSMAX })
  if (-not $bigl.Count) { return @{ Tree = $tree; Oids = @() } }
  $idx = Join-Path $w "index-$commit"; $env:GIT_INDEX_FILE = $idx; git -C $w read-tree $tree
  foreach ($line in $bigl) {
    $meta, $path = $line -split "`t", 2; $parts = $meta -split '\s+'; $mode = $parts[0]; $blob = $parts[2]; $size = [long]$parts[3]
    $tmp = Join-Path $w "blob-$blob"; if (-not (Test-Path $tmp)) { cmd /c "git -C `"$w`" cat-file blob $blob > `"$tmp`"" }
    $oid = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower()
    $od = Join-Path $w "lfs\objects\$($oid.Substring(0,2))\$($oid.Substring(2,2))"; New-Item -ItemType Directory -Force $od | Out-Null; if (-not (Test-Path "$od\$oid")) { Move-Item $tmp "$od\$oid" } else { Remove-Item $tmp }
    $pf = Join-Path $w "ptr-$oid"; [IO.File]::WriteAllText($pf, "version https://git-lfs.github.com/spec/v1`noid sha256:$oid`nsize $size`n", (New-Object Text.UTF8Encoding $false))   # exact bytes (PS 5.1 pipes add CRLF)
    $pb = git -C $w hash-object -w --no-filters $pf; Remove-Item $pf
    git -C $w update-index --cacheinfo "$mode,$pb,$path"; $oids += $oid
  }
  $tree = git -C $w write-tree; Remove-Item Env:GIT_INDEX_FILE; Remove-Item $idx -EA SilentlyContinue
  @{ Tree = $tree; Oids = $oids }
}
function Wait-Network {   # 16 Nov: the VM's DNS/network dropped several times overnight - wait until GitHub answers again
  for ($i = 0; $i -lt 30; $i++) { try { $null = Invoke-WebRequest https://api.github.com/zen -UseBasicParsing -TimeoutSec 15; return } catch { Start-Sleep 60 } }
}
$queue = New-Object System.Collections.Queue; foreach ($x in $list) { $queue.Enqueue(@($x, 0)) }
while ($queue.Count) {
  $item = $queue.Dequeue(); $x = $item[0]; $attempt = $item[1]
  $repo = $x.Repo; $n = [int]$x.PR; $row = [pscustomobject]@{ Repo = $repo; PR = $n; State = $x.State; Base = ''; MappedBase = ''; LargeFiles = ''; NewPR = ''; Result = '' }
  try {
    $p = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$repo/pulls/$n" -Headers $src
    # walk back from the PR head (first parents) to the newest commit that exists in tcm-pilot = where the PR branched off
    $sha = $p.head.sha; $tc = $null; $bc = $null
    for ($i = 0; $i -lt 400 -and $sha; $i++) {
      $cc = try { Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$repo/commits/$sha" -Headers $src -EA Stop } catch { $null }
      if (-not $cc) { break }
      if ($i -gt 0) { $tc = Find-TargetCommit $repo $cc; if ($tc) { $bc = $cc; break } }
      $sha = if ($cc.parents.Count) { $cc.parents[0].sha } else { $null }
    }
    $row.Base = if ($bc) { $bc.sha.Substring(0, 10) } else { '' }
    $synth = $false
    if (-not $tc) {   # the PR's base is in no branch of fin-tcm any more (e.g. 2014 RISK-cmr PRs): anchor a stand-in base on the
      # newest tcm-pilot commit of the same base branch (else the default branch) at the original base commit's date
      $ob = try { Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$repo/commits/$($p.base.sha)" -Headers $src -EA Stop } catch { $null }
      if ($ob) {
        $until = ([datetime]$ob.commit.committer.date).ToUniversalTime().ToString('s') + 'Z'
        $tc = @(try { Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$repo/commits?sha=$([uri]::EscapeDataString($p.base.ref))&until=$until&per_page=1" -Headers $tgt -EA Stop } catch { $null }) | Select-Object -First 1
        if (-not $tc) { $tc = @(Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$repo/commits?until=$until&per_page=1" -Headers $tgt -EA SilentlyContinue) | Select-Object -First 1 }
        if (-not $tc) { $tc = @(Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$repo/commits?per_page=1" -Headers $tgt -EA SilentlyContinue) | Select-Object -First 1 }
        if ($tc) { $synth = $true; $bc = $ob; $row.Base = $ob.sha.Substring(0, 10) }
      }
    }
    if (-not $tc) { $row.Result = 'SKIP: base commit not found in tcm-pilot'; [void]$rows.Add($row); continue }
    $row.MappedBase = $tc.sha.Substring(0, 10)
    $w = "C:\kon-migration\pr-recover\$repo.git"; if (-not (Test-Path $w)) { git init --bare -q $w }
    for ($f = 0; $f -lt 4 -and (git -C $w cat-file -t $p.head.sha 2>$null) -ne 'commit'; $f++) {   # 16 Nov: retry - overnight drops made 5 FCGC fetches fail
      if ($f) { Wait-Network; Start-Sleep 30 }
      git -C $w -c "http.extraHeader=Authorization: Basic $sb" fetch -q --depth=1 "https://github.com/fin-tcm/$repo.git" $p.head.sha 2>&1 | Out-Null }
    if ($synth) { git -C $w -c "http.extraHeader=Authorization: Basic $sb" fetch -q --depth=1 "https://github.com/fin-tcm/$repo.git" $p.base.sha 2>&1 | Out-Null
      if ((git -C $w cat-file -t $p.base.sha 2>$null) -ne 'commit') { $row.Result = 'SKIP: original base commit could not be fetched'; [void]$rows.Add($row); continue } }
    git -C $w -c "http.extraHeader=Authorization: Basic $tb" fetch -q --depth=1 "https://github.com/tcm-pilot/$repo.git" $tc.sha 2>&1 | Out-Null
    if ((git -C $w cat-file -t $p.head.sha 2>$null) -ne 'commit') { $row.Result = 'SKIP: head commit could not be fetched'; [void]$rows.Add($row); continue }
    $big = @(git -C $w ls-tree -r -l $p.head.sha | Where-Object { $_ -match '^\d+ blob ([0-9a-f]+)\s+(\d+)\t(.+)$' -and [long]$Matches[2] -gt $LFSMAX } | ForEach-Object { ($_ -split "`t")[1] })
    $row.LargeFiles = $big.Count
    $ct = Convert-Tree $w $p.head.sha; $tree = $ct.Tree; $lfsOids = @($ct.Oids)
    if ($synth) {   # stand-in base: the original base commit's tree on top of the anchor, so the PR diff equals the original
      $cb = Convert-Tree $w $p.base.sha; $lfsOids += @($cb.Oids)
      $baseTree = $cb.Tree
    }
    if (-not $Apply) { $row.Result = 'would create' + $(if ($synth) { ' (stand-in base)' } else { '' }) + $(if ($lfsOids.Count) { " (LFS-converted $($lfsOids.Count) file(s))" } else { '' }); [void]$rows.Add($row); continue }
    if ($lfsOids.Count) {   # upload the large files to tcm-pilot's LFS store (skipped by git-lfs when already there)
      $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $tb"
      git -C $w lfs push --object-id "https://github.com/tcm-pilot/$repo.git" @lfsOids 2>&1 | Out-Null; $lfsRc = $LASTEXITCODE; $env:GIT_CONFIG_COUNT = '0'
      if ($lfsRc) { throw 'LFS upload failed' }
    }
    # one commit with the PR's changes on the located base
    $env:GIT_AUTHOR_NAME = $bc.commit.author.name; $env:GIT_AUTHOR_EMAIL = 'migration@teciem.com'; $env:GIT_COMMITTER_NAME = 'Teciem migration'; $env:GIT_COMMITTER_EMAIL = 'migration@teciem.com'
    $env:GIT_AUTHOR_NAME = 'Teciem migration'
    $baseSha = $tc.sha
    if ($synth) { $baseSha = "Base of fin-tcm PR #$n`n`nThe files as they were on $($p.base.ref) when the PR was opened (Finastra commit $($p.base.sha)); that commit is no longer part of the repository's branches." | git -C $w commit-tree $baseTree -p $tc.sha }
    $nc = "Recreated fin-tcm PR #$n ($($p.title))`n`nThe original commits of this PR are combined into one commit: the PR reference was no longer available in Finastra GitHub." | git -C $w commit-tree $tree -p $baseSha
    $hn = "fin-tcm-pr/$n-head"; $bn = "fin-tcm-pr/$n-base"
    # 16 Nov: a retry after a failed PR creation reuses the temp branches already pushed (a rebuilt commit would get a new timestamp/ID)
    $have = @(git -C $w -c "http.extraHeader=Authorization: Basic $tb" ls-remote --heads "https://github.com/tcm-pilot/$repo.git" "refs/heads/$hn" "refs/heads/$bn" 2>$null)
    if ($have.Count -lt 2) {
      $o = git -C $w -c "http.extraHeader=Authorization: Basic $tb" push --porcelain "https://github.com/tcm-pilot/$repo.git" "$($nc):refs/heads/$hn" "$($baseSha):refs/heads/$bn" 2>&1 | ForEach-Object { "$_" }
      if ($LASTEXITCODE) { throw "push failed: $(($o | Where-Object { $_ -match '^!|error' }) -join ' ')" }
    }
    $who = $p.user.login; $tciem = $map[$who.ToLower()]
    $when = if ($p.merged_at) { "merged $($p.merged_at.Substring(0,10))" } elseif ($p.closed_at) { "closed without merging $($p.closed_at.Substring(0,10))" } else { 'open' }
    $body = "> Migrated from fin-tcm PR #$n by $who$(if ($tciem) { " (Teciem: $tciem)" }), created $($p.created_at.Substring(0,10)); originally $($p.head.ref) -> $($p.base.ref), $when.`n> Original in Finastra GitHub (Finastra account needed): https://github.com/fin-tcm-old/$repo/pull/$n`n> The PR's original commits are combined into one commit here because the PR reference was no longer available in Finastra GitHub; the original discussion is copied in the comments below.`n`n$($p.body)"
    if ($body.Length -gt 65000) { $body = $body.Substring(0, 65000) }
    $new = Invoke-RestMethod -Method Post "https://api.github.com/repos/tcm-pilot/$repo/pulls" -Headers $tgt -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes((@{ title = $p.title; head = $hn; base = $bn; body = $body } | ConvertTo-Json)))
    $row.NewPR = $new.number
    if ($p.state -eq 'closed') { $null = Invoke-RestMethod -Method Patch "https://api.github.com/repos/tcm-pilot/$repo/pulls/$($new.number)" -Headers $tgt -ContentType application/json -Body '{"state":"closed"}' }
    git -C $w -c "http.extraHeader=Authorization: Basic $tb" push -q "https://github.com/tcm-pilot/$repo.git" ":refs/heads/$hn" ":refs/heads/$bn" 2>&1 | Out-Null
    $row.Result = "CREATED #$($new.number) $(if ($p.state -eq 'closed') { 'closed' } else { 'open' })"
  } catch {
    $msg = $_.Exception.Message
    if ($msg -match 'could not be resolved|Unable to connect|timed out|connection' -and $attempt -lt 5 -and -not $row.NewPR) { Wait-Network; $queue.Enqueue(@($x, $attempt + 1)); continue }
    $row.Result = "FAILED: $msg"
  }
  [void]$rows.Add($row)
}
$f = "C:\kon-migration\pr-recover\recover-$(Get-Date -Format yyyyMMdd-HHmm).csv"; $rows | Export-Csv $f -NoTypeInformation -Encoding utf8
"PRs: $($rows.Count)"; $rows | Group-Object { ($_.Result -split '[:#]')[0].Trim() } | ForEach-Object { "  {0,-22} {1}" -f $_.Name, $_.Count }
$rows | Where-Object { $_.Result -like 'SKIP*' -or $_.Result -like 'FAILED*' } | Group-Object Result | ForEach-Object { "  - $($_.Name): $($_.Count)" }
"detail: $f"
