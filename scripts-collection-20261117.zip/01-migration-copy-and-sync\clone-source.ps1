param(
  [string]$Org  = "fin-tcm",
  [string]$Repo = "kon-kplus-front",
  [string]$Work = "C:\kon-migration"
)
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')

# load tokens from pats.txt without echoing them
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"([^"]*)"') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))

# auth via env-based git config: not persisted, not on the command line; scoped to github.com only
$env:GIT_CONFIG_COUNT   = "1"
$env:GIT_CONFIG_KEY_0   = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $b64"
$env:GIT_TERMINAL_PROMPT = "0"
$env:GCM_INTERACTIVE     = "never"

New-Item -ItemType Directory -Force $Work | Out-Null
$dir = Join-Path $Work "$Repo.git"
$log = Join-Path $Work "$Repo-clone.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

Log "=== clone $Org/$Repo -> $dir ==="
if (-not (Test-Path "$dir\HEAD")) {
  # reftable: the repo has refs differing only by case, which the 'files' backend can't store on Windows
  git init --bare -q --ref-format=reftable $dir
  git -C $dir config remote.origin.url "https://github.com/$Org/$Repo.git"
  git -C $dir config remote.origin.fetch "+refs/heads/*:refs/heads/*"
  git -C $dir config --add remote.origin.fetch "+refs/tags/*:refs/tags/*"
  git -C $dir config lfs.url "https://github.com/$Org/$Repo.git/info/lfs"
}
if (-not (Test-Path "$dir\HEAD")) { Log "FATAL: could not create $dir"; exit 1 }
if ((git -C $dir rev-parse --show-ref-format) -ne 'reftable') {
  Log "migrating refs to reftable ..."
  git -C $dir refs migrate --ref-format=reftable *>&1 | ForEach-Object { "$_" } | Add-Content $log -Encoding utf8
}

Log "git fetch (heads + tags) ..."
$t = Get-Date
git -C $dir fetch origin --prune --no-progress *>&1 | ForEach-Object { "$_" } | Where-Object { $_ -notmatch '^\s*\*? ?\[new (tag|branch)\]' } | Add-Content $log -Encoding utf8
$rc = $LASTEXITCODE
Log ("git fetch exit={0} in {1:N0} min" -f $rc, ((Get-Date)-$t).TotalMinutes)
if ($rc -ne 0) { Get-Content $log -Tail 15; Log "FATAL: fetch failed"; exit 1 }
$heads = @(git -C $dir for-each-ref --format="%(refname)" refs/heads).Count
$tags  = @(git -C $dir for-each-ref --format="%(refname)" refs/tags).Count
Log "branches=$heads tags=$tags"
git -C $dir count-objects -vH | ForEach-Object { Log "  $_" }

Log "git lfs fetch --all ..."
$t = Get-Date
git -C $dir lfs fetch --all origin *>&1 | ForEach-Object { "$_" } | Out-File $log -Append -Encoding utf8
Log ("git lfs fetch exit={0} in {1:N0} min" -f $LASTEXITCODE, ((Get-Date)-$t).TotalMinutes)

Log "LFS inventory (all refs) ..."
$inv = Join-Path $Work "$Repo-lfs-inventory.txt"
git -C $dir lfs ls-files --all --long --size *>&1 | ForEach-Object { "$_" } | Out-File $inv -Encoding utf8
$oids = Get-Content $inv | ForEach-Object { if ($_ -match '^([0-9a-f]{64})\s') { $Matches[1] } } | Sort-Object -Unique
$lfsDir = Join-Path $dir "lfs\objects"
$missing = @($oids | Where-Object { -not (Test-Path (Join-Path $lfsDir "$($_.Substring(0,2))\$($_.Substring(2,2))\$_")) })
$bytes = (Get-ChildItem $lfsDir -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
Log ("LFS objects referenced={0} present={1} missing={2} localSize={3:N2} GB" -f $oids.Count, ($oids.Count - $missing.Count), $missing.Count, ($bytes/1GB))
if ($missing.Count) { $missing | Out-File (Join-Path $Work "$Repo-lfs-missing.txt") -Encoding utf8; Log "missing OIDs written to $Repo-lfs-missing.txt" }
Log "=== done ==="
