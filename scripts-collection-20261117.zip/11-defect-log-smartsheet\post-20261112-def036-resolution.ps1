# 12 Nov 2026 (Gareth: "post"). Sets the empty Resolution cell of DEF-036 (Alexandra Vate asked). Nothing else changed.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$text = 'GitHub Desktop is supported. Once users receive their Teciem laptops they install GitHub Desktop and sign in with their Teciem GitHub account via SSO to connect to the GitHub cloud environment. Closed 11/4 (Kaitlin Walker).'
$sid = '3761521504348036'
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$hd = @{ Authorization = "Bearer $tok" }
$sh = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sid" -Headers $hd
$cid = @{}; $sh.columns | ForEach-Object { $cid[$_.title] = $_.id }
$row = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $cid['Defect ID']).value -eq 'DEF-036' }
if (@($row).Count -ne 1) { throw "DEF-036 row not found exactly once" }
$cur = ($row.cells | Where-Object columnId -eq $cid['Resolution']).value
if ($cur) { throw "Resolution already has a value - not overwriting: $cur" }
if ($DryRun) { "dry run: would set Resolution of DEF-036 (row $($row.id)) to: $text"; return }
$body = ConvertTo-Json -Depth 5 @(@{ id = $row.id; cells = @(@{ columnId = $cid['Resolution']; value = $text }) })
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sid/rows" -Headers $hd -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
"updated rows: $(@($res.result).Count); Resolution now: $(($res.result[0].cells | Where-Object columnId -eq $cid['Resolution']).value)"
