param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out = "C:\kon-migration\probe",
  [int]$Sample = 0          # 0 = all repos for per-repo checks; N = random sample of N repos (faster)
)
# Read-only probe of everything GitHub can hold, source vs target. Writes probe-github.json + per-category CSVs.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$Auth = @{ $SrcOrg = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
           $TgtOrg = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" } }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "probe-github.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Get-One($org, $uri) {
  for ($a = 1; ; $a++) {
    try { return Invoke-RestMethod $uri -Headers $Auth[$org] }
    catch { $c = $_.Exception.Response.StatusCode.value__; if ($c -in 403, 429 -and $a -lt 5) { Start-Sleep (30 * $a); continue }; return $null }
  }
}
function Get-All($org, $uri, $prop) {
  $acc = New-Object System.Collections.ArrayList; $page = 1
  do { $r = Get-One $org "$uri$(if($uri -match '\?'){'&'}else{'?'})per_page=100&page=$page"; $n = 0
       $items = if ($prop) { $r.$prop } else { $r }
       foreach ($x in $items) { if ($x) { [void]$acc.Add($x); $n++ } }; $page++ } while ($n -eq 100)
  $acc
}
function Gql($org, $q, $v) { try { Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $Auth[$org] -Body (@{ query = $q; variables = $v } | ConvertTo-Json -Depth 10 -Compress) -ContentType application/json } catch { $null } }

$res = [ordered]@{}
function Put($cat, $src, $tgt, $note) { $res[$cat] = [ordered]@{ Source = $src; Target = $tgt; Note = $note }; Log ("{0,-38} source={1,-10} target={2,-10} {3}" -f $cat, $src, $tgt, $note) }

Log "=== GitHub probe $SrcOrg -> $TgtOrg ==="
# ---------- org level ----------
foreach ($pair in @(
  @('Org members', "members", ''), @('Org owners', "members?role=admin", ''), @('Outside collaborators', "outside_collaborators", ''),
  @('Teams', "teams", ''), @('Org webhooks', "hooks", ''), @('Org Actions secrets', "actions/secrets", 'secrets'),
  @('Org Actions variables', "actions/variables", 'variables'), @('Org Dependabot secrets', "dependabot/secrets", 'secrets'),
  @('Org Codespaces secrets', "codespaces/secrets", 'secrets'), @('Self-hosted runners (org)', "actions/runners", 'runners'),
  @('Runner groups', "actions/runner-groups", 'runner_groups'), @('Org rulesets', "rulesets", ''),
  @('GitHub App installations', "installations", 'installations'), @('Custom repository roles', "custom-repository-roles", 'custom_roles'),
  @('Org custom properties (schema)', "properties/schema", ''), @('Code security configurations', "code-security/configurations", ''))) {
  $s = @(Get-All $SrcOrg "https://api.github.com/orgs/$SrcOrg/$($pair[1])" $pair[2]).Count
  $t = @(Get-All $TgtOrg "https://api.github.com/orgs/$TgtOrg/$($pair[1])" $pair[2]).Count
  Put $pair[0] $s $t ''
}
$sApps = @(Get-All $SrcOrg "https://api.github.com/orgs/$SrcOrg/installations" 'installations' | ForEach-Object { $_.app_slug }); $tApps = @(Get-All $TgtOrg "https://api.github.com/orgs/$TgtOrg/installations" 'installations' | ForEach-Object { $_.app_slug })
$res['GitHub App installations'].Note = "missing in target: " + ((@($sApps | Where-Object { $_ -notin $tApps })) -join ', ')
$sHooks = @(Get-All $SrcOrg "https://api.github.com/orgs/$SrcOrg/hooks" ''); $res['Org webhooks'].Note = "source targets: " + ((@($sHooks | ForEach-Object { ([uri]$_.config.url).Host }) | Sort-Object -Unique) -join ', ')
$sProps = @(Get-All $SrcOrg "https://api.github.com/orgs/$SrcOrg/properties/schema" '' | ForEach-Object { $_.property_name }); $tProps = @(Get-All $TgtOrg "https://api.github.com/orgs/$TgtOrg/properties/schema" '' | ForEach-Object { $_.property_name })
$res['Org custom properties (schema)'].Note = "missing in target: " + ((@($sProps | Where-Object { $_ -notin $tProps })) -join ', ')
foreach ($ptype in 'container', 'npm', 'maven', 'nuget', 'rubygems') {
  $s = @(Get-All $SrcOrg "https://api.github.com/orgs/$SrcOrg/packages?package_type=$ptype" ''); $t = @(Get-All $TgtOrg "https://api.github.com/orgs/$TgtOrg/packages?package_type=$ptype" '')
  Put "GitHub Packages ($ptype)" $s.Count $t.Count $(if ($s.Count) { "e.g. " + ((@($s | Select-Object -First 5 | ForEach-Object name)) -join ', ') } else { '' })
}
$pq = 'query($o:String!){organization(login:$o){projectsV2{totalCount}}}'
Put 'Projects (org)' (Gql $SrcOrg $pq @{ o = $SrcOrg }).data.organization.projectsV2.totalCount (Gql $TgtOrg $pq @{ o = $TgtOrg }).data.organization.projectsV2.totalCount ''

# ---------- per repo ----------
$srcRepos = @(Get-All $SrcOrg "https://api.github.com/orgs/$SrcOrg/repos?type=all" '')
$tgtIdx = @{}; foreach ($r in (Get-All $TgtOrg "https://api.github.com/orgs/$TgtOrg/repos?type=all" '')) { $tgtIdx[$r.name.ToLower()] = $r }
Put 'Repositories' $srcRepos.Count $tgtIdx.Count ''
$both = @($srcRepos | Where-Object { $tgtIdx.ContainsKey($_.name.ToLower()) })
$check = if ($Sample -gt 0) { @($both | Get-Random -Count ([Math]::Min($Sample, $both.Count))) } else { $both }
Log "per-repo checks on $($check.Count) repos"
$rows = New-Object System.Collections.ArrayList; $i = 0
$cq = 'query($o:String!,$n:String!){repository(owner:$o,name:$n){issues{totalCount} pullRequests{totalCount} releases{totalCount} discussions{totalCount} milestones{totalCount} labels{totalCount} deployments{totalCount} hasWikiEnabled hasDiscussionsEnabled}}'
foreach ($s in $check) {
  $i++; if ($i % 100 -eq 0) { Log "  ...$i/$($check.Count)" }
  $t = $tgtIdx[$s.name.ToLower()]
  $sg = (Gql $SrcOrg $cq @{ o = $SrcOrg; n = $s.name }).data.repository; $tg = (Gql $TgtOrg $cq @{ o = $TgtOrg; n = $t.name }).data.repository
  $row = [ordered]@{ Repo = $s.name
    Archived = "$($s.archived)/$($t.archived)"; Visibility = "$($s.visibility)/$($t.visibility)"
    Issues = "$($sg.issues.totalCount)/$($tg.issues.totalCount)"; PRs = "$($sg.pullRequests.totalCount)/$($tg.pullRequests.totalCount)"
    Releases = "$($sg.releases.totalCount)/$($tg.releases.totalCount)"; Discussions = "$($sg.discussions.totalCount)/$($tg.discussions.totalCount)"
    Milestones = "$($sg.milestones.totalCount)/$($tg.milestones.totalCount)"; Labels = "$($sg.labels.totalCount)/$($tg.labels.totalCount)"
    Wiki = "$($sg.hasWikiEnabled)/$($tg.hasWikiEnabled)"
    Webhooks = "$(@(Get-All $SrcOrg "https://api.github.com/repos/$SrcOrg/$($s.name)/hooks" '').Count)/$(@(Get-All $TgtOrg "https://api.github.com/repos/$TgtOrg/$($t.name)/hooks" '').Count)"
    DeployKeys = "$(@(Get-All $SrcOrg "https://api.github.com/repos/$SrcOrg/$($s.name)/keys" '').Count)/$(@(Get-All $TgtOrg "https://api.github.com/repos/$TgtOrg/$($t.name)/keys" '').Count)"
    Autolinks = "$(@(Get-All $SrcOrg "https://api.github.com/repos/$SrcOrg/$($s.name)/autolinks" '').Count)/$(@(Get-All $TgtOrg "https://api.github.com/repos/$TgtOrg/$($t.name)/autolinks" '').Count)"
    DirectCollaborators = "$(@(Get-All $SrcOrg "https://api.github.com/repos/$SrcOrg/$($s.name)/collaborators?affiliation=direct" '').Count)/$(@(Get-All $TgtOrg "https://api.github.com/repos/$TgtOrg/$($t.name)/collaborators?affiliation=direct" '').Count)"
    Topics = "$(@($s.topics).Count)/$(@($t.topics).Count)"
    CustomProps = "$(@((Get-One $SrcOrg "https://api.github.com/repos/$SrcOrg/$($s.name)/properties/values") | Where-Object { $_.value }).Count)/$(@((Get-One $TgtOrg "https://api.github.com/repos/$TgtOrg/$($t.name)/properties/values") | Where-Object { $_.value }).Count)"
    Pages = "$([bool](Get-One $SrcOrg "https://api.github.com/repos/$SrcOrg/$($s.name)/pages"))/$([bool](Get-One $TgtOrg "https://api.github.com/repos/$TgtOrg/$($t.name)/pages"))"
    Description = $(if ("$($s.description)" -eq "$($t.description)") { 'same' } else { 'DIFFERS' })
    MergeSettings = $(if ("$($s.allow_squash_merge)$($s.allow_merge_commit)$($s.allow_rebase_merge)$($s.delete_branch_on_merge)" -eq "$($t.allow_squash_merge)$($t.allow_merge_commit)$($t.allow_rebase_merge)$($t.delete_branch_on_merge)") { 'same' } else { 'DIFFERS' }) }
  [void]$rows.Add([pscustomobject]$row)
}
$rows | Export-Csv (Join-Path $Out "github-per-repo.csv") -NoTypeInformation -Encoding utf8
function SumPair($col) { $a = 0; $b = 0; foreach ($r in $rows) { $p = "$($r.$col)" -split '/'; $a += [int]("0" + ($p[0] -replace '\D', '')); $b += [int]("0" + ($p[1] -replace '\D', '')) }; @($a, $b) }
function DiffCount($col) { @($rows | Where-Object { $p = "$($_.$col)" -split '/'; $p[0] -ne $p[1] }).Count }
foreach ($col in 'Issues', 'PRs', 'Releases', 'Discussions', 'Milestones', 'Labels', 'Webhooks', 'DeployKeys', 'Autolinks', 'DirectCollaborators', 'Topics', 'CustomProps') {
  $sum = SumPair $col; Put "Repo $col (total over $($rows.Count) repos)" $sum[0] $sum[1] "$(DiffCount $col) repos differ"
}
foreach ($col in 'Archived', 'Visibility', 'Wiki', 'Pages') { Put "Repo $col" '' '' "$(DiffCount $col) repos differ" }
foreach ($col in 'Description', 'MergeSettings') { Put "Repo $col" '' '' "$(@($rows | Where-Object { $_.$col -eq 'DIFFERS' }).Count) repos differ" }
$res | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $Out "probe-github.json") -Encoding utf8
Log "=== done ==="
