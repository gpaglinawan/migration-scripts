param(
  [string]$Orig = "C:\kon-migration\kon-kplus-front.git",
  [string]$Copy = "C:\kon-migration\kon-kplus-front-lfs.git",
  [string]$Out  = "C:\kon-migration\kon-bigfiles"
)
# Verifies the LFS rewrite lost nothing. Read-only on both repos.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
$log = Join-Path $Out "verify.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
$fail = 0

# 1. same ref names
$before = @(git -C $Orig for-each-ref --format="%(refname) %(objectname)")
$after  = @(git -C $Copy for-each-ref --format="%(refname) %(objectname)")
$bMap=@{}; foreach($l in $before){ $p=$l.Split(' '); $bMap[$p[0]]=$p[1] }
$aMap=@{}; foreach($l in $after){ $p=$l.Split(' '); $aMap[$p[0]]=$p[1] }
$onlyB = @($bMap.Keys | Where-Object { -not $aMap.ContainsKey($_) })
$onlyA = @($aMap.Keys | Where-Object { -not $bMap.ContainsKey($_) })
Log "1. refs: original=$($bMap.Count) rewritten=$($aMap.Count) missing=$($onlyB.Count) extra=$($onlyA.Count)"
if ($onlyB.Count -or $onlyA.Count) { $fail++; $onlyB + $onlyA | Out-File (Join-Path $Out "verify-ref-mismatch.txt") -Encoding utf8 }

# 2. every big blob's content is in LFS with matching sha256
$tmp = Join-Path $Out "blob.tmp"
$lfsDir = Join-Path $Copy "lfs\objects"
$ok2 = 0; $bad2 = @()
foreach ($l in Get-Content (Join-Path $Out "big-blobs.txt")) {
  $sha1 = $l.Split(' ')[0]
  cmd /c "git -C $Orig cat-file blob $sha1 > `"$tmp`""
  $h = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower()
  $obj = Join-Path $lfsDir "$($h.Substring(0,2))\$($h.Substring(2,2))\$h"
  if ((Test-Path $obj) -and (Get-Item $obj).Length -eq (Get-Item $tmp).Length) { $ok2++ } else { $bad2 += "$sha1 sha256=$h" }
}
Remove-Item $tmp -ErrorAction SilentlyContinue
Log "2. large files preserved in LFS (sha256 + size match): $ok2 of $($ok2 + $bad2.Count)"
if ($bad2.Count) { $fail++; $bad2 | Out-File (Join-Path $Out "verify-lfs-missing.txt") -Encoding utf8 }

# 3. every ref tip: identical content except .gitattributes and the files converted to LFS pointers
#    (the copy still holds all original objects, so original and rewritten tips can be diffed in one repo)
$bigPaths = @{}; Import-Csv (Join-Path $Out "big-files.csv") | ForEach-Object { $bigPaths[$_.Path] = $true }
$diffRefs = 0; $unexpected = New-Object System.Collections.ArrayList; $i = 0
foreach ($ref in $bMap.Keys) {
  $i++; if ($i % 1000 -eq 0) { Log "   ...$i/$($bMap.Count) refs compared" }
  if (-not $aMap.ContainsKey($ref)) { continue }
  if ($bMap[$ref] -eq $aMap[$ref]) { continue }   # commit unchanged
  $files = @(git -C $Copy diff-tree -r --no-renames --name-only "$($bMap[$ref])^{tree}" "$($aMap[$ref])^{tree}" 2>$null)
  $bad = @($files | Where-Object { $_ -and $_ -notmatch '(^|/)\.gitattributes$' -and -not $bigPaths[$_] })
  if ($bad.Count) { $diffRefs++; foreach ($f in $bad) { [void]$unexpected.Add("$ref`t$f") } }
}
Log "3. ref tips with unexpected content differences: $diffRefs"
if ($diffRefs) { $fail++; $unexpected | Out-File (Join-Path $Out "verify-content-diff.txt") -Encoding utf8 }

# 4. nothing left above GitHub's limit in the rewritten history
$tooBig = 0
cmd /c "git -C $Copy rev-list --objects --all | git -C $Copy cat-file --batch-check=""%(objecttype) %(objectsize)"" > `"$Out\after-sizes.txt`""
$sr = [IO.File]::OpenText("$Out\after-sizes.txt"); while (($l = $sr.ReadLine()) -ne $null) { $p = $l.Split(' '); if ($p[0] -eq 'blob' -and [long]$p[1] -gt 100MB) { $tooBig++ } }; $sr.Close()
Log "4. blobs >100MB reachable in rewritten history: $tooBig"
if ($tooBig) { $fail++ }

Log ("=== VERIFY {0} ({1} check(s) failed) ===" -f $(if ($fail) { 'FAILED' } else { 'PASSED' }), $fail)
exit $fail
