param(
  [Parameter(Mandatory)][string[]]$Repos,
  [string]$SrcOrg = "tcm-pilot",
  [string]$TgtOrg = "tcm-pilot-test",
  [string]$Work = "C:\kon-migration\testorg",
  [switch]$CloneOnly,                    # fetch the copies (and LFS objects) but don't touch the target org
  [int]$Batch = 200
)
# Copies repositories into a test organisation: all branches, tags and LFS objects, default branch, private.
# Git content only (no PRs/issues). Never pushes to the source. Re-runnable: existing clones are updated,
# existing target repos are reused, and only refs that differ are pushed (with --force: the test org is disposable).
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$env:GIT_TERMINAL_PROMPT = "0"; $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work "copy.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function RemoteRefs($url) { $m = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal); git ls-remote $url 'refs/heads/*' 'refs/tags/*' | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notmatch '\^\{\}$') { $m[$p[1]] = $p[0] } }; $m }

Log "=== copy $($Repos.Count) repos $SrcOrg -> $TgtOrg $(if($CloneOnly){'(clone only)'}) ==="
$results = @()
foreach ($r in $Repos) {
  $dir = Join-Path $Work "$r.git"; $src = "https://github.com/$SrcOrg/$r.git"; $tgt = "https://github.com/$TgtOrg/$r.git"
  # 1. clone or update (branches and tags only; refs/pull/* can't be pushed)
  if (-not (Test-Path $dir)) {
    git init --bare -q --ref-format=reftable $dir
    git -C $dir config remote.origin.url $src
    git -C $dir config remote.origin.fetch "+refs/heads/*:refs/heads/*"
    git -C $dir config --add remote.origin.fetch "+refs/tags/*:refs/tags/*"
  }
  git -C $dir fetch -q --prune origin 2>&1 | Select-Object -Last 2 | ForEach-Object { Log "  $r fetch: $_" }
  git -C $dir lfs fetch --all origin 2>&1 | Select-Object -Last 1 | ForEach-Object { Log "  $r lfs: $_" }
  $local = @(git -C $dir for-each-ref --format="%(refname)" refs/heads refs/tags)
  if ($CloneOnly) { Log "  $r cloned: $($local.Count) refs"; continue }

  # 2. target repo
  $src_meta = Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$r" -Headers $hdr
  try { $null = Invoke-RestMethod "https://api.github.com/repos/$TgtOrg/$r" -Headers $hdr }
  catch { Invoke-RestMethod -Method POST "https://api.github.com/orgs/$TgtOrg/repos" -Headers $hdr -ContentType application/json -Body (@{ name = $r; private = $true; description = "Test copy of $SrcOrg/$r"; has_wiki = $false } | ConvertTo-Json) | Out-Null; Log "  $r created in $TgtOrg" }

  # 3. LFS objects first, then refs in batches (only those that differ)
  git -C $dir config lfs.url "$tgt/info/lfs"
  $oids = @(Get-ChildItem (Join-Path $dir "lfs\objects") -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object Name)
  if ($oids.Count) { git -C $dir lfs push --object-id $tgt @oids 2>&1 | Select-Object -Last 1 | ForEach-Object { Log "  $r lfs push: $_" } }
  $have = RemoteRefs $tgt
  $todo = @($local | Where-Object { $have[$_] -ne (git -C $dir rev-parse $_) })
  # default branch first so the repository has history before the other refs
  $def = "refs/heads/$($src_meta.default_branch)"; $todo = @($todo | Where-Object { $_ -eq $def }) + @($todo | Where-Object { $_ -ne $def })
  for ($i = 0; $i -lt $todo.Count; $i += $Batch) {
    $chunk = $todo[$i..([Math]::Min($i + $Batch - 1, $todo.Count - 1))]
    git -C $dir push -q --force $tgt @($chunk | ForEach-Object { "+${_}:${_}" }) 2>&1 | Where-Object { $_ -match 'error|rejected|fatal' } | Select-Object -First 3 | ForEach-Object { Log "  $r push: $_" }
  }
  try { Invoke-RestMethod -Method PATCH "https://api.github.com/repos/$TgtOrg/$r" -Headers $hdr -ContentType application/json -Body (@{ default_branch = $src_meta.default_branch } | ConvertTo-Json) | Out-Null } catch { Log "  $r default branch not set: $($_.Exception.Message)" }

  # 4. verify against the source
  $s = RemoteRefs $src; $t = RemoteRefs $tgt
  $diff = @($s.Keys | Where-Object { $t[$_] -ne $s[$_] })
  Log ("  {0,-44} refs={1} differing={2} lfs={3}" -f $r, $s.Count, $diff.Count, $oids.Count)
  $results += [pscustomobject]@{ Repo = $r; Refs = $s.Count; Differing = $diff.Count; LfsObjects = $oids.Count; DefaultBranch = $src_meta.default_branch }
}
if ($results) { $results | Export-Csv (Join-Path $Work "copy-results.csv") -NoTypeInformation -Encoding utf8 }
$env:GIT_CONFIG_COUNT = "0"
Log "=== done ==="
