param(
  [string]$Name = "kon-kplus-front",
  [string]$Orig = "C:\kon-migration\kon-kplus-front.git",
  [string]$Copy = "C:\kon-migration\kon-kplus-front-lfs2.git",
  [string]$Target = "https://github.com/tcm-pilot/kon-kplus-front.git",
  [string]$Out = "C:\kon-migration\kon-catchup",
  [string]$PrevMap = "C:\kon-migration\kon-kplus-front-lfs.git\filter-repo\commit-map"
)
# Catch-up for a repo migrated with the large-file rewrite: fetch the latest Finastra refs into the bare mirror,
# re-run the (deterministic) rewrite into a fresh copy, check that unchanged history kept its commit IDs,
# then push only what changed (kon-push.ps1: LFS first, trunk in steps, refs in batches, no force).
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "catchup.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

# 1. fetch latest from Finastra (prune: branches deleted in Finastra leave the mirror; the target is never pruned)
Log "=== 1. fetch $Name from fin-tcm ==="
$env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))
$env:GIT_TERMINAL_PROMPT = "0"
$before = @(git -C $Orig for-each-ref --format="%(objectname) %(refname)")
git -C $Orig fetch --prune origin 2>&1 | Select-Object -Last 3 | ForEach-Object { Log "   $_" }
if ($LASTEXITCODE -ne 0) { Log "FATAL: fetch failed"; exit 1 }
$after = @(git -C $Orig for-each-ref --format="%(objectname) %(refname)")
$changed = @(Compare-Object $before $after | Where-Object SideIndicator -eq '=>').Count
Log "   refs before=$($before.Count) after=$($after.Count) new or moved=$changed"
$env:GIT_CONFIG_COUNT = "0"

# 2. rewrite into a fresh copy
Log "=== 2. rewrite (files > 100 MB -> LFS) ==="
& C:\kon-migration\scripts\lfs-rewrite.ps1 -Orig $Orig -Copy $Copy -Out (Join-Path $Out "rewrite") | ForEach-Object { Log "   $_" }
$newMap = Join-Path $Copy "filter-repo\commit-map"
if (-not (Test-Path $newMap)) { Log "FATAL: rewrite produced no commit map"; exit 1 }

# determinism check: every commit in the previous map must map to the same new commit
$prev = New-Object 'System.Collections.Generic.Dictionary[string,string]'; foreach ($l in [IO.File]::ReadLines($PrevMap)) { $p = $l.Split(' '); if ($p.Count -eq 2 -and $p[0] -ne 'old') { $prev[$p[0]] = $p[1] } }
$same = 0; $diff = 0; foreach ($l in [IO.File]::ReadLines($newMap)) { $p = $l.Split(' '); if ($p.Count -eq 2 -and $prev.ContainsKey($p[0])) { if ($prev[$p[0]] -eq $p[1]) { $same++ } else { $diff++ } } }
Log "   determinism: $same commits kept their rewritten ID, $diff changed"
if ($diff -gt 0) { Log "FATAL: rewrite is not reproducing the previous IDs - not pushing"; exit 1 }

# 3. push only what changed (no force)
Log "=== 3. push to $Target ==="
& C:\kon-migration\scripts\kon-push.ps1 -Repo $Copy -Target $Target -Out (Join-Path $Out "push") | ForEach-Object { Log "   $_" }
Log "=== catch-up finished (push exit $LASTEXITCODE = refs still mismatched) ==="
