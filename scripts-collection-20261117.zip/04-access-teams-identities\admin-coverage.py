# 14 Nov 2026 - read-only: which held direct-admin grants are already covered in tcm-pilot because the person is a member
# of a team that has ADMIN on that repo. Input: admin-grants-for-owners CSV + tracksheet access CSV (team permissions).
import csv, json, os, sys, time, urllib.request
tok = os.environ['GH_TGT_PAT']
grants = list(csv.DictReader(open(sys.argv[1], encoding='utf-8-sig')))
acc = {r['Repo']: r for r in csv.DictReader(open(r'C:\kon-migration\tracksheet\access-tcm-pilot.csv', encoding='utf-8-sig'))}
def gql(q, v):
    for a in range(6):
        try:
            req = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v}).encode(), headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
            return json.load(urllib.request.urlopen(req, timeout=120))['data']
        except Exception: time.sleep(10 * (a + 1))
admin_teams = {}
for g in grants:
    for x in (acc.get(g['Repo'], {}).get('Teams') or '').split(';'):
        if x.endswith(':ADMIN'): admin_teams.setdefault(g['Repo'], set()).add(x.rsplit(':', 1)[0])
members = {}
for slug in sorted({t for s in admin_teams.values() for t in s}):
    logins, after = set(), None
    while True:
        d = gql('query($s:String!,$a:String){ organization(login:"tcm-pilot"){ team(slug:$s){ members(first:100, after:$a){ pageInfo{hasNextPage endCursor} nodes{ login } } } } }', {'s': slug, 'a': after})
        m = d['organization']['team']['members']; logins |= {n['login'].lower() for n in m['nodes']}
        if not m['pageInfo']['hasNextPage']: break
        after = m['pageInfo']['endCursor']
    members[slug] = logins
out = []
for g in grants:
    via = [t for t in sorted(admin_teams.get(g['Repo'], set())) if g['Person'].lower() in members.get(t, set())]
    g['Already admin via team in tcm-pilot'] = ', '.join(via)
    out.append(g)
with open(sys.argv[2], 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
cov = sum(1 for g in out if g['Already admin via team in tcm-pilot'])
print(f'admin teams checked: {len(members)}; grants {len(out)}; already covered by a team: {cov}; still to decide: {len(out) - cov}')
