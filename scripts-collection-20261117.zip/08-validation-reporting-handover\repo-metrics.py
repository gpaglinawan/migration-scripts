# 14 Nov 2026 - read-only metrics per repo for the GitHub tracksheet: PRs (open/merged/closed), releases, archived,
# default branch, size, LFS-tracked flag not available via API. 25 repos per GraphQL query.
# Usage: python -I repo-metrics.py <org> <repos.txt> <out.csv>   (token in GH_SRC_PAT for fin-tcm, GH_TGT_PAT otherwise)
import sys, os, json, csv, time, urllib.request, urllib.error
org, listfile, out = sys.argv[1], sys.argv[2], sys.argv[3]
tok = os.environ['GH_SRC_PAT' if org == 'fin-tcm' else 'GH_TGT_PAT']
repos = [l.strip() for l in open(listfile, encoding='utf-8-sig') if l.strip()]
F = ('name isArchived visibility diskUsage defaultBranchRef{name} '
     'o:pullRequests(states:OPEN){totalCount} m:pullRequests(states:MERGED){totalCount} c:pullRequests(states:CLOSED){totalCount} '
     'releases{totalCount}')
def post(q):
    for a in range(8):
        try:
            req = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q}).encode(), headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
            d = json.load(urllib.request.urlopen(req, timeout=120))
            if any(e.get('type') == 'RATE_LIMITED' for e in d.get('errors') or []): time.sleep(60); continue
            return d
        except Exception as e:
            time.sleep(10 * (a + 1))
    return {'data': {}}
rows = []
for i in range(0, len(repos), 25):
    chunk = repos[i:i + 25]
    q = '{' + ' '.join(f'r{j}:repository(owner:"{org}",name:{json.dumps(n)}){{{F}}}' for j, n in enumerate(chunk)) + '}'
    d = (post(q).get('data') or {})
    for j, n in enumerate(chunk):
        r = d.get(f'r{j}')
        if not r: rows.append({'Repo': n, 'Found': 'no'}); continue
        rows.append({'Repo': n, 'Found': 'yes', 'Archived': r['isArchived'], 'Visibility': r['visibility'], 'SizeKB': r['diskUsage'],
                     'Default': (r.get('defaultBranchRef') or {}).get('name', ''), 'PROpen': r['o']['totalCount'], 'PRMerged': r['m']['totalCount'],
                     'PRClosed': r['c']['totalCount'], 'Releases': r['releases']['totalCount']})
    if (i // 25) % 20 == 0: print(f'{org}: {i + len(chunk)}/{len(repos)}', flush=True)
with open(out, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['Repo','Found','Archived','Visibility','SizeKB','Default','PROpen','PRMerged','PRClosed','Releases']); w.writeheader(); w.writerows(rows)
print(f'done {len(rows)} -> {out}')
