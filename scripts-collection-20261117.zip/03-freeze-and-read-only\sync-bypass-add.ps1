# Lets the nightly sync update protected branches in tcm-pilot until cutover: adds "Organization admin" as a bypass
# actor on each repository ruleset that blocked the sync (list: C:\kon-migration\rules\sync-blocking-rulesets.csv).
# Every ruleset is backed up first to C:\kon-migration\rules\bypass-backup\<repo>-<id>.json; sync-bypass-restore.ps1
# puts them all back exactly as they were. Rulesets that already have the bypass are skipped. Run by the org owner.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$bk = "C:\kon-migration\rules\bypass-backup"; New-Item -ItemType Directory -Force $bk | Out-Null
$list = Import-Csv C:\kon-migration\rules\sync-blocking-rulesets.csv | Select-Object Repo, RulesetId -Unique
$added = 0; $skipped = 0
foreach ($x in $list) {
  $u = "https://api.github.com/repos/tcm-pilot/$($x.Repo)/rulesets/$($x.RulesetId)"
  $rs = Invoke-RestMethod $u -Headers $h
  $file = Join-Path $bk "$($x.Repo)-$($x.RulesetId).json"
  if (-not (Test-Path $file)) { $rs | ConvertTo-Json -Depth 10 | Set-Content $file -Encoding utf8 }   # keep the ORIGINAL on re-runs
  if ($rs.bypass_actors | Where-Object { $_.actor_type -eq 'OrganizationAdmin' }) { $skipped++; continue }
  $actors = @($rs.bypass_actors | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } }) + @{ actor_id = 1; actor_type = 'OrganizationAdmin'; bypass_mode = 'always' }
  Invoke-RestMethod -Method PUT $u -Headers $h -ContentType application/json -Body (@{ bypass_actors = $actors } | ConvertTo-Json -Depth 5) | Out-Null
  $added++; "{0,-42} ruleset {1} '{2}': bypass added" -f $x.Repo, $x.RulesetId, $rs.name
}
"done: bypass added to $added rulesets, $skipped already had it. Backups: $bk"
