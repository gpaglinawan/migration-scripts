# Gives the Summit DevOps team access to their repositories in tcm-pilot-test (Soukaina Lourhaoui's request, 26 Oct 2026).
# Creates team "summit-devops-test" once, adds the people below and grants the team admin on every repo of the list
# that has already been copied. The direct admin access given earlier on 14 of the repos is left as it is. Safe to re-run.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$org = "tcm-pilot-test"; $team = "summit-devops-test"
# Doru, Gaurav, Noris and Soukaina (already direct admins) + Mihai-Daniel Cilidariu and Bogdan Kucsinschi (asked 26 Oct)
# + svc-deliv-teciem_tciem (Summit delivery service account, was in sum_admin in fin-tcm; asked 5 Nov)
$members = 'doru-florea_tciem','Gaurav-Kotecha_tciem','Noris-Filip_tciem','Soukaina-Lourhaoui_tciem',
           'mihai-cilidariu_tciem','Bogdan-Kucsinschi_tciem','svc-deliv-teciem_tciem'
$repos = @(Get-Content C:\kon-migration\testorg-summit-repos.txt | ForEach-Object { $_.Trim() } | Where-Object { $_ })

try { $null = Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$team" -Headers $h }
catch { Invoke-RestMethod -Method POST "https://api.github.com/orgs/$org/teams" -Headers $h -ContentType application/json -Body (@{ name = $team; description = "Summit DevOps - test organisation (TCM-DevOps-Summit)"; privacy = "closed" } | ConvertTo-Json) | Out-Null; "team $team created" }
foreach ($m in $members) {
  try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$team/memberships/$m" -Headers $h -ContentType application/json -Body '{"role":"member"}' | Out-Null }
  catch { "  $m : $($_.ErrorDetails.Message)" }
}
# keep the team equal to the list: remove anyone not on it (except the token owner, who GitHub adds as creator)
foreach ($x in (Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$team/members?per_page=100" -Headers $h)) {
  if ($members -notcontains $x.login -and $x.login -ne 'Gareth-Cabrera_tciem') { Invoke-RestMethod -Method DELETE "https://api.github.com/orgs/$org/teams/$team/memberships/$($x.login)" -Headers $h | Out-Null; "removed $($x.login) (not on the list)" }
}
"members: $($members.Count)"
$done = 0; $later = @()
foreach ($r in $repos) {
  try { $null = Invoke-RestMethod "https://api.github.com/repos/$org/$r" -Headers $h } catch { $later += $r; continue }
  # a repo that GEI is still importing exists but is locked: count it as not ready yet
  try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$team/repos/$org/$r" -Headers $h -ContentType application/json -Body '{"permission":"admin"}' | Out-Null; $done++ }
  catch { if ("$($_.ErrorDetails.Message)" -match 'locked') { $later += "$r (importing)" } else { "  $r : $($_.ErrorDetails.Message)" } }
}
"team has admin on $done repos; not ready yet ($($later.Count)): $($later -join ', ')"
