# 14 Nov 2026 - GIT-019C: verify the LFS copies (<repo>-pr2) before their swap (GIT-019D). Read-only on fin-tcm; on
# tcm-pilot it only ADDS missing LFS objects (fetched from fin-tcm) - never changes refs.
# Per repo: (1) PRs: every fin-tcm PR number present in the copy, and copy >= older -pr copy;
# (2) branch/tag NAMES: all fin-tcm names present (commit IDs differ by design - history rewritten for files > 100 MB);
# (3) LFS: every LFS object referenced in the copy's history is downloadable from the copy (GitHub LFS batch API);
#     missing ones are fetched from fin-tcm and uploaded, then re-checked;
# (4) built after the freeze (13 Nov 17:03 CET).  Output: C:\kon-migration\swap\git-019c-verify.csv
param([Parameter(Mandatory)][string[]]$Repos, [string]$Work = 'C:\kon-migration\lfscheck-pr2')
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$env:GIT_TERMINAL_PROMPT = '0'; $py = 'C:\kon-migration\tools\python\python.exe'; $diff = 'C:\kon-migration\scripts\pr-numbers-diff.py'
New-Item -ItemType Directory -Force $Work | Out-Null; $out = 'C:\kon-migration\swap\git-019c-verify.csv'
function Get-Names($b64, $url) { @(git -c "http.extraHeader=Authorization: Basic $b64" ls-remote --heads --tags $url 2>$null | Where-Object { $_ -notmatch '\^\{\}$' } | ForEach-Object { ($_ -split "`t")[1] }) }
function Test-Lfs($b64, $url, $objs) {   # returns oids NOT downloadable
  $missing = @()
  for ($k = 0; $k -lt $objs.Count; $k += 100) {
    $chunk = $objs[$k..([Math]::Min($k + 99, $objs.Count - 1))]
    $body = @{ operation = 'download'; transfers = @('basic'); objects = @($chunk | ForEach-Object { @{ oid = $_.oid; size = $_.size } }) } | ConvertTo-Json -Depth 4
    try { $r = Invoke-RestMethod -Method Post "$url/info/lfs/objects/batch" -Headers @{ Authorization = "Basic $b64"; Accept = 'application/vnd.git-lfs+json' } -ContentType 'application/vnd.git-lfs+json' -Body $body
          $missing += @($r.objects | Where-Object { $_.error -or -not $_.actions.download } | ForEach-Object oid) } catch { $missing += @($chunk.oid) }
  }
  $missing
}
foreach ($r in $Repos) {
  $copy = "$r-pr2"; $t0 = Get-Date
  $info = try { Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$copy" -Headers $gh } catch { $null }
  if (-not $info) { [pscustomobject]@{ Repo = $r; Copy = $copy; Verdict = 'NOT FOUND' } | Export-Csv $out -Append -NoTypeInformation -Encoding utf8; "$copy : not found"; continue }
  $built = ([datetime]$info.created_at).ToLocalTime()
  # (1) PRs
  $cp = (& $py -I $diff "fin-tcm/$r" "tcm-pilot/$copy" 2>$null | Select-Object -First 1) -replace '.*: (\d+) PRs; .*: (\d+); missing (\d+)', '$1|$2|$3' -split '\|'
  $old = (& $py -I $diff "fin-tcm/$r" "tcm-pilot/$r-pr" 2>$null | Select-Object -First 1) -replace '.*: (\d+) PRs; .*: (\d+); missing (\d+)', '$2'
  # (2) ref names
  $sn = Get-Names $sb "https://github.com/fin-tcm/$r.git"; $tn = Get-Names $tb "https://github.com/tcm-pilot/$copy.git"
  $missNames = @($sn | Where-Object { $_ -notin $tn })
  # (3) LFS objects referenced in the copy's history
  $d = Join-Path $Work "$copy.git"
  if (-not (Test-Path $d)) { git -c "http.extraHeader=Authorization: Basic $tb" clone --bare --quiet "https://github.com/tcm-pilot/$copy.git" $d 2>&1 | Out-Null }
  $js = (git -C $d lfs ls-files --all --json 2>$null) -join "`n"
  $objs = @(if ($js) { ($js | ConvertFrom-Json).files | Where-Object { $_ } | ForEach-Object { [pscustomobject]@{ oid = $_.oid; size = [long]$_.size } } | Sort-Object oid -Unique })
  $miss = if ($objs.Count) { @(Test-Lfs $tb "https://github.com/tcm-pilot/$copy.git" $objs) } else { @() }
  $fixed = 0
  if ($miss.Count) {   # copy them from fin-tcm (add only)
    $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'
    $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")))"
    git -C $d lfs fetch "https://github.com/fin-tcm/$r.git" --all 2>&1 | Out-Null
    $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $([Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT")))"
    git -C $d -c lfs.allowincompletepush=true lfs push --object-id "https://github.com/tcm-pilot/$copy.git" @($miss) 2>&1 | Out-Null
    $env:GIT_CONFIG_COUNT = '0'
    $miss2 = @(Test-Lfs $tb "https://github.com/tcm-pilot/$copy.git" @($objs | Where-Object { $_.oid -in $miss })); $fixed = $miss.Count - $miss2.Count; $miss = $miss2
  }
  $notOnSource = if ($miss.Count) { @(Test-Lfs $sb "https://github.com/fin-tcm/$r.git" @($objs | Where-Object { $_.oid -in $miss })).Count } else { 0 }
  $v = if ($cp.Count -lt 3) { 'CHECK: PR count failed' } elseif ($cp[2] -ne '0') { "CHECK: $($cp[2]) PRs missing" } elseif ($missNames.Count) { "CHECK: $($missNames.Count) branch/tag names missing" }
       elseif ($miss.Count -gt $notOnSource) { "CHECK: $($miss.Count - $notOnSource) LFS objects missing" } elseif ($built -lt [datetime]'2026-11-13T17:03:00') { 'CHECK: built before the freeze' } else { 'READY to swap' }
  [pscustomobject]@{ Repo = $r; Copy = $copy; Built = $built.ToString('ddd HH:mm'); SrcPRs = $cp[0]; CopyPRs = $cp[1]; OldPrCopyPRs = $old; SrcRefNames = $sn.Count; CopyRefNames = $tn.Count; MissingRefNames = $missNames.Count
                     LfsObjects = $objs.Count; LfsCopiedNow = $fixed; LfsMissing = $miss.Count; LfsAlsoMissingInFinTcm = $notOnSource; Verdict = $v; Minutes = [int]((Get-Date) - $t0).TotalMinutes } |
    Tee-Object -Variable row | Export-Csv $out -Append -NoTypeInformation -Encoding utf8
  "{0,-30} built {1}  PRs {2}/{3} (old -pr {4})  refs {5}/{6}  LFS {7} (copied {8}, missing {9}, of which not in fin-tcm either {10})  -> {11}" -f $copy, $row.Built, $row.CopyPRs, $row.SrcPRs, $old, ($tn.Count), ($sn.Count), $objs.Count, $fixed, $miss.Count, $notOnSource, $v
}
