# 15 Nov 2026 - after the KON-kplus-front swap GitHub briefly locks the new repo. Waits for the lock to clear, then copies
# teams, direct collaborators and repo rulesets from the previous live repo (KON-kplus-front-old2) onto KON-kplus-front.
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $A = 'https://api.github.com'; $old = 'KON-kplus-front-old2'; $new = 'KON-kplus-front'
for ($i = 0; $i -lt 90; $i++) {
  try { $null = Invoke-RestMethod -Method Put "$A/orgs/tcm-pilot/teams/kon_r/repos/tcm-pilot/$new" -Headers $t -ContentType application/json -Body '{"permission":"pull"}'; "unlocked $(Get-Date -Format HH:mm:ss)"; break }
  catch { if ("$($_.ErrorDetails.Message)" -notmatch 'locked') { "other error: $($_.ErrorDetails.Message)"; break } }
  Start-Sleep 20
}
$ok = 0; $bad = @()
foreach ($tm in (Invoke-RestMethod "$A/repos/tcm-pilot/$old/teams?per_page=100" -Headers $t)) { try { $null = Invoke-RestMethod -Method Put "$A/orgs/tcm-pilot/teams/$($tm.slug)/repos/tcm-pilot/$new" -Headers $t -ContentType application/json -Body (@{ permission = $tm.permission } | ConvertTo-Json); $ok++ } catch { $bad += "team $($tm.slug): $($_.ErrorDetails.Message)" } }
"teams ok $ok"; $ok = 0
foreach ($c in (Invoke-RestMethod "$A/repos/tcm-pilot/$old/collaborators?affiliation=direct&per_page=100" -Headers $t)) { $perm = if ($c.permissions.admin) {'admin'} elseif ($c.permissions.maintain) {'maintain'} elseif ($c.permissions.push) {'push'} elseif ($c.permissions.triage) {'triage'} else {'pull'}; try { $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$new/collaborators/$($c.login)" -Headers $t -ContentType application/json -Body (@{ permission = $perm } | ConvertTo-Json); $ok++ } catch { $bad += "collab $($c.login): $($_.ErrorDetails.Message)" } }
"collaborators ok $ok"
$have = @((Invoke-RestMethod "$A/repos/tcm-pilot/$new/rulesets?includes_parents=false" -Headers $t).name)
foreach ($rs in (Invoke-RestMethod "$A/repos/tcm-pilot/$old/rulesets?includes_parents=false" -Headers $t)) { if ($rs.name -in $have) { continue }; $f = Invoke-RestMethod "$A/repos/tcm-pilot/$old/rulesets/$($rs.id)" -Headers $t
  $body = @{ name = $f.name; target = $f.target; enforcement = $f.enforcement; conditions = $f.conditions; rules = $f.rules; bypass_actors = @($f.bypass_actors | Where-Object { $_ }) } | ConvertTo-Json -Depth 20
  try { $null = Invoke-RestMethod -Method Post "$A/repos/tcm-pilot/$new/rulesets" -Headers $t -ContentType application/json -Body $body; "ruleset '$($f.name)' copied" } catch { $bad += "ruleset $($f.name): $($_.ErrorDetails.Message)" } }
$bad
Add-Content C:\kon-migration\nightly\cutover-20261113.log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') KON-kplus-front (email-mapped) teams/collaborators/rulesets re-applied from KON-kplus-front-old2 after GitHub lock (failures: $($bad.Count))" -Encoding utf8
