# DEF-013 / DEF-014 / DEF-118 (read-only): compares every team in fin-tcm with tcm-pilot (matched by slug):
#   display name (capitals), description, privacy, parent, and code review assignment settings.
# Writes team-settings-diff.csv next to this script.
$ErrorActionPreference = "Stop"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Teams($org, $tok) {
  $hh = @{ Authorization = "Bearer $tok" }; $all = @(); $after = $null
  do {
    $q = 'query($o:String!,$a:String){ organization(login:$o){ teams(first:100, after:$a){ pageInfo{hasNextPage endCursor} nodes{ slug name description privacy notificationSetting parentTeam{slug}
          reviewRequestDelegationEnabled reviewRequestDelegationAlgorithm reviewRequestDelegationMemberCount reviewRequestDelegationNotifyTeam } } } }'
    $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hh -ContentType application/json -Body (@{ query = $q; variables = @{ o = $org; a = $after } } | ConvertTo-Json)
    if ($r.errors) { throw ($r.errors | ConvertTo-Json -Compress) }
    $t = $r.data.organization.teams; $all += $t.nodes; $after = $t.pageInfo.endCursor
  } while ($t.pageInfo.hasNextPage)
  $all
}
$src = Teams 'fin-tcm' $env:GH_SRC_PAT; $tgt = Teams 'tcm-pilot' $env:GH_TGT_PAT
$ti = @{}; $tgt | ForEach-Object { $ti[$_.slug] = $_ }
$rows = foreach ($s in $src) {
  $t = $ti[$s.slug]
  if (-not $t) { [pscustomobject]@{ slug = $s.slug; issue = 'missing in tcm-pilot'; finastra = $s.name; teciem = '' }; continue }
  if ($s.name -cne $t.name) { [pscustomobject]@{ slug = $s.slug; issue = 'name'; finastra = $s.name; teciem = $t.name } }
  if ("$($s.description)" -cne "$($t.description)") { [pscustomobject]@{ slug = $s.slug; issue = 'description'; finastra = "$($s.description)"; teciem = "$($t.description)" } }
  if ($s.privacy -ne $t.privacy) { [pscustomobject]@{ slug = $s.slug; issue = 'privacy'; finastra = $s.privacy; teciem = $t.privacy } }
  if ("$($s.parentTeam.slug)" -ne "$($t.parentTeam.slug)") { [pscustomobject]@{ slug = $s.slug; issue = 'parent'; finastra = "$($s.parentTeam.slug)"; teciem = "$($t.parentTeam.slug)" } }
  $rs = "$($s.reviewRequestDelegationEnabled)|$($s.reviewRequestDelegationAlgorithm)|$($s.reviewRequestDelegationMemberCount)|$($s.reviewRequestDelegationNotifyTeam)"
  $rt = "$($t.reviewRequestDelegationEnabled)|$($t.reviewRequestDelegationAlgorithm)|$($t.reviewRequestDelegationMemberCount)|$($t.reviewRequestDelegationNotifyTeam)"
  if ($rs -ne $rt) { [pscustomobject]@{ slug = $s.slug; issue = 'code review assignment'; finastra = $rs; teciem = $rt } }
}
$rows | Export-Csv (Join-Path $PSScriptRoot "team-settings-diff.csv") -NoTypeInformation -Encoding utf8
"teams: fin-tcm $($src.Count), tcm-pilot $($tgt.Count)"
$rows | Group-Object issue | ForEach-Object { "{0,-24} {1}" -f $_.Name, $_.Count }
