# 16 Nov 2026 (DEF-067/086/261/262/265; Gareth: "1. ok"). Deletes in tcm-pilot the branches that Finastra deleted after migration
# (list: branch-cleanup\extra-branches-20261116-1551.csv). Per repo:
#   1 re-check now: delete only if the branch still exists in tcm-pilot on the SAME commit as listed, and does NOT exist in fin-tcm
#   2 skip branches deliberately carried over in today's swaps (swap\precheck\*.csv)
#   3 back up: fetch exactly those branches (full objects) into a local bare repo and write a git bundle - restorable any time
#   4 delete (one push of deletions per repo); log every branch
# Dry run unless -Apply. Output: branch-cleanup\delete-<stamp>.csv, bundles in branch-cleanup\backup\<repo>.bundle
param([switch]$Apply, [string]$List = 'C:\kon-migration\branch-cleanup\extra-branches-20261116-1551.csv')
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'
$dir = 'C:\kon-migration\branch-cleanup'; $bk = Join-Path $dir 'backup'; New-Item -ItemType Directory -Force $bk | Out-Null
$log = Join-Path $dir "delete-$(Get-Date -Format yyyyMMdd-HHmm).log"
function Write-Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $l; Add-Content $log $l -Encoding utf8 }
function Get-Heads($org, $repo, $b64) {
  for ($a = 0; $a -lt 4; $a++) {
    $o = git -c "http.extraHeader=Authorization: Basic $b64" ls-remote --heads "https://github.com/$org/$repo.git" 2>$null
    if (-not $LASTEXITCODE) { $h = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal); foreach ($l in $o) { $s, $r = $l -split "`t", 2; $h[$r.Substring(11)] = $s }; return $h }
    Start-Sleep 30
  }
  $null
}
# 16 Nov: delete only branches whose tip commit also exists in fin-tcm (proves Finastra had it and deleted the branch);
# a tip that exists only in tcm-pilot is work done in tcm-pilot (e.g. taw, taw-agent-sdk) and is kept
$srcApi = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }
function Test-InFinTcm($repo, $sha) {
  for ($a = 0; $a -lt 3; $a++) {
    try { $null = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$repo/commits/$sha" -Headers $srcApi -EA Stop; return $true }
    catch { $c = [int]$_.Exception.Response.StatusCode; if ($c -in 404, 422) { return $false }; Start-Sleep 20 }
  }
  $false   # unsure -> treat as not in fin-tcm -> kept
}
$keep = @{}; Get-ChildItem C:\kon-migration\swap\precheck\*.csv -EA SilentlyContinue | ForEach-Object { $r = $_.BaseName; Import-Csv $_.FullName | ForEach-Object { $keep["$r|$($_.Ref -replace '^heads/','')"] = 1 } }
$rows = New-Object System.Collections.ArrayList
$byRepo = Import-Csv $List | Where-Object Branch | Group-Object Repo
Write-Log "=== $(if($Apply){'APPLY'}else{'PLAN'}): $(@($byRepo).Count) repos, $((Import-Csv $List | Where-Object Branch).Count) listed branches ==="
foreach ($g in $byRepo) {
  $repo = $g.Name; $t = Get-Heads 'tcm-pilot' $repo $tb; $s = Get-Heads 'fin-tcm' $repo $sb
  if ($null -eq $t -or $null -eq $s) { Write-Log "$repo : could not list - skipped"; foreach ($x in $g.Group) { [void]$rows.Add([pscustomobject]@{ Repo = $repo; Branch = $x.Branch; Sha = $x.TcmPilotSha; Result = 'SKIP: could not list' }) }; continue }
  $del = @()
  foreach ($x in $g.Group) {
    $b = $x.Branch; $res =
      if ($keep["$repo|$b"]) { 'SKIP: carried over in swap (kept)' }
      elseif (-not $t.ContainsKey($b)) { 'SKIP: no longer in tcm-pilot' }
      elseif ($t[$b] -ne $x.TcmPilotSha) { 'SKIP: moved since listing' }
      elseif ($s.ContainsKey($b)) { 'SKIP: exists in fin-tcm' }
      elseif (-not (Test-InFinTcm $repo $x.TcmPilotSha)) { 'SKIP: commit not in fin-tcm (work done in tcm-pilot - kept)' }
      else { $del += $b; 'DELETE' }
    [void]$rows.Add([pscustomobject]@{ Repo = $repo; Branch = $b; Sha = $x.TcmPilotSha; Result = $res })
  }
  if (-not $del.Count) { Write-Log "$repo : nothing to delete"; continue }
  if (-not $Apply) { Write-Log "$repo : would delete $($del.Count)"; continue }
  # backup
  $w = Join-Path $bk "$repo.git"; if (-not (Test-Path $w)) { git init --bare -q $w }
  $specs = @($del | ForEach-Object { "+refs/heads/$($_):refs/heads/$_" })
  git -C $w -c "http.extraHeader=Authorization: Basic $tb" fetch -q "https://github.com/tcm-pilot/$repo.git" @specs 2>&1 | Out-Null
  $missing = @($del | Where-Object { (git -C $w rev-parse --verify -q "refs/heads/$_" 2>$null) -ne $t[$_] })
  if ($missing.Count) { Write-Log "$repo : backup incomplete for $($missing.Count) branch(es) - NOT deleting this repo"; foreach ($r in $rows | Where-Object { $_.Repo -eq $repo -and $_.Result -eq 'DELETE' }) { $r.Result = 'SKIP: backup failed' }; continue }
  git -C $w bundle create (Join-Path $bk "$repo.bundle") --branches 2>&1 | Out-Null
  if ($LASTEXITCODE) { Write-Log "$repo : bundle failed - NOT deleting"; continue }
  # delete (in chunks of 50 refs per push)
  for ($i = 0; $i -lt $del.Count; $i += 50) {
    $chunk = @($del[$i..([Math]::Min($i + 49, $del.Count - 1))] | ForEach-Object { ":refs/heads/$_" })
    $o = git -C $w -c "http.extraHeader=Authorization: Basic $tb" push --porcelain "https://github.com/tcm-pilot/$repo.git" @chunk 2>&1 | ForEach-Object { "$_" }
    foreach ($l in $o) { if ($l -match '^([-!])\s+:refs/heads/(.+?)\s') { $b = $Matches[2]; $ok = $Matches[1] -eq '-'; ($rows | Where-Object { $_.Repo -eq $repo -and $_.Branch -eq $b }) | ForEach-Object { $_.Result = if ($ok) { 'DELETED' } else { "FAILED: $l" } } } }
  }
  Write-Log "$repo : deleted $(@($rows | Where-Object { $_.Repo -eq $repo -and $_.Result -eq 'DELETED' }).Count) of $($del.Count) (backup $repo.bundle)"
}
$out = Join-Path $dir "delete-$(Get-Date -Format yyyyMMdd-HHmm).csv"; $rows | Export-Csv $out -NoTypeInformation -Encoding utf8
Write-Log "=== done: $(($rows | Group-Object { ($_.Result -split ':')[0] } | ForEach-Object { "$($_.Name) $($_.Count)" }) -join ', ') -> $out"
