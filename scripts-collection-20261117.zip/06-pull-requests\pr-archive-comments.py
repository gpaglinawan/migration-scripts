# 15 Nov 2026 (DEF-233/240, Samar's QA P1; Gareth: "ok 1 and 2"). For PRs recreated in tcm-pilot ("Migrated from fin-tcm
# PR #N" in the body), copies the original discussion from Finastra GitHub (fin-tcm) into the tcm-pilot PR as archive
# comment(s), so Teciem-only (_tciem) accounts can read it without access to fin-tcm-old.
#   copied: conversation comments, reviews with their verdict and text, inline review comments (file + line), with the
#           original author login and date. @mentions are neutralised (nobody is notified) and #N references are
#           neutralised (PR numbers differ in tcm-pilot, they would link to the wrong PR).
#   split into several comments when longer than GitHub's comment limit. Idempotent: a PR that already has an archive
#   comment is skipped. Read-only on fin-tcm.
# Usage:
#   pr-archive-comments.py --repo SPH-sophis --target-pr 11711 --out sample.md          (dry run: writes the comment text)
#   pr-archive-comments.py --repo SPH-sophis --target-pr 11711 --post-to tcm-pilot-test/<repo>#<n>   (test post elsewhere)
#   pr-archive-comments.py --repo SPH-sophis [--open-only] --apply                       (post on tcm-pilot)
import argparse, json, os, re, sys, time, urllib.request, urllib.error
ap = argparse.ArgumentParser()
ap.add_argument('--repo', required=True); ap.add_argument('--target-pr', type=int); ap.add_argument('--open-only', action='store_true')
ap.add_argument('--out'); ap.add_argument('--post-to'); ap.add_argument('--apply', action='store_true'); ap.add_argument('--per-hour', type=int, default=400)
a = ap.parse_args()
S, T = os.environ['GH_SRC_PAT'], os.environ['GH_TGT_PAT']
MARK = 'Archived discussion from Finastra GitHub'
LIMIT = 60000
def call(url, tok, method='GET', body=None):
    for att in range(10):
        try:
            r = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body is not None else None,
                                       headers={'Authorization': f'Bearer {tok}', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'})
            resp = urllib.request.urlopen(r, timeout=120); txt = resp.read()
            return json.loads(txt) if txt else None
        except urllib.error.HTTPError as e:
            if e.code in (403, 429, 502, 503) and att < 9:   # 16 Nov: secondary rate limit with several jobs posting - honour Retry-After, back off longer
                ra = e.headers.get('Retry-After') if e.headers else None
                time.sleep(int(ra) + 5 if ra and ra.isdigit() else 60 * (att + 1)); continue
            raise
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:   # 16 Nov: network drops - wait and retry
            if att < 5: time.sleep(60 * (att + 1)); continue
            raise
def pages(url, tok):
    out, p = [], 1
    while True:
        b = call(f'{url}{"&" if "?" in url else "?"}per_page=100&page={p}', tok); out += b
        if len(b) < 100: return out
        p += 1
ZW = '​'
def safe(text):
    t = text or ''
    t = re.sub(r'@(?=[A-Za-z0-9])', '@' + ZW, t)                    # no notifications
    t = re.sub(r'(?<![\w/&])#(?=\d)', '#' + ZW, t)                  # no links to the wrong PR number
    return t
def quote(text): return '\n'.join('> ' + l for l in safe(text).splitlines()) or '> (empty)'
def day(s): return (s or '')[:16].replace('T', ' ') + ' UTC' if s else ''
def build(n, src_repo):
    base = f'https://api.github.com/repos/fin-tcm/{src_repo}'
    issue = pages(f'{base}/issues/{n}/comments', S)
    reviews = [r for r in pages(f'{base}/pulls/{n}/reviews', S) if (r.get('body') or '').strip() or r.get('state') in ('APPROVED', 'CHANGES_REQUESTED')]
    inline = pages(f'{base}/pulls/{n}/comments', S)
    items = [(c['created_at'], f"**`{(c.get('user') or {}).get('login', 'ghost')}`** commented, {day(c['created_at'])}\n\n{quote(c.get('body'))}") for c in issue]
    items += [(r['submitted_at'] or '', f"**`{(r.get('user') or {}).get('login', 'ghost')}`** review: **{r['state'].replace('_', ' ').lower()}**, {day(r.get('submitted_at'))}" + (f"\n\n{quote(r.get('body'))}" if (r.get('body') or '').strip() else '')) for r in reviews]
    items += [(c['created_at'], f"**`{(c.get('user') or {}).get('login', 'ghost')}`** on `{c.get('path')}`" + (f" line {c.get('line') or c.get('original_line')}" if (c.get('line') or c.get('original_line')) else '') + f", {day(c['created_at'])}\n\n{quote(c.get('body'))}") for c in inline]
    items.sort(key=lambda x: x[0])
    head = (f"### {MARK} (fin-tcm PR #{ZW}{n})\n"
            f"The original PR is in Finastra's GitHub, which Teciem accounts cannot open. Its discussion is copied here "
            f"(copied {time.strftime('%d %b %Y').lstrip('0')}): {len(issue)} comment(s), {len(reviews)} review(s), {len(inline)} review comment(s). "
            f"Authors are shown with their Finastra login; nobody is notified. Images and attachments stored in Finastra GitHub may not display.\n\n---\n")
    parts, cur = [], head
    for _, it in items:
        block = it + '\n\n---\n'
        if len(cur) + len(block) > LIMIT:
            parts.append(cur); cur = f"### {MARK} (fin-tcm PR #{ZW}{n}), continued\n\n---\n"
        cur += block[:LIMIT - 200]
    parts.append(cur)
    if len(parts) > 1: parts = [p.replace(f'(fin-tcm PR #{ZW}{n})', f'(fin-tcm PR #{ZW}{n}, part {i + 1} of {len(parts)})', 1) for i, p in enumerate(parts)]
    return parts, len(items)
# target PRs to process
tbase = f'https://api.github.com/repos/tcm-pilot/{a.repo}'
if a.target_pr: targets = [call(f'{tbase}/pulls/{a.target_pr}', T)]
else: targets = [p for p in pages(f'{tbase}/pulls?state={"open" if a.open_only else "all"}', T)]
done = posted = skipped = 0
gap = 3600.0 / a.per_hour
for p in targets:
    m = re.match(r'^(?:> )?Migrated from fin-tcm PR #(\d+)\b', p.get('body') or '')
    if not m: continue
    n = int(m.group(1))
    existing = pages(f'{tbase}/issues/{p["number"]}/comments', T)
    if any(MARK in (c.get('body') or '') for c in existing): skipped += 1; continue
    parts, count = build(n, a.repo)
    if count == 0: skipped += 1; continue
    if a.out:
        with open(a.out, 'a', encoding='utf-8') as f:
            for i, part in enumerate(parts): f.write(f'<!-- {a.repo} tcm-pilot #{p["number"]} <- fin-tcm #{n}, comment {i + 1}/{len(parts)}, {len(part)} chars -->\n{part}\n\n')
        print(f'{a.repo} #{p["number"]} <- #{n}: {count} items, {len(parts)} comment(s) -> {a.out}')
    if a.post_to:
        org_repo, num = a.post_to.split('#')
        for part in parts: call(f'https://api.github.com/repos/{org_repo}/issues/{num}/comments', T, 'POST', {'body': part}); time.sleep(gap)
        print(f'test-posted {len(parts)} comment(s) to {a.post_to}')
    if a.apply:
        for part in parts: call(f'{tbase}/issues/{p["number"]}/comments', T, 'POST', {'body': part}); time.sleep(gap)
        posted += len(parts)
    done += 1
print(f'{a.repo}: PRs archived {done}, skipped {skipped} (already archived or no discussion), comments posted {posted}')
