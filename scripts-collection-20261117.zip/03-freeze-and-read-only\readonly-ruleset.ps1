﻿# Makes every repo of an org read-only until cutover (Lukasz Garstecki's request, approved by Gareth 2026-11-09).
# Two org rulesets - all branches, all tags - with the rules "restrict creations", "restrict updates", "restrict deletions".
# Only the team "migration-sync" (just the account the nightly/corrective syncs run as) may bypass them, so the sync keeps
# working; org admins are NOT exempt. Reading, cloning, issues and PR comments still work; merging a PR does not.
# Existing repo rulesets and branch protection are not touched.
#   .\readonly-ruleset.ps1 -Org tcm-pilot            show state
#   .\readonly-ruleset.ps1 -Org tcm-pilot -Apply     create the team and both rulesets (re-run safe)
#   .\readonly-ruleset.ps1 -Org tcm-pilot -Remove    AT GO-LIVE (cutover step GIT-023): delete both rulesets. Imports during cutover exclude only the new repo while it imports (see taas-tms-pr-import.ps1)
param([Parameter(Mandatory)][string]$Org, [switch]$Apply, [switch]$Remove, [string]$SyncLogin = 'Gareth-Cabrera_tciem')
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ghAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$api = "https://api.github.com/orgs/$Org"
$names = @{ branch = 'Migration read-only until cutover (branches)'; tag = 'Migration read-only until cutover (tags)' }
$logFile = 'C:\kon-migration\rules\readonly-ruleset.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}: {2}" -f (Get-Date), $Org, $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
# (Invoke-RestMethod returns the JSON array as ONE pipeline object in PS 5.1: unroll it with ForEach-Object)
function Get-ReadonlyRulesets { Invoke-RestMethod "$api/rulesets?per_page=100" -Headers $ghAuth | ForEach-Object { $_ } | Where-Object { $_.id -and $_.name -in $names.Values } }

if ($Remove) {
  foreach ($rs in Get-ReadonlyRulesets) { Invoke-RestMethod -Method DELETE "$api/rulesets/$($rs.id)" -Headers $ghAuth | Out-Null; Write-Log "removed ruleset $($rs.id) '$($rs.name)'" }
  if (-not (Get-ReadonlyRulesets)) { Write-Log 'read-only rulesets gone - repos writable again for their teams' }
  return
}
if (-not $Apply) { Get-ReadonlyRulesets | ForEach-Object { "$($_.id) $($_.name) enforcement=$($_.enforcement)" }; return }

# bypass team with only the sync account
$team = try { Invoke-RestMethod "$api/teams/migration-sync" -Headers $ghAuth } catch {
  Invoke-RestMethod -Method POST "$api/teams" -Headers $ghAuth -ContentType application/json -Body (@{ name = 'migration-sync'; privacy = 'closed'; description = 'Only the migration sync account - bypasses the read-only rulesets until cutover' } | ConvertTo-Json) }
Invoke-RestMethod -Method PUT "$api/teams/migration-sync/memberships/$SyncLogin" -Headers $ghAuth -ContentType application/json -Body '{"role":"maintainer"}' | Out-Null
$members = @(Invoke-RestMethod "$api/teams/migration-sync/members?per_page=100" -Headers $ghAuth | ForEach-Object { $_ } | ForEach-Object { $_.login })
Write-Log "team migration-sync id=$($team.id) members: $($members -join ', ')"
if ($members.Count -ne 1 -or $members[0] -ne $SyncLogin) { throw "migration-sync must contain only $SyncLogin - fix the team first" }

$existing = @(Get-ReadonlyRulesets)
foreach ($target in 'branch', 'tag') {
  $body = @{ name = $names[$target]; target = $target; enforcement = 'active'
             bypass_actors = @(@{ actor_id = $team.id; actor_type = 'Team'; bypass_mode = 'always' })
             conditions = @{ ref_name = @{ include = @('~ALL'); exclude = @() }; repository_name = @{ include = @('~ALL'); exclude = @(); protected = $false } }
             rules = @(@{ type = 'creation' }, @{ type = 'update' }, @{ type = 'deletion' }) } | ConvertTo-Json -Depth 8
  $have = $existing | Where-Object { $_.name -eq $names[$target] }
  $rs = if ($have) { Invoke-RestMethod -Method PUT "$api/rulesets/$($have.id)" -Headers $ghAuth -ContentType application/json -Body $body }
        else { Invoke-RestMethod -Method POST "$api/rulesets" -Headers $ghAuth -ContentType application/json -Body $body }
  $back = Invoke-RestMethod "$api/rulesets/$($rs.id)" -Headers $ghAuth
  Write-Log ("ruleset {0} '{1}' enforcement={2} rules={3} bypass={4}" -f $back.id, $back.name, $back.enforcement, (@($back.rules.type) -join ','), (@($back.bypass_actors | ForEach-Object { "$($_.actor_type):$($_.actor_id)" }) -join ','))
}
