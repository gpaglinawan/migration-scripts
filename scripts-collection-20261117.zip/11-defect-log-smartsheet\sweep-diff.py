# Hourly defect sweep: read the live defect log, diff against sweep-state.json, print new/changed defects, save state.
# Read-only on Smartsheet. Token read from pats.txt, never printed.
import json, sys, urllib.request
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
tok = None
lines = open(r'C:\development\pats.txt', encoding='utf-8-sig').read().splitlines()
for i, l in enumerate(lines):
    if l.strip().upper().startswith('SMARTSHEET TOKEN'):
        rest = l.split(':', 1)[1].strip() if ':' in l else (l.split('=', 1)[1].strip() if '=' in l else '')
        tok = rest.strip('"\' ') or lines[i + 1].strip().strip('"\' ')
        break
req = urllib.request.Request('https://api.smartsheet.com/2.0/sheets/3761521504348036?include=discussions', headers={'Authorization': 'Bearer ' + tok})
sh = json.load(urllib.request.urlopen(req, timeout=120))
cols = {c['id']: c['title'] for c in sh['columns']}
disc = {}
for d in sh.get('discussions', []):
    if d.get('parentType') == 'ROW': disc[d['parentId']] = disc.get(d['parentId'], 0) + d.get('commentCount', 0)
cur = {}
for r in sh['rows']:
    v = {cols[c['columnId']]: (c.get('displayValue') or c.get('value') or '') for c in r['cells']}
    did = str(v.get('Defect ID', '')).strip()
    if not did: continue
    cur[did] = {'Status': str(v.get('Status', '')), 'Retest': str(v.get('Retest Status', '')), 'Platform': str(v.get('Platform', '')),
                'Comments': len(str(v.get('Comments', ''))), '_row': r['id'], '_v': v}   # length of the Comments column (as earlier sweeps stored)
path = r'C:\development\defects\sweep-state.json'
old = json.load(open(path, encoding='utf-8-sig'))
out = []
for k, c in sorted(cur.items()):
    o = old.get(k)
    if not o: out.append(('NEW', k, c))
    else:
        ch = [f"{f}: {o.get(f)!r} -> {c[f]!r}" for f in ('Status', 'Retest', 'Comments') if str(o.get(f, '')) != str(c[f])]
        if ch: out.append(('CHANGED', k, c, ch))
print(f'rows={len(cur)} new={sum(1 for x in out if x[0]=="NEW")} changed={sum(1 for x in out if x[0]=="CHANGED")}')
for x in out:
    v = x[2]['_v']
    print(f"\n== {x[0]} {x[1]} [{x[2]['Platform']}] status={x[2]['Status']!r} retest={x[2]['Retest']!r} by={v.get('Submitted By (Email)', '')}")
    if x[0] == 'CHANGED': print('   ' + '; '.join(x[3]))
    for f in ('Product / Team', 'Category', 'Defect Summary', 'Defect Description', 'Resolution'):
        if v.get(f): print(f'   {f}: {str(v[f])[:600]}')
if '--save' in sys.argv:
    json.dump({k: {f: c[f] for f in ('Comments', 'Status', 'Retest', 'Platform')} for k, c in cur.items()}, open(path, 'w', encoding='utf-8'), indent=2)
    print('state saved')
