# Gives R&D access to OPICS-opics4plus in tcm-pilot-test (Vijay Kumar's request, 3 Nov 2026).
# Creates OPICS_W / OPICS_R in the test org with the same members as in tcm-pilot, and grants them
# push / pull on OPICS-opics4plus. Members not yet in the test org are added through the team. Safe to re-run.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$src = "tcm-pilot"; $org = "tcm-pilot-test"; $repos = @('OPICS-opics4plus', 'OPICS-opicsbat')   # opicsbat: Vijay, 3 Nov, same access as opics4plus
$teams = @{ 'opics_w' = @{ name = 'OPICS_W'; perm = 'push' }; 'opics_r' = @{ name = 'OPICS_R'; perm = 'pull' } }

foreach ($slug in $teams.Keys) {
  $t = $teams[$slug]
  try { $null = Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$slug" -Headers $h }
  catch { Invoke-RestMethod -Method POST "https://api.github.com/orgs/$org/teams" -Headers $h -ContentType application/json -Body (@{ name = $t.name; description = "$($t.name) - copy of tcm-pilot team for testing"; privacy = "closed" } | ConvertTo-Json) | Out-Null; "team $slug created" }
  $members = @(); $page = 1
  do { $r = @(Invoke-RestMethod "https://api.github.com/orgs/$src/teams/$slug/members?per_page=100&page=$page" -Headers $h | ForEach-Object { $_ }); $members += $r.login; $page++ } while ($r.Count -eq 100)
  $failed = @()
  foreach ($m in $members) {
    try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$slug/memberships/$m" -Headers $h -ContentType application/json -Body '{"role":"member"}' | Out-Null }
    catch { $failed += "$m ($($_.ErrorDetails.Message))" }
  }
  foreach ($repo in $repos) { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$slug/repos/$org/$repo" -Headers $h -ContentType application/json -Body (@{ permission = $t.perm } | ConvertTo-Json) | Out-Null }
  "$slug : $($members.Count - $failed.Count)/$($members.Count) members, $($t.perm) on $($repos -join ', ')"
  $failed | ForEach-Object { "  failed: $_" }
}
# opicsbat also gets the team opics4plus already has in the test org
Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/fusioninvest-devops-test/repos/$org/OPICS-opicsbat" -Headers $h -ContentType application/json -Body '{"permission":"push"}' | Out-Null
"fusioninvest-devops-test : push on OPICS-opicsbat"
