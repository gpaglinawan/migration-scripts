param(
  [Parameter(Mandatory)][string[]]$Repos,
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$SvcMap = "C:\kon-migration\service-accounts\svc-account-map.csv",
  [string]$Out    = "C:\kon-migration\gei-new-20261030",
  [string[]]$HoldTeams = @("jellyfish-fin-tcm", "security-manager", "protivity"),   # same hold as team-fix.ps1

  [switch]$Apply
)
# For repos just migrated with GEI (which copies no access): gives the same teams and direct collaborators the
# same role on each repo in the target as in the source. Only adds; never removes or lowers. Plan only unless -Apply.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$ht = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$svc = @{}; if (Test-Path $SvcMap) { Import-Csv $SvcMap | Where-Object Target | ForEach-Object { $svc[$_.Source.ToLower()] = $_.Target } }
function ToTgt($l) { if ($svc[$l.ToLower()]) { $svc[$l.ToLower()] } else { ($l -replace '_finastra$', '') + '_tciem' } }
function Perm($x) { $n = if ($x.role_name) { $x.role_name } else { $x.permission }; switch ($n) { 'read' { 'pull' } 'write' { 'push' } default { $n } } }   # custom role names pass through
$plan = New-Object System.Collections.Generic.List[object]
foreach ($repo in $Repos) {
  try { Invoke-RestMethod "https://api.github.com/repos/$TgtOrg/$repo" -Headers $ht | Out-Null } catch { $plan.Add([pscustomobject]@{ Repo = $repo; Kind = '-'; Who = '-'; Perm = '-'; Result = 'skipped: not in target' }); continue }
  foreach ($t in @(Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$repo/teams?per_page=100" -Headers $hs) | ForEach-Object { $_ }) {
    $plan.Add([pscustomobject]@{ Repo = $repo; Kind = 'team'; Who = $t.slug; Perm = (Perm $t); Result = $(if ($t.slug -in $HoldTeams) { 'held: decision pending' } else { '' }) }) }
  foreach ($c in @(Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$repo/collaborators?affiliation=direct&per_page=100" -Headers $hs) | ForEach-Object { $_ }) {
    $plan.Add([pscustomobject]@{ Repo = $repo; Kind = 'user'; Who = (ToTgt $c.login); Perm = (Perm $c); Result = '' }) }
}
if ($Apply) {
  foreach ($r in ($plan | Where-Object { -not $_.Result })) {
    $u = if ($r.Kind -eq 'team') { "https://api.github.com/orgs/$TgtOrg/teams/$($r.Who)/repos/$TgtOrg/$($r.Repo)" } else { "https://api.github.com/repos/$TgtOrg/$($r.Repo)/collaborators/$($r.Who)" }
    try { Invoke-RestMethod -Method PUT $u -Headers $ht -ContentType application/json -Body (@{ permission = $r.Perm } | ConvertTo-Json) | Out-Null; $r.Result = 'done' }
    catch { $r.Result = "FAILED $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" } }
}
$f = Join-Path $Out ("access-" + $(if ($Apply) { 'applied' } else { 'plan' }) + "-" + (Get-Date -Format yyyyMMdd-HHmm) + ".csv")
$plan | Export-Csv $f -NoTypeInformation -Encoding utf8
$plan | Group-Object Kind, { ($_.Result -split ' ')[0] } | Select-Object Count, Name | Format-Table -AutoSize
"file: $f"
