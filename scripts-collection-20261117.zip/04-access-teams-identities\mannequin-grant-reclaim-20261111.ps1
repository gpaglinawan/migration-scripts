# Grant approved by Gareth 2026-11-11 ("2. Grant"): add Randolph-Reyes_tciem and SVC-tcm-tfc-app-1_tciem to tcm-pilot
# (role: member - no team access), then reclaim their mannequins (randolph-reyes_finastra, SVC-tcm-tfc-app-1_finastra), which
# failed earlier with "Target must be a member of the tcm-pilot organization". Run by Gareth (the agent's grant was blocked).
# Log: C:\kon-migration\mannequins\tcm-pilot-reclaim-20261111.log
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $env:GH_PAT = $env:GH_TGT_PAT
$log = 'C:\kon-migration\mannequins\tcm-pilot-reclaim-20261111.log'
function Write-Log($m) { $l = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
Write-Log 'Grant (Gareth 11 Nov): add 2 accounts to tcm-pilot as member, then reclaim their mannequins'
foreach ($p in @(@('randolph-reyes_finastra', 'Randolph-Reyes_tciem'), @('SVC-tcm-tfc-app-1_finastra', 'SVC-tcm-tfc-app-1_tciem'))) {
  try { $m = Invoke-RestMethod -Method PUT "https://api.github.com/orgs/tcm-pilot/memberships/$($p[1])" -Headers $t -ContentType application/json -Body '{"role":"member"}'
        Write-Log "  $($p[1]): tcm-pilot membership $($m.state) ($($m.role))" }
  catch { Write-Log "  $($p[1]): membership FAILED $($_.ErrorDetails.Message)"; continue }
  $o = gh gei reclaim-mannequin --github-target-org tcm-pilot --mannequin-user $p[0] --target-user $p[1] --skip-invitation --no-prompt 2>&1 | ForEach-Object { "$_" }
  Write-Log "  $($p[0]) -> $($p[1]): $(($o | Select-Object -Last 1) -join ' ')"
}
Write-Log 'done'
