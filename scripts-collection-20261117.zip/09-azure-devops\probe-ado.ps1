﻿param(
  [string]$SourceOrg = "https://dev.azure.com/TreasuryCapitalMarkets",
  [string]$TargetOrg = "https://dev.azure.com/tcm-staging",
  [string]$Out = "C:\kon-migration\probe"
)
# Read-only probe of everything an Azure DevOps project/org holds, source vs target, per project (matched by name).
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "probe-ado.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function AuthHdr($pat) { @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat")) } }
$SP = $env:AZDO_SOURCE_PAT; $TP = $env:AZDO_PAT
function Count($uri, $pat) {
  try { $r = Invoke-RestMethod $uri -Headers (AuthHdr $pat); if ($null -ne $r.count) { return [int]$r.count }; return @($r.value | Where-Object { $_ }).Count } catch { return '-' }
}
function WiCount($org, $pat, $proj) {
  try { @((Invoke-RestMethod -Method POST "$org/$([uri]::EscapeDataString($proj))/_apis/wit/wiql?api-version=7.1" -Headers (AuthHdr $pat) -Body (@{ query = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = @project" } | ConvertTo-Json) -ContentType application/json).workItems | Where-Object { $_ }).Count } catch { '-' }
}
function HostOf($org, $sub) { $org -replace 'dev\.azure\.com', "$sub.dev.azure.com" }

$rows = New-Object System.Collections.ArrayList
$srcProjects = (Invoke-RestMethod "$SourceOrg/_apis/projects?`$top=500&api-version=7.1" -Headers (AuthHdr $SP)).value | Sort-Object name
$tgtNames = @((Invoke-RestMethod "$TargetOrg/_apis/projects?`$top=500&api-version=7.1" -Headers (AuthHdr $TP)).value.name)
Log "=== ADO probe: $($srcProjects.Count) source projects ==="
$checks = [ordered]@{
  'Repos'                 = { param($o, $p, $e) "$o/$e/_apis/git/repositories?api-version=7.1" }
  'Work items'            = $null
  'Build pipelines'       = { param($o, $p, $e) "$o/$e/_apis/build/definitions?api-version=7.1" }
  'Release pipelines'     = { param($o, $p, $e) "$(HostOf $o 'vsrm')/$e/_apis/release/definitions?api-version=7.1" }
  'Variable groups'       = { param($o, $p, $e) "$o/$e/_apis/distributedtask/variablegroups?api-version=7.1" }
  'Service connections'   = { param($o, $p, $e) "$o/$e/_apis/serviceendpoint/endpoints?api-version=7.1" }
  'Secure files'          = { param($o, $p, $e) "$o/$e/_apis/distributedtask/securefiles?api-version=7.1-preview.1" }
  'Environments'          = { param($o, $p, $e) "$o/$e/_apis/distributedtask/environments?api-version=7.1" }
  'Agent queues'          = { param($o, $p, $e) "$o/$e/_apis/distributedtask/queues?api-version=7.1" }
  'Teams'                 = { param($o, $p, $e) "$o/_apis/projects/$e/teams?api-version=7.1" }
  'Wikis'                 = { param($o, $p, $e) "$o/$e/_apis/wiki/wikis?api-version=7.1" }
  'Test plans'            = { param($o, $p, $e) "$o/$e/_apis/testplan/plans?api-version=7.1" }
  'Dashboards (project)'  = { param($o, $p, $e) "$o/$e/_apis/dashboard/dashboards?api-version=7.1-preview.3" }
  'Branch policies'       = { param($o, $p, $e) "$o/$e/_apis/policy/configurations?api-version=7.1" }
  'Feeds (project)'       = { param($o, $p, $e) "$(HostOf $o 'feeds')/$e/_apis/packaging/feeds?api-version=7.1-preview.1" }
  'Delivery plans'        = { param($o, $p, $e) "$o/$e/_apis/work/plans?api-version=7.1" }
}
$targetMap = @{}   # renamed projects keep their name; -old projects are the former Basic ones
foreach ($p in $srcProjects) {
  $tn = if ($tgtNames -contains $p.name) { $p.name } else { $null }
  $se = [uri]::EscapeDataString($p.name); $te = if ($tn) { [uri]::EscapeDataString($tn) } else { $null }
  foreach ($k in $checks.Keys) {
    if ($k -eq 'Work items') { $s = WiCount $SourceOrg $SP $p.name; $t = if ($tn) { WiCount $TargetOrg $TP $tn } else { '-' } }
    else { $s = Count (& $checks[$k] $SourceOrg $p.name $se) $SP; $t = if ($tn) { Count (& $checks[$k] $TargetOrg $tn $te) $TP } else { '-' } }
    [void]$rows.Add([pscustomobject]@{ Project = $p.name; Item = $k; Source = $s; Target = $t; Match = $(if ("$s" -eq "$t") { 'yes' } else { 'no' }) })
  }
  Log "  $($p.name) checked"
}
# org level
foreach ($pair in @(
  @('Agent pools (org)', '_apis/distributedtask/pools?api-version=7.1', ''),
  @('Extensions installed', '_apis/extensionmanagement/installedextensions?api-version=7.1-preview.1', 'extmgmt'),
  @('Service hooks', '_apis/hooks/subscriptions?api-version=7.1', ''),
  @('Users (entitlements)', '_apis/userentitlements?top=10000&api-version=7.1-preview.3', 'vsaex'),
  @('Groups', '_apis/graph/groups?api-version=7.1-preview.1', 'vssps'),
  @('Feeds (org-scoped)', '_apis/packaging/feeds?api-version=7.1-preview.1', 'feeds'),
  @('Process templates', '_apis/process/processes?api-version=7.1', ''))) {
  $sh = if ($pair[2]) { HostOf $SourceOrg $pair[2] } else { $SourceOrg }; $th = if ($pair[2]) { HostOf $TargetOrg $pair[2] } else { $TargetOrg }
  $s = Count "$sh/$($pair[1])" $SP; $t = Count "$th/$($pair[1])" $TP
  [void]$rows.Add([pscustomobject]@{ Project = '(organization)'; Item = $pair[0]; Source = $s; Target = $t; Match = $(if ("$s" -eq "$t") { 'yes' } else { 'no' }) })
}
$sExt = try { @((Invoke-RestMethod "$(HostOf $SourceOrg 'extmgmt')/_apis/extensionmanagement/installedextensions?api-version=7.1-preview.1" -Headers (AuthHdr $SP)).value | ForEach-Object { "$($_.publisherId).$($_.extensionId)" }) } catch { @() }
$tExt = try { @((Invoke-RestMethod "$(HostOf $TargetOrg 'extmgmt')/_apis/extensionmanagement/installedextensions?api-version=7.1-preview.1" -Headers (AuthHdr $TP)).value | ForEach-Object { "$($_.publisherId).$($_.extensionId)" }) } catch { @() }
@($sExt | Where-Object { $_ -notin $tExt }) | Set-Content (Join-Path $Out "ado-extensions-missing.txt") -Encoding utf8
$rows | Export-Csv (Join-Path $Out "probe-ado.csv") -NoTypeInformation -Encoding utf8
Log "=== done: $(@($rows | Where-Object Match -eq 'no').Count) mismatches of $($rows.Count) checks ==="
