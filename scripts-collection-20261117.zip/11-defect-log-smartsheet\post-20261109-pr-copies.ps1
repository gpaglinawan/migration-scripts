# 9 Nov 2026 (Gareth: "post them"): comments on DEF-045/083/093/110 and resolutions on DEF-083/110 - the PR-preserving
# (-pr) copy approach. Statuses are not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-083' = 'The current tcm-pilot/FCGC-pricing-analytics has the code and all branches but no PRs: its files over 100 MB stopped it from going through GitHub''s importer. A full copy with PRs, FCGC-pricing-analytics-pr, was made on 7 Nov. Its files over 100 MB were moved to LFS before import, and it is checked against fin-tcm every night. It has 5,032 of 5,256 PRs, with reviews, comments and the same PR numbers. At cutover it replaces the current repo under the same name. 224 PRs cannot be imported: their branches were deleted in fin-tcm and GitHub no longer holds their commits. All 224 were merged or closed, and they stay readable in fin-tcm.'
  'DEF-093' = 'The full rehearsal of the new method finished on 9 Nov in tcm-pilot-test/KON-kplus-front-rehearsal. It contains 39,462 PRs with the same numbers as fin-tcm, and 38,802 of 39,481 (98.3%) are identical in state, reviews, comments and threads. KON-kplus-front will be migrated this way at cutover, replacing the current repo. Because PR numbers are kept, Jira links resolve once the Jira GitHub app points at tcm-pilot (DEF-026). The same method was used for 9 other repositories with large files (RISK-cmr, FCGC-pricing-analytics, TO-treasury-installer, MAFTP-fpp-fusioncapital, MAFTP-fpp-vaas-che, FCBO-fusion-detect-core, SFX-netcore-common, OPICS-programmers, FWK-utfinstaller), and for TAAS-tms. Those copies are already in tcm-pilot, checked nightly, and swapped in at cutover. Next: breakdown of the 679 differing PRs, and the cutover timing for the roughly 19-hour run.'
  'DEF-110' = 'PR #1 ("Feature/UTFInstaller 1.3", closed, branch feature/UTFInstaller_1.3) is present in tcm-pilot/FWK-utfinstaller-pr, the copy with PRs that replaces FWK-utfinstaller at cutover (1 of 1 PR). Fixed - verify after cutover.'
  'DEF-045' = 'TO-treasury-installer-pr (with PRs, 1,678 of 1,688; its 1.1 GB file moved to LFS) replaces the current repo at cutover.'
}
$resolutions = @{
  'DEF-083' = 'Repository migrated with full history; files over 100 MB moved to Git LFS (commit IDs differ from fin-tcm by design). PRs carried over in the replacement copy, which is swapped in at cutover (5,032 of 5,256; the other 224 reference commits that no longer exist in fin-tcm).'
  'DEF-110' = 'PR #1 migrated in the replacement copy, which is swapped in at cutover.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun

$sheetId = 3761521504348036
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$ssAuth = @{ Authorization = "Bearer $tok" }
$sheet = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sheetId" -Headers $ssAuth
$idCol = ($sheet.columns | Where-Object title -eq 'Defect ID').id; $resCol = ($sheet.columns | Where-Object title -eq 'Resolution').id
$rows = foreach ($defect in $resolutions.Keys) {
  $row = $sheet.rows | Where-Object { ($_.cells | Where-Object columnId -eq $idCol).displayValue -eq $defect }
  $old = "$(($row.cells | Where-Object columnId -eq $resCol).value)".Trim()
  if ($old) { Write-Warning "$defect already has a Resolution - left as is: $old"; continue }
  "--- $defect Resolution: $($resolutions[$defect])" | Out-Host
  @{ id = $row.id; cells = @(@{ columnId = $resCol; value = $resolutions[$defect] }) }
}
if ($DryRun -or -not $rows) { return }
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sheetId/rows" -Headers $ssAuth -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @($rows) -Depth 6)))
"resolution rows updated: $(@($res.result).Count) (resultCode $($res.resultCode))"
