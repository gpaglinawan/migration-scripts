# 16 Nov 2026 - read-only: every open recreated PR whose original had discussion (Samar's open_recreated_detail.csv)
# must have an "Archived discussion from Finastra GitHub" comment in tcm-pilot.
import csv, json, os, urllib.request, time
T = os.environ['GH_TGT_PAT']
def get(u):
    for a in range(5):
        try: return json.load(urllib.request.urlopen(urllib.request.Request(u, headers={'Authorization': 'Bearer ' + T, 'Accept': 'application/vnd.github+json'}), timeout=60))
        except Exception: time.sleep(10 * (a + 1))
rows = [r for r in csv.DictReader(open(r'C:\development\samar\sync\Accounts\audit\qa\open_recreated_detail.csv', encoding='utf-8-sig')) if int(r['SourceComments'] or 0) > 0]
miss, ok = [], 0
for r in rows:
    cs = get(f"https://api.github.com/repos/tcm-pilot/{r['Repo']}/issues/{r['TargetPR']}/comments?per_page=100") or []
    if any('Archived discussion from Finastra GitHub' in (c.get('body') or '') for c in cs): ok += 1
    else: miss.append(f"{r['Repo']}#{r['TargetPR']}")
print(f'open recreated PRs with discussion: {len(rows)}; with archive comment: {ok}; without: {len(miss)}')
print('missing:', ', '.join(miss[:30]))
