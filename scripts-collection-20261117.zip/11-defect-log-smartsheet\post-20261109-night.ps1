# 9 Nov 2026 night (Gareth: "fix as many as we can and update the smartsheet").
# Comments on DEF-067/086/099/114/116/136/137/138/139; status -> "Ready for Retest" on DEF-067 and DEF-086 only.
# Evidence: C:\kon-migration\def067-refs-20261109 (ls-remote of both orgs), C:\development\defects\def099-retest-20261109.log
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$sync = 'Re-checked tonight (every branch and tag, fin-tcm vs tcm-pilot): RISK-fusionrisk-integration-api, FRCP-pricing-engine-fusionrisk, SOLINT-fusion-risk-packs, RISK-fr-cmr-tests, RISK-fr-limit-test, MAFTP-csm and MAFTP-krecord now match fin-tcm (HEAD, branches and tags). RISK-fusion-risk (8 branches incl. master) and RISK-fr_qa (9 branches) differ only by commits made in fin-tcm today, after the 02:00 CET nightly sync; all are straight additions (nothing rewritten) and are picked up by tonight''s sync. A difference limited to commits made since the last nightly sync is expected until cutover, when the final sync runs. Extra branches in tcm-pilot (e.g. 5 in RISK-fr-cmr-tests, 3 in RISK-fr-limit-test) are branches deleted in fin-tcm after the migration; the sync does not delete branches, and they can be removed at cutover if the team wants. RISK-cmr: commit IDs differ by design (files over 100 MB moved to Git LFS); its PR-preserving copy replaces it at cutover (see DEF-093). Ready for retest.'
$comments = @{
  'DEF-067' = $sync
  'DEF-086' = $sync
  'DEF-099' = 'Retested by Gareth: pipeline variables compared for every pipeline in all 10 projects (TreasuryCapitalMarkets -> tcm-staging). No pipeline is missing variables. Open point for the Terraform team: the two secrets on Terraform / aft-account-customizations (TF_KMS_KEY_ID, TFC_API_TOKEN) were created empty because Azure DevOps does not allow secret values to be copied; they must be re-entered by the owning team before that pipeline runs (suggested: Cedric Kamdem Tsanang, Anis Khachnaoui or Lukasz Kruczek, who run it in Finastra). Can be closed.'
  'DEF-138' = 'MCH-mch: the 9 PRs not in tcm-pilot are #1995-#2003, all opened after the initial migration (the nightly sync copies branches and commits, not PRs). "IN_SYNC" in the compare tool means the code (branches/commits) is identical. Open PRs created since the initial migration are recreated at cutover (cutover step GIT-020); closed/merged ones are not copied under the current plan - their code is already in tcm-pilot and they stay readable in fin-tcm. Whether to also copy closed PRs is being decided.'
  'DEF-114' = 'FCBO-securities-inventory-service: the 9 PRs not in tcm-pilot (#155-#164) were all opened after the initial migration; the nightly sync copies branches and commits, not PRs. Open ones are recreated at cutover (GIT-020); the code of the closed/merged ones is already in tcm-pilot. Same explanation as DEF-138.'
  'DEF-116' = 'Cause found: the tcm-pilot organisation''s base permission is "Read", so every member can read every repository. In fin-tcm it is "No permission", so people only saw the repos of their own teams. Rachel''s teams are the same in both (ft_*, fst_*, invest-ps, toolkit, copilot). Fix: set the tcm-pilot base permission to "No permission", as in fin-tcm. This is an organisation-wide change, so it needs approval and a check first that no one relies on base read access (e.g. CI accounts outside the product teams). Pending decision.'
  'DEF-136' = 'Not a migration issue. The error comes from Teciem Entra ID: the user is not assigned to the "GitHub EMU" enterprise application, so GitHub cannot create the account (there is no sumitkumar-das account in fin-tcm or tcm-pilot). Fix: Teciem IT / Entra admin adds Sumitkumar.Das@teciem.com to a group assigned to the GitHub EMU app; the account is then created automatically and can be added to the Kondor teams. Dependency on Teciem IT.'
  'DEF-137' = 'The display name comes from Teciem Entra ID, not from the migration: GitHub EMU takes the name from the identity provider and users cannot change it (fin-tcm: "Leon Kemna"; tcm-pilot: "Kemna, Leon" for every account). Fix: Teciem IT / Entra admin changes the GitHub EMU app''s provisioning mapping for the display name to "givenName surname"; names update on the next provisioning cycle. Dependency on Teciem IT.'
  'DEF-139' = 'Checked team MCH: 70 members in fin-tcm, 68 in tcm-pilot. Missing in tcm-pilot: (1) one unnamed _finastra account with no Teciem account; (2) Ion Ciubotaru - his Teciem login has the names the other way round (Ion-Ciubotaru_tciem instead of ciubotaru-ion_tciem), so the migration did not match him: he is not a member of tcm-pilot and is in none of his 14 fin-tcm teams (incl. mch_w, kon_w, risk_w, to_w). He is the only person with this problem (all fin-tcm members checked). Fix pending approval: add Ion-Ciubotaru_tciem to tcm-pilot and to the same 14 teams. This does not match "4 vs 3" - Leon, could you say which team (or child team) you compared?'
}
$statusTo = @{ 'DEF-067' = 'Ready for Retest'; 'DEF-086' = 'Ready for Retest' }
$sheetId = 3761521504348036
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$ssAuth = @{ Authorization = "Bearer $tok" }
$sheet = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sheetId" -Headers $ssAuth
$idCol = ($sheet.columns | Where-Object title -eq 'Defect ID').id; $stCol = ($sheet.columns | Where-Object title -eq 'Status')
$rows = foreach ($defect in $statusTo.Keys) {
  if (@($stCol.options).Count -and @($stCol.options) -notcontains $statusTo[$defect]) { throw "bad status $($statusTo[$defect])" }
  $row = $sheet.rows | Where-Object { ($_.cells | Where-Object columnId -eq $idCol).displayValue -eq $defect }
  if (-not $row) { Write-Warning "$defect not found"; continue }
  "--- $defect status: '$(($row.cells | Where-Object columnId -eq $stCol.id).displayValue)' -> '$($statusTo[$defect])'" | Out-Host
  @{ id = $row.id; cells = @(@{ columnId = $stCol.id; value = $statusTo[$defect] }) }
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
if ($DryRun -or -not $rows) { return }
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sheetId/rows" -Headers $ssAuth -ContentType 'application/json; charset=utf-8' `
       -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @($rows) -Depth 6)))
"status rows updated: $(@($res.result).Count) (resultCode $($res.resultCode))"
