# 11 Nov 2026 (Gareth: "post"). Comment only - status not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-101' = 'Checked 11 Nov: all 28 agent pools exist in tcm-staging, but none has agents registered. In TreasuryCapitalMarkets only 5 pools have agents online: LinuxFlyweight 32, LinuxStandard 32, AWSLinuxTerraform-pods 10, TCM-DevOps-Pool 5, AWSLinuxTerraform 4. The other 23 pools (including Default) have no online agents in the source either. The 83 working agents must be re-registered against https://dev.azure.com/tcm-staging by the team that runs them (suggested: TCM-DevOps-Infra), possibly depending on network access to Teciem; planned in the cutover runbook as ADO-010 (Sat 14 Nov). Owner needed. Pool administrator rights in tcm-staging will be given to the named people.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
