# 15 Nov 2026 (Gareth: "yes and fix" - DEF-244). tcm-staging is frozen (Deny entries from ado-freeze-target.ps1). To
# recreate the 64 active Finastra PRs, this opens ONLY the PullRequestContribute bit (16384) in the existing Deny entries
# on the affected repos and their projects; push / branch / tag / force-push denies stay in place. Runs
# ado-active-pr-recreate.ps1 -Apply, then restores every touched entry to its exact frozen value (finally block).
# Backup of the frozen values: C:\kon-migration\ado-freeze-target\pr-window-<stamp>\frozen-aces.json
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT")) }
$o = 'https://dev.azure.com/tcm-staging'; $ns = '2e9eb7ed-3c0a-47d4-87c1-0ffdd275fd87'; $PRBIT = 16384
$log = 'C:\kon-migration\ado-nightly\cutover-20261113.log'; $dir = "C:\kon-migration\ado-freeze-target\pr-window-$(Get-Date -Format yyyyMMdd-HHmm)"; New-Item -ItemType Directory -Force $dir | Out-Null
$plan = Import-Csv (Get-ChildItem C:\kon-migration\ado-nightly\ado-active-pr-recreate-*.csv | Sort-Object LastWriteTime | Select-Object -Last 1).FullName | Where-Object { $_.PR -and $_.Result -notlike 'SKIP*' }
$targets = $plan | Select-Object Project, Repo -Unique
$tokens = @{}
foreach ($t in $targets) {
  $r = Invoke-RestMethod "$o/$([uri]::EscapeDataString($t.Project))/_apis/git/repositories/$([uri]::EscapeDataString($t.Repo))?api-version=7.1" -Headers $hs
  $tokens["repoV2/$($r.project.id)"] = 1; $tokens["repoV2/$($r.project.id)/$($r.id)"] = 1
}
$saved = New-Object System.Collections.ArrayList
foreach ($tok in $tokens.Keys) {
  $acl = @((Invoke-RestMethod "$o/_apis/accesscontrollists/$ns`?token=$([uri]::EscapeDataString($tok))&recurse=false&api-version=7.1" -Headers $hs).value) | Where-Object { $_.token -eq $tok }
  foreach ($a in $acl) { foreach ($p in $a.acesDictionary.PSObject.Properties) { $ace = $p.Value; if ([int]$ace.deny -band $PRBIT) { [void]$saved.Add([pscustomobject]@{ Token = $tok; Descriptor = $ace.descriptor; Allow = [int]$ace.allow; Deny = [int]$ace.deny }) } } }
}
$saved | ConvertTo-Json -Depth 4 | Out-File "$dir\frozen-aces.json" -Encoding utf8
"tokens: $($tokens.Count); deny entries with the PR bit: $($saved.Count)"
function Set-AceValue($token, $descriptor, $allow, $deny) {
  $body = @{ token = $token; merge = $false; accessControlEntries = @(@{ descriptor = $descriptor; allow = $allow; deny = $deny; extendedInfo = @{} }) } | ConvertTo-Json -Depth 5
  $null = Invoke-RestMethod -Method Post "$o/_apis/accesscontrolentries/$ns`?api-version=7.1" -Headers $hs -ContentType 'application/json' -Body $body
}
try {
  foreach ($s in $saved) { Set-AceValue $s.Token $s.Descriptor $s.Allow ($s.Deny -band (-bnot $PRBIT)) }
  Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') tcm-staging PR window OPEN: PR-contribute deny lifted on $($saved.Count) entries ($($tokens.Count) tokens, 18 repos); push/branch denies unchanged; backup $dir" -Encoding utf8
  $ErrorActionPreference = 'Continue'
  & C:\kon-migration\scripts\ado-active-pr-recreate.ps1 -Apply 2>&1 | ForEach-Object { "$_" } | Where-Object { $_ -notmatch 'Basic [A-Za-z0-9+/=]{20,}' }
} finally {
  $ErrorActionPreference = 'Continue'; $bad = 0
  foreach ($s in $saved) { try { Set-AceValue $s.Token $s.Descriptor $s.Allow $s.Deny } catch { $bad++; Add-Content $log "!! RESTORE FAILED $($s.Token) $($s.Descriptor)" -Encoding utf8 } }
  $still = 0; foreach ($tok in $tokens.Keys) { $acl = @((Invoke-RestMethod "$o/_apis/accesscontrollists/$ns`?token=$([uri]::EscapeDataString($tok))&recurse=false&api-version=7.1" -Headers $hs).value) | Where-Object { $_.token -eq $tok }; foreach ($a in $acl) { foreach ($p in $a.acesDictionary.PSObject.Properties) { if ([int]$p.Value.deny -band $PRBIT) { $still++ } } } }
  "freeze restored: $($saved.Count - $bad) of $($saved.Count) entries; deny entries with the PR bit now: $still (expected $($saved.Count))"
  Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') tcm-staging PR window CLOSED: $($saved.Count - $bad)/$($saved.Count) entries restored; PR-bit denies present $still" -Encoding utf8
}
