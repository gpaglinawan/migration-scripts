# Re-copies code scanning dismissals fin-tcm -> tcm-pilot inside a short window where delegated
# alert dismissal is switched off on config 287096 ("Prevent direct alert dismissals - Custom").
# Agreed with Alexandru Dracea: run this as part of every sync until cutover.
# The setting is always switched back on (finally block), even if the copy fails.
param(
  [string[]]$Repos = @('SPH-sophis', 'OPICS-opics4plus', 'SUM-summit', 'KON-kplus-front', 'FABCOM-regulatory', 'FCGC-pricing-analytics'),
  [int]$ConfigId = 287096,
  [string]$Out = "C:\kon-migration\code-scanning-states-apply-$(Get-Date -Format yyyyMMdd-HHmm)",
  [string]$LooseMatches   # optional matches.csv from code-scanning-loose-match.ps1 (moved-line pairs, OK'd by Alexandru 3 Nov)
)
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*\$env:GH_TGT_PAT\s*=\s*(.+)$' } | ForEach-Object { $tok = $matches[1].Trim().Trim('"', "'") }
$hdr = @{ Authorization = "Bearer $tok"; Accept = 'application/vnd.github+json'; 'X-GitHub-Api-Version' = '2022-11-28' }
$cfg = "https://api.github.com/orgs/tcm-pilot/code-security/configurations/$ConfigId"
New-Item -ItemType Directory -Force $Out | Out-Null
function Stamp($m) { "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m }

function Set-Delegated($value) {
  for ($try = 1; $try -le 5; $try++) {
    try {
      Invoke-RestMethod -Method PATCH $cfg -Headers $hdr -ContentType application/json -Body (@{ code_scanning_delegated_alert_dismissal = $value } | ConvertTo-Json) | Out-Null
      $now = (Invoke-RestMethod $cfg -Headers $hdr).code_scanning_delegated_alert_dismissal
      if ($now -eq $value) { Stamp "delegated alert dismissal = $now"; return }
      throw "still $now"
    } catch { Stamp "set $value attempt $try failed: $($_.Exception.Message)"; Start-Sleep -Seconds (15 * $try) }
  }
  throw "could not set delegated alert dismissal to $value"
}

$before = (Invoke-RestMethod $cfg -Headers $hdr).code_scanning_delegated_alert_dismissal
Stamp "config $ConfigId before: $before"
try {
  Set-Delegated 'disabled'
  Start-Sleep -Seconds 30   # let the change reach the enforced repos
  & C:\kon-migration\scripts\code-scanning-migrate.ps1 -Step states -Apply -Repos $Repos -Out $Out
  if ($LooseMatches) {
    # moved-line pairs: copy the Finastra dismissal onto the paired tcm-pilot alert if it is still open
    Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*\$env:GH_SRC_PAT\s*=\s*(.+)$' } | ForEach-Object { $stok = $matches[1].Trim().Trim('"', "'") }
    $shdr = @{ Authorization = "Bearer $stok"; Accept = 'application/vnd.github+json'; 'X-GitHub-Api-Version' = '2022-11-28' }
    $llog = Join-Path $Out 'loose-apply.log'
    function LogL($m) { for ($i = 0; $i -lt 10; $i++) { try { Add-Content -Path $llog -Value $m -ErrorAction Stop; return } catch { Start-Sleep -Milliseconds 300 } } }
    foreach ($m in (Import-Csv $LooseMatches)) {
      $t = "https://api.github.com/repos/tcm-pilot/$($m.Repo)/code-scanning/alerts/$($m.TgtAlert)"
      try {
        if ((Invoke-RestMethod $t -Headers $hdr).state -ne 'open') { LogL "$($m.Repo) : #$($m.TgtAlert) already not open, skipped"; continue }
        $sa = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$($m.Repo)/code-scanning/alerts/$($m.SrcAlert)" -Headers $shdr
        $c = "Migrated from fin-tcm #$($sa.number) (line $($m.SrcLine) -> $($m.TgtLine)) dismissed by $($sa.dismissed_by.login): $($sa.dismissed_comment)"
        $c = $c.Substring(0, [Math]::Min(280, $c.Length))
        # send UTF-8 bytes: PS 5.1 mangles non-ASCII (e.g. ¶ ±) in string bodies -> "Problems parsing JSON"
        $body = [Text.Encoding]::UTF8.GetBytes((@{ state = 'dismissed'; dismissed_reason = $sa.dismissed_reason; dismissed_comment = $c } | ConvertTo-Json))
        Invoke-RestMethod -Method PATCH $t -Headers $hdr -ContentType 'application/json; charset=utf-8' -Body $body | Out-Null
        LogL "$($m.Repo) : loose dismissed #$($m.TgtAlert) ($($sa.dismissed_reason))"
      } catch { LogL "$($m.Repo) : loose #$($m.TgtAlert) FAILED $($_.ErrorDetails.Message)" }
    }
    Stamp "loose matches dismissed: $(@(Select-String $llog -Pattern 'loose dismissed').Count)  skipped: $(@(Select-String $llog -Pattern 'skipped').Count)  failed: $(@(Select-String $llog -Pattern ' FAILED ').Count)"
  }
} finally {
  if ($before -eq 'enabled') { Set-Delegated 'enabled' }
  $log = Join-Path $Out 'code-scanning-states.log'
  if (Test-Path $log) {
    $ok = @(Select-String -Path $log -Pattern ' : dismissed #').Count
    $bad = @(Select-String -Path $log -Pattern ' FAILED ').Count
    Stamp "dismissed: $ok   failed: $bad"
  }
}
