# Appends a dated line to the "Comments" column of one or more rows in the Defect Log Smartsheet.
# Usage: .\smartsheet-comment.ps1 -Updates @{ 'DEF-013' = 'text'; 'DEF-014' = 'text' } [-DryRun]
# Existing comment text is kept; the new line goes on the end, prefixed with today's date (m/d).
param([Parameter(Mandatory)][hashtable]$Updates, [switch]$DryRun, [long]$SheetId = 3761521504348036)
$ErrorActionPreference = "Stop"
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$h = @{ Authorization = "Bearer $tok" }
$sh = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$SheetId" -Headers $h
$idc = ($sh.columns | Where-Object title -eq 'Defect ID').id; $cc = ($sh.columns | Where-Object title -eq 'Comments').id
$date = "{0}/{1}" -f (Get-Date).Month, (Get-Date).Day
$rows = foreach ($k in $Updates.Keys) {
  $r = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $idc).displayValue -eq $k }
  if (-not $r) { Write-Warning "$k not found"; continue }
  $old = "$(($r.cells | Where-Object columnId -eq $cc).value)".TrimEnd()
  $new = if ($old) { "$old`n`n$date - $($Updates[$k])" } else { "$date - $($Updates[$k])" }
  "--- $k (row $($r.id)) adds: $date - $($Updates[$k])" | Out-Host
  @{ id = $r.id; cells = @(@{ columnId = $cc; value = $new }) }
}
if ($DryRun -or -not $rows) { return }
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$SheetId/rows" -Headers $h -ContentType 'application/json; charset=utf-8' `
       -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @($rows) -Depth 6)))
"updated rows: $(@($res.result).Count) (resultCode $($res.resultCode))"
