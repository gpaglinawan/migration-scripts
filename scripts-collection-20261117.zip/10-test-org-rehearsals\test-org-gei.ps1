param(
  [Parameter(Mandatory)][string[]]$Repos,
  [string]$SrcOrg = "tcm-pilot",
  [string]$TgtOrg = "tcm-pilot-test",
  [string]$Work = "C:\kon-migration\testorg-gei",
  [int]$MaxInFlight = 10,
  [switch]$SkipLfs                       # skip step 2 (LFS objects) when the users do not need them
)
# Copies repositories into the test organisation with GitHub Enterprise Importer (same commit IDs, PRs and issues,
# files up to 400 MB), then copies their Git LFS objects, which GEI does not migrate. Repos that already exist in the
# target are skipped (delete a partial copy first to redo it). Never writes to the source.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GH_SOURCE_PAT = $env:GH_TGT_PAT; $env:GH_PAT = $env:GH_TGT_PAT     # both orgs are in the Teciem enterprise
$hdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
New-Item -ItemType Directory -Force $Work | Out-Null; Set-Location $Work
$log = Join-Path $Work "gei.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Exists($org, $r) { try { $null = Invoke-RestMethod "https://api.github.com/repos/$org/$r" -Headers $hdr; $true } catch { $false } }

$todo = @($Repos | Where-Object { -not (Exists $TgtOrg $_) })
Log "=== GEI $SrcOrg -> $TgtOrg : $($todo.Count) to migrate, $($Repos.Count - $todo.Count) already present ==="

# 1. queue migrations (at most $MaxInFlight at a time) and wait for them
$queued = @{}; $state = @{}
$pending = New-Object System.Collections.Queue; foreach ($r in $todo) { $pending.Enqueue($r) }
while ($pending.Count -or $queued.Count) {
  while ($pending.Count -and $queued.Count -lt $MaxInFlight) {
    $r = $pending.Dequeue()
    $o = gh gei migrate-repo --github-source-org $SrcOrg --source-repo $r --github-target-org $TgtOrg --target-repo $r --target-repo-visibility private --queue-only 2>&1 | ForEach-Object { "$_" }
    $id = ([regex]::Match(($o -join ' '), '\(ID: (RM_[A-Za-z0-9_\-]+)\)')).Groups[1].Value
    if ($id) { $queued[$r] = $id; Log "  queued $r ($id)" } else { $state[$r] = 'QUEUE-FAILED'; Log "  $r : could not queue - $(($o | Select-Object -Last 2) -join ' ')" }
  }
  Start-Sleep -Seconds 30
  foreach ($r in @($queued.Keys)) {
    $q = '{ node(id:"' + $queued[$r] + '"){ ... on Migration { state failureReason } } }'
    $s = (Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hdr -ContentType application/json -Body (@{ query = $q } | ConvertTo-Json)).data.node
    if ($s.state -in 'SUCCEEDED', 'FAILED') { $state[$r] = $s.state; $queued.Remove($r); Log "  $r : $($s.state) $($s.failureReason)" }
  }
}

# 2. LFS objects (GEI doesn't copy them)
$env:GIT_TERMINAL_PROMPT = "0"; $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
foreach ($r in $Repos) {
  if ($SkipLfs -or ($state[$r] -and $state[$r] -ne 'SUCCEEDED')) { continue }
  $dir = Join-Path $Work "$r.git"
  if (-not (Test-Path $dir)) {
    git init --bare -q --ref-format=reftable $dir
    git -C $dir config remote.origin.url "https://github.com/$SrcOrg/$r.git"
    git -C $dir config remote.origin.fetch "+refs/heads/*:refs/heads/*"; git -C $dir config --add remote.origin.fetch "+refs/tags/*:refs/tags/*"
  }
  # only fetch git history if the repo has LFS files: check the default branch for an LFS .gitattributes first
  $attr = try { (Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$r/contents/.gitattributes" -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github.raw" }) } catch { '' }
  $big = @('KON-kplus-front', 'RISK-cmr', 'SUM-summit') -contains $r
  if (-not $big -and "$attr" -notmatch 'filter=lfs') { continue }
  git -C $dir fetch -q origin 2>$null
  git -C $dir lfs fetch --all origin 2>&1 | Select-Object -Last 1 | ForEach-Object { Log "  $r lfs fetch: $_" }
  $oids = @(Get-ChildItem (Join-Path $dir "lfs\objects") -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object Name)
  if ($oids.Count) {
    git -C $dir config lfs.url "https://github.com/$TgtOrg/$r.git/info/lfs"
    git -C $dir lfs push --object-id "https://github.com/$TgtOrg/$r.git" @oids 2>&1 | Select-Object -Last 1 | ForEach-Object { Log "  $r lfs push: $_" }
  }
  Log "  $r : $($oids.Count) LFS objects copied"
}
$env:GIT_CONFIG_COUNT = "0"
$state.GetEnumerator() | ForEach-Object { [pscustomobject]@{ Repo = $_.Key; State = $_.Value } } | Export-Csv (Join-Path $Work "results.csv") -NoTypeInformation -Encoding utf8
Log "=== done: $(@($state.Values | Where-Object { $_ -eq 'SUCCEEDED' }).Count) succeeded, $(@($state.Values | Where-Object { $_ -ne 'SUCCEEDED' }).Count) not ==="
