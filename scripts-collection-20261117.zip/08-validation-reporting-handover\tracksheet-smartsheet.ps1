# 14 Nov 2026 (Gareth: "create smartsheet. Share it with me first"). Creates (first run) or refreshes the live GitHub
# validation tracksheet in Gareth's Smartsheet Home (private to him; not in any workspace, not shared).
# Data columns are rewritten on each refresh; any extra columns people add (owner, comments) are never touched.
# Usage: .\tracksheet-smartsheet.ps1 -Csv <tracksheet.csv> [-SheetId <id>]   (no -SheetId = create)
param([Parameter(Mandatory)][string]$Csv, [string]$SheetId, [string]$AsOf = (Get-Date -Format 'ddd dd MMM HH:mm') + ' CET')
$ErrorActionPreference = 'Stop'
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$hd = @{ Authorization = "Bearer $tok" }; $api = 'https://api.smartsheet.com/2.0'
function Send-Ss($m, $p, $b) { Invoke-RestMethod -Method $m "$api$p" -Headers $hd -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes(($b | ConvertTo-Json -Depth 10))) }
$data = @(Import-Csv $Csv); $cols = $data[0].PSObject.Properties.Name
$numeric = 'PRs (fin-tcm)','PRs (tcm-pilot)','PR difference','Releases (fin-tcm)','Releases (tcm-pilot)','Size MB (fin-tcm)','Size MB (tcm-pilot)','Teams (fin-tcm)','Teams (tcm-pilot)','Direct collaborators (fin-tcm)','Direct collaborators (tcm-pilot)'
$status = 'Overall status','Default branch','PRs','Releases','Code: branches + tags','Archived state','Teams','Direct collaborators'
$prCols = 'PRs (fin-tcm)','PRs (tcm-pilot)','PR difference'   # highlighted (bold, light orange) - Samar: PRs first
# background colours from Smartsheet's palette: 14 green #C6E7C8, 12 amber #FFE1AF, 11 red #FFCCD2
function Get-Fmt($v) { $bg = if ($v -match '^(OK|PASS)') { 14 } elseif ($v -match '^IN PROGRESS') { 12 } elseif ($v -match '^(GAP|DIFF|CHECK|MISSING|FAIL)') { 11 } else { $null }; if ($bg) { ",,,,,,,,,$bg,,,,,,," } else { $null } }
if (-not $SheetId) {
  $def = @{ name = 'GitHub migration validation (fin-tcm -> tcm-pilot)'; columns = @(for ($k = 0; $k -lt $cols.Count; $k++) { $c = @{ title = $cols[$k]; type = 'TEXT_NUMBER' }; if ($k -eq 0) { $c.primary = $true }; $c }) }
  $SheetId = (Send-Ss Post '/sheets' $def).result.id; "created sheet $SheetId"
}
$sheet = Invoke-RestMethod "$api/sheets/$SheetId" -Headers $hd
# column layout follows the CSV: add missing data columns, move existing ones into order (columns people added are left after them)
for ($k = 0; $k -lt $cols.Count; $k++) {
  $c = $sheet.columns | Where-Object title -eq $cols[$k]
  if (-not $c) { $null = Send-Ss Post "/sheets/$SheetId/columns" @(@{ title = $cols[$k]; type = 'TEXT_NUMBER'; index = $k }) }
  elseif ($c.index -ne $k -and -not $c.primary) { $null = Send-Ss Put "/sheets/$SheetId/columns/$($c.id)" @{ index = $k } }
  $sheet = Invoke-RestMethod "$api/sheets/$SheetId`?pageSize=1" -Headers $hd
}
$sheet = Invoke-RestMethod "$api/sheets/$SheetId" -Headers $hd
$cid = @{}; $sheet.columns | ForEach-Object { $cid[$_.title] = $_.id }
$rowByRepo = @{}; foreach ($r in $sheet.rows) { $v = ($r.cells | Where-Object columnId -eq $cid['Repo']).value; if ($v) { $rowByRepo["$v"] = $r.id } }
function Get-Cells($d) { foreach ($c in $cols) { $v = $d.$c; $cell = @{ columnId = $cid[$c]; value = $(if ($c -in $numeric -and "$v" -match '^-?\d+$') { [int]$v } else { "$v" }) }; if ($c -in $status) { $f = Get-Fmt "$v"; if ($f) { $cell.format = $f } else { $cell.format = ',,,,,,,,,,,,,,,,' } } elseif ($c -in $prCols) { $cell.format = ',,1,,,,,,,5,,,,,,,' }; $cell } }
$add = @(); $upd = @()
foreach ($d in $data) { $cells = @(Get-Cells $d); if ($rowByRepo[$d.Repo]) { $upd += @{ id = $rowByRepo[$d.Repo]; cells = $cells } } else { $add += @{ toBottom = $true; cells = $cells } } }
for ($k = 0; $k -lt $add.Count; $k += 300) { $null = Send-Ss Post "/sheets/$SheetId/rows" @($add[$k..([Math]::Min($k + 299, $add.Count - 1))]) }
for ($k = 0; $k -lt $upd.Count; $k += 300) { $null = Send-Ss Put "/sheets/$SheetId/rows" @($upd[$k..([Math]::Min($k + 299, $upd.Count - 1))]) }
"rows added $($add.Count), updated $($upd.Count)"
# Summary panel (sheet summary fields): replaced on each run
$cnt = $data | Group-Object 'Overall status'; $rt = $data | Group-Object 'Migration route'
$ps = 0; $pt = 0; $rs = 0; $rtt = 0; foreach ($d in $data) { $ps += [int]$d.'PRs (fin-tcm)'; $pt += [int]$d.'PRs (tcm-pilot)'; $rs += [int]$d.'Releases (fin-tcm)'; $rtt += [int]$d.'Releases (tcm-pilot)' }
$fields = @(@{ title = 'As of'; type = 'TEXT_NUMBER'; objectValue = $AsOf }, @{ title = 'Repos'; type = 'TEXT_NUMBER'; objectValue = "$($data.Count)" }) +
  @(foreach ($s in 'PASS','IN PROGRESS','CHECK','FAIL') { @{ title = "Status: $s"; type = 'TEXT_NUMBER'; objectValue = "$((@($cnt | Where-Object Name -eq $s).Count) * (($cnt | Where-Object Name -eq $s).Count))" } }) +
  @(@{ title = 'PRs fin-tcm / tcm-pilot'; type = 'TEXT_NUMBER'; objectValue = ('{0:N0} / {1:N0}' -f $ps, $pt) }, @{ title = 'Releases fin-tcm / tcm-pilot'; type = 'TEXT_NUMBER'; objectValue = ('{0:N0} / {1:N0}' -f $rs, $rtt) }) +
  @(foreach ($g in $rt) { @{ title = "Route: $($g.Name)"; type = 'TEXT_NUMBER'; objectValue = "$($g.Count)" } })
$old = @((Invoke-RestMethod "$api/sheets/$SheetId/summary/fields" -Headers $hd).data)
if ($old) { $null = Invoke-RestMethod -Method Delete "$api/sheets/$SheetId/summary/fields?ids=$(($old.id) -join ',')" -Headers $hd }
$null = Send-Ss Post "/sheets/$SheetId/summary/fields" $fields
$link = (Invoke-RestMethod "$api/sheets/$SheetId" -Headers $hd).permalink
"sheet $SheetId : $link"
