# PR method rehearsal (approved by Gareth 2026-11-10): times a full GEI re-import (code + all PRs, reviews, comments, same
# numbers) of a sample of the 311 repos with PR changes since import, so the cutover option "re-import the 311 repos" can be
# judged on measured numbers on Thursday. fin-tcm -> tcm-pilot-test/<repo>-reimport (new repos only; existing test repos
# are not touched; nothing in tcm-pilot is changed). LFS objects are not copied (timed separately if the option is chosen).
# Output: C:\kon-migration\reimport-rehearsal\<date>\results.csv + summary.md
param([int]$Random = 15, [int]$MaxInFlight = 10, [string]$Suffix = '-reimport')
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GH_SOURCE_PAT = $env:GH_SRC_PAT; $env:GH_PAT = $env:GH_TGT_PAT
$tgtAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$out = "C:\kon-migration\reimport-rehearsal\$(Get-Date -Format yyyy-MM-dd)"; New-Item -ItemType Directory -Force $out | Out-Null; Set-Location $out
$logFile = "$out\run.log"; function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
function Get-Gql($tok, $q) { (Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -ContentType application/json -Body (@{ query = $q } | ConvertTo-Json)).data }

$per = Import-Csv C:\kon-migration\pr-activity\2026-11-10\per-repo.csv | Where-Object { [int]$_.MissingOpen + [int]$_.MissingMerged + [int]$_.MissingClosed + [int]$_.StaleState -gt 0 }
$big = 'SUM-summit', 'OPICS-opics4plus', 'SPH-sophis', 'KON-kplus-back', 'ARC-almonde'
$rest = @($per | Where-Object { $_.Repo -notin $big } | Sort-Object { [Math]::Abs(("$($_.Repo)".GetHashCode()) % 9973) })   # fixed pseudo-random order
$sample = @($big) + @($rest | Select-Object -First $Random | ForEach-Object { $_.Repo })
$info = @{}; $per | ForEach-Object { $info[$_.Repo] = $_ }
Write-Log "=== re-import rehearsal: $($sample.Count) repos, $(($sample | ForEach-Object { [int]$info[$_].PrsTotal } | Measure-Object -Sum).Sum) PRs, $([Math]::Round(($sample | ForEach-Object { [double]$info[$_].DiskMB } | Measure-Object -Sum).Sum / 1024, 1)) GB (of 311 repos, 185,178 PRs, 40 GB)"

$t0 = Get-Date; $queued = @{}; $start = @{}; $res = @{}
$pending = New-Object System.Collections.Queue; foreach ($r in $sample) { $pending.Enqueue($r) }
while ($pending.Count -or $queued.Count) {
  while ($pending.Count -and $queued.Count -lt $MaxInFlight) {
    $r = $pending.Dequeue(); $tn = "$r$Suffix"
    $exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot-test/$tn" -Headers $tgtAuth; $true } catch { $false }
    if ($exists) { Write-Log "  $tn already exists - skipped"; $res[$r] = 'SKIPPED'; continue }
    $o = gh gei migrate-repo --github-source-org fin-tcm --source-repo $r --github-target-org tcm-pilot-test --target-repo $tn --target-repo-visibility private --queue-only 2>&1 | ForEach-Object { "$_" }
    $id = ([regex]::Match(($o -join ' '), '\(ID: (RM_[A-Za-z0-9_\-]+)\)')).Groups[1].Value
    if ($id) { $queued[$r] = $id; $start[$r] = Get-Date; Write-Log "  queued $r ($id)" } else { $res[$r] = 'QUEUE-FAILED'; Write-Log "  $r : could not queue - $(($o | Select-Object -Last 2) -join ' ')" }
  }
  Start-Sleep -Seconds 60
  foreach ($r in @($queued.Keys)) {
    $s = (Get-Gql $env:GH_TGT_PAT ('{ node(id:"' + $queued[$r] + '"){ ... on Migration { state failureReason } } }')).node
    if ($s.state -in 'SUCCEEDED', 'FAILED') { $res[$r] = $s.state; $mins = ((Get-Date) - $start[$r]).TotalMinutes; $queued.Remove($r)
      $start[$r] = $mins; Write-Log ("  $r : $($s.state) after {0:N0} min $($s.failureReason)" -f $mins) }
  }
}
$total = ((Get-Date) - $t0).TotalMinutes
$rows = foreach ($r in $sample) {
  $c = if ($res[$r] -eq 'SUCCEEDED') { (Get-Gql $env:GH_TGT_PAT ('{ repository(owner:"tcm-pilot-test", name:"' + $r + $Suffix + '") { pullRequests { totalCount } } }')).repository.pullRequests.totalCount } else { '' }
  [pscustomobject]@{ Repo = $r; State = $res[$r]; Minutes = $(if ($start[$r] -is [double]) { [Math]::Round($start[$r], 1) } else { '' }); PRsFinTcm = $info[$r].PrsTotal; PRsImported = $c; SizeMB = $info[$r].DiskMB }
}
$rows | Export-Csv "$out\results.csv" -NoTypeInformation -Encoding utf8
$ok = @($rows | Where-Object State -eq 'SUCCEEDED')
$prsOk = ($ok | Measure-Object { [int]$_.PRsFinTcm } -Sum).Sum
$md = @("# Re-import rehearsal - $(Get-Date -Format 'yyyy-MM-dd HH:mm') CET", '',
  "- Repos: $($sample.Count) ($($ok.Count) succeeded), up to $MaxInFlight at a time; wall clock **$([Math]::Round($total / 60, 1)) h**",
  "- PRs imported: $(($ok | Measure-Object { [int]$_.PRsImported } -Sum).Sum) of $prsOk in fin-tcm for the succeeded repos",
  "- Longest repo: $(($rows | Where-Object { $_.Minutes -ne '' } | Sort-Object { [double]$_.Minutes } -Descending | Select-Object -First 1 | ForEach-Object { "$($_.Repo) $($_.Minutes) min" }))", '',
  '| Repo | State | Minutes | PRs fin-tcm | PRs imported | Size MB |', '|---|---|---|---|---|---|')
$md += $rows | ForEach-Object { "| $($_.Repo) | $($_.State) | $($_.Minutes) | $($_.PRsFinTcm) | $($_.PRsImported) | $($_.SizeMB) |" }
$md | Set-Content "$out\summary.md" -Encoding utf8
Write-Log "=== done after $([Math]::Round($total / 60, 1)) h: $($ok.Count)/$($sample.Count) succeeded"
