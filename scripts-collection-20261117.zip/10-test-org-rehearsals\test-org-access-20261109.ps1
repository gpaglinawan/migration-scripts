# Access for 3 repos copied into tcm-pilot-test on 9 Nov 2026 (approved by Gareth: "grant").
#   OPICS-opicsdevops               SaiYaswanth Chavan: same access as OPICS-opics4plus in tcm-pilot-test (teams + direct)
#   SUM-summit-snowflake-connector  Gaurav Kotecha: same as fin-tcm (direct collaborators mapped _finastra -> _tciem;
#                                   svc-deliv and the hashed account have no Teciem login; teams security-manager /
#                                   jellyfish-fin-tcm do not exist in the test org)
#   KQ-qa_octane_automation         Lukasz: KQ teams as in tcm-pilot - kq_admin (admin), kq_w (push), kq_r (pull) created in
#                                   the test org with the tcm-pilot members (leftover fin-tcm* / CI / security teams not copied)
# Additive only, safe to re-run. Log: C:\kon-migration\rules\test-org-access-20261109.log
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ghAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$testOrg = 'tcm-pilot-test'; $gh = 'https://api.github.com'
$logFile = 'C:\kon-migration\rules\test-org-access-20261109.log'
function Write-Log($msg) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
function Get-All($url) { $out = @(); $page = 1; do { $batch = @(Invoke-RestMethod "$url$(if ($url -match '\?') { '&' } else { '?' })per_page=100&page=$page" -Headers $ghAuth | ForEach-Object { $_ }); $out += $batch; $page++ } while ($batch.Count -eq 100); $out }
function ConvertTo-Perm($role) { switch ($role) { 'write' { 'push' } 'read' { 'pull' } default { $role } } }
function Grant-Team($slug, $repoName, $perm) {
  try { Invoke-RestMethod -Method PUT "$gh/orgs/$testOrg/teams/$slug/repos/$testOrg/$repoName" -Headers $ghAuth -ContentType application/json -Body (@{ permission = $perm } | ConvertTo-Json) | Out-Null; Write-Log "  team $slug -> $perm" }
  catch { Write-Log "  FAILED team $slug -> $perm : $($_.ErrorDetails.Message)" } }
function Grant-User($login, $repoName, $perm) {
  try { Invoke-RestMethod -Method PUT "$gh/repos/$testOrg/$repoName/collaborators/$login" -Headers $ghAuth -ContentType application/json -Body (@{ permission = $perm } | ConvertTo-Json) | Out-Null; Write-Log "  user $login -> $perm" }
  catch { Write-Log "  FAILED user $login -> $perm : $($_.ErrorDetails.Message)" } }

# 1. OPICS-opicsdevops = OPICS-opics4plus in the test org
Write-Log '=== OPICS-opicsdevops (copy of OPICS-opics4plus access in tcm-pilot-test)'
foreach ($team in Get-All "$gh/repos/$testOrg/OPICS-opics4plus/teams") { Grant-Team $team.slug 'OPICS-opicsdevops' $team.permission }
foreach ($user in Get-All "$gh/repos/$testOrg/OPICS-opics4plus/collaborators?affiliation=direct") { Grant-User $user.login 'OPICS-opicsdevops' (ConvertTo-Perm $user.role_name) }

# 2. SUM-summit-snowflake-connector = fin-tcm direct collaborators, mapped
Write-Log '=== SUM-summit-snowflake-connector (fin-tcm direct collaborators -> _tciem)'
$snowflake = [ordered]@{ 'noris-filip' = 'admin'; 'Delia-Corduneanu' = 'admin'; 'Daniela-Stanciu' = 'admin'; 'Doru-Florea' = 'admin'; 'Calin-Mihai-Istrate' = 'admin'
                         'Gaurav-Kotecha' = 'admin'; 'soukaina-lourhaoui' = 'admin'; 'mihai-cilidariu' = 'admin'; 'catalinaelena-radu' = 'push'
                         'florina-balasescu' = 'pull'; 'costin-chirita' = 'pull' }
foreach ($name in $snowflake.Keys) { Grant-User "${name}_tciem" 'SUM-summit-snowflake-connector' $snowflake[$name] }
Write-Log '  not granted: svc-deliv_finastra, 30608c1b9c1f55f0e401b9e6d195a4_finastra (no Teciem login); teams security-manager, jellyfish-fin-tcm (not in test org)'

# 3. KQ-qa_octane_automation: wait for its copy, then KQ teams copied from tcm-pilot
$geiLog = 'C:\kon-migration\testorg-gei-kq-octane\gei.log'
for ($wait = 0; $wait -lt 120 -and -not (Select-String -Path $geiLog -Pattern '=== done' -Quiet); $wait++) { Start-Sleep 30 }
if (-not (Select-String -Path $geiLog -Pattern '=== done: 1 succeeded' -Quiet)) { Write-Log "=== KQ-qa_octane_automation: copy not finished/succeeded - access NOT granted (see $geiLog)"; return }
Write-Log '=== KQ-qa_octane_automation (KQ teams from tcm-pilot)'
$kqTeams = [ordered]@{ 'kq_admin' = 'admin'; 'kq_w' = 'push'; 'kq_r' = 'pull' }
foreach ($slug in $kqTeams.Keys) {
  $src = Invoke-RestMethod "$gh/orgs/tcm-pilot/teams/$slug" -Headers $ghAuth
  try { $null = Invoke-RestMethod "$gh/orgs/$testOrg/teams/$slug" -Headers $ghAuth }
  catch { Invoke-RestMethod -Method POST "$gh/orgs/$testOrg/teams" -Headers $ghAuth -ContentType application/json -Body (@{ name = $src.name; description = "$($src.name) - copy of tcm-pilot team for testing"; privacy = 'closed' } | ConvertTo-Json) | Out-Null; Write-Log "  team $slug created" }
  $members = @(Get-All "$gh/orgs/tcm-pilot/teams/$slug/members" | ForEach-Object { $_.login }); $failed = @()
  foreach ($login in $members) { try { Invoke-RestMethod -Method PUT "$gh/orgs/$testOrg/teams/$slug/memberships/$login" -Headers $ghAuth -ContentType application/json -Body '{"role":"member"}' | Out-Null } catch { $failed += "$login ($($_.ErrorDetails.Message))" } }
  Write-Log "  team $slug : $($members.Count - $failed.Count)/$($members.Count) members"; $failed | ForEach-Object { Write-Log "    failed: $_" }
  Grant-Team $slug 'KQ-qa_octane_automation' $kqTeams[$slug]
}
Write-Log '=== done'
