param(
  [Parameter(Mandatory)][string]$Orig,          # bare clone, never modified
  [Parameter(Mandatory)][string]$Copy,          # working copy that gets rewritten
  [Parameter(Mandatory)][string]$Out,           # logs + reports
  [long]$ThresholdBytes = 100MB,
  [string[]]$PathRename = @(),         # e.g. 'QuickFixn/.git/:QuickFixn/_git/' for committed .git folders GitHub rejects
  [switch]$DropNullGitlinks            # drop submodule entries recorded with an all-zero commit id (GitHub rejects them: fsck nullSha1)
)
# Rewrites a copy of the repo so every blob larger than $ThresholdBytes is stored in Git LFS (exact content,
# sha256-addressed) and replaced by an LFS pointer. Everything else (other files, authors, dates, messages,
# ref names) is unchanged. Uses git-filter-repo (fast-export/fast-import), far faster than git lfs migrate.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
$py = "C:\kon-migration\tools\python\python.exe"
$fr = "C:\kon-migration\tools\filter-repo\git-filter-repo"
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "rewrite.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

Log "=== copy $Orig -> $Copy ==="
if (Test-Path $Copy) { [IO.Directory]::Delete("\\?\$((Resolve-Path $Copy).Path)", $true) }   # 14 Nov: Remove-Item left >260-char ref files behind
robocopy $Orig $Copy /E /NFL /NDL /NJH /NJS /NP /MT:8 | Out-Null
if ($LASTEXITCODE -ge 8) { Log "FATAL: copy failed (robocopy $LASTEXITCODE)"; exit 1 }
Remove-Item (Join-Path $Copy "hooks\pre-push"), (Join-Path $Copy "hooks\post-checkout"), (Join-Path $Copy "hooks\post-commit"), (Join-Path $Copy "hooks\post-merge") -ErrorAction SilentlyContinue
Log ("refs: {0}" -f @(git -C $Copy for-each-ref --format="%(refname)").Count)

$lfsDir = (Join-Path $Copy "lfs\objects") -replace '\\','/'
$cb = @"
if len(blob.data) > ${ThresholdBytes}:
    import hashlib, os
    h = hashlib.sha256(blob.data).hexdigest()
    d = os.path.join('$lfsDir', h[0:2], h[2:4])
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, h)
    if not os.path.exists(p) or os.path.getsize(p) != len(blob.data):
        with open(p + '.tmp', 'wb') as f:
            f.write(blob.data)
        os.replace(p + '.tmp', p)
    blob.data = ('version https://git-lfs.github.com/spec/v1\noid sha256:%s\nsize %d\n' % (h, len(blob.data))).encode()
"@
Log "git filter-repo (blobs > $ThresholdBytes bytes -> LFS) ..."
$t = Get-Date
Push-Location $Copy
# history contains paths that are legal in git but not on NTFS (e.g. ending in '*'); this is a bare repo with no
# checkout, so let fast-import keep them byte-identical instead of rejecting them
$env:GIT_CONFIG_COUNT = "2"
$env:GIT_CONFIG_KEY_0 = "core.protectNTFS"; $env:GIT_CONFIG_VALUE_0 = "false"
$env:GIT_CONFIG_KEY_1 = "core.longpaths";   $env:GIT_CONFIG_VALUE_1 = "true"
# --preserve-commit-hashes: keep commit messages byte-identical (don't rewrite hashes mentioned in messages)
# --replace-refs delete-no-add: don't create refs/replace/* that would otherwise be pushed
$renameArgs = @(foreach ($pr in $PathRename) { '--path-rename'; $pr })
if ($renameArgs) { Log "path renames: $($PathRename -join ', ')" }
if ($DropNullGitlinks) {
  $renameArgs += @('--commit-callback', "commit.file_changes = [c for c in commit.file_changes if not (c.type == b'M' and c.mode == b'160000' and c.blob_id == b'0' * 40)]")
  Log "dropping submodule entries with an all-zero commit id"
}
& $py -I $fr --force --preserve-commit-hashes --replace-refs delete-no-add @renameArgs --blob-callback $cb *>&1 |
  ForEach-Object { "$_" } | Where-Object { $_ -notmatch '^\s*Parsed \d+ commits' } | Add-Content $log -Encoding utf8
$rc = $LASTEXITCODE
Pop-Location
Log ("filter-repo exit={0} in {1:N0} min" -f $rc, ((Get-Date)-$t).TotalMinutes)
if ($rc -ne 0) { Log "FATAL: filter-repo failed"; exit 1 }

Log ("refs after: {0}" -f @(git -C $Copy for-each-ref --format="%(refname)").Count)
$lfs = @(Get-ChildItem (Join-Path $Copy "lfs\objects") -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike '*.tmp' })
Log ("LFS objects in copy: {0} ({1:N2} GB)" -f $lfs.Count, (($lfs | Measure-Object Length -Sum).Sum/1GB))
Log "=== done ==="
