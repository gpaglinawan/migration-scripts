# Registers the Windows scheduled task "Teciem nightly repo sync" for the current user: daily at 01:00, runs
# C:\kon-migration\scripts\nightly-sync.ps1 (max 8 h, no overlapping runs). Runs while you are logged on
# (a disconnected remote-desktop session counts). Report: C:\kon-migration\nightly\latest-report.md
# Remove later with:  Unregister-ScheduledTask -TaskName "Teciem nightly repo sync" -Confirm:$false
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "C:\kon-migration\scripts\nightly-sync.ps1"' -WorkingDirectory 'C:\kon-migration'
$trigger = New-ScheduledTaskTrigger -Daily -At 01:00
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Hours 8) -MultipleInstances IgnoreNew -StartWhenAvailable
$principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName "Teciem nightly repo sync" -Description "fin-tcm -> tcm-pilot delta sync + report (C:\kon-migration\nightly\latest-report.md)" -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Force | Out-Null
Get-ScheduledTask -TaskName "Teciem nightly repo sync" | Get-ScheduledTaskInfo | Select-Object TaskName, NextRunTime | Format-List
