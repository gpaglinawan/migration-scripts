# DEF-013 / DEF-014 / DEF-118: restores tcm-pilot team display names, descriptions and code review assignment
# to match fin-tcm, from team-settings-diff.csv. Dry run unless -Apply.
# A name change must keep the team slug (so @mentions and CODEOWNERS keep working): the script checks the slug
# GitHub would give the new name, skips the team if it differs, and stops if a rename changes a slug anyway.
param([switch]$Apply, [string]$Org = "tcm-pilot")
$ErrorActionPreference = "Stop"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ht = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$log = Join-Path $PSScriptRoot ("team-settings-fix-{0:yyyyMMdd-HHmm}.log" -f (Get-Date))
function Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $l; Add-Content $log $l -Encoding utf8 }
function SlugOf($n) { (($n.ToLower() -replace '[^a-z0-9_]+', '-') -replace '-+', '-').Trim('-') }
$diff = @(Import-Csv (Join-Path $PSScriptRoot "team-settings-diff.csv"))
Log "=== team settings fix ($(if ($Apply) { 'APPLY' } else { 'dry run' })) on $Org, $($diff.Count) differences ==="
foreach ($g in $diff | Group-Object slug) {
  $slug = $g.Name; $body = @{}
  foreach ($d in $g.Group) {
    switch ($d.issue) {
      'name'        { if ((SlugOf $d.finastra) -eq $slug) { $body.name = $d.finastra } else { Log "SKIP $slug name '$($d.finastra)': slug would become $(SlugOf $d.finastra)" } }
      'description' { $body.description = $d.finastra }
    }
  }
  if ($body.Count) {
    Log ("{0}: {1}" -f $slug, (($body.GetEnumerator() | ForEach-Object { "$($_.Key) -> '$($_.Value)'" }) -join '; '))
    if ($Apply) {
      $r = Invoke-RestMethod -Method PATCH "https://api.github.com/orgs/$Org/teams/$slug" -Headers $ht -ContentType application/json -Body ($body | ConvertTo-Json)
      if ($r.slug -ne $slug) { Log "STOP: slug changed $slug -> $($r.slug)"; exit 1 }
    }
  }
  $cr = $g.Group | Where-Object issue -eq 'code review assignment'
  if ($cr) {
    $e, $alg, $cnt, $notify = $cr.finastra -split '\|'
    Log "${slug}: code review assignment -> enabled=$e algorithm=$alg members=$cnt notifyTeam=$notify"
    if ($Apply) {
      $id = (Invoke-RestMethod "https://api.github.com/orgs/$Org/teams/$slug" -Headers $ht).node_id
      $q = 'mutation($i:ID!,$e:Boolean!,$a:TeamReviewAssignmentAlgorithm,$c:Int,$n:Boolean){ updateTeamReviewAssignment(input:{id:$i, enabled:$e, algorithm:$a, teamMemberCount:$c, notifyTeam:$n}){ team { slug reviewRequestDelegationEnabled } } }'
      $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $ht -ContentType application/json `
           -Body (@{ query = $q; variables = @{ i = $id; e = [bool]::Parse($e); a = $alg; c = [int]$cnt; n = [bool]::Parse($notify) } } | ConvertTo-Json)
      if ($r.errors) { Log "   FAILED: $($r.errors | ConvertTo-Json -Compress)" }
    }
  }
  if ($g.Group | Where-Object issue -eq 'missing in tcm-pilot') { Log "${slug}: missing in $Org, not created by this script (needs its members and repo access too)" }
}
Log "=== done ==="
