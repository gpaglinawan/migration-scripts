param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$In     = "C:\kon-migration\rules",
  [string[]]$Repos,            # default: repos rules-compare.csv shows as short in the target
  [switch]$Apply
)
# Copies repo rulesets and classic branch protection rules that exist in the source but not in the target
# (matched by ruleset name / branch pattern). Team and user actors are mapped to target equivalents
# (team by slug, user _finastra -> _tciem); GitHub App actors cannot be mapped and are skipped + reported.
# Plan only unless -Apply. Never modifies or deletes existing target rules.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$log = Join-Path $In "rules-sync-$(if($Apply){'apply'}else{'plan'}).log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Rest($method, $uri, $hdr, $body) {
  if ($body) { return Invoke-RestMethod -Method $method -Uri $uri -Headers $hdr -Body ($body | ConvertTo-Json -Depth 30 -Compress) -ContentType application/json }
  Invoke-RestMethod -Method $method -Uri $uri -Headers $hdr
}
function Gql($query, $vars) { Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $tgtHdr -Body (@{ query = $query; variables = $vars } | ConvertTo-Json -Depth 30 -Compress) -ContentType application/json }
# PS 5.1: Invoke-RestMethod emits a JSON array as ONE pipeline object, so @(Rest ...) is a 1-element list holding
# the whole page. Enumerate with foreach to get the items.
function All($uri, $hdr) {
  $acc = New-Object System.Collections.ArrayList; $page = 1
  do { $r = Rest GET "$uri$(if($uri -match '\?'){'&'}else{'?'})per_page=100&page=$page" $hdr; $n = 0
       foreach ($x in $r) { if ($x) { [void]$acc.Add($x); $n++ } }; $page++ } while ($n -eq 100)
  $acc   # unrolled into the pipeline so `foreach ($t in All ...)` sees each item
}

# team maps: source id -> slug, target slug -> (id, node_id)
$srcTeamSlug = @{}; foreach ($tm in All "https://api.github.com/orgs/$SrcOrg/teams" $srcHdr) { $srcTeamSlug[[string]$tm.id] = $tm.slug }
$tgtTeam = @{};     foreach ($tm in All "https://api.github.com/orgs/$TgtOrg/teams" $tgtHdr) { $tgtTeam[$tm.slug] = $tm }
$userNode = @{}
function TgtUserNode($srcLogin) {
  $tl = ($srcLogin -replace '_finastra$', '_tciem')
  if ($userNode.ContainsKey($tl)) { return $userNode[$tl] }
  try { $u = Rest GET "https://api.github.com/users/$tl" $tgtHdr; $userNode[$tl] = $u.node_id } catch { $userNode[$tl] = $null }
  $userNode[$tl]
}

if (-not $Repos) {
  $cmp = Import-Csv (Join-Path $In "rules-compare.csv")
  $Repos = @($cmp | Where-Object { $_.InTarget -eq 'True' -and ([int]$_.TgtRulesets -lt [int]$_.SrcRulesets -or [int]$_.TgtBranchProtection -lt [int]$_.SrcBranchProtection) } | ForEach-Object Repo)
}
Log "=== rules sync $SrcOrg -> $TgtOrg : $($Repos.Count) repos, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="

foreach ($repo in $Repos) {
  # ---- repo rulesets ----
  $rsFile = Join-Path $In "src-repo-rulesets\$repo.json"
  if (Test-Path $rsFile) {
    # PS 5.1: ConvertFrom-Json emits a JSON array as ONE object - pipe through ForEach-Object to unroll it
    $srcSets = @(Get-Content $rsFile -Raw | ConvertFrom-Json | ForEach-Object { $_ })
    $have = @{}; foreach ($x in (All "https://api.github.com/repos/$TgtOrg/$repo/rulesets?includes_parents=false" $tgtHdr)) { if ($x.name) { $have[$x.name] = $true } }
    foreach ($rs in $srcSets) {
      if (-not $rs.name -or $have[$rs.name]) { continue }
      $notes = @(); $bypass = @()
      foreach ($b in @($rs.bypass_actors)) {
        switch ($b.actor_type) {
          'Team'        { $slug = $srcTeamSlug[[string]$b.actor_id]; $tt = if ($slug) { $tgtTeam[$slug] }
                          if ($tt) { $bypass += @{ actor_id = $tt.id; actor_type = 'Team'; bypass_mode = $b.bypass_mode } } else { $notes += "team $slug not in target" } }
          'Integration' { $notes += "app bypass (id $($b.actor_id)) skipped" }
          default       { $bypass += @{ actor_id = $b.actor_id; actor_type = $b.actor_type; bypass_mode = $b.bypass_mode } }   # OrganizationAdmin, RepositoryRole, DeployKey
        }
      }
      $rules = @(foreach ($r in @($rs.rules)) {
        $o = @{ type = $r.type }
        if ($r.parameters) {
          $p = $r.parameters | ConvertTo-Json -Depth 20 | ConvertFrom-Json
          if ($p.required_status_checks) { foreach ($c in $p.required_status_checks) { $c.PSObject.Properties.Remove('integration_id') } }
          $o.parameters = $p
        }
        $o })
      $body = @{ name = $rs.name; target = $rs.target; enforcement = $rs.enforcement; conditions = $rs.conditions; rules = $rules; bypass_actors = $bypass }
      # an unmappable team would make the rule stricter than the source - hold it for a human
      if ($notes -match 'not in target') { Log "  $repo : HOLD ruleset '$($rs.name)' - $($notes -join '; ')"; continue }
      if ($Apply) {
        try { Rest POST "https://api.github.com/repos/$TgtOrg/$repo/rulesets" $tgtHdr $body | Out-Null; Log "  $repo : ruleset created '$($rs.name)' [$($rs.enforcement)] $($notes -join '; ')" }
        catch { Log "  $repo : ruleset FAILED '$($rs.name)': $($_.ErrorDetails.Message -replace '\s+',' ')" }
      } else { Log "  $repo : would create ruleset '$($rs.name)' [$($rs.enforcement)] rules=$($rules.Count) bypass=$($bypass.Count) $($notes -join '; ')" }
    }
  }

  # ---- classic branch protection ----
  $bpFile = Join-Path $In "src-branch-protection\$repo.json"
  if (Test-Path $bpFile) {
    $srcRules = @(Get-Content $bpFile -Raw | ConvertFrom-Json | ForEach-Object { $_ })
    $q = 'query($o:String!,$n:String!){repository(owner:$o,name:$n){id branchProtectionRules(first:100){nodes{pattern}}}}'
    $tr = (Gql $q @{ o = $TgtOrg; n = $repo }).data.repository
    if (-not $tr) { Log "  $repo : not in target - skipped"; continue }
    $havePat = @{}; foreach ($x in @($tr.branchProtectionRules.nodes)) { $havePat[$x.pattern] = $true }
    foreach ($bp in $srcRules) {
      if (-not $bp.pattern -or $havePat[$bp.pattern]) { continue }
      $notes = @()
      function MapActors($nodes) {
        $ids = @()
        foreach ($n in @($nodes)) { $a = $n.actor
          switch ($a.__typename) {
            'Team' { if ($tgtTeam[$a.slug]) { $ids += $tgtTeam[$a.slug].node_id } else { $script:notes += "team $($a.slug) missing" } }
            'User' { $id = TgtUserNode $a.login; if ($id) { $ids += $id } else { $script:notes += "user $($a.login) missing" } }
            default { $script:notes += "$($a.__typename) $($a.slug) skipped" }
          } }
        , $ids
      }
      $inp = @{
        repositoryId = $tr.id; pattern = $bp.pattern
        isAdminEnforced = $bp.isAdminEnforced; allowsDeletions = $bp.allowsDeletions; allowsForcePushes = $bp.allowsForcePushes
        blocksCreations = $bp.blocksCreations; dismissesStaleReviews = $bp.dismissesStaleReviews; lockBranch = $bp.lockBranch
        requireLastPushApproval = $bp.requireLastPushApproval; requiredApprovingReviewCount = $bp.requiredApprovingReviewCount
        requiresApprovingReviews = $bp.requiresApprovingReviews; requiresCodeOwnerReviews = $bp.requiresCodeOwnerReviews
        requiresCommitSignatures = $bp.requiresCommitSignatures; requiresConversationResolution = $bp.requiresConversationResolution
        requiresLinearHistory = $bp.requiresLinearHistory; requiresStatusChecks = $bp.requiresStatusChecks
        requiresStrictStatusChecks = $bp.requiresStrictStatusChecks; restrictsPushes = $bp.restrictsPushes
        restrictsReviewDismissals = $bp.restrictsReviewDismissals; requiredStatusCheckContexts = @($bp.requiredStatusCheckContexts)
        pushActorIds = (MapActors $bp.pushAllowances.nodes); bypassPullRequestActorIds = (MapActors $bp.bypassPullRequestAllowances.nodes)
        reviewDismissalActorIds = (MapActors $bp.reviewDismissalAllowances.nodes)
      }
      if ($notes -match 'missing') { Log "  $repo : HOLD branch protection '$($bp.pattern)' - $($notes -join '; ')"; continue }
      if ($Apply) {
        $m = 'mutation($i:CreateBranchProtectionRuleInput!){createBranchProtectionRule(input:$i){branchProtectionRule{pattern}}}'
        $res = Gql $m @{ i = $inp }
        if ($res.errors) { Log "  $repo : branch protection FAILED '$($bp.pattern)': $(($res.errors | ForEach-Object message) -join '; ')" }
        else { Log "  $repo : branch protection created '$($bp.pattern)' $($notes -join '; ')" }
      } else { Log "  $repo : would protect '$($bp.pattern)' (reviews=$($bp.requiredApprovingReviewCount) checks=$(@($bp.requiredStatusCheckContexts).Count) restrictsPushes=$($bp.restrictsPushes)) $($notes -join '; ')" }
    }
  }
}
Log "=== done ==="
