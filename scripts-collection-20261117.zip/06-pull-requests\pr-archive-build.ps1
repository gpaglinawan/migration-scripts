param(
  [string]$Repo = "kon-kplus-front",
  [string]$SrcOrg = "fin-tcm",
  [string]$In = "C:\kon-migration\pr-archive\kon-kplus-front",
  [string]$OutRepo = "C:\kon-migration\pr-archive\KON-kplus-front-pr-archive",
  [string]$OpenMap = "C:\kon-migration\pr-archive\kon-kplus-front\open-pr-map.csv"
)
# Builds a read-only, searchable archive of every pull request exported by pr-export.ps1:
# one Markdown page per PR (description, reviews, conversation, line comments with their diff context)
# under prs/<thousands>/<number>.md, plus README.md and index.csv. Output is a plain git working tree.
$ErrorActionPreference = "Stop"
$utf8 = New-Object Text.UTF8Encoding $false
# Export files are UTF-8 without BOM: read them with [IO.File] (UTF-8), never Get-Content, which PS 5.1 reads as ANSI.
function ReadPages($sub) { foreach ($f in (Get-ChildItem (Join-Path $In $sub) -Filter page-*.json | Sort-Object Name)) { $t = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8); if ($t.Trim().Length -lt 3) { continue }; $j = $t | ConvertFrom-Json; foreach ($x in $j) { $x } } }
function Q([string]$t) { if (-not $t) { return "" }; ($t -split "`r?`n" | ForEach-Object { "> $_" }) -join "`n" }
function D($v) { if ($v) { ([datetime]$v).ToUniversalTime().ToString('yyyy-MM-dd HH:mm') + ' UTC' } else { '' } }
function Who($a) { if ($a -and $a.login) { $a.login } else { 'ghost' } }

Write-Host "reading export..."
$prs = @(ReadPages 'prs')
$rc = @{}; foreach ($c in (ReadPages 'review-comments')) { $n = [int]($c.pull_request_url -replace '.*/', ''); if (-not $rc[$n]) { $rc[$n] = New-Object System.Collections.ArrayList }; [void]$rc[$n].Add($c) }
$ic = @{}; foreach ($c in (ReadPages 'issue-comments')) { $n = [int]($c.issue_url -replace '.*/', ''); if (-not $ic[$n]) { $ic[$n] = New-Object System.Collections.ArrayList }; [void]$ic[$n].Add($c) }
$open = @{}; if (Test-Path $OpenMap) { foreach ($m in (Import-Csv $OpenMap)) { $open[[int]$m.Source] = [int]$m.Target } }
Write-Host "PRs=$($prs.Count) review comments for $($rc.Count) PRs, conversation comments for $($ic.Count) PRs"

if (Test-Path (Join-Path $OutRepo "prs")) { throw "$OutRepo\prs already exists - use a new folder" }
New-Item -ItemType Directory -Force $OutRepo | Out-Null
$index = New-Object System.Collections.ArrayList
$i = 0
foreach ($p in $prs) {
  $i++; $n = [int]$p.number
  $state = if ($p.mergedAt) { 'merged' } elseif ($p.state -eq 'CLOSED') { 'closed' } else { 'open' }
  $sb = New-Object Text.StringBuilder
  [void]$sb.AppendLine("# #$n $($p.title)").AppendLine()
  [void]$sb.AppendLine("| | |").AppendLine("|---|---|")
  [void]$sb.AppendLine("| State | **$state**$(if($p.isDraft){' (draft)'}) |")
  [void]$sb.AppendLine("| Author | $(Who $p.author) |")
  [void]$sb.AppendLine("| Opened | $(D $p.createdAt) |")
  if ($p.mergedAt) { [void]$sb.AppendLine("| Merged | $(D $p.mergedAt) by $(Who $p.mergedBy) |") } elseif ($p.closedAt) { [void]$sb.AppendLine("| Closed | $(D $p.closedAt) |") }
  [void]$sb.AppendLine("| Branches | ``$($p.headRefName)`` into ``$($p.baseRefName)`` |")
  [void]$sb.AppendLine("| Size | $($p.commits.totalCount) commits, $($p.changedFiles) files, +$($p.additions) / -$($p.deletions) |")
  $labels = @($p.labels.nodes.name | Where-Object { $_ }); if ($labels.Count) { [void]$sb.AppendLine("| Labels | $($labels -join ', ') |") }
  if ($p.milestone) { [void]$sb.AppendLine("| Milestone | $($p.milestone.title) |") }
  [void]$sb.AppendLine("| Finastra | $($p.url) (head ``$($p.headRefOid)``) |")
  if ($open[$n]) { [void]$sb.AppendLine("| Teciem | still open: tcm-pilot/KON-kplus-front#$($open[$n]) |") }
  [void]$sb.AppendLine().AppendLine("## Description").AppendLine()
  [void]$sb.AppendLine($(if ($p.body) { $p.body } else { '_No description._' }))

  # conversation: comments and reviews in time order
  $ev = New-Object System.Collections.ArrayList
  foreach ($c in @($ic[$n])) { if ($c) { [void]$ev.Add([pscustomobject]@{ At = [datetime]$c.created_at; Text = "**$(Who $c.user)** commented on $(D $c.created_at)`n`n$(Q $c.body)" }) } }
  foreach ($r in @($p.reviews.nodes)) { if ($r -and ($r.body -or $r.state -ne 'COMMENTED')) { [void]$ev.Add([pscustomobject]@{ At = [datetime]$r.submittedAt; Text = "**$(Who $r.author)** reviewed: $($r.state.ToLower().Replace('_',' ')) on $(D $r.submittedAt)$(if($r.body){"`n`n$(Q $r.body)"})" }) } }
  if ($p.reviews.totalCount -gt @($p.reviews.nodes).Count) { [void]$ev.Add([pscustomobject]@{ At = [datetime]::MaxValue; Text = "_$($p.reviews.totalCount - @($p.reviews.nodes).Count) further reviews not shown; see the line comments below._" }) }
  if ($ev.Count) { [void]$sb.AppendLine().AppendLine("## Conversation"); foreach ($e in ($ev | Sort-Object At)) { [void]$sb.AppendLine().AppendLine("---").AppendLine($e.Text) } }

  # line comments grouped by thread (in_reply_to)
  $lc = @($rc[$n] | Where-Object { $_ })
  if ($lc.Count) {
    [void]$sb.AppendLine().AppendLine("## Line comments")
    $roots = @($lc | Where-Object { -not $_.in_reply_to_id } | Sort-Object created_at)
    $replies = @{}; foreach ($c in ($lc | Where-Object { $_.in_reply_to_id })) { $k = [string]$c.in_reply_to_id; if (-not $replies[$k]) { $replies[$k] = New-Object System.Collections.ArrayList }; [void]$replies[$k].Add($c) }
    foreach ($c in $roots) {
      $line = if ($c.line) { $c.line } elseif ($c.original_line) { $c.original_line } else { '' }
      $hunk = (($c.diff_hunk -split "`n") | Select-Object -Last 6) -join "`n"
      [void]$sb.AppendLine().AppendLine("### ``$($c.path)``$(if($line){" line $line"})").AppendLine().AppendLine('```diff').AppendLine($hunk).AppendLine('```')
      [void]$sb.AppendLine("**$(Who $c.user)** on $(D $c.created_at)").AppendLine().AppendLine((Q $c.body))
      foreach ($r in (@($replies[[string]$c.id]) | Where-Object { $_ } | Sort-Object created_at)) { [void]$sb.AppendLine().AppendLine("**$(Who $r.user)** replied on $(D $r.created_at)").AppendLine().AppendLine((Q $r.body)) }
    }
  }
  $bucket = "{0:D2}xxx" -f [int][Math]::Floor($n / 1000)
  $dir = Join-Path $OutRepo "prs\$bucket"; if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force $dir | Out-Null }
  [IO.File]::WriteAllText((Join-Path $dir "$n.md"), $sb.ToString(), $utf8)
  [void]$index.Add([pscustomobject]@{ Number = $n; Title = $p.title; State = $state; Author = (Who $p.author); Opened = ([datetime]$p.createdAt).ToString('yyyy-MM-dd'); MergedOrClosed = $(if ($p.mergedAt) { ([datetime]$p.mergedAt).ToString('yyyy-MM-dd') } elseif ($p.closedAt) { ([datetime]$p.closedAt).ToString('yyyy-MM-dd') } else { '' }); Head = $p.headRefName; Base = $p.baseRefName; TeciemPR = $open[$n]; File = "prs/$bucket/$n.md" })
  if ($i % 5000 -eq 0) { Write-Host "  $i / $($prs.Count)" }
}
$index | Sort-Object Number | Export-Csv (Join-Path $OutRepo "index.csv") -NoTypeInformation -Encoding utf8

$stats = $index | Group-Object State | ForEach-Object { "$($_.Count) $($_.Name)" }
$readme = @"
# KON-kplus-front pull request archive

Read-only copy of every pull request from Finastra **$SrcOrg/$Repo** ($($prs.Count) pull requests: $($stats -join ', ')), exported on $(Get-Date -Format 'd MMMM yyyy').

KON-kplus-front was moved to tcm-pilot by git push rather than the GitHub importer, because its history contained files over GitHub's 100 MB limit (now in Git LFS). Pull requests don't move with a git push, so they are kept here. The open ones were also recreated as real pull requests in tcm-pilot/KON-kplus-front.

## Finding a pull request

- **By number:** ``prs/<thousands>/<number>.md``, for example #39260 is ``prs/39xxx/39260.md``.
- **By title, author, branch or date:** open ``index.csv`` (GitHub shows it as a searchable table).
- **By text:** use the GitHub search box in this repository (descriptions, comments and file paths are all searchable).

Each page has the description, the reviews and conversation in time order, and every line comment with the code it referred to.

## Things to know

- Commit IDs and links on these pages refer to **Finastra**. Because large files were moved to LFS, commit IDs in tcm-pilot differ from the point the first large file was added.
- ``#123`` references inside descriptions and comments mean Finastra pull request numbers. Use the folders above to look them up.
- Pull requests still open at export time are also open in tcm-pilot/KON-kplus-front. The ``TeciemPR`` column in index.csv gives the new number.
"@
[IO.File]::WriteAllText((Join-Path $OutRepo "README.md"), $readme, $utf8)
Write-Host "done: $($index.Count) pages in $OutRepo"
