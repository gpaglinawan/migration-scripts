# tcm-pilot-test access requests of 3 Nov 2026. Safe to re-run (repos still importing are reported and skipped).
#  - Jason Gibbons + Sebastian Alin Macovei: org members, admin on SPH-sophis (Jason's request, write-access testing)
#  - Balasundaram A: org member (Chris's request)
#  - Paul Jouet: admin on KON-kondor-docker, THIRD-scripts, THIRD-idakdb (THIRD pipeline test)
#  - Rachel Ho: admin on her 52 repos (UAT; list in C:\kon-migration\testorg-rachel-repos.txt)
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$org = 'tcm-pilot-test'
function Member($u) {
  try { $m = Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/memberships/$u" -Headers $h -ContentType application/json -Body '{"role":"member"}'; "$u : org $($m.state) $($m.role)" }
  catch { "$u : org membership FAILED $($_.ErrorDetails.Message)" }
}
function RepoAdmin($u, $r) {
  try { Invoke-RestMethod -Method PUT "https://api.github.com/repos/$org/$r/collaborators/$u" -Headers $h -ContentType application/json -Body '{"permission":"admin"}' | Out-Null; $true }
  catch { if ("$($_.ErrorDetails.Message)" -match 'locked|Not Found') { 'later' } else { "$($_.ErrorDetails.Message)" } }
}

foreach ($u in 'Jason-Gibbons_tciem', 'SebastianAlin-Macovei_tciem', 'balasundaram-a_tciem') { Member $u }
foreach ($u in 'Jason-Gibbons_tciem', 'SebastianAlin-Macovei_tciem') { $x = RepoAdmin $u 'SPH-sophis'; "$u : admin on SPH-sophis -> $(if ($x -eq $true) {'done'} elseif ($x -eq 'later') {'NOT READY (still importing) - re-run later'} else {"FAILED $x"})" }

# Paul Jouet: admin on the Kondor/THIRD repos he asked for (THIRD pipeline testing)
foreach ($r in 'KON-kondor-docker', 'THIRD-scripts', 'THIRD-idakdb') { $x = RepoAdmin 'Paul-Jouet_tciem' $r; "Paul-Jouet_tciem : admin on $r -> $(if ($x -eq $true) {'done'} elseif ($x -eq 'later') {'NOT READY - re-run later'} else {"FAILED $x"})" }

$repos = @(Get-Content C:\kon-migration\testorg-rachel-repos.txt | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$done = 0; $later = @(); $bad = @()
foreach ($r in $repos) { $x = RepoAdmin 'Rachel-Ho_tciem' $r; if ($x -eq $true) { $done++ } elseif ($x -eq 'later') { $later += $r } else { $bad += "$r ($x)" } }
"Rachel-Ho_tciem : admin on $done/$($repos.Count) repos; not ready yet: $($later.Count); failed: $($bad -join ', ')"
