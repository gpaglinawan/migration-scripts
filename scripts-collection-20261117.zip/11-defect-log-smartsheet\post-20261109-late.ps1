# 9 Nov 2026 late: DEF-099 retest result and findings on DEF-114/138/140/143. Comments only; no status change.
# Run with -DryRun first.
param([switch]$DryRun)
$comments = @{
  'DEF-099' = 'Retested by Gareth: pipeline variables compared for every pipeline in all 10 projects (TreasuryCapitalMarkets -> tcm-staging). No pipeline is missing variables. Open point for the Terraform team: the two secrets on Terraform / aft-account-customizations (TF_KMS_KEY_ID, TFC_API_TOKEN) were created empty because Azure DevOps does not allow secret values to be copied; they must be re-entered by the owning team before that pipeline runs. Can be closed.'
  'DEF-138' = 'MCH-mch: the 9 PRs not in tcm-pilot are #1995-#2003, all opened after the initial migration (the nightly sync copies branches and commits, not PRs). "IN_SYNC" in the compare tool means the code (branches/commits) is identical. Open PRs created since the initial migration are recreated at cutover (cutover step GIT-020); closed/merged ones are not copied, their code is already in tcm-pilot and they stay readable in fin-tcm.'
  'DEF-114' = 'FCBO-securities-inventory-service: the 9 PRs not in tcm-pilot (#155-#164) were all opened after the initial migration; the nightly sync copies branches and commits, not PRs. Open ones are recreated at cutover (GIT-020); the code of the closed/merged ones is already in tcm-pilot. Same explanation as DEF-138.'
  'DEF-143' = 'MAFQA-ffc-core-samples: DanielGabriel-Cotoi_tciem is admin in tcm-pilot (same as DanielGabriel-Cotoi_finastra in fin-tcm). Ready for retest by Leon.'
  'DEF-140' = 'Team FFC in tcm-pilot now has the name "FFC" (in capitals, as in fin-tcm) and the same description as in fin-tcm. The team picture cannot be set through GitHub''s API, so a team maintainer needs to upload it again in the team settings. Ready for retest by Leon.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
