# 9 Nov 2026, approved by Gareth ("grant"): Cristian Ilie asked for 18 repos in tcm-pilot-test to test commits, PRs and
# merges. Adds Cristian-Ilie_tciem as a direct collaborator with WRITE (push) on each of them - matching the write teams
# (kon_w, to_w) they are in on tcm-pilot. Only these 18 test-org repos; nothing in tcm-pilot is changed.
# Repos not yet imported are skipped and reported. Re-run safe. Log: C:\kon-migration\rules\test-org-access-cristian-20261109.log
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ghAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$userLogin = 'Cristian-Ilie_tciem'; $orgName = 'tcm-pilot-test'
$logFile = 'C:\kon-migration\rules\test-org-access-cristian-20261109.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
$repoList = 'KON-common-services','KON-db-enrichment','KON-deal-buffer','KON-deal-filter','KON-deal-mapper','KON-deltaconx-gateway',
  'KON-regulatory-reporting-deployment','KON-rest-enrichment','KON-tradekast-consumer','KON-valuation-publisher','KON-workflow-controller',
  'TO-aks-deployment-pandora','VAL-criteria-tables','VAL-deployment','VAL-input-gateway','VAL-input-mapper','val-mapping-runtime-poc','VAL-workflow-controller'
$okCount = 0
foreach ($repoName in $repoList) {
  $exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/$orgName/$repoName" -Headers $ghAuth; $true } catch { $false }
  if (-not $exists) { Write-Log "  $repoName : not in $orgName yet - skipped"; continue }
  Invoke-RestMethod -Method PUT "https://api.github.com/repos/$orgName/$repoName/collaborators/$userLogin" -Headers $ghAuth -ContentType application/json -Body '{"permission":"push"}' | Out-Null
  $perm = Invoke-RestMethod "https://api.github.com/repos/$orgName/$repoName/collaborators/$userLogin/permission" -Headers $ghAuth
  if ($perm.role_name -in 'write', 'maintain', 'admin') { $okCount++ }
  Write-Log "  $repoName : $userLogin role=$($perm.role_name)"
}
Write-Log "=== $okCount of $($repoList.Count) repos: $userLogin has write ==="
