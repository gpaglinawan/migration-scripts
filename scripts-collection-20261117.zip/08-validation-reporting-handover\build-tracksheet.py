﻿# 14 Nov 2026 - GitHub migration validation tracksheet (fin-tcm -> tcm-pilot), requested by Samar Roy.
# One row per fin-tcm repo: migration route, source vs target per metric, status per check, overall status.
# Inputs (C:\kon-migration\tracksheet): metrics-fin-tcm.csv, metrics-tcm-pilot.csv, metrics-copies.csv, tcm-pilot-names.txt
# plus a refs compare-summary.csv (argv[2]) and its label (argv[3]). Output: argv[1] (.xlsx), stdlib only.
import csv, sys, os, re, zipfile, datetime
from xml.sax.saxutils import escape
out, cmp_path, cmp_label = sys.argv[1], sys.argv[2], sys.argv[3]
D = r'C:\kon-migration\tracksheet'
def rd(p): return {r['Repo']: r for r in csv.DictReader(open(p, encoding='utf-8-sig'))} if os.path.exists(p) else {}
src, tgt, cop = rd(f'{D}\\metrics-fin-tcm.csv'), rd(f'{D}\\metrics-tcm-pilot.csv'), rd(f'{D}\\metrics-copies.csv')
names = set(l.strip() for l in open(f'{D}\\tcm-pilot-names.txt', encoding='utf-8-sig') if l.strip())
cmp_ = {r['Repo']: r for r in csv.DictReader(open(cmp_path, encoding='utf-8-sig'))}
acc_s, acc_t = rd(f'{D}\\access-fin-tcm.csv'), rd(f'{D}\\access-tcm-pilot.csv')
login_map = {r['Src'].lower(): r['Tgt'] for r in csv.DictReader(open(r'C:\kon-migration\rules\member-names-20261111.csv', encoding='utf-8-sig')) if r.get('Tgt')}
# 14 Nov: admin grants held for owners (Gareth "apply without admin") and grants on read-only archived repos are not gaps
import glob
_dc = sorted(glob.glob(r'C:\kon-migration\teams\direct-collab-copy-*.csv'), key=os.path.getmtime)
held, roarch = set(), set()
for _f in _dc:   # union of all runs (a later run may not have marked archived repos)
    for r in csv.DictReader(open(_f, encoding='utf-8-sig')):
        if r['Action'].startswith('HELD'): held.add((r['Repo'], r['Teciem'].lower()))
        elif 'archived' in r['Action']: roarch.add((r['Repo'], r['Teciem'].lower()))
def logins(s): return [x.rsplit(':', 1)[0] for x in (s or '').split(';') if ':' in x]
# 15 Nov: (1) PR totals GitHub reports for fin-tcm can include PRs it cannot list; pr-gaps\pr-listable.csv holds the
# one-by-one listed counts (Repo,SrcListable,TgtListable). (2) refs where Teciem changed a branch before the freeze: the
# Finastra version is kept next to it (refs\preserved-refs.csv, Result PUSHED). (3) repos whose branch was rewritten for >100 MB files.
_lp = r'C:\kon-migration\pr-gaps\pr-listable.csv'
listable = {r['Repo']: (int(r['SrcListable']), int(r['TgtListable'])) for r in csv.DictReader(open(_lp, encoding='utf-8-sig'))} if os.path.exists(_lp) else {}
_pp = r'C:\kon-migration\refs\preserved-refs.csv'
kept = {(r['Repo'], r['Ref']) for r in csv.DictReader(open(_pp, encoding='utf-8-sig')) if r['Result'] == 'PUSHED'} if os.path.exists(_pp) else set()
_dp = os.path.join(os.path.dirname(cmp_path), 'compare-detail.csv')
diffs = {}
for r in (csv.DictReader(open(_dp, encoding='utf-8-sig')) if os.path.exists(_dp) else []):
    diffs.setdefault(r['Repo'], []).append(((r['Repo'], r['Ref']), r['Issue']))
lfs_rewritten = {'KON-doc-kondor-archive', 'KON-kondor-enablement'}   # KON-kondor-enablement: 5 branches = same commits (msg/date/author) rewritten to LFS, verified 15 Nov 05:25
_up = r'C:\kon-migration\pr-gaps\pr-unfetchable.csv'   # PRs whose head commit GitHub no longer serves from fin-tcm (cannot be recreated)
unfetch = {}
for r in (csv.DictReader(open(_up, encoding='utf-8-sig')) if os.path.exists(_up) else []):
    if r['Reason'].startswith('PR head not fetchable'): unfetch[r['Repo']] = unfetch.get(r['Repo'], 0) + 1
# 15 Nov re-check: PRs whose head commit is still available in fin-tcm are recoverable - they do not count as accepted
_hc = r'C:\kon-migration\pr-gaps\pr-head-commit-check.csv'
for r in (csv.DictReader(open(_hc, encoding='utf-8-sig')) if os.path.exists(_hc) else []):
    if r['HeadCommitExists'] == 'True': unfetch[r['Repo']] = unfetch.get(r['Repo'], 0) - 1
reimport = {r['Repo'] for r in csv.DictReader(open(r'C:\kon-migration\rules\reimport-62-20261112.csv', encoding='utf-8-sig'))} | {'ARC-almonde_Sept19'}
lfs = {'KON-kplus-front','RISK-cmr','FCGC-pricing-analytics','TO-treasury-installer','MAFTP-fpp-fusioncapital','MAFTP-fpp-vaas-che',
       'FCBO-fusion-detect-core','SFX-netcore-common','OPICS-programmers','FWK-utfinstaller','TAAS-tms'}
fallback = {'SPH-sophis': 'GitHub import failed twice - current repo kept, PRs recreated (GIT-007B)',
            'TCMRTMDM-rtmd': 'GitHub import failed - current repo kept, PRs recreated after GIT-007B'}
new8 = {'FNX-oxi-libs','git-playground','mcp-conformance','SUM-summit-JaaS-Pipelines'}
done7b = set()
for l in open(r'C:\kon-migration\pr-recreate\run.log', encoding='utf-8', errors='ignore'):
    m = re.match(r'\[2026-11-14 1[3-9][^\]]*\] (\S+) : import ', l)
    if m: done7b.add(m.group(1))
in7b = set(l.strip() for l in open(r'C:\kon-migration\pr-recreate\git-007b-repos-20261114.txt', encoding='utf-8-sig') if l.strip())
done62 = set()   # repos the API pass for the 62 has finished (log lines after 19:20 on 14 Nov)
_cur = None
for l in open(r'C:\kon-migration\pr-recreate\run.log', encoding='utf-8', errors='ignore'):
    m = re.match(r'\[2026-11-1[45] (\d\d):(\d\d)[^\]]*\] (\S+) : import ', l)
    if m and (m.group(1), m.group(2)) >= ('19', '20') or (m and l.startswith('[2026-11-15')):
        if _cur: done62.add(_cur)
        _cur = m.group(3)
    if 'temporary branches removed' in l or 'to do 0;' in l:
        if _cur: done62.add(_cur)
def i(x):
    try: return int(x)
    except: return 0
def prs(m): return i(m.get('PROpen')) + i(m.get('PRMerged')) + i(m.get('PRClosed')) if m else 0

rows = []
for repo in sorted(src, key=str.lower):
    s = src[repo]; t = tgt.get(repo, {}); c = cmp_.get(repo, {})
    route, note, cmp_name, pending = 'Migrated (GEI) + sync + PR recreate', '', repo, ''
    if repo in lfs:
        route = 'Large files -> LFS copy'
        copy = f'{repo}-pr2' if f'{repo}-pr2' in names else f'{repo}-pr'
        if f'{repo}-old' in names: note = 'copy swapped in'
        else: cmp_name, pending, note = copy, 'swap', f'PRs counted on {copy} (swap GIT-019D pending)'
        if repo == 'KON-kplus-front' and f'{repo}-old' not in names: note += '; -pr2 rebuild running'
    elif repo in fallback: route, note = 'Re-import failed -> fallback', fallback[repo]   # 15 Nov: PR pass finished - judged on counts now
    elif repo in reimport:
        # 14 Nov 19:15 (Gareth, option A): re-import copies NOT used (new commit IDs); originals kept, PRs via the API pass
        route, note = 'API PR pass (re-import rolled back)', 'original repo kept (commit IDs identical to fin-tcm); missing PRs recreated by the API pass started 19:20'
        if repo not in done62: pending = 'PR pass'
    elif repo in new8: route, note = 'New since migration (pushed 14 Nov)', 'git-playground: 5 PRs not carried' if repo == 'git-playground' else ''
    elif repo == 'msi-simple-springboot-blueprint':
        route, note = ('Locked import -> re-imported 15 Nov', 'locked repo kept as -old') if f'{repo}-old' in names else ('Locked (original import failed)', 'repo locked for migration - re-import needed')
    tc = cop.get(cmp_name) if cmp_name != repo else t
    found = (t.get('Found') == 'yes')
    # checks
    ps, pt = prs(s), prs(tc)
    lst = listable.get(repo)
    if not found: pr_st = 'MISSING'
    elif pt >= ps: pr_st = 'OK'
    elif lst and lst[1] >= lst[0]: pr_st = f'OK (all {lst[0]} PRs present when listed one by one; fin-tcm total {ps} counts {ps - lst[0]} PRs GitHub cannot list)'
    elif not pending and unfetch.get(repo, 0) >= ps - pt: pr_st = f'OK ({ps - pt} PR(s) could not be recreated: neither their PR reference nor their commits are available in fin-tcm - list in pr-gaps\\pr-head-commit-check.csv)'
    elif repo in in7b and repo not in done7b: pr_st = 'IN PROGRESS'
    elif pending: pr_st = 'IN PROGRESS'
    else: pr_st = f'GAP {ps - pt}'
    rs, rt = i(s.get('Releases')), i((tc or {}).get('Releases'))
    rel_st = 'OK' if rt >= rs else 'IN PROGRESS'   # GIT-007A (release copy) still to run
    db_st = 'OK' if not found or s.get('Default') == (tc or t).get('Default') else 'DIFF'
    ar_st = 'OK' if not found or s.get('Archived') == t.get('Archived') or f'{repo}-old' in names else 'DIFF'
    st = c.get('Status', '')
    if not found: code_st = 'MISSING'
    elif repo in new8 and st in ('NOT_IN_TARGET', ''): code_st = 'OK (pushed + verified 14 Nov 01:25)'
    elif st in ('IN_SYNC', 'IN_SYNC_REWRITTEN'): code_st = 'OK'
    elif repo in lfs: code_st = 'OK (LFS copy - new commit IDs by design)' if st else 'n/a'
    elif repo in lfs_rewritten: code_st = 'OK (file over 100 MB moved to LFS - rewritten branch by design)'
    elif st == 'OUT_OF_SYNC' and repo in diffs and all(k in kept or iss == 'EXTRA_IN_TARGET' for k, iss in diffs[repo]):
        code_st = f"OK (Teciem changes kept; Finastra version kept as fin-tcm-kept/* for {sum(1 for k, iss in diffs[repo] if k in kept)} ref(s))"
    elif route == 'Re-imported + swapped': code_st = 'CHECK (new commit IDs - re-import rewrote history; decision pending)' if st == 'OUT_OF_SYNC' else ('OK' if st == 'IN_SYNC' else 'n/a')
    elif route.startswith('Re-imported'): code_st = 'IN PROGRESS (copy: new commit IDs - decision pending)'
    elif st == 'OUT_OF_SYNC': code_st = f"CHECK (missing {c.get('MissingBranches') or 0}, behind/diverged {c.get('StaleBranches') or 0}, tags {i(c.get('MissingTags')) + i(c.get('DiffTags'))})"
    elif st == 'NOT_IN_TARGET': code_st = 'MISSING'
    else: code_st = st or 'n/a'
    checks = [pr_st, rel_st, db_st, ar_st, code_st]
    if any(x == 'MISSING' for x in checks): overall = 'FAIL'
    elif all(x.startswith('OK') for x in checks): overall = 'PASS'
    elif any(x.startswith(('GAP', 'DIFF', 'CHECK')) for x in checks): overall = 'CHECK'
    else: overall = 'IN PROGRESS'
    # access (14 Nov, Samar: PRs first, then size, teams, permissions)
    sa, ta = acc_s.get(repo, {}), acc_t.get(cmp_name, {})
    steams = dict(x.split(':', 1) for x in (sa.get('Teams') or '').split(';') if ':' in x)
    tteams = dict(x.split(':', 1) for x in (ta.get('Teams') or '').split(';') if ':' in x)
    miss = [k for k in steams if k not in tteams]; diffp = [k for k in steams if k in tteams and tteams[k] != steams[k]]
    if not found: tm_st = 'MISSING'
    elif cmp_name != repo and pending == 'swap': tm_st = 'IN PROGRESS (copied at swap)'
    elif not miss and not diffp: tm_st = 'OK'
    else: tm_st = 'CHECK (' + ', '.join(([f'missing {len(miss)}: ' + ','.join(miss[:4])] if miss else []) + ([f'permission differs {len(diffp)}: ' + ','.join(diffp[:3])] if diffp else [])) + ')'
    cs_, ct_ = i(sa.get('DirectCollaborators')), i(ta.get('DirectCollaborators'))
    tlog = {x.lower() for x in logins(ta.get('CollaboratorLogins'))}
    slog = [x for x in logins(sa.get('CollaboratorLogins')) if x != 'ghost']
    nomap = [x for x in slog if x.lower() not in login_map]
    cmiss = [login_map[x.lower()] for x in slog if x.lower() in login_map and login_map[x.lower()].lower() not in tlog]
    nheld = sum(1 for x in cmiss if (repo, x.lower()) in held)
    nro = sum(1 for x in cmiss if (repo, x.lower()) in roarch)
    cmiss = [x for x in cmiss if (repo, x.lower()) not in held and (repo, x.lower()) not in roarch]
    extra = '; '.join(p for p in [f'{nheld} admin held for owners' if nheld else '', f'{nro} not needed: repo read-only' if nro else '',
                                  f'{len(nomap)} without Teciem account' if nomap else ''] if p)
    if not found: co_st = 'MISSING'
    elif pending == 'swap' and cmp_name != repo: co_st = 'IN PROGRESS (copied at swap)'
    elif cmiss: co_st = f'GAP {len(cmiss)}: ' + ','.join(cmiss[:3]) + (f' (+{extra})' if extra else '')
    else: co_st = 'OK' + (f' ({extra})' if extra else '')
    if not tm_st.startswith('OK') and overall == 'PASS': overall = 'IN PROGRESS' if tm_st.startswith('IN PROGRESS') else 'CHECK'
    if co_st.startswith('GAP') and overall == 'PASS': overall = 'CHECK'
    mb = lambda m: round(i((m or {}).get('SizeKB')) / 1024)
    rows.append([repo, overall, ps, pt, pt - ps, pr_st, mb(s), mb(tc), len(steams), len(tteams), tm_st, cs_, ct_, co_st,
                 rs, rt, rel_st, s.get('Default'), (tc or t).get('Default', ''), db_st, code_st, s.get('Archived'), t.get('Archived', ''), ar_st,
                 route, cmp_name if found else '(not in tcm-pilot)', note])

H = ['Repo','Overall status','PRs (fin-tcm)','PRs (tcm-pilot)','PR difference','PRs',
     'Size MB (fin-tcm)','Size MB (tcm-pilot)','Teams (fin-tcm)','Teams (tcm-pilot)','Teams',
     'Direct collaborators (fin-tcm)','Direct collaborators (tcm-pilot)','Direct collaborators',
     'Releases (fin-tcm)','Releases (tcm-pilot)','Releases','Default branch (fin-tcm)','Default branch (tcm-pilot)','Default branch',
     'Code: branches + tags','Archived (fin-tcm)','Archived (tcm-pilot)','Archived state','Migration route','Compared with (tcm-pilot)','Notes']
STATUS_COLS = {1, 5, 10, 13, 16, 19, 20, 23}
PR_COLS = {2, 3, 4, 5}
# ---------------- xlsx (stdlib) ----------------
def col(n):
    s = ''
    n += 1
    while n: n, r = divmod(n - 1, 26); s = chr(65 + r) + s
    return s
def st_for(v):
    v = str(v)
    if v.startswith(('OK', 'PASS')): return 3
    if v.startswith('IN PROGRESS'): return 4
    if v.startswith(('GAP', 'DIFF', 'CHECK', 'MISSING', 'FAIL')): return 5
    return 2
def cell(ref, v, s, f=None):
    if f is not None: return f'<c r="{ref}" s="{s}"><f>{escape(f)}</f><v>{v}</v></c>'
    if isinstance(v, (int, float)) and not isinstance(v, bool): return f'<c r="{ref}" s="{s}"><v>{v}</v></c>'
    return f'<c r="{ref}" s="{s}" t="inlineStr"><is><t xml:space="preserve">{escape("" if v is None else str(v))}</t></is></c>'
def sheet(rows_xml, cols_xml, freeze=None, af=None, merges=None):
    pane = f'<sheetViews><sheetView workbookViewId="0"><pane ySplit="{freeze[0]}" xSplit="{freeze[1]}" topLeftCell="{col(freeze[1])}{freeze[0]+1}" activePane="bottomRight" state="frozen"/></sheetView></sheetViews>' if freeze else '<sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews>'
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            + pane + f'<cols>{cols_xml}</cols><sheetData>{"".join(rows_xml)}</sheetData>' + (f'<autoFilter ref="{af}"/>' if af else '')
            + (f'<mergeCells count="{len(merges)}">' + ''.join(f'<mergeCell ref="{m}"/>' for m in merges) + '</mergeCells>' if merges else '') + '</worksheet>')
# Repos sheet
rx = ['<row r="1" ht="42" customHeight="1">' + ''.join(cell(f'{col(j)}1', h, 11 if j in PR_COLS else 1) for j, h in enumerate(H)) + '</row>']
for n, r in enumerate(rows, start=2):
    rx.append(f'<row r="{n}">' + ''.join(cell(f'{col(j)}{n}', v, (st_for(v) if j in STATUS_COLS else (12 if j in PR_COLS else (7 if isinstance(v, int) else 2)))) for j, v in enumerate(r)) + '</row>')
last = len(rows) + 1
widths = [34, 13, 10, 10, 10, 13, 10, 10, 9, 9, 26, 12, 12, 14, 10, 10, 13, 15, 15, 11, 30, 10, 10, 11, 30, 28, 60]
repos_xml = sheet(rx, ''.join(f'<col min="{j+1}" max="{j+1}" width="{w}" customWidth="1"/>' for j, w in enumerate(widths)), freeze=(1, 2), af=f'A1:{col(len(H)-1)}{last}')
# Summary sheet (formulas with cached values so it shows without recalculation)
now = datetime.datetime.now().strftime('%a %d %b %Y %H:%M CET')
from collections import Counter
oc = Counter(r[1] for r in rows); rc = Counter(r[24] for r in rows)
sx = [f'<row r="1" ht="30" customHeight="1">{cell("A1", "GitHub migration validation - fin-tcm -> tcm-pilot", 8)}</row>',
      f'<row r="2">{cell("A2", f"As of {now}. One row per fin-tcm repository on the Repos sheet; source = fin-tcm (read-only since 13 Nov 17:03 CET), target = tcm-pilot.", 9)}</row>',
      f'<row r="3">{cell("A3", f"Code (branches/tags) column: {cmp_label}", 9)}</row>',
      f'<row r="5">{cell("A5", "Overall status", 1)}{cell("B5", "Repos", 1)}{cell("C5", "Meaning", 1)}</row>']
meaning = {'PASS': 'All checks match the source', 'IN PROGRESS': 'Gap explained by a step still running (PR pass, release copy, swap, rebuild)',
           'CHECK': 'Difference to look at (see the check columns and Notes)', 'FAIL': 'Repository not found in tcm-pilot'}
rr = 6
for k in ['PASS', 'IN PROGRESS', 'CHECK', 'FAIL']:
    sx.append(f'<row r="{rr}">{cell(f"A{rr}", k, st_for(k))}{cell(f"B{rr}", oc.get(k, 0), 7, f"COUNTIF(Repos!$B$2:$B${last},A{rr})")}{cell(f"C{rr}", meaning[k], 2)}</row>'); rr += 1
sx.append(f'<row r="{rr}">{cell(f"A{rr}", "Total", 10)}{cell(f"B{rr}", len(rows), 10, f"SUM(B6:B{rr-1})")}</row>'); rr += 2
sx.append(f'<row r="{rr}">{cell(f"A{rr}", "Migration route", 1)}{cell(f"B{rr}", "Repos", 1)}{cell(f"C{rr}", "PASS", 1)}{cell(f"D{rr}", "IN PROGRESS", 1)}{cell(f"E{rr}", "CHECK", 1)}</row>'); rr += 1
for k, v in sorted(rc.items(), key=lambda x: -x[1]):
    rk = [r for r in rows if r[24] == k]
    sx.append(f'<row r="{rr}">{cell(f"A{rr}", k, 2)}{cell(f"B{rr}", v, 7, f"COUNTIF(Repos!$Y$2:$Y${last},A{rr})")}'
              + ''.join(cell(f"{c}{rr}", sum(1 for r in rk if r[1] == s), 7, f'COUNTIFS(Repos!$Y$2:$Y${last},$A{rr},Repos!$B$2:$B${last},"{s}")') for c, s in [('C', 'PASS'), ('D', 'IN PROGRESS'), ('E', 'CHECK')]) + '</row>'); rr += 1
rr += 1
tot = lambda k: sum(r[k] for r in rows)
sx.append(f'<row r="{rr}">{cell(f"A{rr}", "Totals", 1)}{cell(f"B{rr}", "fin-tcm", 1)}{cell(f"C{rr}", "tcm-pilot", 1)}{cell(f"D{rr}", "Difference", 1)}</row>'); rr += 1
for lbl, a, b in [('Pull requests', 2, 3), ('Releases', 14, 15)]:
    sx.append(f'<row r="{rr}">{cell(f"A{rr}", lbl, 2)}{cell(f"B{rr}", tot(a), 7, f"SUM(Repos!${col(a)}$2:${col(a)}${last})")}{cell(f"C{rr}", tot(b), 7, f"SUM(Repos!${col(b)}$2:${col(b)}${last})")}{cell(f"D{rr}", tot(b) - tot(a), 7, f"C{rr}-B{rr}")}</row>'); rr += 1
summary_xml = sheet(sx, '<col min="1" max="1" width="40" customWidth="1"/><col min="2" max="5" width="14" customWidth="1"/><col min="3" max="3" width="70" customWidth="1"/>')
# Legend sheet
lg = [('Column', 'What is compared'), ('Migration route', 'How the repo reached tcm-pilot: GEI import + nightly/final sync + PR recreate; LFS copy (history rewritten for files > 100 MB, PRs kept); re-imported after the freeze and swapped in; fallback; new repo.'),
      ('Compared with', 'The tcm-pilot repo the target figures come from. Normally the same name; for copies not yet swapped in, the copy (-pr, -pr2, -ri).'),
      ('PRs', 'Total pull requests (open + merged + closed). PRs recreated through the API show "merged" as "closed" (GitHub limit), so totals are compared. OK = target >= source.'),
      ('Releases', 'Total releases. IN PROGRESS until the release copy (GIT-007A) has run.'),
      ('Default branch', 'Same default branch name on both sides.'), ('Archived state', 'Same archived flag (swapped-out -old repos are archived on purpose).'),
      ('Code: branches + tags', 'Every branch and tag at the same commit (refs compare). LFS copies have different commit IDs by design: checked against the rewritten history instead.'),
      ('Overall status', 'PASS / IN PROGRESS / CHECK / FAIL - see Summary.')]
lx = [f'<row r="{n}">' + cell(f'A{n}', a, 1 if n == 1 else 10) + cell(f'B{n}', b, 1 if n == 1 else 2) + '</row>' for n, (a, b) in enumerate(lg, start=1)]
legend_xml = sheet(lx, '<col min="1" max="1" width="26" customWidth="1"/><col min="2" max="2" width="120" customWidth="1"/>')
styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
  '<fonts count="5"><font><sz val="10"/><name val="Arial"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>'
  '<font><b/><sz val="16"/><color rgb="FF1F3864"/><name val="Arial"/></font><font><i/><sz val="10"/><color rgb="FF595959"/><name val="Arial"/></font><font><b/><sz val="10"/><name val="Arial"/></font></fonts>'
  '<fills count="8"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
  '<fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/></patternFill></fill>'
  '<fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/></patternFill></fill>'
  '<fill><patternFill patternType="solid"><fgColor rgb="FFC55A11"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFCE4D6"/></patternFill></fill></fills>'
  '<borders count="2"><border/><border><left style="thin"><color rgb="FFD9D9D9"/></left><right style="thin"><color rgb="FFD9D9D9"/></right><top style="thin"><color rgb="FFD9D9D9"/></top><bottom style="thin"><color rgb="FFD9D9D9"/></bottom></border></borders>'
  '<cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="13">'
  '<xf fontId="0" fillId="0" borderId="0"/>'
  '<xf fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
  '<xf fontId="0" fillId="0" borderId="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
  '<xf fontId="0" fillId="3" borderId="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
  '<xf fontId="0" fillId="4" borderId="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
  '<xf fontId="0" fillId="5" borderId="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
  '<xf fontId="0" fillId="0" borderId="0"/>'
  '<xf fontId="0" fillId="0" borderId="1" numFmtId="3" applyNumberFormat="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>'
  '<xf fontId="2" fillId="0" borderId="0" applyFont="1"/>'
  '<xf fontId="3" fillId="0" borderId="0" applyFont="1"/>'
  '<xf fontId="4" fillId="0" borderId="1" numFmtId="3" applyFont="1" applyBorder="1" applyNumberFormat="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
  '<xf fontId="1" fillId="6" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
  '<xf fontId="4" fillId="7" borderId="1" numFmtId="3" applyFont="1" applyFill="1" applyBorder="1" applyNumberFormat="1" applyAlignment="1"><alignment vertical="top"/></xf>'
  '</cellXfs></styleSheet>')
ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
  '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
  '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
  + ''.join(f'<Override PartName="/xl/worksheets/sheet{k}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for k in (1, 2, 3))
  + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>')
rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
  '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
  '<sheets><sheet name="Summary" sheetId="1" r:id="rId1"/><sheet name="Repos" sheetId="2" r:id="rId2"/><sheet name="Legend" sheetId="3" r:id="rId3"/></sheets>'
  f'<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="1" hidden="1">Repos!$A$1:${col(len(H)-1)}${last}</definedName></definedNames>'
  '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
wbrels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
  + ''.join(f'<Relationship Id="rId{k}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{k}.xml"/>' for k in (1, 2, 3))
  + '<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml', ct); z.writestr('_rels/.rels', rels); z.writestr('xl/workbook.xml', wb); z.writestr('xl/_rels/workbook.xml.rels', wbrels)
    z.writestr('xl/styles.xml', styles); z.writestr('xl/worksheets/sheet1.xml', summary_xml); z.writestr('xl/worksheets/sheet2.xml', repos_xml); z.writestr('xl/worksheets/sheet3.xml', legend_xml)
with open(os.path.splitext(out)[0] + '.csv', 'w', newline='', encoding='utf-8') as f:   # same rows, for the Smartsheet refresh
    w = csv.writer(f); w.writerow(H); w.writerows(rows)
print(f'{len(rows)} repos -> {out}'); print(dict(oc)); print(dict(rc))




