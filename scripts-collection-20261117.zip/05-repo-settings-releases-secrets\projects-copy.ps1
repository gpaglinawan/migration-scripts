param(
  [int[]]$Numbers,                       # source project numbers; default: all
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out = "C:\kon-migration\projects",
  [int]$PauseMs = 400,                   # between mutations (GitHub secondary rate limits)
  [switch]$Apply
)
# Copies org Projects (v2): project settings, custom fields (single-select options, iterations), Status options,
# linked repositories and teams, items (issues/PRs re-linked to the migrated ones by repo+number, draft issues
# recreated), every item's field values, archived state, closed/template state. Views and built-in workflows have
# no create API: they are exported to views-<n>.md for manual recreation. Idempotent: a project already created
# (recorded in project-map.json) is resumed, items already added are skipped.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcAuth = @{ Authorization = "Bearer $env:GH_SRC_PAT" }; $tgtAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT" }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "projects-copy.log"; $mapFile = Join-Path $Out "project-map.json"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Gql($auth, $query, $vars) {
  for ($a = 1; ; $a++) {
    try { $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $auth -Body (@{ query = $query; variables = $vars } | ConvertTo-Json -Depth 30 -Compress) -ContentType application/json }
    catch { if ($a -lt 5) { Start-Sleep (15 * $a); continue }; throw }
    if ($r.errors -and ($r.errors.type -contains 'RATE_LIMITED' -or ($r.errors.message -join ' ') -match 'secondary rate|abuse') -and $a -lt 6) { Start-Sleep (60 * $a); continue }
    return $r
  }
}
function Mut($query, $vars) { if (-not $Apply) { return $null }; Start-Sleep -Milliseconds $PauseMs; $r = Gql $tgtAuth $query $vars; if ($r.errors) { Log "    ERROR: $(($r.errors.message | Select-Object -First 2) -join '; ')" }; $r }

$map = @{}; if (Test-Path $mapFile) { (Get-Content $mapFile -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $map[$_.Name] = $_.Value } }
function SaveMap { $map | ConvertTo-Json | Set-Content $mapFile -Encoding utf8 }
$tgtOrgId = (Gql $tgtAuth 'query($o:String!){organization(login:$o){id}}' @{ o = $TgtOrg }).data.organization.id
$defaultFields = 'Title','Assignees','Status','Labels','Linked pull requests','Milestone','Repository','Reviewers','Parent issue','Sub-issues progress','Type','Tracks','Tracked by'

# source project list
$list = (Gql $srcAuth 'query($o:String!){organization(login:$o){projectsV2(first:100){nodes{number}}}}' @{ o = $SrcOrg }).data.organization.projectsV2.nodes | ForEach-Object number | Sort-Object
if ($Numbers) { $list = @($list | Where-Object { $_ -in $Numbers }) }
Log "=== projects copy $SrcOrg -> $TgtOrg : $($list.Count) projects, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="

$qProj = @'
query($o:String!,$n:Int!){organization(login:$o){projectV2(number:$n){id title closed public template shortDescription readme
 fields(first:50){nodes{__typename ... on ProjectV2FieldCommon{id name dataType}
   ... on ProjectV2SingleSelectField{options{name color description}}
   ... on ProjectV2IterationField{configuration{startDay duration iterations{title startDate duration} completedIterations{title startDate duration}}}}}
 repositories(first:50){nodes{name}} teams(first:50){nodes{slug}}
 views(first:30){nodes{number name layout filter
   fields(first:30){nodes{... on ProjectV2FieldCommon{name}}}
   groupByFields(first:5){nodes{... on ProjectV2FieldCommon{name}}} verticalGroupByFields(first:5){nodes{... on ProjectV2FieldCommon{name}}}
   sortByFields(first:5){nodes{direction field{... on ProjectV2FieldCommon{name}}}}}}
 workflows(first:20){nodes{name enabled}}}}}
'@
$qItems = @'
query($o:String!,$n:Int!,$c:String){organization(login:$o){projectV2(number:$n){items(first:50,after:$c){pageInfo{hasNextPage endCursor} nodes{isArchived type
 content{__typename ... on Issue{number repository{name}} ... on PullRequest{number repository{name}} ... on DraftIssue{title body}}
 fieldValues(first:30){nodes{__typename
   ... on ProjectV2ItemFieldTextValue{text field{... on ProjectV2FieldCommon{name}}}
   ... on ProjectV2ItemFieldNumberValue{number field{... on ProjectV2FieldCommon{name}}}
   ... on ProjectV2ItemFieldDateValue{date field{... on ProjectV2FieldCommon{name}}}
   ... on ProjectV2ItemFieldSingleSelectValue{name field{... on ProjectV2FieldCommon{name}}}
   ... on ProjectV2ItemFieldIterationValue{title field{... on ProjectV2FieldCommon{name}}}}}}}}}}
'@

foreach ($n in $list) {
  $p = (Gql $srcAuth $qProj @{ o = $SrcOrg; n = [int]$n }).data.organization.projectV2
  Log "--- #$n '$($p.title)' $(if($p.closed){'[closed]'}) $(if($p.template){'[template]'})"
  # views checklist (manual)
  $md = @("# Views to recreate for '$($p.title)' (source #$n)", "")
  foreach ($v in $p.views.nodes) {
    $md += "## $($v.name)  ($($v.layout -replace '_LAYOUT',''))"
    if ($v.filter) { $md += "- Filter: ``$($v.filter)``" }
    $md += "- Visible fields: $((@($v.fields.nodes | ForEach-Object name)) -join ', ')"
    if ($v.groupByFields.nodes) { $md += "- Group by: $((@($v.groupByFields.nodes | ForEach-Object name)) -join ', ')" }
    if ($v.verticalGroupByFields.nodes) { $md += "- Columns (board): $((@($v.verticalGroupByFields.nodes | ForEach-Object name)) -join ', ')" }
    if ($v.sortByFields.nodes) { $md += "- Sort: $((@($v.sortByFields.nodes | ForEach-Object { "$($_.field.name) $($_.direction)" })) -join ', ')" }
    $md += ""
  }
  $md += "## Built-in workflows (Settings > Workflows)"; foreach ($w in $p.workflows.nodes) { $md += "- $($w.name): $(if($w.enabled){'ON'}else{'off'})" }
  $md | Set-Content (Join-Path $Out "views-$n.md") -Encoding utf8

  # 1. project
  $key = "$n"; $tid = $map[$key]
  if (-not $tid) {
    if (-not $Apply) { Log "  would create project"; $tid = "plan" }
    else {
      $r = Mut 'mutation($i:CreateProjectV2Input!){createProjectV2(input:$i){projectV2{id number}}}' @{ i = @{ ownerId = $tgtOrgId; title = $p.title } }
      $tid = $r.data.createProjectV2.projectV2.id; if (-not $tid) { Log "  FAILED create"; continue }
      $map[$key] = $tid; SaveMap; Log "  created target project #$($r.data.createProjectV2.projectV2.number)"
      Mut 'mutation($i:UpdateProjectV2Input!){updateProjectV2(input:$i){projectV2{id}}}' @{ i = @{ projectId = $tid; shortDescription = "$($p.shortDescription)"; readme = "$($p.readme)"; public = [bool]$p.public } } | Out-Null
    }
  } else { Log "  resuming existing target project" }

  # 2. fields
  $tf = @{}
  if ($Apply) { foreach ($f in (Gql $tgtAuth 'query($id:ID!){node(id:$id){... on ProjectV2{fields(first:50){nodes{... on ProjectV2FieldCommon{id name dataType} ... on ProjectV2SingleSelectField{options{id name}} ... on ProjectV2IterationField{configuration{iterations{id title} completedIterations{id title}}}}}}}}' @{ id = $tid }).data.node.fields.nodes) { $tf[$f.name] = $f } }
  foreach ($f in $p.fields.nodes) {
    if (-not $f.name) { continue }
    $isDefault = $defaultFields -contains $f.name
    if ($f.dataType -eq 'SINGLE_SELECT') {
      $opts = @($f.options | ForEach-Object { @{ name = $_.name; color = $_.color; description = "$($_.description)" } })
      if ($tf[$f.name]) {
        $have = @($tf[$f.name].options | ForEach-Object name); $want = @($opts | ForEach-Object { $_.name })
        if (Compare-Object $have $want) { Log "  set options of '$($f.name)': $($want -join ', ')"; Mut 'mutation($i:UpdateProjectV2FieldInput!){updateProjectV2Field(input:$i){projectV2Field{... on ProjectV2SingleSelectField{id}}}}' @{ i = @{ fieldId = $tf[$f.name].id; singleSelectOptions = $opts } } | Out-Null }
      } elseif (-not $isDefault) { Log "  field '$($f.name)' (single select: $(@($opts).Count) options)"; Mut 'mutation($i:CreateProjectV2FieldInput!){createProjectV2Field(input:$i){projectV2Field{... on ProjectV2FieldCommon{id}}}}' @{ i = @{ projectId = $tid; dataType = 'SINGLE_SELECT'; name = $f.name; singleSelectOptions = $opts } } | Out-Null }
    } elseif ($f.dataType -eq 'ITERATION') {
      if (-not $tf[$f.name]) {
        $c = $f.configuration; $its = @(@($c.completedIterations) + @($c.iterations) | Where-Object { $_ } | Sort-Object startDate | ForEach-Object { @{ title = $_.title; startDate = $_.startDate; duration = $_.duration } })
        Log "  field '$($f.name)' (iteration: $($its.Count) iterations)"
        Mut 'mutation($i:CreateProjectV2FieldInput!){createProjectV2Field(input:$i){projectV2Field{... on ProjectV2FieldCommon{id}}}}' @{ i = @{ projectId = $tid; dataType = 'ITERATION'; name = $f.name; iterationConfiguration = @{ startDate = $(if ($its) { $its[0].startDate } else { (Get-Date).ToString('yyyy-MM-dd') }); duration = [int]$c.duration; iterations = $its } } } | Out-Null
      }
    } elseif ($f.dataType -in 'TEXT', 'NUMBER', 'DATE' -and -not $isDefault -and -not $tf[$f.name]) {
      Log "  field '$($f.name)' ($($f.dataType))"; Mut 'mutation($i:CreateProjectV2FieldInput!){createProjectV2Field(input:$i){projectV2Field{... on ProjectV2FieldCommon{id}}}}' @{ i = @{ projectId = $tid; dataType = $f.dataType; name = $f.name } } | Out-Null
    }
  }
  # refresh target field map after creation
  $tf = @{}
  if ($Apply) { foreach ($f in (Gql $tgtAuth 'query($id:ID!){node(id:$id){... on ProjectV2{fields(first:50){nodes{... on ProjectV2FieldCommon{id name dataType} ... on ProjectV2SingleSelectField{options{id name}} ... on ProjectV2IterationField{configuration{iterations{id title} completedIterations{id title}}}}}}}}' @{ id = $tid }).data.node.fields.nodes) { $tf[$f.name] = $f } }

  # 3. linked repositories and teams
  foreach ($rn in @($p.repositories.nodes | ForEach-Object name)) {
    $rid = (Gql $tgtAuth 'query($o:String!,$n:String!){repository(owner:$o,name:$n){id}}' @{ o = $TgtOrg; n = $rn }).data.repository.id
    if ($rid) { Log "  link repo $rn"; Mut 'mutation($i:LinkProjectV2ToRepositoryInput!){linkProjectV2ToRepository(input:$i){repository{id}}}' @{ i = @{ projectId = $tid; repositoryId = $rid } } | Out-Null } else { Log "  repo $rn not in target - not linked" }
  }
  foreach ($ts in @($p.teams.nodes | ForEach-Object slug)) {
    $teamId = (Gql $tgtAuth 'query($o:String!,$s:String!){organization(login:$o){team(slug:$s){id}}}' @{ o = $TgtOrg; s = $ts }).data.organization.team.id
    if ($teamId) { Log "  link team $ts"; Mut 'mutation($i:LinkProjectV2ToTeamInput!){linkProjectV2ToTeam(input:$i){team{id}}}' @{ i = @{ projectId = $tid; teamId = $teamId } } | Out-Null } else { Log "  team $ts not in target - not linked" }
  }

  # 4. items + field values
  $existing = @{}
  if ($Apply) {
    $cur = $null
    do { $page = (Gql $tgtAuth 'query($id:ID!,$c:String){node(id:$id){... on ProjectV2{items(first:100,after:$c){pageInfo{hasNextPage endCursor} nodes{content{__typename ... on Issue{number repository{name}} ... on PullRequest{number repository{name}} ... on DraftIssue{title}}}}}}}' @{ id = $tid; c = $cur }).data.node.items
         foreach ($it in $page.nodes) { $c = $it.content; if ($c.__typename -eq 'DraftIssue') { $existing["draft|$($c.title)"] = $true } elseif ($c) { $existing["$($c.repository.name)|$($c.number)"] = $true } }
         $cur = $page.pageInfo.endCursor } while ($page.pageInfo.hasNextPage)
  }
  $added = 0; $skipped = 0; $missing = 0; $cur = $null
  do {
    $page = (Gql $srcAuth $qItems @{ o = $SrcOrg; n = [int]$n; c = $cur }).data.organization.projectV2.items
    foreach ($it in $page.nodes) {
      $c = $it.content; $itemId = $null
      if (-not $c) { continue }
      if ($c.__typename -eq 'DraftIssue') {
        if ($existing["draft|$($c.title)"]) { $skipped++; continue }
        if (-not $Apply) { $added++; continue }
        $r = Mut 'mutation($i:AddProjectV2DraftIssueInput!){addProjectV2DraftIssue(input:$i){projectItem{id}}}' @{ i = @{ projectId = $tid; title = $c.title; body = "$($c.body)" } }
        $itemId = $r.data.addProjectV2DraftIssue.projectItem.id
      } else {
        $k = "$($c.repository.name)|$($c.number)"
        if ($existing[$k]) { $skipped++; continue }
        $kind = if ($c.__typename -eq 'Issue') { 'issue' } else { 'pullRequest' }
        $cid = (Gql $tgtAuth "query(`$o:String!,`$r:String!,`$n:Int!){repository(owner:`$o,name:`$r){$kind(number:`$n){id}}}" @{ o = $TgtOrg; r = $c.repository.name; n = [int]$c.number }).data.repository.$kind.id
        if (-not $cid) { $missing++; Add-Content (Join-Path $Out "missing-items-$n.txt") "$($c.__typename) $k" -Encoding utf8; continue }
        if (-not $Apply) { $added++; continue }
        $r = Mut 'mutation($i:AddProjectV2ItemByIdInput!){addProjectV2ItemById(input:$i){item{id}}}' @{ i = @{ projectId = $tid; contentId = $cid } }
        $itemId = $r.data.addProjectV2ItemById.item.id
      }
      if (-not $itemId) { continue }
      $added++
      foreach ($fv in $it.fieldValues.nodes) {
        $fname = $fv.field.name; if (-not $fname -or -not $tf[$fname] -or $fname -in 'Title', 'Assignees', 'Labels', 'Milestone', 'Repository', 'Reviewers', 'Linked pull requests') { continue }
        $val = $null
        switch ($fv.__typename) {
          'ProjectV2ItemFieldTextValue'         { $val = @{ text = $fv.text } }
          'ProjectV2ItemFieldNumberValue'       { $val = @{ number = [double]$fv.number } }
          'ProjectV2ItemFieldDateValue'         { $val = @{ date = $fv.date } }
          'ProjectV2ItemFieldSingleSelectValue' { $o = @($tf[$fname].options | Where-Object { $_.name -eq $fv.name })[0]; if ($o) { $val = @{ singleSelectOptionId = $o.id } } }
          'ProjectV2ItemFieldIterationValue'    { $ti = @(@($tf[$fname].configuration.iterations) + @($tf[$fname].configuration.completedIterations) | Where-Object { $_ -and $_.title -eq $fv.title })[0]; if ($ti) { $val = @{ iterationId = $ti.id } } }
        }
        if ($val) { Mut 'mutation($i:UpdateProjectV2ItemFieldValueInput!){updateProjectV2ItemFieldValue(input:$i){projectV2Item{id}}}' @{ i = @{ projectId = $tid; itemId = $itemId; fieldId = $tf[$fname].id; value = $val } } | Out-Null }
      }
      if ($it.isArchived) { Mut 'mutation($i:ArchiveProjectV2ItemInput!){archiveProjectV2Item(input:$i){item{id}}}' @{ i = @{ projectId = $tid; itemId = $itemId } } | Out-Null }
      if ($added % 50 -eq 0) { Log "  ...$added items" }
    }
    $cur = $page.pageInfo.endCursor
  } while ($page.pageInfo.hasNextPage)
  Log "  items: $(if($Apply){'added'}else{'would add'}) $added, already present $skipped, not found in target $missing"

  # 5. closed / template
  if ($Apply -and $p.closed) { Mut 'mutation($i:UpdateProjectV2Input!){updateProjectV2(input:$i){projectV2{id}}}' @{ i = @{ projectId = $tid; closed = $true } } | Out-Null; Log "  closed" }
  if ($Apply -and $p.template) { Mut 'mutation($i:MarkProjectV2AsTemplateInput!){markProjectV2AsTemplate(input:$i){projectV2{id}}}' @{ i = @{ projectId = $tid } } | Out-Null; Log "  marked as template" }
}
Log "=== done. Views/workflows to recreate by hand: $Out\views-<number>.md ==="
