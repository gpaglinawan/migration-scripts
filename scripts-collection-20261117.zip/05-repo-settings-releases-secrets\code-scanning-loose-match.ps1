param(
  [string[]]$Repos = @('SUM-summit', 'KON-kplus-front', 'FABCOM-regulatory', 'TO-pgz-reports', 'FCGC-pricing-analytics', 'OPICS-opics4plus', 'THIRD-idakdb', 'SPH-sophis', 'KON-kplus-back', 'RISK-fusion-risk', 'TCM-collateral', 'SUM-digital-reporting', 'TO-treasury-oauth-server', 'TO-user-session', 'MAFINT-kondor-report-execution'),
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out = "C:\kon-migration\code-scanning-loose-match-$(Get-Date -Format yyyyMMdd-HHmm)"
)
# PLAN ONLY (never writes). For source dismissed alerts with no exact target match (rule + path + start line),
# looks for an open target alert with the same rule + path + message, i.e. the same finding on a moved line.
# Each target alert is used at most once; the nearest line wins. Writes matches.csv and a summary.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "loose-match.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Paged($uri, $hdr) {
  $acc = New-Object System.Collections.ArrayList; $page = 1
  do { $n = 0; try { $r = Invoke-RestMethod "$uri$(if($uri -match '\?'){'&'}else{'?'})per_page=100&page=$page" -Headers $hdr; foreach ($x in $r) { if ($x) { [void]$acc.Add($x); $n++ } } } catch { break }; $page++ } while ($n -eq 100)
  $acc
}
function Msg($a) { ("$($a.most_recent_instance.message.text)" -replace '\s+', ' ').Trim() }

$rows = New-Object System.Collections.ArrayList
foreach ($r in $Repos) {
  $tgt = @(Paged "https://api.github.com/repos/$TgtOrg/$r/code-scanning/alerts?state=open" $tgtHdr)
  $src = @(Paged "https://api.github.com/repos/$SrcOrg/$r/code-scanning/alerts?state=dismissed" $srcHdr)
  $exact = @{}; $loose = @{}
  foreach ($ta in $tgt) {
    $l = $ta.most_recent_instance.location
    $exact["$($ta.rule.id)|$($l.path)|$($l.start_line)"] = $true
    $k = "$($ta.rule.id)|$($l.path)|$(Msg $ta)"
    if (-not $loose[$k]) { $loose[$k] = New-Object System.Collections.ArrayList }
    [void]$loose[$k].Add($ta)
  }
  $used = @{}; $m = 0; $none = 0; $pathOnly = 0
  foreach ($sa in $src) {
    $l = $sa.most_recent_instance.location
    if ($exact["$($sa.rule.id)|$($l.path)|$($l.start_line)"]) { continue }   # handled by the exact pass
    $cands = @($loose["$($sa.rule.id)|$($l.path)|$(Msg $sa)"] | Where-Object { $_ -and -not $used[$_.number] })
    if (-not $cands.Count) {
      $samePath = @($tgt | Where-Object { $_.rule.id -eq $sa.rule.id -and $_.most_recent_instance.location.path -eq $l.path }).Count
      if ($samePath) { $pathOnly++ } else { $none++ }
      continue
    }
    $best = $cands | Sort-Object { [Math]::Abs($_.most_recent_instance.location.start_line - $l.start_line) } | Select-Object -First 1
    $used[$best.number] = $true; $m++
    [void]$rows.Add([pscustomobject]@{ Repo = $r; SrcAlert = $sa.number; TgtAlert = $best.number; Rule = $sa.rule.id; Path = $l.path
      SrcLine = $l.start_line; TgtLine = $best.most_recent_instance.location.start_line; Reason = $sa.dismissed_reason; DismissedBy = $sa.dismissed_by.login })
  }
  Log "$r : loose match $m | same rule+path but different message $pathOnly | nothing similar $none"
}
$rows | Export-Csv (Join-Path $Out "matches.csv") -NoTypeInformation -Encoding utf8
Log "=== total loose matches: $($rows.Count) (written to matches.csv) ==="
