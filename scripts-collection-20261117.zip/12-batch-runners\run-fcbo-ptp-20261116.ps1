﻿# 16 Nov 2026 (DEF-114; Gareth: "1 and 2"). PR-preserving copies <repo>-pr2 with unchanged commit IDs, 3 at a time. Nothing live is touched.
$list = Get-Content C:\kon-migration\pr-preload\fcbo-ptp-20261116.txt; $log = 'C:\kon-migration\pr-preload\fcbo-ptp-20261116.log'
$running = @()
foreach ($r in $list) {
  while (@($running | Where-Object { -not $_.HasExited }).Count -ge 3) { Start-Sleep 20 }
  $w = "C:\kon-migration\pr-preload\$r-pr2-20261116"; New-Item -ItemType Directory -Force $w | Out-Null
  "[$(Get-Date -Format 'HH:mm:ss')] start $r" | Add-Content $log -Encoding utf8
  $running += Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -Command `"& C:\kon-migration\scripts\pr-preload\pr-preload.ps1 -Repo $r -TargetName $r-pr2 -KeepCommitIds -Work $w *> $w-console.out`"" -PassThru -WindowStyle Hidden
}
$running | ForEach-Object { $_.WaitForExit() }
foreach ($r in $list) { $l = Get-Content "C:\kon-migration\pr-preload\$r-pr2-20261116\run.log" -EA SilentlyContinue; "[$(Get-Date -Format 'HH:mm:ss')] $r : $(($l | Select-String 'PRs identical|STOP:|import SUCCEEDED|import FAILED' | ForEach-Object { $_.Line.Substring(22) }) -join ' | ')" | Add-Content $log -Encoding utf8 }
"[$(Get-Date -Format 'HH:mm:ss')] === ALL DONE ===" | Add-Content $log -Encoding utf8
