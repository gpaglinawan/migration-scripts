# 14 Nov 2026 (Gareth: "post"). DEF-225 comment (status unchanged: depends on Teciem IT); DEF-226 comment + Status -> Ready for Retest.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-225' = 'Root cause: the 7 users (CorneliaElena-Popa, gee-way-wong, DoinitaFlorentina-Cioplea, ioanaandra-andronic, iulianamadalina-petre, Cristina-Robu, jhing-doctor) have no Teciem GitHub account. Teciem GitHub accounts are provisioned from Teciem Entra ID and these users are not in it (checked 14 Nov: not org members, no _tciem account). Action: Teciem IT (Vlad Negrea) to confirm whether they are Teciem staff and provision them; once their accounts exist, the migration team adds them to the same teams as in fin-tcm (sum_pr-approvers, sum_techops, sumqa_r, summitqa_read, summitqa_devwrite, sum_acct, sum_w, sum_r). Dependency: Teciem IT.'
  'DEF-226' = 'Root cause: in fin-tcm these 4 teams were synced from Finastra Entra groups (SG_GHEC-SUM_PR-approvers, _CI-admin, _R, _W); in tcm-pilot their members were copied as a static list, not linked to any group, so group ownership did not carry over. Fixed 14 Nov: mihai-cilidariu_tciem is now team maintainer of sum_pr-approvers, sum_ci-admin, sum_r and sum_w and can add/remove members directly in GitHub (note: GitHub requires maintainers to be team members, so he is now also a member of these teams). Long-term (hypercare): Teciem Entra equivalents of these groups with team sync, to be agreed with Teciem IT. Ready for retest.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
if ($DryRun) { 'dry run: would set DEF-226 Status to Ready for Retest'; return }
$sid = '3761521504348036'
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$hd = @{ Authorization = "Bearer $tok" }
$sh = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sid" -Headers $hd
$cid = @{}; $sh.columns | ForEach-Object { $cid[$_.title] = $_.id }
$opts = ($sh.columns | Where-Object title -eq 'Status').options
if ($opts -and 'Ready for Retest' -notin $opts) { throw "Status option 'Ready for Retest' not found: $($opts -join ', ')" }
$row = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $cid['Defect ID']).value -eq 'DEF-226' }
$body = ConvertTo-Json -Depth 5 @(@{ id = $row.id; cells = @(@{ columnId = $cid['Status']; value = 'Ready for Retest' }) })
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sid/rows" -Headers $hd -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
"DEF-226 status now: $(($res.result[0].cells | Where-Object columnId -eq $cid['Status']).value)"
