# Read-only status check for open defects that can be verified by script (fin-tcm vs tcm-pilot).
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = "Bearer $env:GH_SRC_PAT" }; $ht = @{ Authorization = "Bearer $env:GH_TGT_PAT" }
function Api($h, $u) { try { Invoke-RestMethod "https://api.github.com/$u" -Headers $h } catch { $null } }
function Refs($org, $repo, $tok) {
  $env:GIT_TERMINAL_PROMPT = "0"; $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
  $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$tok"))
  $m = @{}; git ls-remote --heads --tags "https://github.com/$org/$repo.git" 2>$null | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notlike '*^{}') { $m[$p[1]] = $p[0] } }
  $env:GIT_CONFIG_COUNT = "0"; $m
}
function Cmp($repo) {
  $s = Refs 'fin-tcm' $repo $env:GH_SRC_PAT; $t = Refs 'tcm-pilot' $repo $env:GH_TGT_PAT
  $miss = @($s.Keys | ? { -not $t.ContainsKey($_) }); $diff = @($s.Keys | ? { $t.ContainsKey($_) -and $t[$_] -ne $s[$_] }); $extra = @($t.Keys | ? { -not $s.ContainsKey($_) })
  $hd = (Api $hs "repos/fin-tcm/$repo").default_branch; $hdt = (Api $ht "repos/tcm-pilot/$repo").default_branch
  "{0,-34} refs {1,5}/{2,-5} missing {3,-4} different {4,-4} extra {5,-4} default {6}{7}" -f $repo, $t.Count, $s.Count, $miss.Count, $diff.Count, $extra.Count, $hd, $(if ($hd -ne $hdt) { " != $hdt" } else { "" })
  foreach ($x in ($diff | Select-Object -First 3)) { "      different: $x" }; foreach ($x in ($miss | Select-Object -First 3)) { "      missing: $x" }; foreach ($x in ($extra | Select-Object -First 3)) { "      extra: $x" }
}
"=== DEF-010 / 060 / 067 / 074 / 083-086 / 089 / 104 / 105: refs and default branch, fin-tcm vs tcm-pilot ==="
'ARC-almonde','THIRDEXT-grpc','RISK-fusion-risk','RISK-fr-cmr-tests','RISK-fr-limit-test','RISK-fr_qa','MAFTP-csm','MAFTP-krecord','RISK-fusionrisk-installer',
'RISK-fusionrisk-integration-api','FRCP-pricing-engine-fusionrisk','RISK-cmr','SOLINT-fusion-risk-packs','FABCOM-regulatory','FCGC-pricing-analytics',
'KON-doc-kondor-archive','KON-kondor-enablement','TO-treasury-installer','KON-kplus-back' | ForEach-Object { Cmp $_ }
"=== DEF-105: RISK-fusion-risk feature/MGR-42624 ==="
"fin-tcm: $(if (Api $hs 'repos/fin-tcm/RISK-fusion-risk/branches/feature%2FMGR-42624') {'exists'} else {'gone'})   tcm-pilot: $(if (Api $ht 'repos/tcm-pilot/RISK-fusion-risk/branches/feature%2FMGR-42624') {'exists'} else {'gone'})"
"=== DEF-110: FWK-utfinstaller PRs ==="
foreach ($x in @(@('fin-tcm', $hs), @('tcm-pilot', $ht))) { $p = @(Api $x[1] "repos/$($x[0])/FWK-utfinstaller/pulls?state=all&per_page=100"); "$($x[0]): $($p.Count) PRs: $(($p.number | Sort-Object) -join ',')" }
"=== DEF-062: FCBO teams, service-account members ==="
foreach ($x in @(@('fin-tcm', $hs), @('tcm-pilot', $ht))) {
  $teams = @(Api $x[1] "orgs/$($x[0])/teams?per_page=100&page=1") + @(Api $x[1] "orgs/$($x[0])/teams?per_page=100&page=2") + @(Api $x[1] "orgs/$($x[0])/teams?per_page=100&page=3") + @(Api $x[1] "orgs/$($x[0])/teams?per_page=100&page=4") + @(Api $x[1] "orgs/$($x[0])/teams?per_page=100&page=5")
  foreach ($tm in $teams | ? { $_.slug -like 'fcbo*' }) { $svc = @(Api $x[1] "orgs/$($x[0])/teams/$($tm.slug)/members?per_page=100" | ? { $_.login -match '^(svc|SVC)' }).login; if ($svc) { "$($x[0]) $($tm.slug): $($svc -join ', ')" } }
}
"=== DEF-041: SUM_R external (Entra) group link ==="
foreach ($s in 'sum_r') { "tcm-pilot $s external groups: $((Api $ht "orgs/tcm-pilot/teams/$s/external-groups").groups.group_name -join ', ')" }
