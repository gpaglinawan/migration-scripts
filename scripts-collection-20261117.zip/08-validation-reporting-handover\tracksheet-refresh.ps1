# 14 Nov 2026 - hourly refresh of the GitHub validation tracksheet (Smartsheet 7889214613180292 + Excel copy) until the
# GitHub Go/No-Go. Re-reads PR/release/size/teams/collaborators for both orgs (read-only, ~10-15 min); the code column
# uses the newest refs compare (GIT-009 at C:\kon-migration\refs\git009-*).
$ErrorActionPreference = 'Continue'
$d = 'C:\kon-migration\tracksheet'; $py = 'C:\kon-migration\tools\python\python.exe'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT" }
$names = @(); $p = 1; do { $page = @(Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/repos?per_page=100&page=$p&type=all" -Headers $gh | ForEach-Object { $_ }); $names += $page.name; $p++ } while ($page.Count -eq 100)
$names | Set-Content "$d\tcm-pilot-names.txt" -Encoding utf8
@($names | Where-Object { $_ -match '-(ri|pr2|pr)$' }) | Set-Content "$d\copies.txt" -Encoding utf8
(Get-Content "$d\copies.txt") + (Get-Content "$d\repos.txt") | Set-Content "$d\repos-and-copies.txt" -Encoding utf8
$jobs = @(
  (Start-Process $py -ArgumentList "-I C:\kon-migration\scripts\repo-metrics.py fin-tcm $d\repos.txt $d\metrics-fin-tcm.csv" -PassThru -WindowStyle Hidden),
  (Start-Process $py -ArgumentList "-I C:\kon-migration\scripts\repo-metrics.py tcm-pilot $d\repos.txt $d\metrics-tcm-pilot.csv" -PassThru -WindowStyle Hidden),
  (Start-Process $py -ArgumentList "-I C:\kon-migration\scripts\repo-metrics.py tcm-pilot $d\copies.txt $d\metrics-copies.csv" -PassThru -WindowStyle Hidden),
  (Start-Process $py -ArgumentList "-I C:\kon-migration\scripts\repo-access.py fin-tcm $d\repos.txt $d\access-fin-tcm.csv" -PassThru -WindowStyle Hidden),
  (Start-Process $py -ArgumentList "-I C:\kon-migration\scripts\repo-access.py tcm-pilot $d\repos-and-copies.txt $d\access-tcm-pilot.csv" -PassThru -WindowStyle Hidden))
$jobs | Wait-Process -Timeout 2400
$cmp = Get-ChildItem C:\kon-migration\refs -Directory -Filter 'git009-*' | Where-Object { Test-Path "$($_.FullName)\compare-summary.csv" } | Sort-Object Name | Select-Object -Last 1   # skip a compare still running
$label = "refs compare $($cmp.Name) (read $((Get-Item "$($cmp.FullName)\compare-summary.csv").LastWriteTime.ToString('dd MMM HH:mm')) CET)"
$out = "$d\GitHub-migration-tracksheet-latest.xlsx"
& $py -I C:\kon-migration\scripts\build-tracksheet.py $out "$($cmp.FullName)\compare-summary.csv" $label | Select-Object -First 2
& C:\kon-migration\scripts\tracksheet-smartsheet.ps1 -Csv ($out -replace '\.xlsx$', '.csv') -SheetId 7889214613180292 | Select-Object -Last 1
"$(Get-Date -Format 'yyyy-MM-dd HH:mm') tracksheet refreshed (Smartsheet + $out)" | Add-Content C:\kon-migration\nightly\cutover-20261113.log
