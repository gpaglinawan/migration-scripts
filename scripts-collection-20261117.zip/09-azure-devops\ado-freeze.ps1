# 13 Nov 2026 (Gareth, after Samar asked us to freeze Azure DevOps). Makes the Git repos of the in-scope
# TreasuryCapitalMarkets projects read-only by adding Deny entries; it never removes or lowers anything.
#   Denied: Contribute (4), Force push (8), Create branch (16), Create tag (32), Manage notes (64),
#           Contribute to pull requests (16384)  -> mask 16508. Read access is untouched.
# Because an explicit Allow on a repo or branch beats a Deny inherited from the project, the Deny is added at
# every place (project, repo, branch) where some identity has an Allow on any of these bits, for that identity;
# identities allowed org-wide (token repoV2) get the Deny at each project.
# Before any change the full permission tree is saved; -Rollback <backup dir> restores each touched entry exactly.
# Usage: .\ado-freeze.ps1                 (dry run)
#        .\ado-freeze.ps1 -Apply
#        .\ado-freeze.ps1 -Rollback C:\kon-migration\ado-freeze\<stamp>
param([switch]$Apply, [string]$Rollback, [string[]]$Projects,
      [string[]]$OutOfScope = @('Test - OE', 'TreasuryKondor', 'TaskFactory'),
      [string]$Root = 'C:\kon-migration\ado-freeze')
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_SOURCE_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_SOURCE_PAT")) }
$o = 'https://dev.azure.com/TreasuryCapitalMarkets'
$ns = '2e9eb7ed-3c0a-47d4-87c1-0ffdd275fd87'   # Git Repositories
$mask = 4 + 8 + 16 + 32 + 64 + 16384

function Set-Ace($token, $descriptor, $allow, $deny, [bool]$merge) {
  $body = @{ token = $token; merge = $merge; accessControlEntries = @(@{ descriptor = $descriptor; allow = $allow; deny = $deny; extendedInfo = @{} }) } | ConvertTo-Json -Depth 5
  $null = Invoke-RestMethod -Method Post "$o/_apis/accesscontrolentries/$ns`?api-version=7.1" -Headers $hs -ContentType 'application/json' -Body $body
}

if ($Rollback) {
  $touched = Import-Csv (Join-Path $Rollback 'touched.csv')
  foreach ($t in $touched) {
    try {
      if ($t.HadAce -eq 'True') { Set-Ace $t.Token $t.Descriptor ([int]$t.OrigAllow) ([int]$t.OrigDeny) $false; $res = 'restored' }
      else { $null = Invoke-RestMethod -Method Delete "$o/_apis/accesscontrolentries/$ns`?token=$([uri]::EscapeDataString($t.Token))&descriptors=$([uri]::EscapeDataString($t.Descriptor))&api-version=7.1" -Headers $hs; $res = 'removed (had none)' }
    } catch { $res = "FAILED: $($_.Exception.Message)" }
    "{0}  {1}  {2}" -f $res, $t.Project, $t.Token
  }
  return
}

$stamp = Get-Date -Format yyyyMMdd-HHmm
$dir = Join-Path $Root $stamp; New-Item -ItemType Directory -Force $dir | Out-Null
$projs = @((Invoke-RestMethod "$o/_apis/projects?api-version=7.1&`$top=500" -Headers $hs).value | Where-Object { $_.name -notin $OutOfScope })
if ($Projects) { $projs = @($projs | Where-Object { $_.name -in $Projects }) }
$rootAcl = @((Invoke-RestMethod "$o/_apis/accesscontrollists/$ns`?token=repoV2&recurse=false&api-version=7.1" -Headers $hs).value)
$rootAcl | ConvertTo-Json -Depth 8 | Out-File "$dir\acl-root.json" -Encoding utf8
$orgWide = @($rootAcl | ForEach-Object { $_.acesDictionary.PSObject.Properties.Value } | Where-Object { $_.allow -band $mask })

$plan = foreach ($p in $projs) {
  $canManage = (Invoke-RestMethod "$o/_apis/permissions/$ns/8192?tokens=repoV2/$($p.id)&api-version=7.1" -Headers $hs).value[0]
  $acls = @((Invoke-RestMethod "$o/_apis/accesscontrollists/$ns`?token=repoV2/$($p.id)&recurse=true&api-version=7.1" -Headers $hs).value)
  $acls | ConvertTo-Json -Depth 8 | Out-File "$dir\acl-$($p.name -replace '[^A-Za-z0-9_-]', '_').json" -Encoding utf8
  $byToken = @{}; foreach ($a in $acls) { $byToken[$a.token] = $a.acesDictionary }
  $want = @{}   # "token|descriptor" -> $true
  # identities allowed above the level we work at (org-wide, and project-wide when we can only manage single repos)
  $above = @($orgWide)
  if ($canManage) { $tops = @("repoV2/$($p.id)") }
  else {
    # 13 Nov: no right at project level (Treasury) - freeze each repo we can manage, at repo level
    $above += @(($acls | Where-Object token -eq "repoV2/$($p.id)").acesDictionary.PSObject.Properties.Value | Where-Object { $_.allow -band $mask })
    $repos = @((Invoke-RestMethod "$o/$([uri]::EscapeDataString($p.name))/_apis/git/repositories?api-version=7.1" -Headers $hs).value)
    $tops = @()
    foreach ($r in $repos) {
      $tk = "repoV2/$($p.id)/$($r.id)"
      if ((Invoke-RestMethod "$o/_apis/permissions/$ns/8192?tokens=$tk&api-version=7.1" -Headers $hs).value[0]) { $tops += $tk }
      else { [pscustomobject]@{ Project = $p.name; Token = $tk; Descriptor = ''; HadAce = ''; OrigAllow = ''; OrigDeny = ''; Action = "SKIPPED: repo $($r.name) - no permission, Finastra ALM must freeze it" } }
    }
  }
  foreach ($a in $acls) { if (-not ($tops | Where-Object { $a.token -eq $_ -or $a.token.StartsWith("$_/") })) { continue }
    foreach ($e in $a.acesDictionary.PSObject.Properties.Value) { if ($e.allow -band $mask) { $want["$($a.token)|$($e.descriptor)"] = $true } } }
  foreach ($t in $tops) { foreach ($e in $above) { $want["$t|$($e.descriptor)"] = $true } }
  foreach ($k in $want.Keys) {
    $token, $desc = $k -split '\|', 2
    $cur = if ($byToken[$token]) { $byToken[$token].PSObject.Properties[$desc].Value } else { $null }
    if ($cur -and (($cur.deny -band $mask) -eq $mask)) { continue }
    [pscustomobject]@{ Project = $p.name; Token = $token; Descriptor = $desc; HadAce = [bool]$cur; OrigAllow = [int]$cur.allow; OrigDeny = [int]$cur.deny; Action = if ($Apply) { 'DENY' } else { 'would deny' } }
  }
}
$todo = @($plan | Where-Object { $_.Descriptor })
if ($Apply) {
  $todo | Export-Csv "$dir\touched.csv" -NoTypeInformation -Encoding utf8   # written BEFORE changing anything, so rollback is always possible
  foreach ($t in $todo) { try { Set-Ace $t.Token $t.Descriptor 0 $mask $true } catch { $t.Action = "FAILED: $($_.Exception.Message)" } }
}
$plan | Export-Csv "$dir\plan.csv" -NoTypeInformation -Encoding utf8
$plan | Group-Object Project | ForEach-Object { "{0,-20} entries: {1,4}   {2}" -f $_.Name, @($_.Group | Where-Object Descriptor).Count, (($_.Group.Action | Sort-Object -Unique) -join '; ') }
if ($Apply) {
  # check with my own account: Contribute must now be denied wherever I had it
  foreach ($p in $projs) { $c = (Invoke-RestMethod "$o/_apis/permissions/$ns/4?tokens=repoV2/$($p.id)&api-version=7.1" -Headers $hs).value[0]; "{0,-20} my Contribute now: {1}" -f $p.name, $c }
  "rollback: .\ado-freeze.ps1 -Rollback $dir"
}
"backup and plan: $dir"
