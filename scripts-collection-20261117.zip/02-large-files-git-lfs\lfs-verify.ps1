param(
  [Parameter(Mandatory)][string]$Orig,   # original bare clone (untouched)
  [Parameter(Mandatory)][string]$Copy,   # rewritten copy
  [Parameter(Mandatory)][string]$Out,
  [long]$ThresholdBytes = 100MB,
  [string[]]$PathRename = @()   # same 'old/:new/' pairs given to lfs-rewrite; a delete+add with identical content across a pair is expected
)
# Verifies an LFS rewrite lost nothing. Read-only on both repos. Exit code = number of failed checks.
#  1. same ref names before/after
#  2. every original blob > threshold exists in the copy's LFS store with matching sha256 and size
#  3. for every ref tip, every file differing between original and rewritten tree is an original blob > threshold
#     that became an LFS pointer for exactly that content (no other file changed, added or removed)
#  4. no blob > threshold remains reachable in the rewritten history
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "verify.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
$fail = 0
$lfsDir = Join-Path $Copy "lfs\objects"
Log "=== verify $Copy against $Orig ==="

# 1. refs
$origRefs = @{}; git -C $Orig for-each-ref --format="%(refname) %(objectname)" | ForEach-Object { $p = $_.Split(' '); $origRefs[$p[0]] = $p[1] }
$copyRefs = @{}; git -C $Copy for-each-ref --format="%(refname) %(objectname)" | ForEach-Object { $p = $_.Split(' '); $copyRefs[$p[0]] = $p[1] }
$missing = @($origRefs.Keys | Where-Object { -not $copyRefs.ContainsKey($_) }); $extra = @($copyRefs.Keys | Where-Object { -not $origRefs.ContainsKey($_) })
Log "1. refs: original=$($origRefs.Count) rewritten=$($copyRefs.Count) missing=$($missing.Count) extra=$($extra.Count)"
if ($missing.Count -or $extra.Count) { $fail++; $missing + $extra | Out-File (Join-Path $Out "verify-ref-mismatch.txt") -Encoding utf8 }

# blob sizes of the original (all objects) -> big blobs
$sizes = Join-Path $Out "orig-objects.txt"
cmd /c "git -C `"$Orig`" cat-file --batch-all-objects --batch-check=""%(objecttype) %(objectname) %(objectsize)"" > `"$sizes`""
$big = @{}; $sr = [IO.File]::OpenText($sizes)
while (($l = $sr.ReadLine()) -ne $null) { $p = $l.Split(' '); if ($p[0] -eq 'blob' -and [long]$p[2] -gt $ThresholdBytes) { $big[$p[1]] = [long]$p[2] } }
$sr.Close()

# 2. big blobs present in LFS with matching sha256
$tmp = Join-Path $Out "blob.tmp"; $sha256Of = @{}; $bad2 = @()
foreach ($b in $big.Keys) {
  cmd /c "git -C `"$Orig`" cat-file blob $b > `"$tmp`""
  $h = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower(); $sha256Of[$b] = $h
  $obj = Join-Path $lfsDir "$($h.Substring(0,2))\$($h.Substring(2,2))\$h"
  if (-not ((Test-Path $obj) -and (Get-Item $obj).Length -eq $big[$b])) { $bad2 += "$b sha256=$h" }
}
Remove-Item $tmp -ErrorAction SilentlyContinue
Log "2. large blobs preserved in LFS (sha256 + size): $($big.Count - $bad2.Count) of $($big.Count)"
if ($bad2.Count) { $fail++; $bad2 | Out-File (Join-Path $Out "verify-lfs-missing.txt") -Encoding utf8 }

# 3. ref tips: only big-blob -> matching-pointer changes. The copy holds every original object, so diff in one repo.
$pointerOk = @{}   # cache "oldblob newblob" -> bool
function Test-Pointer($oldBlob, $newBlob) {
  $k = "$oldBlob $newBlob"; if ($pointerOk.ContainsKey($k)) { return $pointerOk[$k] }
  $ok = $false
  if ($big.ContainsKey($oldBlob)) {
    $txt = (git -C $Copy cat-file blob $newBlob) -join "`n"
    $ok = $txt -match "oid sha256:$($sha256Of[$oldBlob])" -and $txt -match "size $($big[$oldBlob])"
  }
  $pointerOk[$k] = $ok; $ok
}
$bad3 = New-Object System.Collections.ArrayList; $i = 0; $changedTips = 0
foreach ($ref in $origRefs.Keys) {
  $i++; if ($i % 2000 -eq 0) { Log "   ...$i/$($origRefs.Count) refs compared" }
  if (-not $copyRefs.ContainsKey($ref) -or $origRefs[$ref] -eq $copyRefs[$ref]) { continue }
  $changedTips++
  $dels = @{}; $adds = @{}
  foreach ($d in @(git -C $Copy diff-tree -r --no-renames "$($origRefs[$ref])^{tree}" "$($copyRefs[$ref])^{tree}" 2>$null)) {
    # :oldmode newmode oldsha newsha status<TAB>path
    if ($d -notmatch '^:\d+ \d+ ([0-9a-f]{40}) ([0-9a-f]{40}) (\w)\t(.*)$') { continue }
    $oldB = $Matches[1]; $newB = $Matches[2]; $st = $Matches[3]; $path = $Matches[4]
    $renamed = $false
    foreach ($pr in $PathRename) {
      $from, $to = $pr -split ':', 2
      if ($st -eq 'D' -and $path.StartsWith($from)) { $dels[$path.Substring($from.Length)] = $oldB; $renamed = $true }
      if ($st -eq 'A' -and $path.StartsWith($to))   { $adds[$path.Substring($to.Length)] = $newB; $renamed = $true }
    }
    if ($renamed) { continue }
    if ($st -ne 'M' -or -not (Test-Pointer $oldB $newB)) { [void]$bad3.Add("$ref`t$st`t$path") }
  }
  # every renamed file must reappear under the new prefix with identical content (or as its LFS pointer)
  foreach ($k in $dels.Keys) { if (-not $adds.ContainsKey($k) -or ($adds[$k] -ne $dels[$k] -and -not (Test-Pointer $dels[$k] $adds[$k]))) { [void]$bad3.Add("$ref`tRENAME-LOST`t$k") } }
  foreach ($k in $adds.Keys) { if (-not $dels.ContainsKey($k)) { [void]$bad3.Add("$ref`tRENAME-EXTRA`t$k") } }
}
Log "3. ref tips changed by rewrite: $changedTips; unexpected file differences: $($bad3.Count)"
if ($bad3.Count) { $fail++; $bad3 | Out-File (Join-Path $Out "verify-content-diff.txt") -Encoding utf8 }

# 4. nothing above threshold reachable in rewritten history
$after = Join-Path $Out "after-sizes.txt"
cmd /c "git -C `"$Copy`" rev-list --objects --all | git -C `"$Copy`" cat-file --batch-check=""%(objecttype) %(objectsize)"" > `"$after`""
$tooBig = 0; $sr = [IO.File]::OpenText($after); while (($l = $sr.ReadLine()) -ne $null) { $p = $l.Split(' '); if ($p[0] -eq 'blob' -and [long]$p[1] -gt $ThresholdBytes) { $tooBig++ } }; $sr.Close()
Log "4. blobs > threshold reachable after rewrite: $tooBig"
if ($tooBig) { $fail++ }

Log ("=== VERIFY {0} ({1} check(s) failed) ===" -f $(if ($fail) { 'FAILED' } else { 'PASSED' }), $fail)
exit $fail
