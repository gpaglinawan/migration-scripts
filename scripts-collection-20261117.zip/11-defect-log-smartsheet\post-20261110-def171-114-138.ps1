﻿# 10 Nov 2026 (Gareth: "update pls"): comments on DEF-171 (Advanced Security findings) and DEF-114 / DEF-138 (deferral reason
# brought up to date with the 10 Nov PR plan). Comments column only - statuses and Resolutions are not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-171' = 'Checked: Advanced Security (Code Security / CodeQL) is enabled on fin-tcm/SUM-summit and tcm-pilot/SUM-summit, but not on tcm-pilot-test/SUM-summit. Dependabot security updates are on in fin-tcm but off in tcm-pilot and tcm-pilot-test. Secret scanning is off in all three. Done 11/10: Code Security and Dependabot security updates enabled on tcm-pilot-test/SUM-summit (matches fin-tcm) - CodeQL scans can be run there. tcm-pilot/SUM-summit not changed: it is under the enforced org security configuration ''Prevent direct alert dismissals - Custom'', which turns Dependabot alerts and security updates off; changing that configuration affects every repo attached to it and needs the Teciem security owner''s decision.'
  'DEF-114' = 'Update: the nightly sync copies branches and commits, not PRs. All PRs created in fin-tcm after the initial migration (open, merged and closed) are added at cutover - for the 15 FCBO/PTP repos: 15 open, 46 merged, 8 closed, plus 18 whose state changed since. Method (recreate, cutover step GIT-020, or a full re-import of the affected repos) is decided on Thursday after a rehearsal. FCBO-swift-gateway PR #137 shows "merged by Samar-Roy_tciem on 21 Oct" in tcm-pilot because it was still open there and was merged in tcm-pilot during testing (same commit 84bb044); a full re-import would show the original merge by Ana-Maria on 13 Oct. Testing deferred to after cutover.'
  'DEF-138' = 'Update: MCH-mch #1995-#2003 (7 merged, 2 closed) were all created after the initial migration. They are added at cutover by the same method as DEF-114, so the PR counts can be compared only after cutover. The code is identical (IN_SYNC). Testing deferred to after cutover.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun

