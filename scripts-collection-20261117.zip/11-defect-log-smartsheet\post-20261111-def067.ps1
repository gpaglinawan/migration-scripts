# 11 Nov 2026 (Gareth: "post"). Comment only - status (Deferred) not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-067' = 'Re-checked tonight (~21:40 CET), every branch and tag of the 9 listed repos, fin-tcm vs tcm-pilot: all tags match (MAFTP-csm 124, RISK-fusionrisk-integration-api 254, FRCP-pricing-engine-fusionrisk 507, RISK-fusionrisk-installer 176 - no tag mismatches left) and the default branch matches in all 9. All branches match in RISK-fr-limit-test, RISK-fr_qa, MAFTP-csm, MAFTP-krecord and RISK-fusionrisk-installer. The only differences are commits made in fin-tcm today: RISK-fusion-risk (master and 7 branches, 1-3 commits each, plus 5 branches created today) and RISK-fr-cmr-tests (1 branch, 1 commit); all fast-forward cleanly (nothing rewritten) and are copied by tonight''s nightly sync. Branches that exist only in tcm-pilot were deleted in fin-tcm after the migration (the sync does not delete) - covered by DEF-188. Remains Deferred for the retest after the final sync at cutover.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
