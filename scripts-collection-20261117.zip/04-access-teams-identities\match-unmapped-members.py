# 15 Nov 2026 (DEF-220) - read-only: for every fin-tcm member with no Teciem login in the name mapping, look for a Teciem
# enterprise account by NAME (accents ignored, word order ignored, surname may differ). Writes candidates to review;
# changes nothing. Usage: match-unmapped-members.py <out.csv>
import csv, json, os, re, sys, unicodedata, urllib.request
S, T = os.environ['GH_SRC_PAT'], os.environ['GH_TGT_PAT']
def gql(tok, q, v=None):
    r = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v or {}}).encode(), headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
    return json.load(urllib.request.urlopen(r, timeout=120))['data']
def norm(s): return [w for w in re.sub(r'[^a-z ]', ' ', unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode().lower()).split() if len(w) > 1 and w not in ('finastra', 'tciem')]
def page(tok, q, path):
    out, after = [], None
    while True:
        d = gql(tok, q, {'a': after}); node = d
        for k in path: node = node[k]
        out += node['nodes']
        if not node['pageInfo']['hasNextPage']: return out
        after = node['pageInfo']['endCursor']
src = page(S, 'query($a:String){ organization(login:"fin-tcm"){ membersWithRole(first:100, after:$a){ pageInfo{hasNextPage endCursor} nodes{ login name } } } }', ['organization', 'membersWithRole'])
ent = page(T, 'query($a:String){ enterprise(slug:"tcm-enterprise"){ members(first:100, after:$a){ pageInfo{hasNextPage endCursor} nodes{ ... on EnterpriseUserAccount { login name } } } } }', ['enterprise', 'members'])
mapped = {r['Src'].lower(): r['Tgt'] for r in csv.DictReader(open(r'C:\kon-migration\rules\member-names-20261111.csv', encoding='utf-8-sig')) if r.get('Tgt')}
unmapped = [m for m in src if m['login'].lower() not in mapped]
taken = {v.lower() for v in mapped.values()}
ent_words = [(e, set(norm(e.get('name'))) | set(norm((e.get('login') or '').replace('-', ' ')))) for e in ent if e.get('login')]
rows = []
for m in unmapped:
    words = set(norm(m.get('name'))) | set(norm(m['login'].replace('-', ' ').replace('_', ' ')))
    best = []
    for e, ew in ent_words:
        common = words & ew
        if not common: continue
        # first-name match counts most; a shared surname alone is weak
        first = norm(m.get('name') or m['login'])[:1]
        score = len(common) + (1 if first and first[0] in ew else 0)
        best.append((score, e['login'], e.get('name'), sorted(common)))
    best.sort(reverse=True)
    top = [b for b in best if b[0] >= 2][:3]
    rows.append({'fin-tcm login': m['login'], 'fin-tcm name': m.get('name') or '',
                 'Candidate 1': f'{top[0][1]} [{top[0][2]}] match {top[0][3]}' if top else '',
                 'Candidate 2': f'{top[1][1]} [{top[1][2]}]' if len(top) > 1 else '',
                 'Strength': ('strong' if top and top[0][0] >= 3 and (len(top) == 1 or top[1][0] < top[0][0]) else 'review') if top else 'none',
                 'Candidate already mapped to someone else': ('yes' if top and top[0][1].lower() in taken else '')})
with open(sys.argv[1], 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
from collections import Counter
print(f'fin-tcm members {len(src)}; unmapped {len(unmapped)}; enterprise accounts {len(ent)}')
print('match strength:', dict(Counter(r['Strength'] for r in rows)))
