# 15 Nov 2026 (Gareth: every repo PASS for Patrick/Samar; no Teciem work may be overwritten). Additive only.
# For refs where tcm-pilot holds Teciem commits Finastra never had (DIFFERENT): the Finastra version is pushed NEXT TO it as
#   refs/heads/fin-tcm-kept/<branch>  or  refs/tags/fin-tcm-kept/<tag>   - the Teciem ref itself is not touched.
# For refs missing in tcm-pilot (MISSING): pushed under their own name. EXTRA_IN_TARGET refs are left alone.
# Input: a refs compare-detail.csv (Repo,Ref,Issue,Src,Tgt). Output: C:\kon-migration\refs\preserved-refs.csv (appended).
param([Parameter(Mandatory)][string]$Detail, [Parameter(Mandatory)][string[]]$Repos, [switch]$Apply)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'; $work = 'C:\kon-migration\refs\preserve-work'; New-Item -ItemType Directory -Force $work | Out-Null
$out = 'C:\kon-migration\refs\preserved-refs.csv'
$rows = Import-Csv $Detail | Where-Object { $_.Repo -in $Repos -and $_.Issue -in 'DIFFERENT', 'MISSING' }
foreach ($r in $rows) {
  $dest = if ($r.Issue -eq 'MISSING') { $r.Ref } else { $r.Ref -replace '^refs/(heads|tags)/', 'refs/$1/fin-tcm-kept/' }
  if (-not $Apply) { "DRY {0,-26} {1} -> {2}" -f $r.Repo, $r.Ref, $dest; continue }
  $d = Join-Path $work "$($r.Repo).git"; if (-not (Test-Path $d)) { git init --bare -q $d }
  git -C $d -c "http.extraHeader=Authorization: Basic $sb" fetch -q "https://github.com/fin-tcm/$($r.Repo).git" "+$($r.Ref):refs/src/$($r.Ref -replace '^refs/','')" 2>&1 | Out-Null
  $sha = git -C $d rev-parse "refs/src/$($r.Ref -replace '^refs/','')" 2>$null
  if ($sha -ne $r.Src) { $res = "FAILED: fin-tcm ref now $sha (expected $($r.Src))" }
  else {
    $o = @(git -C $d -c "http.extraHeader=Authorization: Basic $tb" push --porcelain "https://github.com/tcm-pilot/$($r.Repo).git" "$($sha):$dest" 2>&1 | ForEach-Object { "$_" })
    $now = ((git -c "http.extraHeader=Authorization: Basic $tb" ls-remote "https://github.com/tcm-pilot/$($r.Repo).git" $dest) -split "`t")[0]
    $res = if ($now -eq $sha) { 'PUSHED' } else { 'FAILED: ' + (($o | Where-Object { $_ -match '^!|remote: ' } | Select-Object -First 3) -join ' | ') }
  }
  [pscustomobject]@{ Repo = $r.Repo; Ref = $r.Ref; Issue = $r.Issue; FinastraCommit = $r.Src; TeciemCommit = $r.Tgt; KeptAs = $dest; Result = $res; At = (Get-Date -Format 'yyyy-MM-dd HH:mm') } |
    Tee-Object -Variable row | Export-Csv $out -Append -NoTypeInformation -Encoding utf8
  "{0,-26} {1} -> {2} : {3}" -f $r.Repo, $r.Ref, $dest, $res
}
