﻿# One-off corrective sync fin-tcm -> tcm-pilot for what the nightly sync deliberately leaves alone:
#   DELETE  branches/tags deleted in Finastra that are still in tcm-pilot
#   FORCE   branches/tags rebased (rewritten) in Finastra, where tcm-pilot still has the old commit
# Safety: a ref is only touched if its CURRENT tcm-pilot commit is one that Finastra had for that same ref in an
#   earlier nightly snapshot (C:\kon-migration\nightly\*\{before,after}\fin-tcm). Anything else (a branch created in
#   Teciem, or commits pushed in Teciem) is KEEP and reported, never changed. Repos rewritten for large files are
#   excluded (their commit IDs differ by design). Dry run unless -Apply; -Apply also backs up every ref it changes.
param([switch]$Apply, [string]$Day = (Get-Date -Format "yyyy-MM-dd"), [string[]]$Only,
      [ValidateSet('DELETE','FORCE')][string[]]$Actions = @('DELETE', 'FORCE'))   # 14 Nov: -Actions FORCE = force pushes only (deletes held for Gareth)
$ErrorActionPreference = "Stop"
$root = "C:\kon-migration\corrective-sync\" + (Get-Date -Format yyyyMMdd-HHmm); New-Item -ItemType Directory -Force $root | Out-Null
$rewritten = 'KON-kplus-front', 'FCGC-pricing-analytics', 'RISK-cmr', 'OPICS-programmers', 'KON-doc-kondor-archive', 'FWK-utfinstaller', 'FCBO-fusion-detect-core', 'MAFTP-fpp-fusioncapital', 'SFX-netcore-common', 'TO-treasury-installer', 'MAFTP-fpp-vaas-che'
$summary = Import-Csv "C:\kon-migration\nightly\$Day\after\compare-summary.csv" | Where-Object { $_.Status -eq 'OUT_OF_SYNC' -and $_.Repo -notin $rewritten -and $_.Archived -ne 'True' }
if ($Only) { $summary = $summary | Where-Object Repo -in $Only }
# every Finastra ref snapshot taken so far (24 Oct onwards): nightly runs, sync-to-target rounds, first refs dump, probe
$snaps = @('C:\kon-migration\refs\fin-tcm', 'C:\kon-migration\probe\refs-now\fin-tcm') +
         @(Get-ChildItem C:\kon-migration\nightly, C:\kon-migration\sync-to-target -Recurse -Directory -Filter 'fin-tcm' -ErrorAction SilentlyContinue | ForEach-Object FullName) | Where-Object { Test-Path $_ }
# tcm-pilot as it was on 24 Oct, before users worked in it: refs present then came from the migration itself
$baseline = 'C:\kon-migration\refs\tcm-pilot'
$hs = @{ Authorization = "Bearer " + ((Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*\$env:GH_SRC_PAT\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] }) | Select-Object -First 1) }
function InFinastra($repo, $sha) { try { $null = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$repo/git/commits/$sha" -Headers $hs; $true } catch { $false } }
function Load($f) { $m = @{}; if (Test-Path $f) { Get-Content $f | ForEach-Object { $p = $_ -split "`t"; if ($p.Count -ge 2 -and $p[1] -notlike '*^{}') { $m[$p[1]] = $p[0] } } }; $m }
$rows = foreach ($s in $summary) {
  $r = $s.Repo
  $src = Load "C:\kon-migration\nightly\$Day\after\fin-tcm\$r.txt"; $tgt = Load "C:\kon-migration\nightly\$Day\after\tcm-pilot\$r.txt"
  $base = Load (Join-Path $baseline "$r.txt")
  $hist = @{}   # ref -> set of commits Finastra had for it in any snapshot
  foreach ($d in $snaps) { $m = Load (Join-Path $d "$r.txt"); foreach ($k in $m.Keys) { if (-not $hist[$k]) { $hist[$k] = @{} }; $hist[$k][$m[$k]] = 1 } }
  foreach ($ref in $tgt.Keys) {
    $t = $tgt[$ref]; $known = $hist[$ref] -and $hist[$ref].ContainsKey($t)
    # 14 Nov: branches pr-recreate.ps1 pushed as heads of recreated OPEN PRs hold Finastra commits but must stay
    if ($ref -like 'refs/heads/fin-tcm-pr/*') { [pscustomobject]@{ Repo = $r; Ref = $ref; Action = 'KEEP (head of a recreated PR)'; Finastra = ''; Teciem = $t }; continue }
    if (-not $src.ContainsKey($ref)) {
      if (-not $known) { $known = InFinastra $r $t }   # the commit is Finastra's, so deleting the branch loses no Teciem work
      $a = if ($known) { 'DELETE' } else { 'KEEP (commit exists only in Teciem)' }
      [pscustomobject]@{ Repo = $r; Ref = $ref; Action = $a; Finastra = ''; Teciem = $t }
    } elseif ($src[$ref] -ne $t) {
      if (-not $known) { $known = InFinastra $r $t }
      $a = if ($known) { 'FORCE' } else { 'KEEP (Teciem has commits Finastra never had)' }
      [pscustomobject]@{ Repo = $r; Ref = $ref; Action = $a; Finastra = $src[$ref]; Teciem = $t }
    }
  }
}
$rows | Export-Csv "$root\plan.csv" -NoTypeInformation -Encoding utf8
"snapshots used: $($snaps.Count) ($((Split-Path (Split-Path (Split-Path $snaps[0]))) | Split-Path -Leaf) onwards)   repos: $(@($summary).Count)"
$rows | Group-Object { ($_.Action -split ' ')[0] } | ForEach-Object { "{0,-7} {1}" -f $_.Name, $_.Count }
"plan: $root\plan.csv"
if (-not $Apply) { return }

# ---- apply: per repo, back up the refs to be changed, then push deletes / forced updates with a lease ----
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))
$tgtHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = "0"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = $tgtHdr; $env:GIT_CONFIG_COUNT = "1"
$ErrorActionPreference = "Continue"
$log = "$root\apply.log"; function Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Host $l; Add-Content $log $l -Encoding utf8 }
$classic = @(Import-Csv C:\kon-migration\rules\classic-bypass-branches.csv)
$bk = "$root\backup"; New-Item -ItemType Directory -Force $bk | Out-Null
$results = foreach ($g in @($rows | Where-Object { $_.Action -in $Actions }) | Group-Object Repo) {
  $r = $g.Name; $todo = @($g.Group)
  $prot = @($classic | Where-Object Repo -eq $r | ForEach-Object { "refs/heads/$($_.Branch)" })
  $skip = @($todo | Where-Object Ref -in $prot); $todo = @($todo | Where-Object Ref -notin $prot)
  foreach ($s in $skip) { Log "  SKIP $r $($s.Ref): classic branch protection" }
  if (-not $todo.Count) { continue }
  $dir = "$root\work\$r.git"; Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue; git init --bare -q $dir
  # backup: current tcm-pilot state of every ref we change -> bundle
  $env:GIT_CONFIG_VALUE_0 = $tgtHdr
  $specs = @($todo | ForEach-Object { "+$($_.Ref):refs/backup/$($_.Ref -replace '^refs/','')" })
  for ($i = 0; $i -lt $specs.Count; $i += 100) { git -C $dir fetch -q "https://github.com/tcm-pilot/$r.git" @($specs[$i..([Math]::Min($i + 99, $specs.Count - 1))]) 2>&1 | Out-Null }
  git -C $dir bundle create -q "$bk\$r.bundle" --all 2>&1 | Out-Null
  if (-not (Test-Path "$bk\$r.bundle")) { Log "STOP $r : backup failed, nothing changed"; [pscustomobject]@{ Repo = $r; Result = 'FAILED backup'; Changed = 0; Rejected = 0; Skipped = 0 }; continue }
  # forced refs: fetch their current Finastra state (+ LFS objects) so they can be pushed
  $force = @($todo | Where-Object Action -eq 'FORCE')
  if ($force.Count) {
    $env:GIT_CONFIG_VALUE_0 = $srcHdr
    $fs = @($force | ForEach-Object { "+$($_.Ref):$($_.Ref)" })
    for ($i = 0; $i -lt $fs.Count; $i += 100) { git -C $dir fetch -q "https://github.com/fin-tcm/$r.git" @($fs[$i..([Math]::Min($i + 99, $fs.Count - 1))]) 2>&1 | Out-Null }
    $refs = @($force.Ref | Where-Object { git -C $dir rev-parse -q --verify $_ 2>$null })   # refs Finastra still has
    if ($refs.Count) {
      git -C $dir -c "lfs.url=https://github.com/fin-tcm/$r.git/info/lfs" lfs fetch "https://github.com/fin-tcm/$r.git" @refs 2>&1 | Out-Null
      $env:GIT_CONFIG_VALUE_0 = $tgtHdr
      git -C $dir -c "lfs.url=https://github.com/tcm-pilot/$r.git/info/lfs" -c lfs.allowincompletepush=true lfs push "https://github.com/tcm-pilot/$r.git" @refs 2>&1 | Out-Null
    }
    # a ref Finastra deleted since the plan was made is left for the next run (a missing source would fail the whole push)
    foreach ($x in @($force | Where-Object Ref -notin $refs)) { Log "  LATER $r $($x.Ref): no longer in Finastra" }
    $todo = @($todo | Where-Object { $_.Action -eq 'DELETE' -or $_.Ref -in $refs })
  }
  # push: deletes and forced updates, each guarded by a lease on the commit tcm-pilot had when the plan was made
  $env:GIT_CONFIG_VALUE_0 = $tgtHdr
  $out = @()
  for ($i = 0; $i -lt $todo.Count; $i += 100) {
    $b = $todo[$i..([Math]::Min($i + 99, $todo.Count - 1))]
    $args2 = @($b | ForEach-Object { "--force-with-lease=$($_.Ref):$($_.Teciem)" }) + @($b | ForEach-Object { if ($_.Action -eq 'DELETE') { ":$($_.Ref)" } else { "+$($_.Ref):$($_.Ref)" } })
    $out += @(git -C $dir push --porcelain "https://github.com/tcm-pilot/$r.git" @args2 2>&1 | ForEach-Object { "$_" })
  }
  $ok = @($out | Where-Object { $_ -match '^[-+*= ]\t' -and $_ -notmatch '\[up to date\]' }).Count
  $rej = @($out | Where-Object { $_ -match '^!\t' }); $rej | ForEach-Object { Log "  REJECTED $r $_" }
  Log ("{0,-40} deleted/updated {1}  rejected {2}  skipped(protected) {3}" -f $r, $ok, $rej.Count, $skip.Count)
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  [pscustomobject]@{ Repo = $r; Result = $(if ($rej.Count) { 'PARTIAL' } else { 'OK' }); Changed = $ok; Rejected = $rej.Count; Skipped = $skip.Count }
}
$results | Export-Csv "$root\apply-results.csv" -NoTypeInformation -Encoding utf8
Log ("=== done: changed {0}, rejected {1}, skipped {2}; backups in {3} ===" -f ($results | Measure-Object Changed -Sum).Sum, ($results | Measure-Object Rejected -Sum).Sum, ($results | Measure-Object Skipped -Sum).Sum, $bk)
