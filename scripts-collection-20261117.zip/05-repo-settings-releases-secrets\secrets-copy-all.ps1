param(
  [string]$Compare   = "C:\kon-migration\actions\repo-actions-compare.csv",
  [string]$Inventory = "C:\kon-migration\actions\repo-actions-source.json",
  [int]$BatchSize    = 20,
  [switch]$OnlyMissing = $true
)
# Runs secrets-copy.ps1 over every repo that has Actions secrets in fin-tcm and exists in tcm-pilot, in batches.
# Each batch stages the target token, copies, and cleans up (token secret + temp branches) before the next starts.
$here = Split-Path $MyInvocation.MyCommand.Path
if (-not (Test-Path $Compare)) { "Inventory not finished yet: $Compare"; return }
$rows = @(Import-Csv $Compare | Where-Object { $_.InTarget -eq 'True' -and [int]$_.SrcSecrets -gt 0 })
if ($OnlyMissing) { $rows = @($rows | Where-Object { $_.MissingSecretNames }) }
$repos = @($rows.Repo | Where-Object { $_ -ne 'SPH-live-environment' })   # pilot already done
"repos to process: $($repos.Count) in batches of $BatchSize"
for ($i = 0; $i -lt $repos.Count; $i += $BatchSize) {
  $batch = $repos[$i..([Math]::Min($i + $BatchSize - 1, $repos.Count - 1))]
  "----- batch $([int]($i / $BatchSize) + 1): $($batch -join ', ')"
  & (Join-Path $here "secrets-copy.ps1") -Repos $batch -Inventory $Inventory -TimeoutMin 15
}
"all batches done - results: C:\kon-migration\actions\secrets-copy\secrets-copy-results.csv"
