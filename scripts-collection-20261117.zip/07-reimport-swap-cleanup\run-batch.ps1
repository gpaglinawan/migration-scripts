# Runs pr-preload.ps1 for several repos one after the other (one at a time: disk space). A repo that stops is logged
# and the batch moves on. Summary: C:\kon-migration\pr-preload\batch.log
param([Parameter(Mandatory)][string[]]$Repos, [string]$TargetOrg = 'tcm-pilot', [string]$TargetName)
$renames = @{ 'SFX-netcore-common' = @('QuickFixn/.git/:QuickFixn/_git/') }
$nullGitlinks = @('MAFTP-fpp-vaas-che')
$batchLog = 'C:\kon-migration\pr-preload\batch.log'
foreach ($r in $Repos) {
  $t0 = Get-Date; Add-Content $batchLog ("[{0:yyyy-MM-dd HH:mm}] start {1}" -f $t0, $r) -Encoding utf8
  $runArgs = @{ Repo = $r; TargetOrg = $TargetOrg }; if ($renames[$r]) { $runArgs.PathRename = $renames[$r] }
  if ($r -in $nullGitlinks) { $runArgs.DropNullGitlinks = $true }; if ($TargetName) { $runArgs.TargetName = $TargetName }
  & C:\kon-migration\scripts\pr-preload\pr-preload.ps1 @runArgs *>&1 | Out-Null
  $last = Get-Content "C:\kon-migration\pr-preload\$r\run.log" -Tail 3 | Where-Object { $_ -match 'STOP|===|identical' } | Select-Object -Last 1
  Add-Content $batchLog ("[{0:yyyy-MM-dd HH:mm}] end   {1} after {2:N0} min: {3}" -f (Get-Date), $r, ((Get-Date) - $t0).TotalMinutes, $last) -Encoding utf8
}
