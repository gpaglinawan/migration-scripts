param(
  [Parameter(Mandatory)][string[]]$Repos,
  [string]$Base   = "C:\kon-migration",
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot"
)
# For each rewritten repo: verify (lfs-verify.ps1) -> target still empty -> chunked push (kon-push.ps1) -> default branch.
# A repo that fails any step is skipped; nothing is forced or deleted.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
$scripts = Split-Path $MyInvocation.MyCommand.Path
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$log = Join-Path $Base "verify-and-push.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

foreach ($repo in $Repos) {
  $orig = Join-Path $Base "$repo.git"; $copy = Join-Path $Base "$repo-lfs.git"; $out = Join-Path $Base "bigfiles-$repo"
  Log "===== $repo ====="
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $scripts "lfs-verify.ps1") -Orig $orig -Copy $copy -Out (Join-Path $out "verify") | ForEach-Object { Log "  $_" }
  if ($LASTEXITCODE -ne 0) { Log "  SKIP $repo - verification failed"; continue }

  $src = Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$repo" -Headers @{ Authorization = "Bearer $env:GH_SRC_PAT" }
  $trunk = $src.default_branch
  $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
  $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
  $existing = @(git ls-remote "https://github.com/$TgtOrg/$repo.git").Count
  Remove-Item Env:GIT_CONFIG_COUNT, Env:GIT_CONFIG_KEY_0, Env:GIT_CONFIG_VALUE_0 -ErrorAction SilentlyContinue
  if ($existing -gt 0) { Log "  SKIP $repo - target is no longer empty ($existing refs)"; continue }

  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $scripts "kon-push.ps1") -Repo $copy -Target "https://github.com/$TgtOrg/$repo.git" -Out (Join-Path $Base "push-$repo") -Trunk $trunk -Steps 10 | ForEach-Object { Log "  $_" }
  if ($LASTEXITCODE -ne 0) { Log "  $repo push finished with $LASTEXITCODE mismatched refs - see push-$repo\verify-missing.txt"; continue }
  try { $r = Invoke-RestMethod -Method PATCH "https://api.github.com/repos/$TgtOrg/$repo" -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT" } -Body (@{ default_branch = $trunk } | ConvertTo-Json) -ContentType application/json; Log "  default branch: $($r.default_branch)" }
  catch { Log "  default branch FAILED: $($_.ErrorDetails.Message)" }
  Log "  DONE $repo"
}
