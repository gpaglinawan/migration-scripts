param(
  [string]$Repo = "kon-kplus-front",
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [int[]]$Numbers,                       # only these source PR numbers (for testing); default all open PRs
  [string]$Out = "C:\kon-migration\pr-archive",
  [hashtable]$Existing,                  # source number -> target number for PRs already created but not recorded (labels + history only)
  [switch]$Apply
)
# Recreates the OPEN pull requests of a push-migrated repo in the target org (same head/base branch names, same draft state),
# with labels and the full Finastra conversation (comments, reviews, line comments) as one history comment.
# Idempotent: source->target numbers are kept in <repo>\open-pr-map.csv and mapped PRs are skipped on a re-run.
# Workflows triggered by pull requests are disabled first (list kept in <repo>\workflows-disabled.txt for cutover).
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$rawHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github.raw" }
$dir = Join-Path $Out $Repo; New-Item -ItemType Directory -Force $dir | Out-Null
$log = Join-Path $dir "open-pr-$(if($Apply){'apply'}else{'plan'}).log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
$api = "https://api.github.com/repos/$TgtOrg/$Repo"
function Post($uri, $body, $method = 'POST') {
  for ($try = 1; $try -le 5; $try++) {
    try { $r = Invoke-RestMethod -Method $method $uri -Headers $tgtHdr -ContentType application/json -Body ([Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Depth 6))); Start-Sleep -Seconds 2; return $r }
    catch { $code = $_.Exception.Response.StatusCode.value__; $msg = "$($_.ErrorDetails.Message)"
      if ($code -eq 422) { throw "422 $msg" }
      $wait = if ($code -in 403, 429) { 90 * $try } else { 15 * $try }; Log "    retry $try ($code) in ${wait}s"; Start-Sleep $wait }
  }
  throw "failed after 5 attempts"
}
# cross references: "#123" means a Finastra PR, not a Teciem one
function Refs([string]$t) { if (-not $t) { return "" }; [regex]::Replace($t, '(?<![\w/&#])#(\d+)\b', "$SrcOrg/$Repo#`$1") }
function Quote([string]$t) { if (-not $t) { return "" }; ($t -split "`r?`n" | ForEach-Object { "> $_" }) -join "`n" }

# 1. open PRs with everything we need (GraphQL)
$q = @'
query($c:String){ repository(owner:"OWNER", name:"REPO"){ pullRequests(states:OPEN, first:20, after:$c){ pageInfo{hasNextPage endCursor}
 nodes{ number title body isDraft createdAt url baseRefName headRefName author{login} labels(first:20){nodes{name}}
  comments(first:100){nodes{ author{login} body createdAt }}
  reviews(first:50){nodes{ author{login} state body submittedAt comments(first:50){nodes{ path line originalLine diffHunk body author{login} createdAt }} }} } } } }
'@ -creplace 'OWNER', $SrcOrg -creplace 'REPO', $Repo
$r = $null
$open = @(); $cursor = $null
do { $r = (Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $srcHdr -ContentType application/json -Body (@{ query = $q; variables = @{ c = $cursor } } | ConvertTo-Json)).data.repository.pullRequests
  foreach ($n in $r.nodes) { $open += $n }; $cursor = $r.pageInfo.endCursor } while ($r.pageInfo.hasNextPage)
if ($Numbers) { $open = @($open | Where-Object { $Numbers -contains $_.number }) }
$open = @($open | Sort-Object number)
$mapFile = Join-Path $dir "open-pr-map.csv"
$map = @{}; if (Test-Path $mapFile) { foreach ($m in (Import-Csv $mapFile)) { $map[[int]$m.Source] = $m } }
Log "=== open PRs $SrcOrg/$Repo -> $TgtOrg/$Repo : $($open.Count) to process, $($map.Count) already mapped, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="

# 2. disable workflows that pull request events would start (and the scheduled / branch-delete ones), once
$wfFile = Join-Path $dir "workflows-disabled.txt"
if ($Apply) {
  foreach ($w in (Invoke-RestMethod "$api/actions/workflows?per_page=100" -Headers $tgtHdr).workflows) {
    if ($w.path -notlike '.github/*' -or $w.state -ne 'active') { continue }
    $t = [string](Invoke-RestMethod "$api/contents/$($w.path)" -Headers $rawHdr)
    if ($t -match '(?m)^\s*(pull_request|pull_request_target|pull_request_review|schedule|delete|status|issue_comment|check_suite)\s*:' -or $t -match '(?m)^\s*on\s*:.*\b(pull_request|schedule|delete)\b') {
      Invoke-RestMethod -Method PUT "$api/actions/workflows/$($w.id)/disable" -Headers $tgtHdr | Out-Null
      Add-Content $wfFile -Value "$($w.id)`t$($w.path)" -Encoding utf8; Log "  disabled workflow $($w.path)"
    }
  }
}

# 3. create
$done = 0; $failed = 0
foreach ($pr in $open) {
  if ($map.ContainsKey([int]$pr.number)) { continue }
  $author = if ($pr.author) { $pr.author.login } else { "ghost" }
  $head = "> **Migrated from Finastra** $SrcOrg/$Repo#$($pr.number), opened by **$author** on $(([datetime]$pr.createdAt).ToString('yyyy-MM-dd')).`n> The conversation from Finastra is in the first comment below.`n`n---`n`n"
  $body = $head + (Refs $pr.body); if ($body.Length -gt 65000) { $body = $body.Substring(0, 65000) + "`n`n_(description truncated)_" }
  if (-not $Apply) { Log "  would create #$($pr.number) [$($pr.headRefName) -> $($pr.baseRefName)] draft=$($pr.isDraft) comments=$(@($pr.comments.nodes).Count) reviews=$(@($pr.reviews.nodes).Count)"; continue }
  try {
    if ($Existing -and $Existing[[int]$pr.number]) { $new = [pscustomobject]@{ number = $Existing[[int]$pr.number] }; Log "  #$($pr.number) : using existing Teciem PR #$($new.number)" }
    else { $new = Post "$api/pulls" @{ title = $pr.title; head = $pr.headRefName; base = $pr.baseRefName; body = $body; draft = [bool]$pr.isDraft; maintainer_can_modify = $false } }
    $labels = @($pr.labels.nodes.name | Where-Object { $_ })
    if ($labels.Count) { try { Post "$api/issues/$($new.number)/labels" @{ labels = $labels } | Out-Null } catch { Log "    labels failed: $($_.Exception.Message)" } }
    # conversation history, oldest first
    $events = @()
    foreach ($c in $pr.comments.nodes) { $events += [pscustomobject]@{ At = [datetime]$c.createdAt; Text = "**$(if($c.author){$c.author.login}else{'ghost'})** commented on $(([datetime]$c.createdAt).ToString('yyyy-MM-dd HH:mm')) UTC`n`n$(Quote (Refs $c.body))" } }
    foreach ($rv in $pr.reviews.nodes) {
      $lines = @(); foreach ($lc in $rv.comments.nodes) {
        $ln = if ($lc.line) { $lc.line } else { $lc.originalLine }
        $hunk = (($lc.diffHunk -split "`n") | Select-Object -Last 4) -join "`n"
        $lines += "``$($lc.path)`` line $ln`n``````diff`n$hunk`n```````n$(Quote (Refs $lc.body))"
      }
      if (-not $rv.body -and -not $lines.Count -and $rv.state -eq 'COMMENTED') { continue }
      $txt = "**$(if($rv.author){$rv.author.login}else{'ghost'})** reviewed ($($rv.state.ToLower().Replace('_',' '))) on $(([datetime]$rv.submittedAt).ToString('yyyy-MM-dd HH:mm')) UTC"
      if ($rv.body) { $txt += "`n`n$(Quote (Refs $rv.body))" }; if ($lines.Count) { $txt += "`n`n" + ($lines -join "`n`n") }
      $events += [pscustomobject]@{ At = [datetime]$rv.submittedAt; Text = $txt }
    }
    $parts = @(); $cur = "### Conversation from Finastra ($SrcOrg/$Repo#$($pr.number))`n"
    if (-not $events.Count) { $cur += "`n_No comments or reviews in Finastra._" }
    foreach ($e in ($events | Sort-Object At)) { $piece = "`n---`n" + $e.Text; if (($cur.Length + $piece.Length) -gt 60000) { $parts += $cur; $cur = "### Conversation from Finastra (continued)`n" }; $cur += $piece }
    $parts += $cur
    foreach ($p in $parts) { Post "$api/issues/$($new.number)/comments" @{ body = $p } | Out-Null }
    $row = [pscustomobject]@{ Source = $pr.number; Target = $new.number; Head = $pr.headRefName; Base = $pr.baseRefName; Draft = $pr.isDraft; HistoryEvents = $events.Count; Created = (Get-Date).ToString('s') }
    $row | Export-Csv $mapFile -Append -NoTypeInformation -Encoding utf8; $map[[int]$pr.number] = $row
    $done++; Log "  #$($pr.number) -> #$($new.number) ($($events.Count) history items)"
  } catch { $failed++; Log "  #$($pr.number) FAILED: $($_.Exception.Message)" }
}
Log "=== done: created $done, failed $failed, mapped total $($map.Count) ==="
