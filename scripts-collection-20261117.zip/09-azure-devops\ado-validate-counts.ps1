# 13 Nov 2026 - ADO-011 count comparison, TreasuryCapitalMarkets vs tcm-staging, for the 9 in-scope projects.
# Read-only. Repos/refs come from ado-nightly-sync.ps1 -DryRun; this script adds repos, work items, pipelines,
# variable groups, feed versions. Writes a CSV next to the cutover log.
param([string]$Out = "C:\kon-migration\ado-nightly\ado-011-counts-$(Get-Date -Format yyyyMMdd-HHmm).csv")
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_SOURCE_PAT|AZDO_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-AuthHeader($p) { @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$p")) } }
$side = @{ Src = @{ Org = 'TreasuryCapitalMarkets'; Hd = (Get-AuthHeader $env:AZDO_SOURCE_PAT) }; Tgt = @{ Org = 'tcm-staging'; Hd = (Get-AuthHeader $env:AZDO_PAT) } }
function Get-Count($s, $proj, $what) {
  $o = $side[$s].Org; $hd = $side[$s].Hd; $e = [uri]::EscapeDataString($proj)
  switch ($what) {
    'Repos (active)' { @((Invoke-RestMethod "https://dev.azure.com/$o/$e/_apis/git/repositories?api-version=7.1" -Headers $hd).value | Where-Object { -not $_.isDisabled }).Count }
    'Work items' {
      $q = @{ query = "SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = @project AND [System.WorkItemType] NOT IN ('Test Plan','Test Suite')" } | ConvertTo-Json
      @((Invoke-RestMethod -Method Post "https://dev.azure.com/$o/$e/_apis/wit/wiql?api-version=7.1" -Headers $hd -ContentType 'application/json' -Body $q).workItems).Count }
    'Build pipelines' { @((Invoke-RestMethod "https://dev.azure.com/$o/$e/_apis/build/definitions?api-version=7.1&`$top=1000" -Headers $hd).value).Count }
    'Variable groups' { @((Invoke-RestMethod "https://dev.azure.com/$o/$e/_apis/distributedtask/variablegroups?api-version=7.1" -Headers $hd).value).Count }
  }
}
$projects = 'Treasury','PipelineTemplate','SelfServicePortal','Pegazus','Jenkins','Opics','FusionRisk_QA','Fusion Invest','Terraform'
$rows = foreach ($p in $projects) { foreach ($w in 'Repos (active)','Work items','Build pipelines','Variable groups') {
  $a = try { Get-Count 'Src' $p $w } catch { "error" }; $b = try { Get-Count 'Tgt' $p $w } catch { "error" }
  [pscustomobject]@{ Project = $p; Item = $w; Finastra = $a; Teciem = $b; Match = if ("$a" -eq "$b") { 'yes' } else { 'NO' } } } }
# feeds: package versions per in-scope feed (first-party, all versions incl. deleted-hidden excluded)
function Get-FeedVersions($s) {
  $o = $side[$s].Org; $hd = $side[$s].Hd; $r = @{}
  foreach ($f in (Invoke-RestMethod "https://feeds.dev.azure.com/$o/_apis/packaging/feeds?api-version=7.1" -Headers $hd).value) {
    if ($f.project -and $f.project.name -in 'TaskFactory','TreasuryKondor','Test - OE') { continue }
    $base = if ($f.project) { "https://feeds.dev.azure.com/$o/$($f.project.id)" } else { "https://feeds.dev.azure.com/$o" }
    $n = 0; $skip = 0
    do { $page = @((Invoke-RestMethod "$base/_apis/packaging/feeds/$($f.id)/packages?includeAllVersions=true&`$top=1000&`$skip=$skip&api-version=7.1" -Headers $hd).value | Where-Object { $_ })
         foreach ($pk in $page) { $n += @($pk.versions | Where-Object { $_ -and -not ($_.sourceChain | Where-Object { $_ }) }).Count }; $skip += 1000 } while ($page.Count -eq 1000)
    $r["$($f.project.name)/$($f.name)"] = $n
  }
  $r
}
$fs = Get-FeedVersions 'Src'; $ft = Get-FeedVersions 'Tgt'
$rows += foreach ($k in $fs.Keys | Sort-Object) { [pscustomobject]@{ Project = ($k -split '/')[0]; Item = "Feed versions: $(($k -split '/')[1])"; Finastra = $fs[$k]; Teciem = $ft[$k]; Match = if ($fs[$k] -eq $ft[$k]) { 'yes' } elseif ($ft[$k] -gt $fs[$k]) { 'more in Teciem' } else { 'NO' } } }
$rows | Export-Csv $Out -NoTypeInformation -Encoding utf8
$rows | Format-Table -AutoSize | Out-String -Width 200
"detail: $Out"
