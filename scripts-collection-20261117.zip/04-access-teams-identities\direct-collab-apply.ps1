param(
  [string]$Diff = "C:\kon-migration\teams\direct-collab-full\diff.csv",
  [string]$TgtOrg = "tcm-pilot",
  [string[]]$Repos,                      # optional: only these repos (e.g. to test on one)
  [switch]$Apply
)
# Restores DIRECT repository access (people added to a repo, not via a team) in Teciem with the same role as in Finastra.
# Uses the MISSING rows of direct-collab-compare.ps1 (person has a Teciem account but no direct access).
# Only adds: never removes or lowers anyone (e.g. access granted by hand in Teciem stays). Plan only unless -Apply.
# Before each grant it re-reads the person's current direct role, so a re-run skips what's already done.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$out = Split-Path $Diff
$log = Join-Path $out "apply-$(if($Apply){'apply'}else{'plan'})-$(Get-Date -Format yyyyMMdd-HHmm).log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
# GitHub API names for the built-in roles
$apiRole = @{ read = 'pull'; triage = 'triage'; write = 'push'; maintain = 'maintain'; admin = 'admin' }

$rows = @(Import-Csv $Diff | Where-Object { $_.Status -eq 'MISSING' -and $_.TeciemLogin })
if ($Repos) { $rows = @($rows | Where-Object { $Repos -contains $_.Repo }) }
Log "=== restore direct access in $TgtOrg : $($rows.Count) grants, $(@($rows.Repo | Sort-Object -Unique).Count) repos, $(@($rows.User | Sort-Object -Unique).Count) people, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="
$rows | Group-Object FinastraRole | ForEach-Object { Log ("  {0,-9} {1}" -f $_.Name, $_.Count) }
if (-not $Apply) { Log "plan only - run again with -Apply"; return }

$done = 0; $skipped = 0; $failed = 0; $archived = 0; $i = 0
# archived repos can't take new collaborators: skip them up front (listed in skipped-archived.csv)
$arch = @{}; $page = 1
do { $n = 0; foreach ($x in (Invoke-RestMethod "https://api.github.com/orgs/$TgtOrg/repos?type=all&per_page=100&page=$page" -Headers $hdr)) { if ($x.archived) { $arch[$x.name.ToLower()] = $true }; $n++ }; $page++ } while ($n -eq 100)
$archRows = @($rows | Where-Object { $arch[$_.Repo.ToLower()] })
if ($archRows.Count) {
  $archRows | Select-Object Repo, TeciemLogin, FinastraRole | Export-Csv (Join-Path $out "skipped-archived.csv") -NoTypeInformation -Encoding utf8
  Log "  skipping $($archRows.Count) grants on $(@($archRows.Repo | Sort-Object -Unique).Count) archived repos (read-only) - see skipped-archived.csv"
  $rows = @($rows | Where-Object { -not $arch[$_.Repo.ToLower()] })
}
foreach ($r in $rows) {
  $i++
  $perm = $apiRole[$r.FinastraRole]; if (-not $perm) { $perm = $r.FinastraRole }   # custom repository role: same name
  # skip if the person already has this level or higher (through a team or a grant made since the comparison) -
  # a direct PUT with a lower role would otherwise downgrade a higher direct grant
  $rank = @{ read = 1; triage = 2; write = 3; maintain = 4; admin = 5 }
  try { $cur = (Invoke-RestMethod "https://api.github.com/repos/$TgtOrg/$($r.Repo)/collaborators/$($r.TeciemLogin)/permission" -Headers $hdr).role_name } catch { $cur = $null }
  if ($cur -and $rank[$cur] -and $rank[$r.FinastraRole] -and $rank[$cur] -ge $rank[$r.FinastraRole]) { $skipped++; continue }
  try {
    Invoke-RestMethod -Method PUT "https://api.github.com/repos/$TgtOrg/$($r.Repo)/collaborators/$($r.TeciemLogin)" -Headers $hdr -ContentType application/json -Body (@{ permission = $perm } | ConvertTo-Json) | Out-Null
    $done++
  } catch {
    $code = $_.Exception.Response.StatusCode.value__
    # archived repos are read-only (also returns 403): record and move on, don't treat it as rate limiting
    if ("$($_.ErrorDetails.Message)" -match 'archived') { $archived++; Add-Content -Path (Join-Path $out "skipped-archived.csv") -Value "$($r.Repo),$($r.TeciemLogin),$($r.FinastraRole)" -Encoding utf8; continue }
    if ($code -in 403, 429) { Log "  rate limited - waiting 2 minutes"; Start-Sleep 120
      try { Invoke-RestMethod -Method PUT "https://api.github.com/repos/$TgtOrg/$($r.Repo)/collaborators/$($r.TeciemLogin)" -Headers $hdr -ContentType application/json -Body (@{ permission = $perm } | ConvertTo-Json) | Out-Null; $done++; continue } catch {} }
    $failed++; Log "  FAILED $($r.Repo) $($r.TeciemLogin) $($r.FinastraRole): $code $($_.ErrorDetails.Message)"
  }
  if ($i % 100 -eq 0) { Log "  $i/$($rows.Count) (added $done, already had it $skipped, failed $failed)" }
  Start-Sleep -Milliseconds 400
}
Log "=== done: added $done, already had it $skipped, archived (skipped) $($archRows.Count + $archived), failed $failed ==="
Log "Re-run direct-collab-compare.ps1 to verify."
