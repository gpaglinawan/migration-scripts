# 12 Nov 2026 (Gareth: "post"). DEF-055 comment + Status -> Ready for Retest. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-055' = 'Re-checked 12 Nov: fixed. The placeholder names ("GitHubArchive\...") were linked to the Teciem accounts on 11 Nov; the PRs in the screenshots now show the real people: OPICS-opics4plus #33981 Rohit-Soni_tciem, #33954 Vignesh-N_tciem, #33952 Aman-Sahoo_tciem, #33947 Ranjeev-Bohara_tciem; OPICS-opicsbat #1708 Renuka-Dakannagari_tciem, #1706 Rohit-Soni_tciem. PR lists and search show them too (author:Rohit-Soni_tciem finds 267 PRs in OPICS-opics4plus; all 20 open PRs in OPICS-opicsbat show Teciem accounts). Remaining: 5 of 147 open PRs in OPICS-opics4plus show a scrambled name (e.g. tcAVyPDTqd18...) - their authors'' Finastra accounts were suspended, so GitHub hides the name and they cannot be matched automatically; they can be linked by hand if the person is identified. Ready for retest.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
if ($DryRun) { 'dry run: would set DEF-055 Status to Ready for Retest'; return }
$sid = '3761521504348036'
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$hd = @{ Authorization = "Bearer $tok" }
$sh = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sid" -Headers $hd
$cid = @{}; $sh.columns | ForEach-Object { $cid[$_.title] = $_.id }
$opts = ($sh.columns | Where-Object title -eq 'Status').options
if ($opts -and 'Ready for Retest' -notin $opts) { throw "Status option 'Ready for Retest' not found: $($opts -join ', ')" }
$row = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $cid['Defect ID']).value -eq 'DEF-055' }
$body = ConvertTo-Json -Depth 5 @(@{ id = $row.id; cells = @(@{ columnId = $cid['Status']; value = 'Ready for Retest' }) })
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sid/rows" -Headers $hd -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
"status now: $(($res.result[0].cells | Where-Object columnId -eq $cid['Status']).value)"
