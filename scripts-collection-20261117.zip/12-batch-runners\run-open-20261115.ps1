﻿Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:PYTHONIOENCODING = 'utf-8'; $log = 'C:\kon-migration\pr-archive\run-open-20261115.log'
foreach ($r in Get-Content C:\kon-migration\pr-archive\repos-open-20261115.txt) {
  "[$(Get-Date -Format 'HH:mm:ss')] $r" | Add-Content $log -Encoding utf8
  & C:\kon-migration\tools\python\python.exe -I C:\kon-migration\scripts\pr-archive-comments.py --repo $r --open-only --apply --per-hour 400 2>&1 | ForEach-Object { "  $_" } | Add-Content $log -Encoding utf8
}
"[$(Get-Date -Format 'HH:mm:ss')] === ALL DONE ===" | Add-Content $log -Encoding utf8
