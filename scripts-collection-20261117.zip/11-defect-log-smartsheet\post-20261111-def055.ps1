# 11 Nov 2026 (Gareth: "post in DEF-055"). Comment only - status not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-055' = 'Fixed: the placeholder (mannequin) authors and reviewers are linked to their Teciem accounts across all of tcm-pilot - linking applies to every repository at once (767 of 1,157 placeholders linked; the rest have no Teciem account to link to: deleted Finastra accounts, people without a Teciem account, non-Finastra accounts). Checked 11 Nov in OPICS-opics4plus and OPICS-opicsbat: in the latest 150 pull requests every person (author and reviewer) now shows as their Teciem account, e.g. Rohit Soni, Aman Sahoo, Vignesh N, Ranjeev Bohara, Renuka Dakannagari, Anish Yadav; searching author:Rohit-Soni_tciem finds 267 PRs, the old rohit-soni_finastra none. The only placeholder left is "Copilot" (GitHub''s automatic code-review bot from fin-tcm), which cannot be linked to a person. Pages opened before the fix may still show "GitHubArchive\..." - please reload (Ctrl+F5) and retest.'
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
