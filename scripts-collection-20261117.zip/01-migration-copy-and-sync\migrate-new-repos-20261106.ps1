﻿# Migrates the 14 repos created in fin-tcm since 2 Nov (nightly report: NOT_IN_TARGET) to tcm-pilot, then gives them
# the same setup as earlier batches: LFS objects, team + direct-collaborator access, rulesets/branch protection, autolinks.
# Only creates new repos and adds settings to them; touches no existing repo. Log: C:\kon-migration\gei-new-20261106\run.log
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GH_SOURCE_PAT = $env:GH_SRC_PAT; $env:GH_PAT = $env:GH_TGT_PAT
$out = "C:\kon-migration\gei-new-20261106"; New-Item -ItemType Directory -Force $out | Out-Null; $log = "$out\run.log"
function Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Host $l; Add-Content $log $l -Encoding utf8 }
$ht = @{ Authorization = "Bearer $env:GH_TGT_PAT" }
$repos = 'KON-test-repo','KQ-dabirska','KQ-rp-triage-plugin','pipeline-app','pipeline-bom','pipeline-core-starter','pipeline-pack','pipeline-umbrella',
         'SUM-summit-Pipelines','taw-e2e-live','taw-license','taw-mcp-starter','taw-packs','TCMLIB-spring-boot-upgrade-fleet'
$res = foreach ($r in $repos) {
  $exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$r" -Headers $ht; $true } catch { $false }
  if ($exists) { Log "$r already in tcm-pilot - skipped"; [pscustomobject]@{ Repo = $r; Result = 'already there' }; continue }
  $t0 = Get-Date
  $o = gh gei migrate-repo --github-source-org fin-tcm --source-repo $r --github-target-org tcm-pilot --target-repo $r --target-repo-visibility private 2>&1 | ForEach-Object { "$_" }
  $ok = $LASTEXITCODE -eq 0
  Log ("{0,-36} GEI {1} in {2:N1} min {3}" -f $r, $(if ($ok) { 'OK' } else { 'FAILED' }), ((Get-Date) - $t0).TotalMinutes, (($o | Select-String 'warning encountered|ERROR' | Select-Object -First 2) -join ' '))
  [pscustomobject]@{ Repo = $r; Name = $r; Result = $(if ($ok) { 'OK' } else { 'FAILED' }); State = $(if ($ok) { 'SUCCEEDED' } else { 'FAILED' }) }
}
$res | Export-Csv "$out\results.csv" -NoTypeInformation -Encoding utf8
$done = @($res | Where-Object Result -eq 'OK' | ForEach-Object Repo)
if (-not $done.Count) { Log "nothing migrated"; return }
Log "--- LFS"; & C:\kon-migration\scripts\lfs-copy.ps1 -Results "$out\results.csv" -Extra @() -Work "$out\lfs" *>&1 | Select-Object -Last 5 | ForEach-Object { Log "  $_" }
Log "--- access"; & C:\kon-migration\scripts\new-repos-access.ps1 -Repos $done -Out $out -Apply *>&1 | Select-Object -Last 5 | ForEach-Object { Log "  $_" }
Log "--- rules"; & C:\kon-migration\scripts\rules-sync.ps1 -Repos $done -Apply *>&1 | Select-Object -Last 5 | ForEach-Object { Log "  $_" }
Log "--- autolinks"; & C:\kon-migration\scripts\autolinks-copy-missing.ps1 -Repos $done -Apply *>&1 | Select-Object -Last 3 | ForEach-Object { Log "  $_" }
Log "=== done: $($done.Count) of $($repos.Count) migrated ==="
