# Completes a release that release-sync.ps1 created but whose asset upload was cut off (11 Nov: ARC-comparison-engine
# ibfs-latest, 34 of 49 assets uploaded before "connection closed"). Adds only the assets missing in tcm-pilot (by name);
# uploads that broke leave no asset or a non-"uploaded" one - those are deleted and uploaded again. Retries 3 times.
param([string]$Repo = 'ARC-comparison-engine', [string]$Tag = 'ibfs-latest')
$ErrorActionPreference = 'Continue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$s = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }
$t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$logFile = 'C:\kon-migration\rules\release-sync.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
$tmp = Join-Path $env:TEMP 'release-assets-resume'; New-Item -ItemType Directory -Force $tmp | Out-Null
$src = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$Repo/releases/tags/$Tag" -Headers $s
$rel = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$Repo/releases/tags/$Tag" -Headers $t
$have = @{}; foreach ($a in $rel.assets) { if ($a.state -eq 'uploaded') { $have[$a.name] = $true } else {
  Invoke-RestMethod -Method DELETE "https://api.github.com/repos/tcm-pilot/$Repo/releases/assets/$($a.id)" -Headers $t | Out-Null; Write-Log "  $Repo $Tag : removed broken asset $($a.name) ($($a.state))" } }
$missing = @($src.assets | Where-Object { -not $have[$_.name] })
Write-Log "  $Repo $Tag : resume - $($missing.Count) of $($src.assets.Count) assets missing"
$fail = 0
foreach ($a in $missing) {
  $file = Join-Path $tmp $a.name; $ok = $false
  for ($i = 1; $i -le 3 -and -not $ok; $i++) {
    try {
      Invoke-WebRequest $a.url -Headers @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/octet-stream' } -OutFile $file -UseBasicParsing
      $up = ($rel.upload_url -replace '\{.*\}$', '') + '?name=' + [uri]::EscapeDataString($a.name) + $(if ($a.label) { '&label=' + [uri]::EscapeDataString($a.label) } else { '' })
      Invoke-RestMethod -Method POST $up -Headers $t -ContentType $(if ($a.content_type) { $a.content_type } else { 'application/octet-stream' }) -InFile $file -TimeoutSec 3600 | Out-Null
      $ok = $true; Write-Log ("    uploaded {0} ({1:N0} MB)" -f $a.name, ($a.size / 1MB))
    } catch {
      Write-Log "    try $i $($a.name): $($_.Exception.Message)"
      $cur = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$Repo/releases/$($rel.id)" -Headers $t
      $cur.assets | Where-Object { $_.name -eq $a.name } | ForEach-Object { Invoke-RestMethod -Method DELETE "https://api.github.com/repos/tcm-pilot/$Repo/releases/assets/$($_.id)" -Headers $t | Out-Null }
    }
  }
  if (-not $ok) { $fail++ }
  Remove-Item $file -ErrorAction SilentlyContinue
}
$final = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$Repo/releases/$($rel.id)" -Headers $t
Write-Log "  $Repo $Tag : resume done - $(@($final.assets | Where-Object state -eq 'uploaded').Count) of $($src.assets.Count) assets, $fail failed"
