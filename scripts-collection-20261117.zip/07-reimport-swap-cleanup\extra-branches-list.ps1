# 16 Nov 2026 (DEF-261/262/265; Gareth: "OK to all" - list first, for review). READ-ONLY.
# Branches present in tcm-pilot but not in fin-tcm (= deleted in Finastra after migration; delta syncs never delete).
# Excludes our own namespaces (fin-tcm-pr/*, fin-tcm-kept/*), dependabot/*, archived and -ri/-old/-r2 working copies.
# Records the tcm-pilot tip so a later delete can verify nothing moved. Output: C:\kon-migration\branch-cleanup\extra-branches-<stamp>.csv
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$tgt = @{ Authorization = "Bearer $env:GH_TGT_PAT" }; $env:GIT_TERMINAL_PROMPT = '0'
$dir = 'C:\kon-migration\branch-cleanup'; New-Item -ItemType Directory -Force $dir | Out-Null
$repos = New-Object System.Collections.ArrayList; $p = 1
do { $n = 0; Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/repos?type=all&per_page=100&page=$p" -Headers $tgt | ForEach-Object { $_ } | ForEach-Object { [void]$repos.Add($_); $n++ }; $p++ } while ($n -eq 100)
$repos = @($repos | Where-Object { -not $_.archived -and $_.name -notmatch '-(ri|old\d*|r2-ri|pr2)$' })
function Get-Heads($org, $repo, $b64) {
  $o = git -c "http.extraHeader=Authorization: Basic $b64" ls-remote --heads "https://github.com/$org/$repo.git" 2>$null
  if ($LASTEXITCODE) { return $null }
  $h = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
  foreach ($l in $o) { $sha, $ref = $l -split "`t", 2; $h[$ref.Substring(11)] = $sha }; $h
}
$rows = New-Object System.Collections.ArrayList; $i = 0
foreach ($r in $repos) {
  $i++; if ($i % 200 -eq 0) { Write-Output "$i / $($repos.Count)" }
  $t = Get-Heads 'tcm-pilot' $r.name $tb; $s = Get-Heads 'fin-tcm' $r.name $sb
  if ($null -eq $t -or $null -eq $s) { [void]$rows.Add([pscustomobject]@{ Repo = $r.name; Branch = ''; TcmPilotSha = ''; Note = 'could not list (repo missing in fin-tcm?)' }); continue }
  foreach ($b in $t.Keys) {
    if ($s.ContainsKey($b) -or $b -like 'fin-tcm-pr/*' -or $b -like 'fin-tcm-kept/*' -or $b -like 'dependabot/*' -or $b -eq $r.default_branch) { continue }
    [void]$rows.Add([pscustomobject]@{ Repo = $r.name; Branch = $b; TcmPilotSha = $t[$b]; Note = '' })
  }
}
$f = Join-Path $dir "extra-branches-$(Get-Date -Format yyyyMMdd-HHmm).csv"; $rows | Export-Csv $f -NoTypeInformation -Encoding utf8
$b = @($rows | Where-Object Branch)
"repos checked: $($repos.Count); extra branches: $($b.Count) in $(@($b.Repo | Sort-Object -Unique).Count) repos; not listable: $(@($rows | Where-Object Note).Count)"
"detail: $f"
