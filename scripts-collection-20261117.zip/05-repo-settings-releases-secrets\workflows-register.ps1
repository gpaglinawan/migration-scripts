param(
  [string[]]$Repos,                      # default: every non-archived tcm-pilot repo
  [string]$Org = "tcm-pilot",
  [string]$Branch = "migration-register-workflows",
  [string]$Out = "C:\kon-migration\actions\workflows-register",
  [switch]$Apply
)
# GH-039: workflow files came across with GEI but GitHub only registers workflows when it processes a push.
# For each repo with workflow files that aren't registered, creates a temporary branch at the default branch head
# (a push event) and deletes it again. Only done where no workflow would run because of it:
#   unsafe triggers = create, delete, check_run, check_suite, status, or push without a branch filter that
#   excludes the temporary branch. Repos with unsafe or unparseable workflows are skipped and listed.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "register-$(if($Apply){'apply'}else{'plan'}).log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

function GlobMatch($pattern, $name) {
  $p = $pattern.Trim().Trim("'`"")
  $neg = $p.StartsWith('!'); if ($neg) { $p = $p.Substring(1) }
  $rx = '^' + ([regex]::Escape($p) -replace '\\\*\\\*', '.*' -replace '\\\*', '[^/]*' -replace '\\\?', '.') + '$'
  return @{ Neg = $neg; Hit = ($name -match $rx) }
}
function ListValues($lines, [int]$start, [int]$indent) {
  # values of a YAML key either inline "[a, b]" / "a" or as a following "- a" block
  $vals = @(); $first = $lines[$start]
  if ($first -match ':\s*\[(.*)\]\s*$') { return @($Matches[1].Split(',') | ForEach-Object { $_.Trim().Trim("'`"") } | Where-Object { $_ }) }
  if ($first -match ':\s*([^\s#\[][^#]*)$') { return @($Matches[1].Trim().Trim("'`"")) }
  for ($i = $start + 1; $i -lt $lines.Count; $i++) {
    $l = $lines[$i]; if ($l -match '^\s*(#.*)?$') { continue }
    $ind = $l.Length - $l.TrimStart().Length; if ($ind -le $indent) { break }
    if ($l -match '^\s*-\s*(.+?)\s*(#.*)?$') { $vals += $Matches[1].Trim("'`"") }
  }
  $vals
}
# returns "safe", or the reason the workflow would (or might) run on the temporary branch
function Check-Workflow([string]$text) {
  $lines = $text -split "`r?`n"
  # some files indent the whole document: measure levels from the top-level indentation
  $base = (@($lines | Where-Object { $_ -notmatch '^\s*(#.*)?$' -and $_ -notmatch '^\s*---' } | ForEach-Object { $_.Length - $_.TrimStart().Length }) | Measure-Object -Minimum).Minimum
  if ($null -eq $base) { $base = 0 }
  $onIdx = -1; for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match ('^\s{' + $base + '}["'']?(on|true)["'']?\s*:')) { $onIdx = $i; break } }
  if ($onIdx -lt 0) { return "no 'on:' found" }
  $unsafe = 'create', 'delete', 'check_run', 'check_suite', 'status'
  $rest = ($lines[$onIdx] -replace '^[^:]+:\s*', '' -replace '\s#.*$', '').Trim()
  if ($rest) {
    $events = @($rest.Trim('[', ']').Split(',') | ForEach-Object { $_.Trim().Trim("'`"") })
    foreach ($e in $events) { if ($e -eq 'push' -or $unsafe -contains $e) { return "on: $e" } }
    return "safe"
  }
  # block form: events are the keys one level in
  $evIndent = -1
  for ($i = $onIdx + 1; $i -lt $lines.Count; $i++) {
    $l = $lines[$i]; if ($l -match '^\s*(#.*)?$') { continue }
    $ind = $l.Length - $l.TrimStart().Length; if ($ind -le $base) { break }
    if ($evIndent -lt 0) { $evIndent = $ind }
    if ($ind -ne $evIndent) { continue }
    if ($l -match '^\s*-\s*(\w+)') { $ev = $Matches[1]; if ($ev -eq 'push' -or $unsafe -contains $ev) { return "on: $ev" }; continue }
    if ($l -notmatch '^\s*["'']?([\w-]+)["'']?\s*:') { return "unparsed line: $($l.Trim())" }
    $ev = $Matches[1]
    if ($unsafe -contains $ev) { return "on: $ev" }
    if ($ev -ne 'push') { continue }
    # push: find its filters
    $br = $null; $brIgn = $null; $hasTags = $false
    for ($j = $i + 1; $j -lt $lines.Count; $j++) {
      $m = $lines[$j]; if ($m -match '^\s*(#.*)?$') { continue }
      $mind = $m.Length - $m.TrimStart().Length; if ($mind -le $evIndent) { break }
      if ($m -match '^\s*branches\s*:') { $br = @(ListValues $lines $j $mind) }
      elseif ($m -match '^\s*branches-ignore\s*:') { $brIgn = @(ListValues $lines $j $mind) }
      elseif ($m -match '^\s*tags(-ignore)?\s*:') { $hasTags = $true }
    }
    if ($null -ne $br) {
      $hit = $false; foreach ($p in $br) { $g = GlobMatch $p $Branch; if ($g.Hit) { $hit = -not $g.Neg } }
      if ($hit) { return "push branches match $Branch" }
    } elseif ($null -ne $brIgn) {
      $ign = $false; foreach ($p in $brIgn) { if ((GlobMatch $p $Branch).Hit) { $ign = $true } }
      if (-not $ign) { return "push branches-ignore doesn't exclude $Branch" }
    } elseif (-not $hasTags) { return "on: push (all branches)" }
  }
  return "safe"
}

# 1. repos and their workflow files (GraphQL, 25 repos per query)
if (-not $Repos) {
  $Repos = @(); $cursor = $null
  do {
    $q = 'query($c:String){ organization(login:"' + $Org + '"){ repositories(first:100, after:$c){ pageInfo{hasNextPage endCursor} nodes{ name isArchived isEmpty } } } }'
    $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hdr -Body (@{ query = $q; variables = @{ c = $cursor } } | ConvertTo-Json -Depth 5) -ContentType application/json
    $pg = $r.data.organization.repositories
    foreach ($n in $pg.nodes) { if (-not $n.isArchived -and -not $n.isEmpty) { $Repos += $n.name } }
    $cursor = $pg.pageInfo.endCursor
  } while ($pg.pageInfo.hasNextPage)
}
Log "=== workflow registration $Org : $($Repos.Count) repos, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="
$files = @{}
for ($i = 0; $i -lt $Repos.Count; $i += 25) {
  $chunk = $Repos[$i..([Math]::Min($i + 24, $Repos.Count - 1))]; $parts = @(); $k = 0
  foreach ($n in $chunk) { $parts += ('r{0}: repository(owner:"{1}", name:"{2}"){{ name defaultBranchRef{{ name target{{ oid }} }} object(expression:"HEAD:.github/workflows"){{ ... on Tree{{ entries{{ name type object{{ ... on Blob{{ text }} }} }} }} }} }}' -f $k, $Org, $n); $k++ }
  try { $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hdr -Body (@{ query = "{ $($parts -join ' ') }" } | ConvertTo-Json) -ContentType application/json }
  catch { Log "  GraphQL chunk at $i failed: $($_.Exception.Message)"; continue }
  foreach ($p in $r.data.PSObject.Properties) {
    $v = $p.Value; if (-not $v -or -not $v.object) { continue }
    $wf = @($v.object.entries | Where-Object { $_.type -eq 'blob' -and $_.name -match '\.ya?ml$' })
    if ($wf.Count) { $files[$v.name] = @{ Head = $v.defaultBranchRef.target.oid; Default = $v.defaultBranchRef.name; Files = $wf } }
  }
}
Log "repos with workflow files: $($files.Count)"

# 2. per repo: registered vs files, trigger safety, then register
$rows = New-Object System.Collections.ArrayList
foreach ($name in ($files.Keys | Sort-Object)) {
  $info = $files[$name]; $api = "https://api.github.com/repos/$Org/$name"
  $reg = @{}; try { foreach ($w in (Invoke-RestMethod "$api/actions/workflows?per_page=100" -Headers $hdr).workflows) { $reg[$w.path] = $true } } catch {}
  $missing = @($info.Files | Where-Object { -not $reg[".github/workflows/$($_.name)"] })
  $row = [pscustomobject]@{ Repo = $name; Files = $info.Files.Count; Registered = $reg.Count; Missing = $missing.Count; Result = ""; Reason = ""; RegisteredAfter = ""; DisabledSchedules = "" }
  if (-not $missing.Count) { $row.Result = "already-registered"; [void]$rows.Add($row); continue }
  $why = @(); foreach ($f in $info.Files) { $c = Check-Workflow ([string]$f.object.text); if ($c -ne "safe") { $why += "$($f.name): $c" } }
  if ($why.Count) { $row.Result = "skipped-unsafe"; $row.Reason = $why -join ' | '; [void]$rows.Add($row); Log "  $name : skipped ($($why[0]))"; continue }
  if (-not $Apply) { $row.Result = "would-register"; [void]$rows.Add($row); continue }
  # GitHub only indexes workflows on a push to the DEFAULT branch, and a new ref on an existing commit isn't a push.
  # So: temp branch with an empty commit (same tree) -> make it default -> push a 2nd empty commit -> restore the
  # default -> delete the temp branch. The real default branch is never touched, so it stays identical to Finastra.
  $tree = $null; $switched = $false
  try {
    $tree = (Invoke-RestMethod "$api/git/commits/$($info.Head)" -Headers $hdr).tree.sha
    $msg = "Register workflows after migration (temporary branch, deleted)"
    $c1 = Invoke-RestMethod -Method POST "$api/git/commits" -Headers $hdr -ContentType application/json -Body (@{ message = $msg; tree = $tree; parents = @($info.Head) } | ConvertTo-Json)
    Invoke-RestMethod -Method POST "$api/git/refs" -Headers $hdr -ContentType application/json -Body (@{ ref = "refs/heads/$Branch"; sha = $c1.sha } | ConvertTo-Json) | Out-Null
    Invoke-RestMethod -Method PATCH $api -Headers $hdr -ContentType application/json -Body (@{ default_branch = $Branch } | ConvertTo-Json) | Out-Null; $switched = $true
    $c2 = Invoke-RestMethod -Method POST "$api/git/commits" -Headers $hdr -ContentType application/json -Body (@{ message = $msg; tree = $tree; parents = @($c1.sha) } | ConvertTo-Json)
    Invoke-RestMethod -Method PATCH "$api/git/refs/heads/$Branch" -Headers $hdr -ContentType application/json -Body (@{ sha = $c2.sha } | ConvertTo-Json) | Out-Null
    $n = 0; for ($w = 0; $w -lt 9; $w++) { Start-Sleep -Seconds 5; try { $n = (Invoke-RestMethod "$api/actions/workflows?per_page=1" -Headers $hdr).total_count } catch {}; if ($n -ge $info.Files.Count) { break } }
    $row.Result = "registered"; Log "  $name : registered ($n workflows)"
  } catch { $row.Result = "failed"; $row.Reason = "$($_.Exception.Message) $($_.ErrorDetails.Message)"; Log "  $name : FAILED $($row.Reason)" }
  finally {
    if ($switched) { try { Invoke-RestMethod -Method PATCH $api -Headers $hdr -ContentType application/json -Body (@{ default_branch = $info.Default } | ConvertTo-Json) | Out-Null }
      catch { $row.Result = "RESTORE-DEFAULT-FAILED"; Log "  $name : !!! could not restore default branch $($info.Default)" } }
    if ($row.Result -ne "RESTORE-DEFAULT-FAILED") { try { Invoke-RestMethod -Method DELETE "$api/git/refs/heads/$Branch" -Headers $hdr | Out-Null } catch {} }
    # GitHub-managed runs (CodeQL default setup, dependency graph) start on the temp branch: cancel them
    try { foreach ($run in (Invoke-RestMethod "$api/actions/runs?branch=$Branch&per_page=20" -Headers $hdr).workflow_runs) { try { Invoke-RestMethod -Method POST "$api/actions/runs/$($run.id)/cancel" -Headers $hdr | Out-Null } catch {} } } catch {}
  }
  [void]$rows.Add($row)
}
# 3. re-check registrations (GitHub processes the push asynchronously)
if ($Apply) {
  Start-Sleep -Seconds 30
  foreach ($row in ($rows | Where-Object Result -eq 'registered')) {
    try { $wfs = Invoke-RestMethod "https://api.github.com/repos/$Org/$($row.Repo)/actions/workflows?per_page=100" -Headers $hdr; $row.RegisteredAfter = $wfs.total_count } catch { continue }
    # scheduled workflows would now run here as well as in Finastra: disable them until cutover
    $sched = @($files[$row.Repo].Files | Where-Object { ([string]$_.object.text) -match '(?m)^\s+schedule\s*:' } | ForEach-Object { ".github/workflows/$($_.name)" })
    $off = @(); foreach ($w in $wfs.workflows) { if ($sched -contains $w.path -and $w.state -eq 'active') {
      try { Invoke-RestMethod -Method PUT "https://api.github.com/repos/$Org/$($row.Repo)/actions/workflows/$($w.id)/disable" -Headers $hdr | Out-Null; $off += $w.path } catch { Log "  $($row.Repo) : could not disable $($w.path)" } } }
    $row.DisabledSchedules = $off -join ' '
    if ($off.Count) { Log "  $($row.Repo) : disabled $($off.Count) scheduled workflows until cutover" }
  }
}
$csv = Join-Path $Out "register-$(if($Apply){'apply'}else{'plan'}).csv"
$rows | Export-Csv $csv -NoTypeInformation -Encoding utf8
$rows | Group-Object Result | ForEach-Object { Log ("  {0,-20} {1}" -f $_.Name, $_.Count) }
Log "=== done: $csv ==="
