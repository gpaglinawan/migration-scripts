# 14 Nov 2026 - GIT-020C for copies built on another VM (Samar's): no local run.log, so everything is read from GitHub.
# Per repo: PR numbers fin-tcm vs copy vs current repo (GraphQL), and every branch/tag commit fin-tcm vs copy (ls-remote).
# Read-only. Appends to C:\kon-migration\swap\git-020c-verify.csv. Usage: .\verify-remote.ps1 -Repos a,b -Suffix ri
param([Parameter(Mandatory)][string[]]$Repos, [string]$Suffix = 'ri')
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'; $py = 'C:\kon-migration\tools\python\python.exe'; $diff = 'C:\kon-migration\scripts\pr-numbers-diff.py'
function Get-Refs($b64, $url) { @(git -c "http.extraHeader=Authorization: Basic $b64" ls-remote --heads --tags $url 2>$null | Where-Object { $_ -notmatch '\^\{\}$' } | ForEach-Object { $_ -replace "`t", ' ' } | Sort-Object) }
$have = @{}; if (Test-Path C:\kon-migration\swap\git-020c-verify.csv) { Import-Csv C:\kon-migration\swap\git-020c-verify.csv | ForEach-Object { $have[$_.Copy] = 1 } }
foreach ($r in $Repos) {
  $copy = "$r-$Suffix"; if ($have[$copy]) { continue }
  $cp = (& $py -I $diff "fin-tcm/$r" "tcm-pilot/$copy" 2>$null | Select-Object -First 1) -replace '.*: (\d+) PRs; .*: (\d+); missing (\d+)', '$1|$2|$3'
  $cu = (& $py -I $diff "fin-tcm/$r" "tcm-pilot/$r" 2>$null | Select-Object -First 1) -replace '.*: (\d+) PRs; .*: (\d+); missing (\d+)', '$2'
  $a = $cp -split '\|'
  $s = Get-Refs $sb "https://github.com/fin-tcm/$r.git"; $t = Get-Refs $tb "https://github.com/tcm-pilot/$copy.git"
  $miss = @($s | Where-Object { $_ -notin $t }).Count; $extra = @($t | Where-Object { $_ -notin $s }).Count
  $refs = if ($Suffix -eq 'pr2') { "$($t.Count) refs (rewritten history - commit IDs differ by design)" } else { "$($s.Count - $miss)/$($s.Count) identical, $extra extra in copy" }
  $v = if ($a.Count -lt 3) { 'CHECK: PR count failed' } elseif ($a[2] -ne '0') { "CHECK: $($a[2]) PRs missing" } elseif ($Suffix -ne 'pr2' -and $miss) { "CHECK: $miss refs differ" } else { 'READY (all PRs) after LFS check' }
  [pscustomobject]@{ Repo = $r; Copy = $copy; SrcPRs = $a[0]; CopyPRs = $a[1]; CurrentPRs = $cu; Refs = $refs; PRsIdentical = '(built on Samar''s VM)'; LFS = 'to check'; Verdict = $v; Time = (Get-Date).ToString('s') } |
    Tee-Object -Variable row | Export-Csv C:\kon-migration\swap\git-020c-verify.csv -NoTypeInformation -Encoding utf8 -Append
  "{0,-34} PRs {1}/{2} (current {3})  refs {4}  -> {5}" -f $copy, $a[1], $a[0], $cu, $refs, $v
}
