# 13 Nov 2026 (cutover, GIT-019B / GIT-020B; Gareth: "yes 1"). Runs pr-preload.ps1 for a list of repos, N at a time,
# each into a NEW repo <repo>-<Suffix> in tcm-pilot and a NEW work folder (never reuses an earlier run's state).
# Unlike pr-preload-to-pilot.ps1 it does NOT edit the read-only rulesets: run it only after the rulesets exclude
# the pattern "*-<Suffix>" (set once by Gareth before the batch), so parallel runs on two VMs can't undo each other.
# Per-repo options kept from run-batch.ps1 (SFX path rename, MAFTP-fpp-vaas-che null gitlinks).
# Usage: .\run-list.ps1 -List .\samar-reimport.txt -Suffix ri -Parallel 3
#        .\run-list.ps1 -List .\samar-lfs.txt -Suffix pr2 -Parallel 3
param([Parameter(Mandatory)][string]$List, [Parameter(Mandatory)][ValidateSet('ri','pr2')][string]$Suffix,
      [int]$Parallel = 3, [string]$WorkRoot = "C:\kon-migration\pr-preload\cutover-20261113")
$ErrorActionPreference = 'Stop'
$renames = @{ 'SFX-netcore-common' = 'QuickFixn/.git/:QuickFixn/_git/' }
$nullGitlinks = @('MAFTP-fpp-vaas-che')
$repos = @(Get-Content $List | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
New-Item -ItemType Directory -Force $WorkRoot | Out-Null
$log = Join-Path $WorkRoot "batch-$Suffix-$env:COMPUTERNAME.log"
function Write-BatchLog($m) { $l = "[{0:yyyy-MM-dd HH:mm}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
Write-BatchLog "=== $($repos.Count) repos, suffix -$Suffix, $Parallel at a time, from $List ==="
$queue = [System.Collections.Queue]::new($repos); $running = @{}
while ($queue.Count -or $running.Count) {
  while ($queue.Count -and $running.Count -lt $Parallel) {
    $r = $queue.Dequeue(); $work = Join-Path $WorkRoot "$r-$Suffix"
    $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "$PSScriptRoot\pr-preload.ps1", '-Repo', $r, '-TargetOrg', 'tcm-pilot', '-TargetName', "$r-$Suffix", '-Work', $work)
    if ($renames[$r]) { $a += @('-PathRename', $renames[$r]) }; if ($r -in $nullGitlinks) { $a += '-DropNullGitlinks' }
    $running[$r] = @{ P = (Start-Process powershell -ArgumentList $a -PassThru -WindowStyle Hidden); T = Get-Date; Work = $work }
    Write-BatchLog "start $r -> tcm-pilot/$r-$Suffix"
  }
  Start-Sleep 30
  foreach ($r in @($running.Keys)) { $j = $running[$r]; if ($j.P.HasExited) {
    $last = Get-Content (Join-Path $j.Work 'run.log') -Tail 4 -ErrorAction SilentlyContinue | Where-Object { $_ -match 'STOP|===|identical|verify' } | Select-Object -Last 1
    Write-BatchLog ("end   {0} after {1:N0} min, exit {2}: {3}" -f $r, ((Get-Date) - $j.T).TotalMinutes, $j.P.ExitCode, $last); $running.Remove($r) } }
}
Write-BatchLog "=== batch done ==="
