# 15 Nov 2026 - KON-kondor-enablement: Finastra branch versions are >2 GB in one push (GitHub limit). Same purpose and
# approval as preserve-refs-bypass.ps1 (Gareth "yes to 1"): adds refs/heads/fin-tcm-kept/<branch> only, moving it forward
# along the branch's first-parent history in steps so each push stays small. Repo rulesets get the migration-sync bypass for
# the run and are restored in finally.
param([string]$Repo = 'KON-kondor-enablement', [int]$Step = 150)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $A = 'https://api.github.com'
$tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT")); $env:GIT_TERMINAL_PROMPT = '0'
$url = "https://github.com/tcm-pilot/$Repo.git"; $d = "C:\kon-migration\refs\preserve-work\$Repo.git"; $csv = 'C:\kon-migration\refs\preserved-refs.csv'; $log = 'C:\kon-migration\nightly\cutover-20261113.log'
function Remote-Sha($ref) { ((git -c "http.extraHeader=Authorization: Basic $tb" ls-remote $url $ref) -split "`t")[0] }
$todo = @(Import-Csv $csv | Where-Object Repo -eq $Repo | Group-Object KeptAs | ForEach-Object { $_.Group[-1] } | Where-Object { $_.Result -ne 'PUSHED' })
$sets = @(Invoke-RestMethod "$A/repos/tcm-pilot/$Repo/rulesets?includes_parents=false" -Headers $gh | ForEach-Object { $_ } | ForEach-Object { Invoke-RestMethod "$A/repos/tcm-pilot/$Repo/rulesets/$($_.id)" -Headers $gh })
$orig = @{}; foreach ($s in $sets) { $orig[$s.id] = @($s.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } }) }
try {
  foreach ($s in $sets) { $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$Repo/rulesets/$($s.id)" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = @($orig[$s.id] + @(@{ actor_id = 20591252; actor_type = 'Team'; bypass_mode = 'always' })) } | ConvertTo-Json -Depth 6) }
  Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') $Repo : bypass added to $($sets.Count) repo ruleset(s) for chunked fin-tcm-kept pushes" -Encoding utf8
  foreach ($r in $todo) {
    $src = "refs/src/$($r.Ref -replace '^refs/','')"; $tip = git -C $d rev-parse $src
    $chain = @(git -C $d rev-list --first-parent --reverse $tip); $res = 'PUSHED'
    for ($k = $Step - 1; $k -lt $chain.Count + $Step - 1; $k += $Step) {
      $c = $chain[[Math]::Min($k, $chain.Count - 1)]
      $o = @(git -C $d -c http.postBuffer=524288000 -c "http.extraHeader=Authorization: Basic $tb" push --porcelain $url "$($c):$($r.KeptAs)" 2>&1 | ForEach-Object { "$_" })
      if ((Remote-Sha $r.KeptAs) -ne $c) { $res = "FAILED at commit $([Math]::Min($k, $chain.Count - 1) + 1)/$($chain.Count): " + (($o | Where-Object { $_ -match '^!|error' } | Select-Object -First 2) -join ' | '); break }
      "  $($r.KeptAs): $([Math]::Min($k + 1, $chain.Count))/$($chain.Count)"
    }
    if ($res -eq 'PUSHED' -and (Remote-Sha $r.KeptAs) -ne $tip) { $res = 'FAILED: tip not reached' }
    [pscustomobject]@{ Repo = $Repo; Ref = $r.Ref; Issue = $r.Issue; FinastraCommit = $r.FinastraCommit; TeciemCommit = $r.TeciemCommit; KeptAs = $r.KeptAs; Result = $res; At = (Get-Date -Format 'yyyy-MM-dd HH:mm') } | Export-Csv $csv -Append -NoTypeInformation -Encoding utf8
    "$($r.KeptAs) : $res"
  }
} finally {
  foreach ($s in $sets) { try { $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$Repo/rulesets/$($s.id)" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = $orig[$s.id] } | ConvertTo-Json -Depth 6) } catch { Add-Content $log "!! RESTORE FAILED $Repo ruleset $($s.id)" -Encoding utf8 } }
  Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') $Repo : repo ruleset bypass lists restored" -Encoding utf8
}
