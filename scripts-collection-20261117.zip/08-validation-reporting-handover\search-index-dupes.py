# 15 Nov 2026 - read-only: lists every PR GitHub's SEARCH INDEX returns for a repo (sliced by created month so each
# slice stays under the 1,000-result search cap), then compares with the real PR list (REST). Shows whether the search
# count is inflated by the same PR numbers being indexed more than once. Usage: search-index-dupes.py <org> <repo> <token-env>
import json, os, sys, time, urllib.request, urllib.parse, collections, datetime
org, repo, tokenv = sys.argv[1], sys.argv[2], sys.argv[3]; tok = os.environ[tokenv]
def get(url):
    for a in range(6):
        try:
            r = urllib.request.Request(url, headers={'Authorization': f'Bearer {tok}', 'Accept': 'application/vnd.github+json'})
            return json.load(urllib.request.urlopen(r, timeout=120))
        except urllib.error.HTTPError as e:
            if e.code in (403, 429): time.sleep(30 * (a + 1)); continue
            raise
real, page = set(), 1
while True:
    b = get(f'https://api.github.com/repos/{org}/{repo}/pulls?state=all&per_page=100&page={page}'); real |= {p['number'] for p in b}
    if len(b) < 100: break
    page += 1
hits = collections.Counter(); total_search = 0
d = datetime.date(2008, 1, 1); end = datetime.date.today() + datetime.timedelta(days=1)
while d < end:
    n = (d.replace(day=28) + datetime.timedelta(days=4)).replace(day=1)
    q = urllib.parse.quote(f'repo:{org}/{repo} is:pr created:{d}..{n - datetime.timedelta(days=1)}')
    first = get(f'https://api.github.com/search/issues?q={q}&per_page=100&page=1'); cnt = first['total_count']; total_search += cnt
    items = first['items']; p = 2
    while len(items) < min(cnt, 1000):
        more = get(f'https://api.github.com/search/issues?q={q}&per_page=100&page={p}')['items']
        if not more: break
        items += more; p += 1; time.sleep(2)
    for it in items: hits[it['number']] += 1
    if cnt > 1000: print(f'  {d:%Y-%m}: {cnt} results (over the 1,000 cap - slice further)')
    d = n; time.sleep(2)
dupes = {k: v for k, v in hits.items() if v > 1}; notreal = set(hits) - real
print(f'{org}/{repo}: real PRs {len(real)}; search index sum of monthly counts {total_search}; distinct numbers in search {len(hits)}')
print(f'  numbers returned more than once by search: {len(dupes)} (extra hits {sum(v - 1 for v in dupes.values())})')
print(f'  numbers in search that are not real PRs: {len(notreal)}; real PRs search never returned: {len(real - set(hits))}')
print('  sample duplicates:', sorted(dupes)[:15])
