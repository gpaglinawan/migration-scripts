# 16 Nov 2026 (DEF-280 / DEF-107; Gareth: "2. ok"). KON-kplus-front was imported with its history rewritten for large files; the import
# dropped reviews and review comments it could not attach to the rewritten commits (e.g. #39043: 27 reviews in Finastra, 1 in tcm-pilot).
# This copies ONLY the missing ones into each affected PR as an "Archived discussion from Finastra GitHub" comment (author, date,
# verdict, file and line; @mentions and #refs neutralised - nobody is notified). Idempotent: PRs that already have a "missing reviews"
# archive comment are skipped. Read-only on fin-tcm.
#   step 1 (always): GraphQL counts per PR (reviews, review threads) in both orgs, 50 PRs per query -> candidates where Finastra has more
#   step 2: per candidate, REST details both sides; missing = source review (state+date+body) / comment (date+body) with no match
# Usage: pr-missing-reviews-archive.py --repo KON-kplus-front [--apply] [--limit N]
import argparse, json, os, re, sys, time, urllib.request, urllib.error, csv
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
ap = argparse.ArgumentParser(); ap.add_argument('--repo', required=True); ap.add_argument('--apply', action='store_true'); ap.add_argument('--limit', type=int, default=0)
a = ap.parse_args()
S, T = os.environ['GH_SRC_PAT'], os.environ['GH_TGT_PAT']
MARK = 'Archived discussion from Finastra GitHub'; SUB = 'reviews not carried over by the import'
OUT = rf'C:\kon-migration\pr-archive\missing-reviews-{a.repo}.csv'
def call(url, tok, method='GET', body=None):
    for att in range(10):
        try:
            r = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body is not None else None,
                                       headers={'Authorization': f'Bearer {tok}', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'})
            t = urllib.request.urlopen(r, timeout=120).read(); return json.loads(t) if t else None
        except urllib.error.HTTPError as e:
            if e.code in (403, 429, 502, 503, 504) and att < 9:
                ra = e.headers.get('Retry-After') if e.headers else None
                time.sleep(int(ra) + 5 if ra and ra.isdigit() else 60 * (att + 1)); continue
            raise
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
            if att < 9: time.sleep(60 * (att + 1)); continue
            raise
def pages(url, tok):
    out, p = [], 1
    while True:
        b = call(f'{url}{"&" if "?" in url else "?"}per_page=100&page={p}', tok) or []; out += b
        if len(b) < 100: return out
        p += 1
def counts(org, tok):
    res, cur = {}, None
    q = 'query($o:String!,$n:String!,$c:String){repository(owner:$o,name:$n){pullRequests(first:50,after:$c){pageInfo{hasNextPage endCursor} nodes{number reviews{totalCount} reviewThreads{totalCount}}}}}'
    while True:
        d = call('https://api.github.com/graphql', tok, 'POST', {'query': q, 'variables': {'o': org, 'n': a.repo, 'c': cur}})
        pr = d['data']['repository']['pullRequests']
        for n in pr['nodes']: res[n['number']] = (n['reviews']['totalCount'], n['reviewThreads']['totalCount'])
        if not pr['pageInfo']['hasNextPage']: return res
        cur = pr['pageInfo']['endCursor']
ZW = '\u200b'
def safe(t):
    t = re.sub(r'@(?=[A-Za-z0-9])', '@' + ZW, t or ''); return re.sub(r'(?<![\w/&])#(?=\d)', '#' + ZW, t)
def quote(t): return '\n'.join('> ' + l for l in safe(t).splitlines()) or '> (empty)'
def day(s): return (s or '')[:16].replace('T', ' ') + ' UTC' if s else ''
print('counting reviews in both orgs ...', flush=True)
src, tgt = counts('fin-tcm', S), counts('tcm-pilot', T)
cand = sorted(n for n, (r, th) in src.items() if n in tgt and (r > tgt[n][0] or th > tgt[n][1]))
print(f'PRs: fin-tcm {len(src)}, tcm-pilot {len(tgt)}; with fewer reviews or review threads in tcm-pilot: {len(cand)}', flush=True)
if a.limit: cand = cand[:a.limit]
rows, posted, base_s, base_t = [], 0, f'https://api.github.com/repos/fin-tcm/{a.repo}', f'https://api.github.com/repos/tcm-pilot/{a.repo}'
for n in cand:
    sr = pages(f'{base_s}/pulls/{n}/reviews', S); tr = pages(f'{base_t}/pulls/{n}/reviews', T)
    sc = pages(f'{base_s}/pulls/{n}/comments', S); tc = pages(f'{base_t}/pulls/{n}/comments', T)
    tkeys = {((x.get('submitted_at') or '')[:19], x.get('state'), (x.get('body') or '').strip()) for x in tr}
    ckeys = {((x.get('created_at') or '')[:19], (x.get('body') or '').strip()) for x in tc}
    mr = [x for x in sr if ((x.get('submitted_at') or '')[:19], x.get('state'), (x.get('body') or '').strip()) not in tkeys and x.get('state') != 'PENDING']
    mc = [x for x in sc if ((x.get('created_at') or '')[:19], (x.get('body') or '').strip()) not in ckeys]
    rows.append({'PR': n, 'SourceReviews': len(sr), 'TargetReviews': len(tr), 'MissingReviews': len(mr), 'SourceReviewComments': len(sc), 'TargetReviewComments': len(tc), 'MissingReviewComments': len(mc), 'Posted': ''})
    if not mr and not mc: continue
    existing = pages(f'{base_t}/issues/{n}/comments', T)
    if any(MARK in (c.get('body') or '') and SUB in (c.get('body') or '') for c in existing): rows[-1]['Posted'] = 'already'; continue
    items = [(x.get('submitted_at') or '', f"**`{(x.get('user') or {}).get('login', 'ghost')}`** review: **{x['state'].replace('_', ' ').lower()}**, {day(x.get('submitted_at'))}" + (f"\n\n{quote(x.get('body'))}" if (x.get('body') or '').strip() else '')) for x in mr]
    items += [(x.get('created_at') or '', f"**`{(x.get('user') or {}).get('login', 'ghost')}`** on `{x.get('path')}`" + (f" line {x.get('line') or x.get('original_line')}" if (x.get('line') or x.get('original_line')) else '') + f", {day(x.get('created_at'))}\n\n{quote(x.get('body'))}") for x in mc]
    items.sort(key=lambda i: i[0])
    head = (f"### {MARK} ({SUB})\nThese {len(mr)} review(s) and {len(mc)} review comment(s) from Finastra PR #{ZW}{n} were not brought across by the "
            f"import (it could not attach them to the rewritten commits), so they are copied here (copied {time.strftime('%d %b %Y').lstrip('0')}). "
            f"Authors are shown with their Finastra login; nobody is notified.\n\n---\n")
    parts, cur = [], head
    for _, it in items:
        blk = it + '\n\n---\n'
        if len(cur) + len(blk) > 60000: parts.append(cur); cur = f"### {MARK} ({SUB}), continued\n\n---\n"
        cur += blk[:59800]
    parts.append(cur)
    if a.apply:
        for p in parts: call(f'{base_t}/issues/{n}/comments', T, 'POST', {'body': p}); time.sleep(9); posted += 1
        rows[-1]['Posted'] = str(len(parts))
    print(f'#{n}: missing reviews {len(mr)}, review comments {len(mc)}' + (' -> posted' if a.apply else ''), flush=True)
with open(OUT, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ['PR']); w.writeheader(); w.writerows(rows)
tot_r = sum(r['MissingReviews'] for r in rows); tot_c = sum(r['MissingReviewComments'] for r in rows)
print(f'done: candidates {len(cand)}, PRs with missing items {sum(1 for r in rows if r["MissingReviews"] or r["MissingReviewComments"])}, '
      f'missing reviews {tot_r}, missing review comments {tot_c}, comments posted {posted} -> {OUT}')
