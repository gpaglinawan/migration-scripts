# 15 Nov 2026 (Gareth: DEF-246 - recreate ADO PR history like DEF-244, test first). Recreates COMPLETED and ABANDONED
# pull requests of a Finastra (TreasuryCapitalMarkets) repo in a tcm-staging repo, as records with the original title,
# description and changes:
#   completed : temp branches mig-pr/<n>-base = Finastra's lastMergeTargetCommit, mig-pr/<n>-head = lastMergeCommit (the
#               merge or squash commit, already in the copied history); PR head -> base, then COMPLETED; temp branches deleted.
#   abandoned : base = lastMergeTargetCommit, head = lastMergeSourceCommit (fetched from Finastra if not in the copy);
#               PR created then ABANDONED; temp branches deleted.
# Each PR description starts with "Migrated from TreasuryCapitalMarkets PR !<n> (<status>) by <author> ..." and a link.
# Not copied: comments, votes, reviewers, linked work items, original author/dates. Idempotent (marker lookup).
# The temp branches are created through the REST refs API; pipelines with CI triggers on all branches WOULD start - only
# run against repos whose pipelines were checked. Dry run unless -Apply.
param([string]$SourceProject = 'Terraform', [Parameter(Mandatory)][string]$SourceRepo, [Parameter(Mandatory)][string]$TargetProject,
      [string]$TargetRepo = $SourceRepo, [string[]]$States = @('completed', 'abandoned'), [int]$Max = 0, [switch]$Apply)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_PAT|AZDO_SOURCE_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$sb64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_SOURCE_PAT")); $tb64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT"))
$src = @{ Authorization = "Basic $sb64" }; $tgt = @{ Authorization = "Basic $tb64" }
$S = "https://dev.azure.com/TreasuryCapitalMarkets/$([uri]::EscapeDataString($SourceProject))/_apis/git/repositories/$([uri]::EscapeDataString($SourceRepo))"
$T = "https://dev.azure.com/tcm-staging/$([uri]::EscapeDataString($TargetProject))/_apis/git/repositories/$([uri]::EscapeDataString($TargetRepo))"
$Tgit = "https://dev.azure.com/tcm-staging/$([uri]::EscapeDataString($TargetProject))/_git/$([uri]::EscapeDataString($TargetRepo))"
$Sgit = "https://dev.azure.com/TreasuryCapitalMarkets/$([uri]::EscapeDataString($SourceProject))/_git/$([uri]::EscapeDataString($SourceRepo))"
$Z = '0000000000000000000000000000000000000000'
function Get-AllPrs($base, $hdr, $status) { $all = @(); $skip = 0; while ($true) { $r = Invoke-RestMethod "$base/pullrequests?searchCriteria.status=$status&`$top=500&`$skip=$skip&api-version=7.1" -Headers $hdr; $all += @($r.value); if ($r.count -lt 500) { break }; $skip += 500 }; $all }
function Test-Commit($sha) { try { $null = Invoke-RestMethod "$T/commits/$sha`?api-version=7.1" -Headers $tgt -ErrorAction Stop; $true } catch { $false } }
function Set-Refs($updates) { Invoke-RestMethod -Method Post "$T/refs?api-version=7.1" -Headers $tgt -ContentType application/json -Body (ConvertTo-Json -Depth 4 @($updates)) }
$src_prs = @(foreach ($st in $States) { Get-AllPrs $S $src $st }) | Sort-Object pullRequestId
if ($Max) { $src_prs = $src_prs | Select-Object -First $Max }
$done = @{}; $stuck = @{}
foreach ($p in (Get-AllPrs $T $tgt 'all')) { if ("$($p.description)" -match 'Migrated from TreasuryCapitalMarkets PR !(\d+)') { if ($p.status -eq 'active') { $stuck[[int]$Matches[1]] = $p.pullRequestId } else { $done[[int]$Matches[1]] = $p.pullRequestId } } }
function Wait-Merge($id) {   # ADO prepares the merge asynchronously; completing before it is ready is silently ignored
  for ($i = 0; $i -lt 45; $i++) { $c = Invoke-RestMethod "$T/pullrequests/$id`?api-version=7.1" -Headers $tgt; if ($c.mergeStatus -in 'succeeded', 'conflicts', 'failure', 'rejectedByPolicy') { return $c }; Start-Sleep 2 }
  Invoke-RestMethod "$T/pullrequests/$id`?api-version=7.1" -Headers $tgt
}
function Complete-Pr($id, $headSha) {
  $c = Wait-Merge $id
  if ($c.mergeStatus -ne 'succeeded') { return "merge status $($c.mergeStatus)" }
  $null = Invoke-RestMethod -Method Patch "$T/pullrequests/$id`?api-version=7.1" -Headers $tgt -ContentType application/json -Body (@{ status = 'completed'; lastMergeSourceCommit = @{ commitId = $c.lastMergeSourceCommit.commitId }; completionOptions = @{ mergeStrategy = 'noFastForward'; deleteSourceBranch = $false; mergeCommitMessage = 'Migrated PR' } } | ConvertTo-Json -Depth 4)
  for ($i = 0; $i -lt 45; $i++) { Start-Sleep 2; $c = Invoke-RestMethod "$T/pullrequests/$id`?api-version=7.1" -Headers $tgt; if ($c.status -eq 'completed') { return 'completed' } }
  "status $($c.status) (merge $($c.mergeStatus))"
}
$work = "C:\kon-migration\ado-pr-history-test\work-$TargetProject-$TargetRepo.git"; $rows = New-Object System.Collections.ArrayList
foreach ($sp in $src_prs) {
  $n = $sp.pullRequestId; $d = Invoke-RestMethod "$S/pullrequests/$n`?api-version=7.1" -Headers $src
  $row = [pscustomobject]@{ PR = $n; Status = $d.status; Title = $d.title; Author = $d.createdBy.displayName; Closed = "$($d.closedDate)".Substring(0, [Math]::Min(10, "$($d.closedDate)".Length)); NewPR = ''; Result = '' }
  if ($done[$n]) { $row.NewPR = $done[$n]; $row.Result = 'EXISTS'; [void]$rows.Add($row); continue }
  $base = $d.lastMergeTargetCommit.commitId; $head = if ($d.status -eq 'completed') { $d.lastMergeCommit.commitId } else { $d.lastMergeSourceCommit.commitId }
  if (-not $base -or -not $head) { $row.Result = 'SKIP: Finastra has no commit ids for this PR'; [void]$rows.Add($row); continue }
  $needFetch = -not (Test-Commit $head) -or -not (Test-Commit $base)
  if (-not $Apply) { $row.Result = 'would create' + $(if ($needFetch) { ' (needs commits from Finastra)' } else { '' }); [void]$rows.Add($row); continue }
  $bn = "refs/heads/mig-pr/$n-base"; $hn = "refs/heads/mig-pr/$n-head"; $finished = $false
  try {
    if ($stuck[$n]) {   # created by an earlier run but not completed: put the temp branches back and complete it
      foreach ($pair in @(@($bn, $base), @($hn, $head))) { $cur = (Invoke-RestMethod "$T/refs?filter=$($pair[0] -replace '^refs/','')&api-version=7.1" -Headers $tgt).value | Where-Object name -eq $pair[0]; if (-not $cur) { $null = Set-Refs @(@{ name = $pair[0]; oldObjectId = $Z; newObjectId = $pair[1] }) } }
      $row.NewPR = $stuck[$n]
      if ($d.status -eq 'completed') { $r = Complete-Pr $stuck[$n] $head; $row.Result = "REPAIRED $r"; $finished = ($r -eq 'completed') }
      else { $null = Invoke-RestMethod -Method Patch "$T/pullrequests/$($stuck[$n])?api-version=7.1" -Headers $tgt -ContentType application/json -Body (@{ status = 'abandoned' } | ConvertTo-Json); $row.Result = 'REPAIRED abandoned'; $finished = $true }
      [void]$rows.Add($row); continue
    }
    if ($needFetch) {   # bring the missing commits over with git (object push to the temp refs only)
      if (-not (Test-Path $work)) { git init --bare -q $work }
      git -C $work -c "http.extraHeader=Authorization: Basic $sb64" fetch -q $Sgit $head $base 2>&1 | Out-Null
      if ($LASTEXITCODE) { throw 'commits no longer exist in Finastra' }
      git -C $work -c "http.extraHeader=Authorization: Basic $tb64" push -q $Tgit "$($base):$bn" "$($head):$hn" 2>&1 | Out-Null
      if ($LASTEXITCODE) { throw 'push of temp branches failed' }
    } else { $null = Set-Refs @(@{ name = $bn; oldObjectId = $Z; newObjectId = $base }, @{ name = $hn; oldObjectId = $Z; newObjectId = $head }) }
    $link = "https://dev.azure.com/TreasuryCapitalMarkets/$([uri]::EscapeDataString($SourceProject))/_git/$([uri]::EscapeDataString($SourceRepo))/pullrequest/$n"
    $desc = "> Migrated from TreasuryCapitalMarkets PR !$n ($($d.status) $($row.Closed)) by $($d.createdBy.displayName), originally $($d.sourceRefName -replace '^refs/heads/','') -> $($d.targetRefName -replace '^refs/heads/',''): $link`n> Comments, votes, reviewers and linked work items are not copied - see the original.`n`n$($d.description)"
    if ($desc.Length -gt 3990) { $desc = $desc.Substring(0, 3990) + '...' }
    $new = Invoke-RestMethod -Method Post "$T/pullrequests?api-version=7.1" -Headers $tgt -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes((@{ sourceRefName = $hn; targetRefName = $bn; title = $d.title; description = $desc } | ConvertTo-Json)))
    $row.NewPR = $new.pullRequestId
    if ($d.status -eq 'completed') {
      $r = Complete-Pr $new.pullRequestId $head; $row.Result = if ($r -eq 'completed') { 'CREATED completed' } else { "CREATED but $r" }; $finished = ($r -eq 'completed')
    } else {
      $null = Invoke-RestMethod -Method Patch "$T/pullrequests/$($new.pullRequestId)?api-version=7.1" -Headers $tgt -ContentType application/json -Body (@{ status = 'abandoned' } | ConvertTo-Json)
      $row.Result = 'CREATED abandoned'; $finished = $true
    }
  } catch { $row.Result = "FAILED: $($_.Exception.Message) $((($_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue).message))" }
  finally {   # remove the temp branches once the PR is completed/abandoned (the PR record keeps their names); a PR left
              # active keeps its branches so the next run can repair it
    if ($Apply -and $finished) { foreach ($rn in $bn, $hn) { try { $cur = (Invoke-RestMethod "$T/refs?filter=$($rn -replace '^refs/','')&api-version=7.1" -Headers $tgt).value | Where-Object name -eq $rn; if ($cur) { $null = Set-Refs @(@{ name = $rn; oldObjectId = $cur.objectId; newObjectId = $Z }) } } catch { } } }
  }
  [void]$rows.Add($row)
}
$f = "C:\kon-migration\ado-nightly\ado-history-pr-$TargetProject-$TargetRepo-$(Get-Date -Format yyyyMMdd-HHmm).csv"; $rows | Export-Csv $f -NoTypeInformation -Encoding utf8
"source PRs ($($States -join '/')): $($rows.Count)"; $rows | Group-Object { ($_.Result -split '[:(]')[0].Trim() } | ForEach-Object { "  {0,-20} {1}" -f $_.Name, $_.Count }
$rows | Where-Object { $_.Result -like 'FAILED*' -or $_.Result -like 'SKIP*' -or $_.Result -like '*status*' } | ForEach-Object { "  !$($_.PR): $($_.Result)" }
"detail: $f"
