param(
  [string]$SrcOrg = "fin-tcm-archive",
  [string]$TgtOrg = "fin-tcm-archive-pilot",
  [string]$MapFile = "C:\kon-migration\archive-access\fin-tcm-archive-member-map.csv",
  [switch]$Apply
)
# Mirrors read access to the archive org: Finastra members of fin-tcm-archive become members of the Teciem archive org
# (base permission read), and the fin-tcm-archive / fin-tcm-archive_r teams are recreated with the same members and repos.
# Owners are added as plain members (owner role left to a person). Only adds; never removes anyone.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
$ht = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$log = "C:\kon-migration\archive-access\mirror-$(Get-Date -Format yyyyMMdd-HHmmss).log"
function Log($m) { $m; if ($Apply) { Add-Content $log $m } }
function P($u, $h) { $acc = @(); $p = 1; do { $r = @(Invoke-RestMethod "https://api.github.com/$u$(if($u -match '\?'){'&'}else{'?'})per_page=100&page=$p" -Headers $h) | ForEach-Object { $_ }; $acc += $r; $p++ } while ($r.Count -eq 100); $acc }

$map = @{}; Import-Csv $MapFile | Where-Object Target | ForEach-Object { $map[$_.Source.ToLower()] = $_.Target }
$have = @{}; P "orgs/$TgtOrg/members" $ht | ForEach-Object { $have[$_.login.ToLower()] = $true }

# 1. org membership
$added = 0; $failed = 0
foreach ($t in ($map.Values | Sort-Object -Unique)) {
  if ($have[$t.ToLower()]) { continue }
  if (-not $Apply) { $added++; continue }
  try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$TgtOrg/memberships/$t" -Headers $ht -ContentType application/json -Body '{"role":"member"}' | Out-Null; $added++; Log "member added $t" }
  catch { $failed++; Log "member FAILED $t : $($_.ErrorDetails.Message)" }
}
Log "org members $(if ($Apply) {'added'} else {'to add'}): $added, failed: $failed"

# 2. teams (parent first), same members and repo permissions
foreach ($slug in 'fin-tcm-archive', 'fin-tcm-archive_r') {
  $st = Invoke-RestMethod "https://api.github.com/orgs/$SrcOrg/teams/$slug" -Headers $hs
  $sm = P "orgs/$SrcOrg/teams/$slug/members" $hs
  $sr = P "orgs/$SrcOrg/teams/$slug/repos" $hs
  $exists = $true; try { Invoke-RestMethod "https://api.github.com/orgs/$TgtOrg/teams/$slug" -Headers $ht | Out-Null } catch { $exists = $false }
  if (-not $Apply) { Log "team $slug : exists=$exists, $($sm.Count) members, repos: $(($sr | ForEach-Object { "$($_.name)=$($_.role_name)" }) -join ', ')"; continue }
  if (-not $exists) {
    $body = @{ name = $st.name; description = $st.description; privacy = $st.privacy }
    if ($st.parent) { $body.parent_team_id = (Invoke-RestMethod "https://api.github.com/orgs/$TgtOrg/teams/$($st.parent.slug)" -Headers $ht).id }
    Invoke-RestMethod -Method POST "https://api.github.com/orgs/$TgtOrg/teams" -Headers $ht -ContentType application/json -Body ($body | ConvertTo-Json) | Out-Null
    Log "team created $slug"
  }
  $n = 0; foreach ($u in $sm) { $t = $map[$u.login.ToLower()]; if (-not $t) { continue }
    try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$TgtOrg/teams/$slug/memberships/$t" -Headers $ht -ContentType application/json -Body '{"role":"member"}' | Out-Null; $n++ } catch { Log "team $slug member FAILED $t : $($_.ErrorDetails.Message)" } }
  Log "team $slug : $n members set"
  foreach ($r in $sr) {
    try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$TgtOrg/teams/$slug/repos/$TgtOrg/$($r.name)" -Headers $ht -ContentType application/json -Body (@{ permission = @{ read = 'pull'; write = 'push' }[$r.role_name] + $(if ($r.role_name -notin 'read','write') { $r.role_name }) } | ConvertTo-Json) | Out-Null; Log "team $slug repo $($r.name) = $($r.role_name)" }
    catch { Log "team $slug repo FAILED $($r.name) : $($_.ErrorDetails.Message)" }
  }
}
if ($Apply) { "log: $log" }
