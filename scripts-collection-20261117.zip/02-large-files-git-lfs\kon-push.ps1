param(
  [string]$Repo   = "C:\kon-migration\kon-kplus-front-lfs.git",
  [string]$Target = "https://github.com/tcm-pilot/kon-kplus-front.git",
  [string]$Out    = "C:\kon-migration\kon-push",
  [string]$Trunk  = "master",
  [int]$Steps     = 20,
  [int]$Batch     = 200
)
# Pushes the rewritten repo to the target in chunks (GitHub rejects single pushes > 2 GB).
# Order: LFS objects first, then trunk history in steps, then branches and tags in batches. No force pushes.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"([^"]*)"') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GIT_CONFIG_COUNT   = "1"
$env:GIT_CONFIG_KEY_0   = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = "0"

New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "push.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Push([string[]]$specs) {
  $o = git -C $Repo push --porcelain $Target @specs 2>&1 | ForEach-Object { "$_" }
  $rc = $LASTEXITCODE
  # only real problems: rejected refs and server/client errors (not branch names that contain "error")
  $o | Where-Object { $_ -match '^!\t|^error:|^fatal:|remote: (error|fatal)' } | Select-Object -First 10 | ForEach-Object { Log "   $_" }
  return $rc
}
$t0 = Get-Date
Log "=== push $Repo -> $Target ==="

# 1. LFS objects, by OID (avoids scanning 12k refs)
$oids = @(Get-ChildItem (Join-Path $Repo "lfs\objects") -Recurse -File | ForEach-Object Name)
Log "1. LFS: pushing $($oids.Count) objects"
if ($oids.Count) {
  git -C $Repo config lfs.url "$Target/info/lfs"
  git -C $Repo lfs push --object-id $Target @oids *>&1 | Select-Object -Last 3 | ForEach-Object { Log "   $_" }
  if ($LASTEXITCODE -ne 0) { Log "FATAL: LFS push failed"; exit 1 }
}

# 2. trunk in steps along first-parent history, halving the step on failure
$chain = @(git -C $Repo rev-list --first-parent --reverse $Trunk)
Log "2. $Trunk : $($chain.Count) first-parent commits, $Steps steps"
$step = [Math]::Max(1, [Math]::Ceiling($chain.Count / $Steps)); $pos = 0; $pushed = -1
# resume: if the target trunk already points into this history (e.g. a push that succeeded server-side but timed out
# client-side), continue after it instead of re-pushing older commits (which would be rejected as non-fast-forward)
$remoteTip = ((git ls-remote $Target "refs/heads/$Trunk") -split "`t")[0]
if ($remoteTip) { $at = [array]::IndexOf($chain, $remoteTip); if ($at -ge 0) { $pushed = $at; Log "   target $Trunk already at $($at + 1)/$($chain.Count) - resuming" } }
while ($pushed -lt $chain.Count - 1) {
  $pos = [Math]::Min($pushed + $step, $chain.Count - 1)
  $t = Get-Date
  $rc = Push @("$($chain[$pos]):refs/heads/$Trunk")
  if ($rc -eq 0) { $pushed = $pos; Log ("   {0}/{1} ok in {2:N0}s" -f ($pos+1), $chain.Count, ((Get-Date)-$t).TotalSeconds); continue }
  # a large push can time out client-side yet succeed on the server: check where the target really is
  $now = [array]::IndexOf($chain, ((git ls-remote $Target "refs/heads/$Trunk") -split "`t")[0])
  if ($now -gt $pushed) { $pushed = $now; Log ("   push reported failure but target is at {0}/{1} - continuing" -f ($now+1), $chain.Count) }
  elseif ($step -gt 1) { $step = [Math]::Max(1, [Math]::Floor($step / 2)); Log "   push failed at $($pos+1), step -> $step" }
  else { Log "FATAL: cannot push commit $($chain[$pos])"; exit 1 }
}

# 3. remaining branches, then tags, in batches
foreach ($ns in 'refs/heads','refs/tags') {
  $localSha = @{}; git -C $Repo for-each-ref --format="%(objectname) %(refname)" $ns | ForEach-Object { $p = $_.Split(' '); $localSha[$p[1]] = $p[0] }
  $remoteSha = @{}; git ls-remote $Target "$ns/*" | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notmatch '\^\{\}$') { $remoteSha[$p[1]] = $p[0] } }
  # resume: only refs not already on the target with the same SHA
  $refs = @($localSha.Keys | Where-Object { $_ -ne "refs/heads/$Trunk" -and $remoteSha[$_] -ne $localSha[$_] } | Sort-Object)
  Log "3. $ns : $($refs.Count) refs to push ($($localSha.Count - $refs.Count) already on target) in batches of $Batch"
  $failed = @()
  for ($i = 0; $i -lt $refs.Count; $i += $Batch) {
    $chunk = $refs[$i..([Math]::Min($i + $Batch - 1, $refs.Count - 1))]
    $rc = Push @($chunk | ForEach-Object { "${_}:${_}" })
    if ($rc -ne 0) {
      # a batch can time out client-side yet land on the server: re-read the target, retry only what is really missing
      $remoteSha = @{}; git ls-remote $Target "$ns/*" | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notmatch '\^\{\}$') { $remoteSha[$p[1]] = $p[0] } }
      $still = @($chunk | Where-Object { $remoteSha[$_] -ne $localSha[$_] })
      if ($still.Count) { Log "   batch reported failure; $($still.Count) of $($chunk.Count) refs really missing - retrying those" }
      foreach ($r in $still) { if ((Push @("${r}:${r}")) -ne 0) { $failed += $r } }
    }
    Log ("   {0}/{1}" -f [Math]::Min($i + $Batch, $refs.Count), $refs.Count)
  }
  if ($failed.Count) { $failed | Out-File (Join-Path $Out "failed-$($ns.Replace('/','-')).txt") -Encoding utf8; Log "   FAILED refs: $($failed.Count)" }
}

# 4. verify: every local ref exists on the target with the same SHA
$local = @{}; git -C $Repo for-each-ref --format="%(objectname) %(refname)" refs/heads refs/tags | ForEach-Object { $p = $_.Split(' '); $local[$p[1]] = $p[0] }
$remote = @{}; git ls-remote $Target 'refs/heads/*' 'refs/tags/*' | ForEach-Object { $p = $_ -split "`t"; if ($p[1] -notmatch '\^\{\}$') { $remote[$p[1]] = $p[0] } }
$missing = @($local.Keys | Where-Object { $remote[$_] -ne $local[$_] })
Log "4. verify: local refs=$($local.Count) target refs=$($remote.Count) mismatched/missing=$($missing.Count)"
if ($missing.Count) { $missing | Out-File (Join-Path $Out "verify-missing.txt") -Encoding utf8 }
Log ("=== done in {0:N0} min ===" -f ((Get-Date)-$t0).TotalMinutes)
exit $missing.Count
