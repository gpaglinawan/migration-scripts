param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out    = "C:\kon-migration\rules"
)
# Read-only: inventories org rulesets, repo rulesets and classic branch protection rules in both orgs (GraphQL,
# 40 repos per call) and writes rules-compare.csv with per-repo counts, plus full JSON of every source ruleset
# and branch protection rule for the later copy step.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$Hdr = @{ $SrcOrg = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json" }
          $TgtOrg = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" } }
New-Item -ItemType Directory -Force $Out, (Join-Path $Out "src-repo-rulesets"), (Join-Path $Out "src-branch-protection") | Out-Null

function Gql($org, $query) {
  for ($a = 1; ; $a++) {
    try { return Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $Hdr[$org] -Body (@{ query = $query } | ConvertTo-Json -Compress) -ContentType application/json }
    catch { if ($a -ge 4) { Write-Warning "GraphQL failed for ${org}: $($_.Exception.Message)"; return $null }; Start-Sleep (10 * $a) }
  }
}
function Rest($org, $uri) { try { Invoke-RestMethod $uri -Headers $Hdr[$org] } catch { $null } }

# org-level rulesets
foreach ($org in $SrcOrg, $TgtOrg) {
  $rs = @(Rest $org "https://api.github.com/orgs/$org/rulesets?per_page=100")
  $full = foreach ($r in $rs) { if ($r.id) { Rest $org "https://api.github.com/orgs/$org/rulesets/$($r.id)" } }
  $full | ConvertTo-Json -Depth 30 | Set-Content (Join-Path $Out "org-rulesets-$org.json") -Encoding utf8
  "{0}: org rulesets={1} {2}" -f $org, @($full).Count, ((@($full) | ForEach-Object { "$($_.name)[$($_.enforcement)/$($_.target)]" }) -join ', ')
}

# per-repo counts
$counts = @{}
foreach ($org in $SrcOrg, $TgtOrg) {
  $names = (Import-Csv "C:\kon-migration\refs\$org-repos.csv").Name
  for ($i = 0; $i -lt $names.Count; $i += 40) {
    $chunk = $names[$i..([Math]::Min($i + 39, $names.Count - 1))]
    $q = "query{"; $j = 0
    foreach ($n in $chunk) { $q += "r${j}:repository(owner:`"$org`",name:`"$n`"){name rulesets(first:1){totalCount} branchProtectionRules(first:1){totalCount}} "; $j++ }
    $q += "}"
    $res = Gql $org $q
    if (-not $res) { continue }
    foreach ($p in $res.data.PSObject.Properties) { $v = $p.Value; if ($v) { $counts["$org|$($v.name.ToLower())"] = @($v.rulesets.totalCount, $v.branchProtectionRules.totalCount) } }
  }
  "{0}: repos scanned={1}" -f $org, @($counts.Keys | Where-Object { $_ -like "$org|*" }).Count
}

# compare + export full source definitions where present
$rows = New-Object System.Collections.ArrayList
foreach ($n in (Import-Csv "C:\kon-migration\refs\$SrcOrg-repos.csv").Name) {
  $k = $n.ToLower(); $s = $counts["$SrcOrg|$k"]; $t = $counts["$TgtOrg|$k"]
  if (-not $s) { continue }
  $inTarget = [bool]$t
  if ($s[0] -gt 0) { $list = Rest $SrcOrg "https://api.github.com/repos/$SrcOrg/$n/rulesets?includes_parents=false&per_page=100"
                     $full = foreach ($r in @($list)) { if ($r.id) { Rest $SrcOrg "https://api.github.com/repos/$SrcOrg/$n/rulesets/$($r.id)" } }
                     $full | ConvertTo-Json -Depth 30 | Set-Content (Join-Path $Out "src-repo-rulesets\$n.json") -Encoding utf8 }
  if ($s[1] -gt 0) { $q = "query{repository(owner:`"$SrcOrg`",name:`"$n`"){branchProtectionRules(first:100){nodes{pattern isAdminEnforced allowsDeletions allowsForcePushes blocksCreations dismissesStaleReviews lockBranch requireLastPushApproval requiredApprovingReviewCount requiresApprovingReviews requiresCodeOwnerReviews requiresCommitSignatures requiresConversationResolution requiresLinearHistory requiresStatusChecks requiresStrictStatusChecks restrictsPushes restrictsReviewDismissals requiredStatusCheckContexts bypassPullRequestAllowances(first:100){nodes{actor{__typename ... on Team{slug} ... on User{login} ... on App{slug}}}} pushAllowances(first:100){nodes{actor{__typename ... on Team{slug} ... on User{login} ... on App{slug}}}} reviewDismissalAllowances(first:100){nodes{actor{__typename ... on Team{slug} ... on User{login} ... on App{slug}}}}}}}}"
                     $bp = Gql $SrcOrg $q
                     $bp.data.repository.branchProtectionRules.nodes | ConvertTo-Json -Depth 30 | Set-Content (Join-Path $Out "src-branch-protection\$n.json") -Encoding utf8 }
  if ($s[0] + $s[1] -eq 0 -and (-not $t -or $t[0] + $t[1] -eq 0)) { continue }
  [void]$rows.Add([pscustomobject]@{ Repo = $n; InTarget = $inTarget; SrcRulesets = $s[0]; TgtRulesets = $(if ($t) { $t[0] }); SrcBranchProtection = $s[1]; TgtBranchProtection = $(if ($t) { $t[1] }) })
}
$rows | Export-Csv (Join-Path $Out "rules-compare.csv") -NoTypeInformation -Encoding utf8
"repos with rules in source: rulesets=$(@($rows | Where-Object { [int]$_.SrcRulesets -gt 0 }).Count) branch-protection=$(@($rows | Where-Object { [int]$_.SrcBranchProtection -gt 0 }).Count)"
"  of those in target with fewer rulesets: $(@($rows | Where-Object { $_.InTarget -and [int]$_.TgtRulesets -lt [int]$_.SrcRulesets }).Count); fewer branch-protection rules: $(@($rows | Where-Object { $_.InTarget -and [int]$_.TgtBranchProtection -lt [int]$_.SrcBranchProtection }).Count)"
