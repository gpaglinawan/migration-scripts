﻿param(
  [string[]]$Repos,                      # default: every fin-tcm repo that has code scanning analyses
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out = "C:\kon-migration\code-scanning",
  [ValidateSet("inventory","upload","states")][string]$Step = "inventory",
  [string]$CommitMapDir = "C:\kon-migration",   # <repo>-lfs.git\filter-repo\commit-map for repos whose history was rewritten
  [switch]$Apply
)
# Migrates code scanning results fin-tcm -> tcm-pilot.
#  inventory : per repo, analyses (latest per ref/tool/category) and alert counts by state. Read-only.
#  upload    : downloads each latest analysis as SARIF and uploads it to the SAME commit/ref in the target
#              (commit SHAs are identical for GEI-migrated repos), recreating the alerts there.
#  states    : copies dismissals (reason + comment) from source alerts onto the matching target alerts
#              (same rule id + path + start line). Run after uploads have been processed.
# Target repos need Advanced Security / Code Security enabled for uploads to be accepted.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
New-Item -ItemType Directory -Force $Out, (Join-Path $Out "sarif") | Out-Null
$log = Join-Path $Out "code-scanning-$Step.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Paged($uri, $hdr) {
  $acc = New-Object System.Collections.ArrayList; $page = 1
  do { $n = 0; try { $r = Invoke-RestMethod "$uri$(if($uri -match '\?'){'&'}else{'?'})per_page=100&page=$page" -Headers $hdr; foreach ($x in $r) { if ($x) { [void]$acc.Add($x); $n++ } } } catch { break }; $page++ } while ($n -eq 100)
  $acc
}

if (-not $Repos) {
  # repos with code scanning alerts in the source org (org-level alert listing, any state)
  $set = @{}; foreach ($a in (Paged "https://api.github.com/orgs/$SrcOrg/code-scanning/alerts?state=open" $srcHdr)) { $set[$a.repository.name] = $true }
  foreach ($st in 'dismissed', 'fixed') { foreach ($a in (Paged "https://api.github.com/orgs/$SrcOrg/code-scanning/alerts?state=$st" $srcHdr)) { $set[$a.repository.name] = $true } }
  $Repos = @($set.Keys | Sort-Object)
}
Log "=== code scanning $Step : $($Repos.Count) repos, mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="

$rows = New-Object System.Collections.ArrayList
foreach ($r in $Repos) {
  $s = "https://api.github.com/repos/$SrcOrg/$r/code-scanning"; $t = "https://api.github.com/repos/$TgtOrg/$r/code-scanning"
  switch ($Step) {
    'inventory' {
      $an = Paged "$s/analyses" $srcHdr
      $latest = @($an | Group-Object { "$($_.ref)|$($_.tool.name)|$($_.category)" } | ForEach-Object { $_.Group | Sort-Object { [datetime]$_.created_at } -Descending | Select-Object -First 1 })
      $alerts = Paged "$s/alerts?state=open" $srcHdr; $dis = Paged "$s/alerts?state=dismissed" $srcHdr
      $tgtA = Paged "$t/alerts?state=open" $tgtHdr
      [void]$rows.Add([pscustomobject]@{ Repo = $r; Analyses = $an.Count; LatestToUpload = $latest.Count; Refs = (($latest.ref | Sort-Object -Unique) -join ' '); Tools = (($latest.tool.name | Sort-Object -Unique) -join ' ')
        SrcOpen = $alerts.Count; SrcDismissed = $dis.Count; TgtOpen = $tgtA.Count })
      Log ("  {0,-40} analyses={1,-4} to upload={2,-3} open={3,-4} dismissed={4,-4} target open={5}" -f $r, $an.Count, $latest.Count, $alerts.Count, $dis.Count, $tgtA.Count)
    }
    'upload' {
      # branch analyses only: PR merge refs (refs/pull/N/merge) point at merge commits that don't carry over
      $an = @(Paged "$s/analyses" $srcHdr | Where-Object { $_.ref -like 'refs/heads/*' })
      $latest = @($an | Group-Object { "$($_.ref)|$($_.tool.name)|$($_.category)" } | ForEach-Object { $_.Group | Sort-Object { [datetime]$_.created_at } -Descending | Select-Object -First 1 })
      # skip analyses of branches that no longer exist in the target (deleted in Finastra) before downloading them
      $tgtBranches = @{}; foreach ($b in (Paged "https://api.github.com/repos/$TgtOrg/$r/branches" $tgtHdr)) { $tgtBranches["refs/heads/$($b.name)"] = $true }
      $before = $latest.Count; $latest = @($latest | Where-Object { $tgtBranches[$_.ref] })
      if ($before -ne $latest.Count) { Log "  $r : $($before - $latest.Count) analyses skipped (branch no longer exists)" }
      # rewritten history (large files moved to LFS): translate source commit SHAs to the new ones
      $cmap = $null; $mf = Join-Path $CommitMapDir "$r-lfs.git\filter-repo\commit-map"
      if (Test-Path $mf) { $cmap = @{}; foreach ($l in [IO.File]::ReadLines($mf)) { $p = $l.Split(' '); if ($p.Count -eq 2 -and $p[0] -ne 'old') { $cmap[$p[0]] = $p[1] } }; Log "  $r : using commit map ($($cmap.Count) commits)" }
      foreach ($a in $latest) {
        $exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/$TgtOrg/$r/commits/$($a.commit_sha)" -Headers $tgtHdr -EA Stop; $true } catch { $false }
        if (-not $exists -and $cmap -and $cmap[$a.commit_sha]) { $a.commit_sha = $cmap[$a.commit_sha]; $exists = $true }
        if (-not $exists) {   # 16 Nov (DEF-249): rebuilt repos (LFS + mailmap rewrites) - find the same commit by committer date + message + author date
          $sc = Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$r/commits/$($a.commit_sha)" -Headers $srcHdr
          $d = [datetime]$sc.commit.committer.date; $since = $d.AddSeconds(-1).ToUniversalTime().ToString('s') + 'Z'; $until = $d.AddSeconds(1).ToUniversalTime().ToString('s') + 'Z'
          $hit = @(Invoke-RestMethod "https://api.github.com/repos/$TgtOrg/$r/commits?sha=$([uri]::EscapeDataString($a.ref -replace '^refs/heads/',''))&since=$since&until=$until&per_page=100" -Headers $tgtHdr -EA SilentlyContinue | ForEach-Object { $_ } | Where-Object { $_.commit.message -eq $sc.commit.message -and $_.commit.author.date -eq $sc.commit.author.date }) | Select-Object -First 1
          if (-not $hit) { Log "  $r : commit $($a.commit_sha.Substring(0,10)) not found in $TgtOrg - skipped"; continue }
          Log "  $r : commit $($a.commit_sha.Substring(0,10)) -> $($hit.sha.Substring(0,10)) (matched by date + message)"; $a.commit_sha = $hit.sha
        }
        $file = Join-Path $Out "sarif\$r-$($a.id).sarif"
        # large SARIF downloads drop the connection now and then: up to 3 attempts
        $got = $false
        for ($try = 1; $try -le 3 -and -not $got; $try++) {
          try { Invoke-WebRequest -UseBasicParsing "$s/analyses/$($a.id)" -Headers @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/sarif+json" } -OutFile $file -TimeoutSec 600; $got = $true }
          catch { if ($try -lt 3) { Start-Sleep (15 * $try) } }
        }
        if (-not $got) { Log "  $r : download $($a.id) FAILED after 3 attempts"; continue }
        if (-not $Apply) { Log "  $r : would upload $($a.tool.name) [$($a.category)] $($a.ref) @ $($a.commit_sha.Substring(0,10))"; continue }
        $bytes = [IO.File]::ReadAllBytes($file); $ms = New-Object IO.MemoryStream
        $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Compress); $gz.Write($bytes, 0, $bytes.Length); $gz.Close()
        $body = @{ commit_sha = $a.commit_sha; ref = $a.ref; sarif = [Convert]::ToBase64String($ms.ToArray()); tool_name = $a.tool.name } | ConvertTo-Json
        try { $u = Invoke-RestMethod -Method POST "$t/sarifs" -Headers $tgtHdr -Body $body -ContentType application/json; Log "  $r : uploaded $($a.tool.name) [$($a.category)] $($a.ref) -> $($u.id)" }
        catch { Log "  $r : upload FAILED $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" }
        Start-Sleep -Milliseconds 500
      }
    }
    'states' {
      $tgtAll = @(Paged "$t/alerts?state=open" $tgtHdr)
      $idx = @{}; foreach ($ta in $tgtAll) { $loc = $ta.most_recent_instance.location; $idx["$($ta.rule.id)|$($loc.path)|$($loc.start_line)"] = $ta }
      foreach ($sa in (Paged "$s/alerts?state=dismissed" $srcHdr)) {
        $loc = $sa.most_recent_instance.location; $k = "$($sa.rule.id)|$($loc.path)|$($loc.start_line)"; $ta = $idx[$k]
        if (-not $ta) { Log "  $r : no target alert for dismissed #$($sa.number) $k"; continue }
        if (-not $Apply) { Log "  $r : would dismiss #$($ta.number) ($($sa.dismissed_reason))"; continue }
        $comment = ("Migrated from fin-tcm #$($sa.number) dismissed by $($sa.dismissed_by.login): $($sa.dismissed_comment)").Substring(0, [Math]::Min(280, ("Migrated from fin-tcm #$($sa.number) dismissed by $($sa.dismissed_by.login): $($sa.dismissed_comment)").Length))
        try { Invoke-RestMethod -Method PATCH "$t/alerts/$($ta.number)" -Headers $tgtHdr -Body (@{ state = 'dismissed'; dismissed_reason = $sa.dismissed_reason; dismissed_comment = $comment } | ConvertTo-Json) -ContentType application/json | Out-Null; Log "  $r : dismissed #$($ta.number) ($($sa.dismissed_reason))" }
        catch { Log "  $r : dismiss #$($ta.number) FAILED $($_.ErrorDetails.Message)" }
      }
    }
  }
}
if ($Step -eq 'inventory') {
  $rows | Export-Csv (Join-Path $Out "inventory.csv") -NoTypeInformation -Encoding utf8
  Log ("repos={0} analyses to upload={1} source open alerts={2} source dismissed={3} target open alerts={4}" -f $rows.Count, ($rows | Measure-Object LatestToUpload -Sum).Sum, ($rows | Measure-Object SrcOpen -Sum).Sum, ($rows | Measure-Object SrcDismissed -Sum).Sum, ($rows | Measure-Object TgtOpen -Sum).Sum)
}
Log "=== done ==="
