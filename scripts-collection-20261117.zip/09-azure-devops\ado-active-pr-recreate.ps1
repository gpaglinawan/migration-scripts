# 15 Nov 2026 (Gareth: "ok fix it" - DEF-244/DEF-125/DEF-134). Recreates in tcm-staging every pull request that is still
# ACTIVE in Finastra's TreasuryCapitalMarkets org (ADO cannot import PR history between orgs). Same project/repo names,
# same source and target branch, title, draft flag; the description starts with a marker naming the original PR, author
# and date, plus a link. Comments, votes and linked work items are not copied (the original stays readable in Finastra).
# Additive only. Skips a PR when its source or target branch is missing in tcm-staging, or when tcm-staging already has an
# active PR for the same source -> target (ADO allows only one). Dry run unless -Apply.
# Output: C:\kon-migration\ado-nightly\ado-active-pr-recreate-<stamp>.csv
param([switch]$Apply)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_PAT|AZDO_SOURCE_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$src = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_SOURCE_PAT")) }
$tgt = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT")) }
$S = 'https://dev.azure.com/TreasuryCapitalMarkets'; $T = 'https://dev.azure.com/tcm-staging'
function Get-ActivePrs($base, $hdr, $projId, $repoId) {
  $all = @(); $skip = 0
  while ($true) {
    $r = Invoke-RestMethod "$base/$projId/_apis/git/repositories/$repoId/pullrequests?searchCriteria.status=active&`$top=500&`$skip=$skip&api-version=7.1" -Headers $hdr -ErrorAction Stop
    $all += @($r.value); if ($r.count -lt 500) { break }; $skip += 500
  }
  $all
}
$repos = (Invoke-RestMethod "$S/_apis/git/repositories?api-version=7.1" -Headers $src).value | Where-Object { -not $_.isDisabled }
$rows = New-Object System.Collections.ArrayList
foreach ($rp in $repos) {
  $prs = try { @(Get-ActivePrs $S $src $rp.project.id $rp.id) } catch { [void]$rows.Add([pscustomobject]@{ Project = $rp.project.name; Repo = $rp.name; PR = ''; Title = ''; Result = "SKIP: could not read source PRs ($($_.Exception.Response.StatusCode.value__))" }); continue }
  $prs = @($prs)   # 16 Nov (DEF-250): the try-expression unrolled a 1-PR result to a scalar with no .Count, so repos with exactly one active PR were skipped (21 PRs)
  if (-not $prs.Count) { continue }
  $tr = try { Invoke-RestMethod "$T/$([uri]::EscapeDataString($rp.project.name))/_apis/git/repositories/$([uri]::EscapeDataString($rp.name))?api-version=7.1" -Headers $tgt -ErrorAction Stop } catch { $null }
  if (-not $tr) { foreach ($p in $prs) { [void]$rows.Add([pscustomobject]@{ Project = $rp.project.name; Repo = $rp.name; PR = $p.pullRequestId; Title = $p.title; Result = 'SKIP: repo not in tcm-staging' }) }; continue }
  $tBranches = @{}; (Invoke-RestMethod "$T/$($tr.project.id)/_apis/git/repositories/$($tr.id)/refs?filter=heads/&api-version=7.1" -Headers $tgt).value | ForEach-Object { $tBranches[$_.name] = 1 }
  $tActive = @{}; @(Get-ActivePrs $T $tgt $tr.project.id $tr.id) | ForEach-Object { $tActive["$($_.sourceRefName)|$($_.targetRefName)"] = $_.pullRequestId }
  foreach ($p in $prs) {
    $key = "$($p.sourceRefName)|$($p.targetRefName)"
    $row = [pscustomobject]@{ Project = $rp.project.name; Repo = $rp.name; PR = $p.pullRequestId; Title = $p.title; Source = $p.sourceRefName; Target = $p.targetRefName; Author = $p.createdBy.displayName; Created = ([datetime]$p.creationDate).ToString('yyyy-MM-dd'); NewPR = ''; Result = '' }
    if (-not $tBranches[$p.sourceRefName]) { $row.Result = 'SKIP: source branch not in tcm-staging' }
    elseif (-not $tBranches[$p.targetRefName]) { $row.Result = 'SKIP: target branch not in tcm-staging' }
    elseif ($tActive[$key]) { $row.Result = "EXISTS: active PR $($tActive[$key]) already open for this branch pair"; $row.NewPR = $tActive[$key] }
    elseif (-not $Apply) { $row.Result = 'would create' }
    else {
      $link = "$S/$([uri]::EscapeDataString($rp.project.name))/_git/$([uri]::EscapeDataString($rp.name))/pullrequest/$($p.pullRequestId)"
      $desc = "> Migrated from TreasuryCapitalMarkets PR !$($p.pullRequestId) by $($p.createdBy.displayName), created $($row.Created): $link`n> Comments, votes and linked work items are not copied - see the original.`n`n$($p.description)"
      if ($desc.Length -gt 3990) { $desc = $desc.Substring(0, 3990) + '...' }
      $body = @{ sourceRefName = $p.sourceRefName; targetRefName = $p.targetRefName; title = $p.title; description = $desc; isDraft = [bool]$p.isDraft } | ConvertTo-Json
      try { $n = Invoke-RestMethod -Method Post "$T/$($tr.project.id)/_apis/git/repositories/$($tr.id)/pullrequests?api-version=7.1" -Headers $tgt -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body)); $row.NewPR = $n.pullRequestId; $row.Result = 'CREATED' }
      catch { $row.Result = "FAILED: $(($_.ErrorDetails.Message | ConvertFrom-Json -ErrorAction SilentlyContinue).message)" }
    }
    [void]$rows.Add($row)
  }
}
$f = "C:\kon-migration\ado-nightly\ado-active-pr-recreate-$(Get-Date -Format yyyyMMdd-HHmm).csv"; $rows | Export-Csv $f -NoTypeInformation -Encoding utf8
"active PRs in Finastra: $(@($rows | Where-Object PR).Count) in $(@($rows | Where-Object PR | ForEach-Object { "$($_.Project)/$($_.Repo)" } | Sort-Object -Unique).Count) repos"
$rows | Group-Object { ($_.Result -split ':')[0] } | ForEach-Object { "  {0,-14} {1}" -f $_.Name, $_.Count }
$rows | Where-Object { $_.Result -like 'SKIP*' -or $_.Result -like 'FAILED*' } | Group-Object Result | ForEach-Object { "  - $($_.Name): $($_.Count)" }
"detail: $f"
