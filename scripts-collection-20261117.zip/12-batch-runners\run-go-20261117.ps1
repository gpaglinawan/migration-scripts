﻿& C:\kon-migration\scripts\swap-checked.ps1 -Repos (Get-Content C:\kon-migration\swap\go-20261117.txt) -WaivePrCount 'SUM-summit'
"=== ALL SWAPS DONE ==="
