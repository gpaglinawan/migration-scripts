param(
  [string]$TgtOrg = "tcm-pilot",
  [string]$In     = "C:\kon-migration\teams",
  # held for a human decision - never changed by this script
  [string[]]$HoldTeamRepoTeams   = @("jellyfish-fin-tcm", "security-manager", "protivity"),
  [string[]]$HoldMembershipTeams = @("copilot", "teciem-idp"),
  [switch]$Apply
)
# Makes tcm-pilot team membership, team roles, team privacy and team->repo permissions match fin-tcm,
# using the CSVs from team-compare.ps1. Plan only unless -Apply. Never touches org owner roles.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$apiHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$mode = if ($Apply) { "apply" } else { "plan" }
$actFile = Join-Path $In "fix-$mode.csv"
$acts = New-Object System.Collections.ArrayList

function Api($method, $url, $body) {
  for ($a = 1; ; $a++) {
    try {
      if ($body) { return Invoke-RestMethod -Method $method -Uri $url -Headers $apiHdr -Body ($body | ConvertTo-Json) -ContentType "application/json" }
      return Invoke-RestMethod -Method $method -Uri $url -Headers $apiHdr
    } catch {
      $code = $_.Exception.Response.StatusCode.value__
      if ($a -ge 3 -or $code -in 400, 401, 403, 404, 422) { throw }
      Start-Sleep (5 * $a)
    }
  }
}
function Act($kind, $target, $detail, [scriptblock]$call) {
  $res = "planned"
  if ($Apply) { try { & $call | Out-Null; $res = "ok" } catch { $res = "ERROR $($_.Exception.Response.StatusCode.value__): $(($_.ErrorDetails.Message -replace '\s+',' '))" } }
  [void]$acts.Add([pscustomobject]@{ Action = $kind; Target = $target; Detail = $detail; Result = $res })
}
function Hold($kind, $target, $detail, $why) { [void]$acts.Add([pscustomobject]@{ Action = "HOLD $kind"; Target = $target; Detail = $detail; Result = $why }) }

$teams    = Import-Csv (Join-Path $In "teams.csv")
$memDiff  = Import-Csv (Join-Path $In "membership-diff.csv")
$permDiff = Import-Csv (Join-Path $In "team-repo-diff.csv")

# 1. team privacy
foreach ($tm in $teams | Where-Object { $_.InTarget -eq 'True' -and $_.SrcPrivacy -ne $_.TgtPrivacy }) {
  $priv = $tm.SrcPrivacy
  Act "set-privacy" $tm.Team "$($tm.TgtPrivacy) -> $priv" { Api PATCH "https://api.github.com/orgs/$TgtOrg/teams/$($tm.Team)" @{ privacy = $priv } }
}
foreach ($tm in $teams | Where-Object { $_.InTarget -ne 'True' }) { Hold "create-team" $tm.Team "$($tm.SrcMembers) members" "enterprise team (ent:) - create at enterprise level" }

# 2. memberships
foreach ($d in $memDiff) {
  if ($HoldMembershipTeams -contains $d.Team -and $d.Status -in 'MISSING_IN_TARGET','EXTRA_IN_TARGET','ROLE_DIFFERS') { Hold $d.Status $d.Team $d.TgtLogin "team held for decision (Copilot seats / IdP-managed)"; continue }
  switch ($d.Status) {
    'MISSING_IN_TARGET' { $role = $d.SrcRole; Act "add-member" $d.Team "$($d.TgtLogin) as $role" { Api PUT "https://api.github.com/orgs/$TgtOrg/teams/$($d.Team)/memberships/$($d.TgtLogin)" @{ role = $role } } }
    'ROLE_DIFFERS'      { $role = $d.SrcRole; Act "set-role" $d.Team "$($d.TgtLogin) $($d.TgtRole) -> $role" { Api PUT "https://api.github.com/orgs/$TgtOrg/teams/$($d.Team)/memberships/$($d.TgtLogin)" @{ role = $role } } }
    'EXTRA_IN_TARGET'   { Act "remove-member" $d.Team "$($d.TgtLogin) ($($d.TgtRole))" { Api DELETE "https://api.github.com/orgs/$TgtOrg/teams/$($d.Team)/memberships/$($d.TgtLogin)" } }
    'USER_NOT_IN_TARGET_ORG' { Hold "add-member" $d.Team "$($d.User) ($($d.SrcRole))" "no _tciem account - IdP provisioning needed" }
  }
}

# 3. team -> repo permissions
foreach ($d in $permDiff) {
  if ($HoldTeamRepoTeams -contains $d.Team) { Hold $d.Status "$($d.Team)/$($d.Repo)" "$($d.TgtPermission) vs source $($d.SrcPermission)" "team held for decision"; continue }
  switch ($d.Status) {
    { $_ -in 'MISSING_IN_TARGET','PERMISSION_DIFFERS' } {
      # the API returns role names (read/write) but the PUT expects pull/push
      $perm = @{ read = 'pull'; write = 'push' }[$d.SrcPermission]; if (-not $perm) { $perm = $d.SrcPermission }
      Act "grant-repo" "$($d.Team)/$($d.Repo)" "$($d.TgtPermission) -> $perm" { Api PUT "https://api.github.com/orgs/$TgtOrg/teams/$($d.Team)/repos/$TgtOrg/$($d.Repo)" @{ permission = $perm } } }
    'EXTRA_IN_TARGET'   { Act "remove-repo" "$($d.Team)/$($d.Repo)" "$($d.TgtPermission)" { Api DELETE "https://api.github.com/orgs/$TgtOrg/teams/$($d.Team)/repos/$TgtOrg/$($d.Repo)" } }
    'REPO_NOT_IN_TARGET' { Hold "grant-repo" "$($d.Team)/$($d.Repo)" "$($d.SrcPermission)" "repo not migrated yet - rerun after migration" }
  }
}

# 4. owners: report only
foreach ($o in Import-Csv (Join-Path $In "owners.csv") | Where-Object { $_.OwnerInSource -ne $_.OwnerInTarget }) {
  Hold "owner-role" "org" "$($o.User) source=$($o.OwnerInSource) target=$($o.OwnerInTarget)" "owner roles are changed only with explicit approval"
}

$acts | Export-Csv $actFile -NoTypeInformation -Encoding utf8
"=== $mode : $($acts.Count) rows -> $actFile ==="
$acts | Group-Object Action | Sort-Object Name | ForEach-Object { "{0,-34} {1}" -f $_.Name, $_.Count }
if ($Apply) { "errors: $(@($acts | Where-Object { $_.Result -like 'ERROR*' }).Count)" }
