param(
  [Parameter(Mandatory)][string[]]$Repos,
  [string]$Base = "C:\kon-migration",
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot"
)
# For repos that are still EMPTY in the target: clone -> (only if blobs > 100 MB) LFS rewrite + verify -> confirm target
# still empty -> chunked push -> default branch -> branch rules (rules-sync). Each repo is independent; a failure skips it.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
$scripts = Split-Path $MyInvocation.MyCommand.Path
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$log = Join-Path $Base "migrate-empty.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
# returns ONLY the child's exit code; its output goes to the log/host, not the pipeline
function Child($file, [string[]]$argList) { & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $scripts $file) @argList | ForEach-Object { Log "    $_" | Out-Host }; return $LASTEXITCODE }

foreach ($repo in $Repos) {
  Log "===== $repo ====="
  $orig = Join-Path $Base "$repo.git"; $lfsCopy = Join-Path $Base "$repo-lfs.git"; $out = Join-Path $Base "bigfiles-$repo"
  if (-not (Test-Path "$orig\HEAD")) { Child "clone-source.ps1" @("-Org", $SrcOrg, "-Repo", $repo, "-Work", $Base) | Out-Null }
  if (-not (Test-Path "$orig\HEAD")) { Log "  SKIP - clone failed"; continue }
  $sizes = Join-Path $Base "$repo-objects.txt"
  cmd /c "git -C `"$orig`" cat-file --batch-all-objects --batch-check=""%(objecttype) %(objectsize)"" > `"$sizes`""
  $big = 0; $sr = [IO.File]::OpenText($sizes); while (($l = $sr.ReadLine()) -ne $null) { $p = $l.Split(' '); if ($p[0] -eq 'blob' -and [long]$p[1] -gt 100MB) { $big++ } }; $sr.Close()
  Remove-Item $sizes -ErrorAction SilentlyContinue
  Log "  blobs > 100 MB: $big"
  $push = $orig
  if ($big -gt 0) {
    if ((Child "lfs-rewrite.ps1" @("-Orig", $orig, "-Copy", $lfsCopy, "-Out", $out)) -ne 0) { Log "  SKIP - rewrite failed"; continue }
    if ((Child "lfs-verify.ps1" @("-Orig", $orig, "-Copy", $lfsCopy, "-Out", (Join-Path $out "verify"))) -ne 0) { Log "  SKIP - verification failed"; continue }
    $push = $lfsCopy
  }
  $src = Invoke-RestMethod "https://api.github.com/repos/$SrcOrg/$repo" -Headers @{ Authorization = "Bearer $env:GH_SRC_PAT" }
  $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"
  $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
  $existing = @(git ls-remote "https://github.com/$TgtOrg/$repo.git").Count
  Remove-Item Env:GIT_CONFIG_COUNT, Env:GIT_CONFIG_KEY_0, Env:GIT_CONFIG_VALUE_0 -ErrorAction SilentlyContinue
  if ($existing -gt 0) { Log "  SKIP - target no longer empty ($existing refs)"; continue }
  $rc = Child "kon-push.ps1" @("-Repo", $push, "-Target", "https://github.com/$TgtOrg/$repo.git", "-Out", (Join-Path $Base "push-$repo"), "-Trunk", $src.default_branch, "-Steps", "10")
  if ($rc -ne 0) { Log "  push finished with $rc mismatched refs - see push-$repo\verify-missing.txt"; continue }
  try { $r = Invoke-RestMethod -Method PATCH "https://api.github.com/repos/$TgtOrg/$repo" -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT" } -Body (@{ default_branch = $src.default_branch } | ConvertTo-Json) -ContentType application/json; Log "  default branch: $($r.default_branch)" } catch { Log "  default branch FAILED" }
  & (Join-Path $scripts "rules-sync.ps1") -Repos @($repo) -Apply 2>&1 | ForEach-Object { "$_" } | Where-Object { $_ -match 'created|FAILED|HOLD' } | ForEach-Object { Log "  rules: $($_.Substring(11))" }
  Log "  DONE $repo"
}
