﻿# GIT-020: recreate in the target org the PRs that fin-tcm got after each repo's import (the nightly / final syncs copy
# branches and tags, not PRs). Approved design (CUTOVER-STEPS GIT-020, Gareth 10 Nov incl. closed/merged, DEF-114/DEF-138).
# Per repo:
#   Missing PR (created in fin-tcm after the repo's tcm-pilot import):
#     OPEN   - head branch in the target (same name, not a fork) -> PR from it; otherwise the PR head (refs/pull/N/head) is
#              pushed as branch fin-tcm-pr/N and kept. Same title / body / draft / base branch.
#     MERGED / CLOSED - temporary branches fin-tcm-pr/N-base (merge-base of the PR's base and head) and fin-tcm-pr/N-head
#              are pushed, the PR is created between them and closed, then both branches are deleted (one push per repo).
#              GitHub cannot set "merged", so these show as closed.
#   Stale PR (in the target, still open there, merged/closed in fin-tcm since): comment with the date + link, then close.
#   Every recreated PR starts with "Migrated from fin-tcm PR #N" and links to -LinkOrg (fin-tcm-old after GIT-025).
#   Reviews, comments, labels and approvals are not copied. No @mentions (nobody is notified).
# Idempotent: target PRs whose body starts with the marker are found and skipped; results in <Work>\<repo>\done.csv.
# Rate: GitHub allows about 500 content-creating requests an hour per account (PR create, close, comment each count) -
#   -PerHour throttles below that. Branch pushes are git, not API, and do not count.
# Dry run by default (lists what it would do); -Apply to change the target.
# Pre-load (Gareth 11 Nov): -States MERGED,CLOSED -NoStale recreates only the PRs that no longer change in fin-tcm.
#   Rehearsal: .\pr-recreate.ps1 -TargetOrg tcm-pilot-test -TargetSuffix -git020 -Repos VAL-criteria-tables -Apply
#   (-TargetSuffix: target repo is <repo><suffix>; the cutoff is still the tcm-pilot import time of <repo>)
param([Parameter(Mandatory)][string[]]$Repos, [string]$TargetOrg = 'tcm-pilot', [string]$CutoffOrg = 'tcm-pilot',
      [string]$SourceOrg = 'fin-tcm', [string]$LinkOrg = 'fin-tcm-old', [string]$Work = 'C:\kon-migration\pr-recreate',
      [int]$PerHour = 450, [string]$TargetSuffix = '', [string[]]$States = @('OPEN', 'MERGED', 'CLOSED'), [switch]$NoStale, [switch]$Apply,
      [switch]$AllMissing)   # 15 Nov (Gareth/Patrick: every repo PASS): also recreate fin-tcm PRs from BEFORE the import that the import did not bring (any number not in the target)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))
$tgtHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = $tgtHdr; $env:GIT_TERMINAL_PROMPT = "0"
$apiT = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
New-Item -ItemType Directory -Force $Work | Out-Null
$logFile = Join-Path $Work 'run.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}{2}" -f (Get-Date), $(if ($Apply) { '' } else { 'DRY ' }), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
function Invoke-Gql($tok, $query) {
  for ($try = 1; ; $try++) {
    try { $resp = Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body (@{ query = $query } | ConvertTo-Json) -ContentType 'application/json'
          if ($resp.errors -and -not $resp.data) { throw ($resp.errors | ConvertTo-Json -Compress) }; return $resp.data }
    catch { if ($try -ge 5) { Write-Log "  GraphQL failed: $($_.Exception.Message)"; return $null }; Start-Sleep (15 * $try) } }
}
# content-creating REST call, throttled to -PerHour, retried on secondary rate limits
$script:stamps = New-Object System.Collections.Queue
function Invoke-Create($method, $uri, $body) {
  while ($script:stamps.Count -ge $PerHour -and ((Get-Date) - $script:stamps.Peek()).TotalMinutes -lt 60) { Start-Sleep 20 }
  while ($script:stamps.Count -and ((Get-Date) - $script:stamps.Peek()).TotalMinutes -ge 60) { [void]$script:stamps.Dequeue() }
  Start-Sleep -Milliseconds 1000   # stays under 80 a minute
  for ($try = 1; ; $try++) {
    try { $r = Invoke-RestMethod -Method $method $uri -Headers $apiT -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Depth 5))); $script:stamps.Enqueue((Get-Date)); return $r }
    catch { $code = [int]$_.Exception.Response.StatusCode; $msg = $_.ErrorDetails.Message; if (-not $msg) { $msg = $_.Exception.Message }
      if (($code -eq 403 -or $code -eq 429) -and $msg -match 'rate limit' -and $try -le 6) { Write-Log "    rate limited - waiting $(60 * $try) s"; Start-Sleep (60 * $try); continue }
      throw "$code $msg" } }
}
$prFields = 'number title body isDraft state createdAt updatedAt mergedAt closedAt url isCrossRepository baseRefName headRefName baseRefOid headRefOid author { login }'
function Get-Marker($n) { "Migrated from fin-tcm PR #$n" }

$total = [ordered]@{ created = 0; closed = 0; staleClosed = 0; skipped = 0; failed = 0 }
foreach ($repo in $Repos) {
  $tr = "$repo$TargetSuffix"; $dir = Join-Path $Work $tr; New-Item -ItemType Directory -Force $dir | Out-Null
  $doneFile = Join-Path $dir 'done.csv'; $rows = New-Object System.Collections.ArrayList
  $cut = (Invoke-Gql $env:GH_TGT_PAT ('{ repository(owner:"' + $CutoffOrg + '", name:"' + $repo + '") { createdAt } }')).repository.createdAt
  if (-not $cut) { Write-Log "$repo : not in $CutoffOrg - skipped"; continue }
  $cutAt = ([datetime]$cut).ToUniversalTime()
  # fin-tcm PRs touched since the import (ordered by update time, newest first)
  $src = @(); $cursor = $null
  do {
    $after = if ($cursor) { ', after:"' + $cursor + '"' } else { '' }
    $page = (Invoke-Gql $env:GH_SRC_PAT ('{ repository(owner:"' + $SourceOrg + '", name:"' + $repo + '") { pullRequests(first:50' + $after + ', orderBy:{field:UPDATED_AT, direction:DESC}) { pageInfo { hasNextPage endCursor } nodes { ' + $prFields + ' } } } }')).repository.pullRequests
    if (-not $page) { break }; $src += @($page.nodes); $cursor = $page.pageInfo.endCursor
  } while ($page.pageInfo.hasNextPage -and ($AllMissing -or ([datetime]$src[-1].updatedAt).ToUniversalTime() -gt $cutAt))
  $isAfter = { param($v) $v -and ([datetime]$v).ToUniversalTime() -gt $cutAt }
  $missing = @($src | Where-Object { (& $isAfter $_.createdAt) -and $_.state -in $States } | Sort-Object number)
  $staleCand = @($src | Where-Object { -not (& $isAfter $_.createdAt) -and $_.state -ne 'OPEN' -and ((& $isAfter $_.mergedAt) -or (& $isAfter $_.closedAt)) })
  # target: PRs already recreated (marker) and open PRs created before the import (stale candidates)
  $tgt = @(); $cursor = $null
  do {
    $after = if ($cursor) { ', after:"' + $cursor + '"' } else { '' }
    $page = (Invoke-Gql $env:GH_TGT_PAT ('{ repository(owner:"' + $TargetOrg + '", name:"' + $tr + '") { pullRequests(first:100' + $after + ', orderBy:{field:CREATED_AT, direction:DESC}) { pageInfo { hasNextPage endCursor } nodes { number state createdAt body } } } }')).repository.pullRequests
    if (-not $page) { break }; $tgt += @($page.nodes); $cursor = $page.pageInfo.endCursor
  } while ($page.pageInfo.hasNextPage -and ($AllMissing -or ([datetime]$tgt[-1].createdAt).ToUniversalTime() -gt $cutAt.AddDays(-1)))
  $already = @{}; foreach ($p in $tgt) { if ("$($p.body)" -match '^(?:> )?Migrated from fin-tcm PR #(\d+)\b') { $already[[int]$Matches[1]] = $p.number } }
  if ($AllMissing) {   # present = target PRs imported with their original number (recreated ones carry the marker and are matched by it)
    $present = @{}; foreach ($p in $tgt) { if ("$($p.body)" -notmatch '^(?:> )?Migrated from fin-tcm PR #\d+\b') { $present[[int]$p.number] = $true } }
    $missing = @($src | Where-Object { -not $present[[int]$_.number] -and $_.state -in $States } | Sort-Object number)
    $NoStale = $true
  }
  $tgtOpen = @{}
  if ($staleCand.Count) {
    for ($i = 0; $i -lt $staleCand.Count; $i += 50) {
      $chunk = @($staleCand[$i..([Math]::Min($i + 49, $staleCand.Count - 1))])
      $q = '{ repository(owner:"' + $TargetOrg + '", name:"' + $tr + '") { ' + (($chunk | ForEach-Object { "p$($_.number): pullRequest(number:$($_.number)) { number state }" }) -join ' ') + ' } }'
      $d = (Invoke-Gql $env:GH_TGT_PAT $q).repository
      foreach ($c in $chunk) { $x = $d."p$($c.number)"; if ($x -and $x.state -eq 'OPEN') { $tgtOpen[$c.number] = $true } }
    }
  }
  $stale = @($staleCand | Where-Object { $tgtOpen[$_.number] -and -not $NoStale })
  $todo = @($missing | Where-Object { -not $already.ContainsKey([int]$_.number) })
  Write-Log ("$repo : import {0:yyyy-MM-dd HH:mm} UTC; created since: {1} (open {2}, merged {3}, closed {4}), already recreated {5}, to do {6}; stale open in target: {7}" -f $cutAt, $missing.Count,
    @($missing | Where-Object state -eq 'OPEN').Count, @($missing | Where-Object state -eq 'MERGED').Count, @($missing | Where-Object state -eq 'CLOSED').Count, ($missing.Count - $todo.Count), $todo.Count, $stale.Count)
  if (-not $todo.Count -and -not $stale.Count) { continue }

  # local copy: target branches (to know what exists) and the fin-tcm PR heads/bases needed
  $git = Join-Path $dir 'repo.git'
  if (-not (Test-Path $git)) { git init --bare -q $git }
  $env:GIT_CONFIG_VALUE_0 = $tgtHdr
  $tgtBranches = @{}; git ls-remote --heads "https://github.com/$TargetOrg/$tr.git" 2>$null | ForEach-Object { if ($_ -match '^([0-9a-f]{40})\s+refs/heads/(.+)$') { $tgtBranches[$Matches[2]] = $Matches[1] } }
  $need = @($todo | Where-Object { $_.state -ne 'OPEN' -or $_.isCrossRepository -or -not $tgtBranches.ContainsKey($_.headRefName) })
  $env:GIT_CONFIG_VALUE_0 = $srcHdr
  if ($need.Count) {
    for ($i = 0; $i -lt $need.Count; $i += 100) {
      $specs = @($need[$i..([Math]::Min($i + 99, $need.Count - 1))] | ForEach-Object { "+refs/pull/$($_.number)/head:refs/pr/$($_.number)" })
      git -C $git fetch -q "https://github.com/$SourceOrg/$repo.git" @specs 2>&1 | Out-Null
    }
    $bases = @($need | Where-Object state -ne 'OPEN' | ForEach-Object { $_.baseRefOid } | Where-Object { $_ } | Sort-Object -Unique)
    for ($i = 0; $i -lt $bases.Count; $i += 100) { git -C $git fetch -q "https://github.com/$SourceOrg/$repo.git" @($bases[$i..([Math]::Min($i + 99, $bases.Count - 1))]) 2>&1 | Out-Null }
  }
  # temporary branch names must pass the repo's branch-name rules (some repos only allow e.g. feature/... names)
  $nameFmt = 'fin-tcm-pr/{0}-{1}'
  if ($need.Count) {
    foreach ($cand in 'fin-tcm-pr/{0}-{1}', 'chore/MIG-{0}/fin-tcm-pr-{1}', 'feature/MIG-{0}_fin-tcm-pr-{1}', 'bugfix/MIG-{0}_fin-tcm-pr-{1}') {
      $okName = $true
      foreach ($kind in 'head', 'base', 'src') { $bnm = $cand -f 1, $kind
        $rl = @(try { Invoke-RestMethod "https://api.github.com/repos/$TargetOrg/$tr/rules/branches/$([uri]::EscapeDataString($bnm))" -Headers $apiT } catch { }) | ForEach-Object { $_ } | Where-Object { $_.type -eq 'branch_name_pattern' }
        foreach ($x in $rl) { $pp = $x.parameters
          $hit = switch ($pp.operator) { 'starts_with' { $bnm.StartsWith($pp.pattern) } 'ends_with' { $bnm.EndsWith($pp.pattern) } 'contains' { $bnm.Contains($pp.pattern) } default { $bnm -cmatch $pp.pattern } }
          if ([bool]$pp.negate) { $hit = -not $hit }; if (-not $hit) { $okName = $false } } }
      if ($okName) { $nameFmt = $cand; break } }
    if ($nameFmt -ne 'fin-tcm-pr/{0}-{1}') { Write-Log "  branch-name rules: temporary branches named like $($nameFmt -f 'N', 'head')" }
  }
  # plan the temporary / kept branches
  $plan = @{}; $push = @(); $refToN = @{}
  foreach ($p in $todo) {
    $n = [int]$p.number
    if ($p.state -eq 'OPEN' -and -not $p.isCrossRepository -and $tgtBranches.ContainsKey($p.headRefName)) {
      if (-not $tgtBranches.ContainsKey($p.baseRefName)) { $plan[$n] = @{ skip = "base branch $($p.baseRefName) not in $TargetOrg" }; continue }
      $plan[$n] = @{ head = $p.headRefName; base = $p.baseRefName }; continue }
    $head = git -C $git rev-parse -q --verify "refs/pr/$n" 2>$null
    if (-not $head) { $plan[$n] = @{ skip = 'PR head not fetchable from fin-tcm' }; continue }
    if ($p.state -eq 'OPEN') {
      if (-not $tgtBranches.ContainsKey($p.baseRefName)) { $plan[$n] = @{ skip = "base branch $($p.baseRefName) not in $TargetOrg" }; continue }
      $kn = $nameFmt -f $n, 'src'; $plan[$n] = @{ head = $kn; base = $p.baseRefName; keep = $true }; $push += "${head}:refs/heads/$kn"; $refToN[$kn] = $n; continue }
    $mb = if ($p.baseRefOid) { git -C $git merge-base $p.baseRefOid $head 2>$null } else { $null }
    if (-not $mb -or $mb -eq $head) { $mb = git -C $git rev-parse -q --verify "$head~$([Math]::Max(1, [int](git -C $git rev-list --count "$($p.baseRefOid)..$head" 2>$null)))" 2>$null }
    if (-not $mb -or $mb -eq $head) { $plan[$n] = @{ skip = 'no commits between base and head (cannot be opened as a PR)' }; continue }
    $hn = $nameFmt -f $n, 'head'; $bn = $nameFmt -f $n, 'base'
    $plan[$n] = @{ head = $hn; base = $bn; temp = $true }; $refToN[$hn] = $n; $refToN[$bn] = $n
    $push += "${head}:refs/heads/$hn", "${mb}:refs/heads/$bn"
  }
  $pushFailed = @{}
  if ($push.Count -and $Apply) {
    $env:GIT_CONFIG_VALUE_0 = $tgtHdr
    for ($i = 0; $i -lt $push.Count; $i += 100) {
      $out = git -C $git push --porcelain "https://github.com/$TargetOrg/$tr.git" @($push[$i..([Math]::Min($i + 99, $push.Count - 1))]) 2>&1 | ForEach-Object { "$_" }
      foreach ($ln in $out) { if ($ln -match '^!\t\S+:refs/heads/(\S+)' -and $refToN.ContainsKey($Matches[1])) { $pushFailed[[int]$refToN[$Matches[1]]] = $ln } }
      $out | Where-Object { $_ -match 'GH013|GH001|push declined' } | Select-Object -First 2 | ForEach-Object { Write-Log "    push: $_" }
    }
  }
  # create / close
  foreach ($p in $todo) {
    $n = [int]$p.number; $pl = $plan[$n]
    $who = if ($p.author) { $p.author.login } else { 'ghost' }
    if ($pl.skip -or $pushFailed[$n]) { $why = if ($pl.skip) { $pl.skip } else { "branch push rejected: $($pushFailed[$n])" }; Write-Log "  #$n $($p.state) - not recreated: $why"; $total.skipped++
      [void]$rows.Add([pscustomobject]@{ Repo = $repo; Source = $n; State = $p.state; Target = ''; Result = "SKIPPED $why" }); continue }
    $link = "https://github.com/$LinkOrg/$repo/pull/$n"
    $when = switch ($p.state) { 'MERGED' { "Merged in fin-tcm on $(([datetime]$p.mergedAt).ToUniversalTime().ToString('yyyy-MM-dd')). " } 'CLOSED' { "Closed in fin-tcm on $(([datetime]$p.closedAt).ToUniversalTime().ToString('yyyy-MM-dd')) without merging. " } default { '' } }
    $head = "> $(Get-Marker $n) by $who, created $(([datetime]$p.createdAt).ToUniversalTime().ToString('yyyy-MM-dd')): $link`n> ${when}Reviews and comments are not copied - see the original." + $(if ($pl.keep) { "`n> The source branch is kept as $($pl.head) (the original was a fork or a deleted branch)." } else { '' })
    $body = "$head`n`n$($p.body)"; if ($body.Length -gt 65000) { $body = $body.Substring(0, 65000) + "`n`n(description cut short - see the original)" }
    if (-not $Apply) { Write-Log "  #$n $($p.state): would create '$($p.title)' $($pl.head) -> $($pl.base)$(if ($pl.temp) { ' then close' })"; continue }
    try {
      $new = Invoke-Create POST "https://api.github.com/repos/$TargetOrg/$tr/pulls" @{ title = $p.title; body = $body; head = $pl.head; base = $pl.base; draft = [bool]$p.isDraft; maintainer_can_modify = $false }
      $total.created++; $res = "CREATED #$($new.number)"
      if ($p.state -ne 'OPEN') { $null = Invoke-Create PATCH "https://api.github.com/repos/$TargetOrg/$tr/pulls/$($new.number)" @{ state = 'closed' }; $total.closed++; $res += ' closed' }
      Write-Log "  #$n $($p.state) -> $res"
      [void]$rows.Add([pscustomobject]@{ Repo = $repo; Source = $n; State = $p.state; Target = $new.number; Result = $res })
    } catch { $total.failed++; Write-Log "  #$n $($p.state) FAILED: $_"; [void]$rows.Add([pscustomobject]@{ Repo = $repo; Source = $n; State = $p.state; Target = ''; Result = "FAILED $_" }) }
  }
  # temporary branches off (one push); kept branches stay
  $temp = @($todo | Where-Object { $plan[[int]$_.number].temp } | ForEach-Object { ":refs/heads/$($plan[[int]$_.number].head)", ":refs/heads/$($plan[[int]$_.number].base)" })
  if ($temp.Count -and $Apply) {
    $env:GIT_CONFIG_VALUE_0 = $tgtHdr
    for ($i = 0; $i -lt $temp.Count; $i += 100) { git -C $git push -q "https://github.com/$TargetOrg/$tr.git" @($temp[$i..([Math]::Min($i + 99, $temp.Count - 1))]) 2>&1 | Out-Null }
    $tempNames = @{}; $temp | ForEach-Object { $tempNames[($_ -replace '^:refs/heads/', '')] = $true }
    $left = @(git ls-remote --heads "https://github.com/$TargetOrg/$tr.git" 2>$null | Where-Object { $_ -match 'refs/heads/(.+)$' -and $tempNames[$Matches[1]] }).Count
    Write-Log "  temporary branches removed ($($temp.Count / 2) PRs; left over: $left)"
  }
  # stale: merged/closed in fin-tcm after the import, still open in the target
  foreach ($p in $stale) {
    $n = [int]$p.number; $link = "https://github.com/$LinkOrg/$repo/pull/$n"
    $what = if ($p.state -eq 'MERGED') { "Merged in fin-tcm on $(([datetime]$p.mergedAt).ToUniversalTime().ToString('yyyy-MM-dd'))" } else { "Closed in fin-tcm on $(([datetime]$p.closedAt).ToUniversalTime().ToString('yyyy-MM-dd')) without merging" }
    if (-not $Apply) { Write-Log "  #$n open in target, $($p.state) in fin-tcm: would comment + close"; continue }
    try { $null = Invoke-Create POST "https://api.github.com/repos/$TargetOrg/$tr/issues/$n/comments" @{ body = "$what after this repository was migrated - $link. Closed here to match." }
          $null = Invoke-Create PATCH "https://api.github.com/repos/$TargetOrg/$tr/pulls/$n" @{ state = 'closed' }; $total.staleClosed++
          Write-Log "  #$n stale -> commented, closed"; [void]$rows.Add([pscustomobject]@{ Repo = $repo; Source = $n; State = $p.state; Target = $n; Result = 'STALE closed' }) }
    catch { $total.failed++; Write-Log "  #$n stale FAILED: $_"; [void]$rows.Add([pscustomobject]@{ Repo = $repo; Source = $n; State = $p.state; Target = $n; Result = "STALE FAILED $_" }) }
  }
  if ($rows.Count) { $rows | Export-Csv $doneFile -NoTypeInformation -Encoding utf8 -Append }
}
Write-Log ("=== done: created {0} (closed {1}), stale closed {2}, not recreated {3}, failed {4}" -f $total.created, $total.closed, $total.staleClosed, $total.skipped, $total.failed)
