# 15 Nov 2026 (Gareth: Lukasz wants his email mapping applied to KON-kplus-front for commit search).
# Builds a NEW copy tcm-pilot/KON-kplus-front-pr2 whose commits carry Teciem e-mails (Lukasz's v08 "Transformation list").
# Touches nothing live: the live KON-kplus-front is only read (fetched). Swap = separate step, needs Gareth's go.
# Reuses last night's rebuild: the live repo already holds the LFS-rewritten history, and last night's remapped PR data
# (export-remapped) carries those commit ids. Steps:
#   1 fetch heads, tags and refs/pull/*/head + all LFS objects of tcm-pilot/KON-kplus-front into a bare repo
#   2 git-filter-repo --mailmap (e-mails only; names, dates, messages, trees unchanged) -> commit-map (live id -> new id)
#   3 remap last night's PR data with that commit-map
#   4 pr-preload.ps1 stages archive, import (into KON-kplus-front-pr2), lfs, verify (no cleanup - keep for the swap check)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$w = 'C:\kon-migration\pr-preload\KON-kplus-front-mailmap-20261115'; $prev = 'C:\kon-migration\pr-preload\KON-kplus-front-pr2-20261113'
$rw = "$w\rewritten.git"; $py = 'C:\kon-migration\tools\python\python.exe'; $here = 'C:\kon-migration\scripts\pr-preload'
$log = "$w\run.log"; function Write-Log($m) { $l = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
$tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT")); $env:GIT_TERMINAL_PROMPT = '0'
$url = 'https://github.com/tcm-pilot/KON-kplus-front.git'
Write-Log "=== mailmap rebuild of KON-kplus-front -> tcm-pilot/KON-kplus-front-pr2 ($((Get-Content "$w\mailmap.txt").Count) mappings) ==="
if (-not (Test-Path "$w\step1.done")) {
  if (Test-Path $rw) { [IO.Directory]::Delete("\\?\$rw", $true) }
  # reftable: KON-kplus-front has branch names that differ only in case, which NTFS cannot hold as loose ref files
  git init --bare -q --ref-format=reftable $rw; git -C $rw config core.longpaths true; git -C $rw remote add origin $url
  git -C $rw config http.extraHeader "Authorization: Basic $tb"
  Write-Log '  fetching heads, tags, refs/pull/*/head ...'
  git -C $rw fetch -q origin '+refs/heads/*:refs/heads/*' '+refs/tags/*:refs/tags/*' '+refs/pull/*/head:refs/pull/*/head' 2>&1 | Select-Object -Last 3 | ForEach-Object { Write-Log "  fetch: $_" }
  Write-Log "  refs: $(@(git -C $rw for-each-ref --format='%(refname)').Count)"
  git -C $rw lfs fetch --all origin 2>&1 | Select-Object -Last 2 | ForEach-Object { Write-Log "  lfs: $_" }
  Write-Log "  LFS objects local: $(@(Get-ChildItem "$rw\lfs\objects" -Recurse -File -EA SilentlyContinue).Count)"
  git -C $rw config --unset http.extraHeader
  git -C $rw for-each-ref --format='%(objectname) %(refname)' | Set-Content "$w\refs-before.txt" -Encoding ascii
  New-Item "$w\step1.done" -ItemType File | Out-Null
}
if (-not (Test-Path "$w\step2.done")) {
  Write-Log '  git-filter-repo --mailmap ...'
  Push-Location $rw
  $env:GIT_CONFIG_COUNT = '2'; $env:GIT_CONFIG_KEY_0 = 'core.protectNTFS'; $env:GIT_CONFIG_VALUE_0 = 'false'; $env:GIT_CONFIG_KEY_1 = 'core.longpaths'; $env:GIT_CONFIG_VALUE_1 = 'true'
  & $py -I C:\kon-migration\tools\filter-repo\git-filter-repo --force --preserve-commit-hashes --replace-refs delete-no-add --mailmap "$w\mailmap.txt" 2>&1 | Select-Object -Last 5 | ForEach-Object { Write-Log "  filter-repo: $_" }
  $env:GIT_CONFIG_COUNT = '0'
  Pop-Location
  if (-not (Test-Path "$rw\filter-repo\commit-map")) { Write-Log 'STOP: no commit-map'; exit 1 }
  Copy-Item "$rw\filter-repo\commit-map" "$w\commit-map" -Force
  $changed = @(Get-Content "$w\commit-map" | Select-Object -Skip 1 | Where-Object { ($_ -split ' ')[0] -ne ($_ -split ' ')[1] }).Count
  Write-Log "  commits rewritten: $changed of $((Get-Content "$w\commit-map").Count - 1)"
  $after = @{}; git -C $rw for-each-ref --format='%(objectname) %(refname)' | ForEach-Object { $p = $_ -split ' ', 2; $after[$p[1]] = $p[0] }
  $lost = @(Get-Content "$w\refs-before.txt" | Where-Object { -not $after.ContainsKey(($_ -split ' ', 2)[1]) }).Count
  Write-Log "  refs after: $($after.Count); refs lost: $lost"
  if ($lost) { Write-Log 'STOP: refs lost in rewrite'; exit 1 }
  # back to the classic ref format for the GitHub archive (the migration writes every ref into packed-refs)
  git -C $rw refs migrate --ref-format=files 2>&1 | ForEach-Object { Write-Log "  refs migrate: $_" }
  $n2 = @(git -C $rw for-each-ref --format='%(refname)').Count
  Write-Log "  ref format now $(git -C $rw rev-parse --show-ref-format); refs $n2"
  if ($n2 -ne $after.Count) { Write-Log 'STOP: ref count changed in format migration'; exit 1 }
  New-Item "$w\step2.done" -ItemType File | Out-Null
}
if (-not (Test-Path "$w\step3.done")) {
  if (Test-Path "$w\export-remapped") { Remove-Item "$w\export-remapped" -Recurse -Force }
  & $py -I "$here\remap_pr_shas.py" "$prev\export-remapped" "$w\commit-map" "$w\export-remapped" 2>&1 | ForEach-Object { Write-Log "  remap: $_" }
  if (-not (Test-Path "$w\export-remapped\schema.json")) { Write-Log 'STOP: remap produced no output'; exit 1 }
  # pr-preload resumes from state.json: export/extract/rewrite/remap are done here
  $st = [ordered]@{}; foreach ($s in 'export', 'extract', 'rewrite', 'remap') { $st["done_$s"] = (Get-Date).ToString('s') }; $st.note = 'mailmap rebuild from live KON-kplus-front + 13 Nov remapped PR data'
  $st | ConvertTo-Json | Set-Content "$w\state.json" -Encoding utf8
  New-Item "$w\step3.done" -ItemType File | Out-Null
}
Write-Log '  handing over to pr-preload.ps1 (archive, import, lfs, verify)'
& C:\kon-migration\scripts\pr-preload\pr-preload.ps1 -Repo KON-kplus-front -TargetName KON-kplus-front-pr2 -Work $w -StopAfter verify 2>&1 | ForEach-Object { "$_" -replace 'gh[spuo]_[A-Za-z0-9]+', '[redacted]' }
