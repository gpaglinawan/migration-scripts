param(
  [string]$Work = "C:\kon-migration\bigfiles-TO-treasury-installer-$(Get-Date -Format yyyyMMdd)",
  [switch]$Push      # push the graft plan (non-force) after a clean local run
)
# TO-treasury-installer resync (ui/core = 1.1 GB, kept in LFS in tcm-pilot). Same method as 26 Oct, in a fresh folder:
#   1. clone Finastra (all branches as local heads + tags + any LFS objects)
#   2. copy -> git lfs migrate import --everything --include=/ui/core
#   3. graft-onto-target.py: new Finastra commits recreated on top of tcm-pilot's existing history (no force push)
#   4. -Push only: LFS objects first, then refs/out/* non-force; protected branches bypassed for the push and restored
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work "refresh.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Auth($pat) { $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$pat")); $env:GIT_TERMINAL_PROMPT = "0" }
$src = "https://github.com/fin-tcm/TO-treasury-installer.git"; $tgt = "https://github.com/tcm-pilot/TO-treasury-installer.git"
$orig = Join-Path $Work "orig"; $rw = Join-Path $Work "rewrite"; $graft = Join-Path $Work "graft.git"

if (-not $Push) {
  Log "=== refresh TO-treasury-installer (local) in $Work ==="
  if (Test-Path $orig) { Log "FATAL: $orig exists - use a new -Work folder"; exit 1 }
  Auth $env:GH_SRC_PAT
  git clone -q --no-checkout $src $orig 2>&1 | ForEach-Object { Log "   $_" }
  if ($LASTEXITCODE) { Log "FATAL: clone failed"; exit 1 }
  git -C $orig for-each-ref --format="%(refname:lstrip=3)" refs/remotes/origin | Where-Object { $_ -ne 'HEAD' } | ForEach-Object { git -C $orig update-ref "refs/heads/$_" "refs/remotes/origin/$_" }
  git -C $orig fetch -q --tags origin
  git -C $orig lfs fetch --all origin 2>&1 | Select-Object -Last 2 | ForEach-Object { Log "   $_" }
  Log "1. orig: heads=$(@(git -C $orig for-each-ref refs/heads).Count) tags=$(@(git -C $orig for-each-ref refs/tags).Count)"

  git clone -q --no-checkout --no-local $orig $rw 2>&1 | ForEach-Object { Log "   $_" }
  git -C $orig for-each-ref --format="%(refname:lstrip=2)" refs/heads | ForEach-Object { git -C $rw update-ref "refs/heads/$_" "refs/remotes/origin/$_" }
  git -C $rw fetch -q --tags origin
  git -C $rw remote remove origin   # also deletes refs/remotes/* (no stdin pipe: PS 5.1 prepends a BOM)
  # existing Finastra LFS objects (if any) must be in the rewrite's store too
  if (Test-Path "$orig\.git\lfs\objects") { robocopy "$orig\.git\lfs\objects" "$rw\.git\lfs\objects" /E /NFL /NDL /NJH /NJS /NP | Out-Null }
  git -C $rw lfs migrate import --everything --include=/ui/core --yes 2>&1 | Select-Object -Last 3 | ForEach-Object { Log "   $_" }
  if ($LASTEXITCODE) { Log "FATAL: lfs migrate failed"; exit 1 }
  Log "2. rewrite: heads=$(@(git -C $rw for-each-ref refs/heads).Count) tags=$(@(git -C $rw for-each-ref refs/tags).Count)"
  # no blob over 100 MB may remain
  $big = @(git -C $rw rev-list --objects --all | git -C $rw cat-file --batch-check='%(objecttype) %(objectsize) %(rest)' | Where-Object { $_ -match '^blob (\d+)' -and [long]$Matches[1] -gt 100MB })
  Log "   blobs over 100 MB left in rewrite: $($big.Count) $($big -join '; ')"
  if ($big.Count) { Log "FATAL: rewrite still has large blobs"; exit 1 }

  $env:GRAFT_W = $Work
  & C:\kon-migration\tools\python\python.exe -I C:\kon-migration\scripts\graft-onto-target.py 2>&1 | ForEach-Object { Log "   $_" }
  Log "=== local refresh finished - review plan.csv, then re-run with -Push ==="
  exit 0
}

# ---- push (non-force) ----
Log "=== push graft plan -> tcm-pilot ==="
$gl = Get-Content (Join-Path $Work "graft.log") -Raw
if ($gl -notmatch 'done \(nothing pushed\) ===\s*$') { Log "STOP: graft did not finish clean - nothing pushed"; exit 2 }
$oids = @(Get-Content (Join-Path $Work "lfs-oids.txt") | Where-Object { $_ -match '^[0-9a-f]{64}$' })
Auth $env:GH_TGT_PAT
if ($oids.Count) { git -C $rw lfs push --object-id $tgt @oids 2>&1 | Select-Object -Last 2 | ForEach-Object { Log "   $_" }; if ($LASTEXITCODE) { Log "FATAL: LFS push failed - nothing else pushed"; exit 1 } }
Log "1. LFS objects pushed: $($oids.Count)"
$apiT = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$toggled = @()
foreach ($c in @(Import-Csv "C:\kon-migration\rules\classic-bypass-branches.csv" | Where-Object { $_.Repo -eq 'TO-treasury-installer' })) {
  $ea = "https://api.github.com/repos/tcm-pilot/TO-treasury-installer/branches/$($c.Branch)/protection/enforce_admins"
  try { if ((Invoke-RestMethod $ea -Headers $apiT).enabled) { Invoke-RestMethod -Method DELETE $ea -Headers $apiT | Out-Null; $toggled += $c.Branch } } catch { Log "   enforce_admins off FAILED $($c.Branch)" }
}
try {
  $refs = @(git -C $graft for-each-ref --format="%(refname)" refs/out/)
  foreach ($r in $refs) {
    $dst = $r -replace '^refs/out/', 'refs/'
    $o = git -C $graft push --porcelain $tgt "${r}:$dst" 2>&1
    $line = @($o | Where-Object { $_ -match "^\S\s+\S+:$([regex]::Escape($dst))" })[0]
    Log "   $dst : $(if ($LASTEXITCODE) { "FAILED $(@($o | Where-Object { $_ -match 'error|reject' }) -join ' | ')" } else { "ok $line" })"
  }
} finally {
  foreach ($b in $toggled) {
    $ea = "https://api.github.com/repos/tcm-pilot/TO-treasury-installer/branches/$b/protection/enforce_admins"
    try { Invoke-RestMethod -Method POST $ea -Headers $apiT | Out-Null } catch {}
    $ok = try { (Invoke-RestMethod $ea -Headers $apiT).enabled } catch { $false }
    if ($ok) { Log "   $b protection bypassed for the push, restored" } else { Log "   WARNING $b enforce_admins NOT restored - run enforce-admins-restore.ps1" }
  }
}
Log "=== push done ==="
