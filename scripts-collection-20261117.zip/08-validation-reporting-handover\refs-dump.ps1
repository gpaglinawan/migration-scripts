param(
  [Parameter(Mandatory)][string]$Org,
  [Parameter(Mandatory)][string]$PatVar,      # GH_SRC_PAT or GH_TGT_PAT
  [string]$Out = "C:\kon-migration\refs",
  [int]$Threads = 8
)
# Read-only: dumps branch + tag refs (sha, name) for every repo in an org via git ls-remote.
# One process per org so the process-wide auth env holds exactly one token.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"([^"]*)"') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$pat = [Environment]::GetEnvironmentVariable($PatVar)
$env:GIT_CONFIG_COUNT   = "1"
$env:GIT_CONFIG_KEY_0   = "http.https://github.com/.extraheader"
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$pat"))
$env:GIT_TERMINAL_PROMPT = "0"

$dir = Join-Path $Out $Org; New-Item -ItemType Directory -Force $dir | Out-Null
$h = @{Authorization="Bearer $pat";Accept="application/vnd.github+json"}
$repos = New-Object System.Collections.ArrayList; $page = 1
do { $r = Invoke-RestMethod "https://api.github.com/orgs/$Org/repos?type=all&per_page=100&page=$page" -Headers $h
     foreach ($x in $r) { [void]$repos.Add([pscustomobject]@{Name=$x.name; Default=$x.default_branch; Archived=$x.archived; Size=$x.size}) }; $page++ } while ($r.Count -eq 100)
$repos | Export-Csv (Join-Path $Out "$Org-repos.csv") -NoTypeInformation -Encoding utf8
"$Org : $($repos.Count) repos"

$pool = [runspacefactory]::CreateRunspacePool(1, $Threads); $pool.Open()
$jobs = foreach ($r in $repos) {
  $ps = [powershell]::Create(); $ps.RunspacePool = $pool
  [void]$ps.AddScript({ param($org, $name, $file)
    $o = & git ls-remote "https://github.com/$org/$name.git" "refs/heads/*" "refs/tags/*" 2>&1
    if ($LASTEXITCODE -eq 0) { $o | Where-Object { $_ -notmatch '\^\{\}$' } | Set-Content -Path $file -Encoding utf8 }
    else { "ERROR`t$($o -join ' ')" | Set-Content -Path $file -Encoding utf8 }
  }).AddArgument($Org).AddArgument($r.Name).AddArgument((Join-Path $dir "$($r.Name).txt"))
  [pscustomobject]@{ PS = $ps; H = $ps.BeginInvoke() }
}
$done = 0
foreach ($j in $jobs) { $j.PS.EndInvoke($j.H); $j.PS.Dispose(); $done++; if ($done % 250 -eq 0) { "  $done/$($repos.Count)" } }
$pool.Close()
"$Org : done"
