﻿param([string]$Out = 'C:\kon-migration\rules\def116-impact-20261110')
New-Item -ItemType Directory -Force $Out | Out-Null
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-All($url, $tok) { $h = @{ Authorization = "Bearer $tok"; Accept = 'application/vnd.github+json' }; $acc = @(); $p = 1
  do { $sep = if ($url -match '\?') { '&' } else { '?' }; $b = @(Invoke-RestMethod "$url${sep}per_page=100&page=$p" -Headers $h | ForEach-Object { $_ }); $acc += $b; $p++ } while ($b.Count -eq 100); $acc }
foreach ($o in @(@{ org = 'fin-tcm'; tok = $env:GH_SRC_PAT }, @{ org = 'tcm-pilot'; tok = $env:GH_TGT_PAT })) {
  $teams = Get-All "https://api.github.com/orgs/$($o.org)/teams" $o.tok
  $grants = foreach ($t in $teams) { foreach ($r in (Get-All "https://api.github.com/orgs/$($o.org)/teams/$($t.slug)/repos" $o.tok)) { [pscustomobject]@{ Team = $t.slug; Repo = $r.name; Perm = $r.role_name } } }
  $grants | Export-Csv "$Out\$($o.org)-team-repos.csv" -NoTypeInformation -Encoding utf8
  $members = foreach ($t in $teams) { foreach ($m in (Get-All "https://api.github.com/orgs/$($o.org)/teams/$($t.slug)/members" $o.tok)) { [pscustomobject]@{ Team = $t.slug; Login = $m.login } } }
  $members | Export-Csv "$Out\$($o.org)-team-members.csv" -NoTypeInformation -Encoding utf8
  Get-All "https://api.github.com/orgs/$($o.org)/members" $o.tok | ForEach-Object { [pscustomobject]@{ Login = $_.login } } | Export-Csv "$Out\$($o.org)-members.csv" -NoTypeInformation -Encoding utf8
  "$($o.org): $(@($teams).Count) teams, $(@($grants).Count) team-repo grants"
}

