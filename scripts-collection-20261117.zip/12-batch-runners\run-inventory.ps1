﻿param([string]$Org, [string]$Var)
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
& C:\kon-migration\tools\python\python.exe -I C:\kon-migration\scripts\bau-inventory.py $Org $Var "C:\kon-migration\bau-pack\inventory-$Org"
