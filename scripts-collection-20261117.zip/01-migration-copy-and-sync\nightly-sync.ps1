# Nightly fin-tcm -> tcm-pilot repository sync + report (scheduled task "Teciem nightly repo sync").
#   1. snapshot branches/tags of both orgs (git ls-remote)        2. compare
#   3. delta-sync every OUT_OF_SYNC / DEFAULT_BRANCH_DIFFERS repo  (no force; repos rewritten for large files excluded)
#   4. snapshot + compare again -> % of repos in sync              5. report: C:\kon-migration\nightly\<date>\report.md
# New repos in Finastra are reported, not migrated (scope decision).
$ErrorActionPreference = "Continue"
$here = Split-Path $MyInvocation.MyCommand.Path
$day = Get-Date -Format "yyyy-MM-dd"
$root = "C:\kon-migration\nightly\$day"; New-Item -ItemType Directory -Force $root | Out-Null
$lock = "C:\kon-migration\nightly\running.lock"
if (Test-Path $lock) { if (((Get-Date) - (Get-Item $lock).LastWriteTime).TotalHours -lt 8) { "another run is in progress - exiting" | Out-File "$root\skipped.txt"; return } }
Set-Content $lock (Get-Date).ToString('s')
$log = "$root\nightly.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Add-Content -Path $log -Value $line -Encoding utf8 }
function Snapshot($dir) {
  Log "snapshot -> $dir"
  $a = Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$here\refs-dump.ps1`" -Org fin-tcm -PatVar GH_SRC_PAT -Out `"$dir`"" -PassThru -WindowStyle Hidden
  $b = Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$here\refs-dump.ps1`" -Org tcm-pilot -PatVar GH_TGT_PAT -Out `"$dir`"" -PassThru -WindowStyle Hidden
  $a.WaitForExit(); $b.WaitForExit()
  & powershell -NoProfile -ExecutionPolicy Bypass -File "$here\refs-compare.ps1" -Refs $dir | ForEach-Object { Log "  $_" }
}
$rewritten = 'KON-kplus-front', 'FCGC-pricing-analytics', 'RISK-cmr', 'OPICS-programmers', 'KON-doc-kondor-archive', 'FWK-utfinstaller', 'FCBO-fusion-detect-core', 'MAFTP-fpp-fusioncapital', 'SFX-netcore-common', 'TO-treasury-installer', 'MAFTP-fpp-vaas-che'   # last two: -pr copies (9 Nov)
# ARC-almonde is back in the normal sync since 30 Oct: its "refused" LFS objects were delta-sync pushing them to the source LFS URL
try {
  Log "=== nightly sync $day ==="
  Snapshot "$root\before"
  # called in-process: an array passed through `powershell -File` would be split into separate arguments
  & "$here\delta-sync.ps1" -Summary "$root\before\compare-summary.csv" -Work "$root\sync" -Exclude $rewritten -Apply | Out-Null
  Log "delta sync finished"
  # read-only check of the PR-preserving copies (<repo>-pr) of the large-file repos, which the sync above skips;
  # runs before the final compare, which counts an UP_TO_DATE copy as IN_SYNC_REWRITTEN
  $pc = @()
  try {
    $pc = @(& "$here\pr-copy-check.ps1" -Out "$root\pr-copy-check")
    Log ("pr-copy check: " + (@($pc | Where-Object { $_ -like 'UP_TO_DATE:*' }) -join ''))
  } catch { Log "pr-copy check failed: $($_.Exception.Message)" }
  Snapshot "$root\after"

  # report
  $s = Import-Csv "$root\after\compare-summary.csv"
  $migrated = @($s | Where-Object { $_.Status -ne 'NOT_IN_TARGET' })
  $inSync = @($migrated | Where-Object { $_.Status -in 'IN_SYNC', 'IN_SYNC_REWRITTEN' })
  $pct = if ($migrated.Count) { [math]::Round(100 * $inSync.Count / $migrated.Count, 1) } else { 0 }
  $res = @(); if (Test-Path "$root\sync\sync-results.csv") { $res = Import-Csv "$root\sync\sync-results.csv" }
  $prev = Get-ChildItem C:\kon-migration\nightly -Directory | Where-Object Name -lt $day | Sort-Object Name | Select-Object -Last 1
  $prevPct = if ($prev -and (Test-Path "$($prev.FullName)\pct.txt")) { Get-Content "$($prev.FullName)\pct.txt" } else { "n/a" }
  "$pct" | Set-Content "$root\pct.txt"
  $md = @("# Nightly repo sync - $day", "",
          "**Repos in sync: $pct%** ($($inSync.Count) of $($migrated.Count) migrated repos). Previous run: $prevPct%. Target: 99%.", "",
          "| Status | Repos |", "|---|---|")
  $md += $s | Group-Object Status | Sort-Object Name | ForEach-Object { "| $($_.Name) | $($_.Count) |" }
  $md += "", "## Tonight's sync", "", "| Result | Repos |", "|---|---|"
  $md += $res | Group-Object { ($_.Result -split ' ')[0] } | ForEach-Object { "| $($_.Name) | $($_.Count) |" }
  $md += "", "## Exceptions that need a person", ""
  $md += "### Branches that diverged (not overwritten) - usually rebased/force-pushed in Finastra, no action for the team"; $md += @($res | Where-Object { $_.Result -like 'PARTIAL*' } | ForEach-Object { "- $($_.Repo): $($_.Rejected) refs" }); if (-not ($res | Where-Object { $_.Result -like 'PARTIAL*' })) { $md += "- none" }
  $md += "", "### Push refused (protected branch, rules, large files, corrupt objects)"; $md += @($res | Where-Object { $_.Result -like 'ERROR*' -or $_.Result -like 'FAILED*' } | ForEach-Object { "- $($_.Repo): $($_.Result)" }); if (-not ($res | Where-Object { $_.Result -like 'ERROR*' -or $_.Result -like 'FAILED*' })) { $md += "- none" }
  $md += "", "### Repos rewritten for large files (need the rewrite-based sync)"; $md += @($s | Where-Object { $_.Repo -in $rewritten -and $_.Status -notin 'IN_SYNC', 'IN_SYNC_REWRITTEN' } | ForEach-Object { "- $($_.Repo): $($_.Status), missing branches $($_.MissingBranches), outdated $($_.StaleBranches)" })
  $md += "", "### New in Finastra, not in Teciem (not migrated automatically)"; $new = @($s | Where-Object Status -eq 'NOT_IN_TARGET'); $md += @($new | Select-Object -First 50 | ForEach-Object { "- $($_.Repo)" }); if ($new.Count -gt 50) { $md += "- ... $($new.Count - 50) more (see after\compare-summary.csv)" }
  $md += "", "Files: $root"
  $md | Set-Content "$root\report.md" -Encoding utf8
  Copy-Item "$root\report.md" "C:\kon-migration\nightly\latest-report.md" -Force
  Log "report written: $pct% in sync"
  if ($pc.Count) { Add-Content "$root\report.md" (@('') + $pc) -Encoding utf8; Copy-Item "$root\report.md" "C:\kon-migration\nightly\latest-report.md" -Force }
  # keep the last 7 nights of work files; remove bulky per-repo snapshots older than that
  Get-ChildItem C:\kon-migration\nightly -Directory | Sort-Object Name -Descending | Select-Object -Skip 7 | ForEach-Object { Remove-Item "$($_.FullName)\before\fin-tcm", "$($_.FullName)\before\tcm-pilot", "$($_.FullName)\after\fin-tcm", "$($_.FullName)\after\tcm-pilot" -Recurse -Force -ErrorAction SilentlyContinue }
}
finally {
  & "$here\enforce-admins-restore.ps1" | Where-Object { $_ -notmatch ': ok$' } | ForEach-Object { Log "  protection check: $_" }
  Remove-Item $lock -Force -ErrorAction SilentlyContinue; Log "=== end ===" }
