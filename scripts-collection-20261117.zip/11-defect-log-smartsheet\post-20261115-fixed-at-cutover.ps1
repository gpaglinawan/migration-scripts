# 15 Nov 2026 (Gareth: "ok let us start" - item 2). Resolution text for defects fixed by the cutover work (status ->
# Ready for Retest) plus DEF-243/245 (known limitation, status unchanged). Dry run unless -Apply.
param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$retest = [ordered]@{
  'DEF-064' = 'Fixed at cutover. RISK-cmr is migrated to tcm-pilot (rebuilt with its files over 100 MB in Git LFS, swapped in 14 Nov): all branches, tags, 1,064 releases and 5,538 of 5,559 PRs; the 21 others cannot be copied because their code no longer exists in Finastra GitHub (list available).'
  'DEF-067' = 'Fixed at cutover. Final sync after the freeze (13-14 Nov) and a full branch/tag comparison on 14 Nov: RISK-fusion-risk, RISK-fr-cmr-tests and RISK-fr-limit-test are IN_SYNC - every branch and tag has the same commit as in fin-tcm.'
  'DEF-074' = 'Fixed at cutover. After the freeze (13 Nov) the final sync ran with the corrective step for rewritten/deleted branches; the 14 Nov comparison shows FABCOM-regulatory IN_SYNC (all branches and tags identical). 2,640 of 2,662 repos are identical; the rest are explained (files over 100 MB moved to LFS, or Teciem-side changes kept next to the Finastra version as fin-tcm-kept/*).'
  'DEF-085' = 'Fixed at cutover. Final sync after the freeze; 14 Nov comparison: the listed repos are IN_SYNC, except KON-kplus-front, RISK-cmr and TO-treasury-installer, whose history was rewritten to move files over 100 MB into Git LFS (GitHub''s limit) - their commit IDs differ by design; all branches, tags and PRs are present.'
  'DEF-086' = 'Fixed at cutover. Final sync after the freeze; 14 Nov comparison: RISK-fusion-risk, RISK-fr-cmr-tests and MAFTP-csm are IN_SYNC (heads, branches, tags and releases match).'
  'DEF-089' = 'Fixed at cutover. KON-kplus-back branches were synced after the freeze. The one remaining difference is tag 2026.4.1000-c04, which Teciem changed in tcm-pilot before the freeze; the Finastra version is kept next to it as fin-tcm-kept/2026.4.1000-c04, so nothing is lost.'
  'DEF-093' = 'Fixed at cutover. KON-kplus-front was rebuilt with its PRs (incl. closed ones) and swapped in: 39,534 of 39,552 PRs, with the Teciem e-mail mapping. The 18 others cannot be copied because their code no longer exists in Finastra GitHub (list sent to Lukasz Garstecki and Christophe Curay).'
  'DEF-114' = 'Fixed at cutover. PRs created in fin-tcm after each repo''s import (incl. FCBO/PTP repos) were recreated in tcm-pilot on 14-15 Nov. Recreated PRs keep title, description and link to the original; GitHub does not allow the original author, merged state or number (see DEF-235).'
  'DEF-138' = 'Fixed at cutover. MCH-mch now has 2,002 PRs in tcm-pilot, the same as fin-tcm. All PRs created after the import were recreated on 14-15 Nov; the GitHub validation sheet shows MCH-mch PASS.'
  'DEF-143' = 'Fixed at cutover for teams and non-admin access: teams copied, and 703 direct collaborator grants added on 14-15 Nov. Individual ADMIN grants (incl. Gabriel Cotoi on MAFQA-ffc-core-samples) were deliberately held for owner confirmation (995 in total) - the owner/team lead confirms and the migration team grants it the same day.'
  'DEF-163' = 'Fixed 15 Nov. KON-kplus-front was rebuilt with Lukasz Garstecki''s e-mail mapping (609 Finastra/Misys/DH addresses -> Teciem) and swapped in: commits by current staff now link to their Teciem GitHub accounts and commit search by author works (e.g. author:lukasz-garstecki_tciem = 592 commits). Commit signatures cannot be kept when history is rewritten. Leavers have no account, so their commits are found by author-email/author-name.'
  'DEF-175' = 'Fixed at cutover. SPH-sophis''s re-import failed twice, so the existing repo was kept and every PR created in fin-tcm after its import was recreated through the API (14-15 Nov); SPH-sophis now shows the same PR count as fin-tcm.'
  'DEF-184' = 'Fixed at cutover. All PRs missing in the 13 repos were recreated on 14-15 Nov. Where PRs remain missing anywhere, their code no longer exists in Finastra GitHub so they cannot be copied (371 PRs in 10 repos, each checked; list and evidence in the PR gap report).'
  'DEF-209' = 'Fixed at cutover. Releases copied (GIT-007A, plus 9 more on 15 Nov): KON-kplus-front has all 4,239 releases with the same tag, draft and pre-release settings as fin-tcm (2 draft releases re-attached to their tags on 15 Nov).'
  'DEF-219' = 'Fixed at cutover for non-admin access: 703 direct collaborator grants added (14-15 Nov, incl. people found later under other surnames). Admin grants (995) are held for owner confirmation by design; people with no Teciem account are with Teciem IT (Vlad Negrea).'
}
$info = [ordered]@{
  'DEF-243' = 'Known GitHub limitation, no fix possible (same as DEF-235/238). SUM-summit PRs that the import could not bring were recreated through the API: GitHub gives them the next free number (fin-tcm #46959 -> tcm-pilot #46974), shows merged PRs as closed and does not allow setting the original author, reviewers, labels or comments. The PR is built on temporary branches fin-tcm-pr/<n>-base/-head (deleted afterwards) because a merged PR''s changes are already in its original target branch. The code itself is complete; each recreated PR names and links to the original. A full number map (7,364 recreated PRs) is available.'
  'DEF-245' = 'Code complete, PR page is a snapshot. SUM-summit-helm-charts #522 was still open when the repo was imported (17 commits at that point); it was merged in fin-tcm on 6 Oct with 25 commits. The final sync brought the merged code into master (merge commit 9f1d222 is in tcm-pilot master) and the copy was closed on 12 Oct with a link to the original. GitHub cannot add commits to a closed PR, so its page shows the pre-import commits. Same for other PRs that were open at import and merged later.'
}
$sid = '3761521504348036'
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$hd = @{ Authorization = "Bearer $tok" }
$sh = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sid" -Headers $hd
$cid = @{}; $sh.columns | ForEach-Object { $cid[$_.title] = $_.id }
$upd = @()
foreach ($set in @(@($retest, 'Ready for Retest'), @($info, $null))) {
  foreach ($k in $set[0].Keys) {
    $row = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $cid['Defect ID']).value -eq $k }
    if (-not $row) { Write-Warning "$k not found"; continue }
    $cur = ($row.cells | Where-Object columnId -eq $cid['Resolution']).value; $st = ($row.cells | Where-Object columnId -eq $cid['Status']).value
    $cells = @(@{ columnId = $cid['Resolution']; value = $(if ($cur) { "$($set[0][$k])`n`n[earlier] $cur" } else { $set[0][$k] }) })
    if ($set[1]) { $cells += @{ columnId = $cid['Status']; value = $set[1] } }
    "{0} [{1} -> {2}]{3}" -f $k, $st, $(if ($set[1]) { $set[1] } else { $st }), $(if ($cur) { ' (keeps earlier resolution below the new one)' } else { '' })
    $upd += @{ id = $row.id; cells = $cells }
  }
}
if (-not $Apply) { "DRY RUN: $($upd.Count) rows"; return }
$r = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sid/rows" -Headers $hd -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -Depth 6 @($upd))))
"posted: $($r.result.Count) rows ($($r.message))"
