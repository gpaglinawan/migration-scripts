# 15 Nov 2026 - read-only: in a tcm-pilot repo, finds PRs recreated by pr-recreate ("Migrated from fin-tcm PR #N")
# whose original #N ALSO exists in the same repo (imported by GitHub) -> duplicate. Prints both, with state + title.
# Usage: pr-duplicates.py <repo> [<repo> ...]
import json, os, re, sys, urllib.request
tok = os.environ['GH_TGT_PAT']
def gql(q, v):
    r = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v}).encode(), headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
    return json.load(urllib.request.urlopen(r, timeout=120))['data']
MARK = re.compile(r'^(?:> )?Migrated from fin-tcm PR #(\d+)\b')
for repo in sys.argv[1:]:
    prs, after = [], None
    while True:
        d = gql('query($r:String!,$a:String){ repository(owner:"tcm-pilot", name:$r){ pullRequests(first:100, after:$a){ pageInfo{hasNextPage endCursor} nodes{ number state title body } } } }', {'r': repo, 'a': after})
        p = d['repository']['pullRequests']; prs += p['nodes']
        if not p['pageInfo']['hasNextPage']: break
        after = p['pageInfo']['endCursor']
    native = {x['number']: x for x in prs if not MARK.match(x['body'] or '')}
    dups = [(int(MARK.match(x['body']).group(1)), x) for x in prs if MARK.match(x['body'] or '') and int(MARK.match(x['body']).group(1)) in native]
    print(f'{repo}: {len(prs)} PRs, recreated {sum(1 for x in prs if MARK.match(x["body"] or ""))}, duplicates {len(dups)}')
    for n, x in sorted(dups, key=lambda t: t[0]):
        o = native[n]; print(f'   original #{n} ({o["state"]}) "{o["title"][:60]}"  <-> copy #{x["number"]} ({x["state"]})')
