﻿# Finastra -> Teciem migration: scripts by purpose (collected 17 Nov 2026)

All scripts used for the GitHub migration (fin-tcm -> tcm-pilot) and the Azure DevOps migration (TreasuryCapitalMarkets -> tcm-staging), grouped by what they are for.
No credentials are stored in any script; they read tokens at run time from a local file on the migration VM, which is not included.
Scripts that change anything run as a dry run unless called with -Apply (column Safety in INDEX.csv). Each script starts with a comment explaining what it does, when it was written and who approved it.

| Folder | What these scripts are for | Scripts |
|---|---|---|
| 01-migration-copy-and-sync | Copy repositories from Finastra (fin-tcm) to Teciem (tcm-pilot) with GitHub Enterprise Importer, then keep them in line until cutover (nightly/delta/corrective syncs, pushes of individual repositories). | 11 |
| 02-large-files-git-lfs | Repositories with files over GitHub's size limit: move those files to Git LFS (history rewrite), copy and verify LFS objects, author e-mail mapping for KON-kplus-front. | 14 |
| 03-freeze-and-read-only | Make platforms read-only for cutover and control exceptions: GitHub org rulesets and migration bypass, preserving Finastra refs, Azure DevOps freeze and short pull-request windows. | 14 |
| 04-access-teams-identities | Who has access: teams and team nesting, direct collaborators, admin grants, service accounts, Finastra-to-Teciem account matching, placeholder (mannequin) linking, Copilot seats. | 17 |
| 05-repo-settings-releases-secrets | Repository content around the code: releases and assets, Actions secrets/variables/environments, autolinks, projects, workflows, code scanning results. | 16 |
| 06-pull-requests | Pull requests that the import could not bring: find gaps, recreate them, recover ones whose reference was lost, copy their original discussion into tcm-pilot as archive comments. | 20 |
| 07-reimport-swap-cleanup | Re-import a repository with its full pull-request history (commit IDs unchanged), check it, swap it in place of the live repository, carry over branches, and clean up branches deleted in Finastra. | 20 |
| 08-validation-reporting-handover | Compare Finastra and Teciem (branches, tags, PRs, access, LFS), build the migration tracksheet, inventories and the BAU handover document; health checks of the migration VM. | 15 |
| 09-azure-devops | Azure DevOps (TreasuryCapitalMarkets -> tcm-staging): pull-request recreation, permissions, feeds, freeze. | 9 |
| 10-test-org-rehearsals | Rehearsals and access set-up in the test organisation tcm-pilot-test before doing the same in production. | 11 |
| 11-defect-log-smartsheet | Reading the defect log (Smartsheet) and posting investigations, resolutions and status updates. | 26 |
| 12-batch-runners | Small wrappers that run the scripts above for a list of repositories in the background. | 14 |

Total: 187 scripts. Full list with each script's own description, safety mode, last change and original location: INDEX.csv (opens in Excel).

## 01-migration-copy-and-sync

_Copy repositories from Finastra (fin-tcm) to Teciem (tcm-pilot) with GitHub Enterprise Importer, then keep them in line until cutover (nightly/delta/corrective syncs, pushes of individual repositories)._

- **clone-source.ps1** - 
- **corrective-sync.ps1** (dry run unless -Apply) - One-off corrective sync fin-tcm -> tcm-pilot for what the nightly sync deliberately leaves alone: DELETE  branches/tags deleted in Finastra that are still in tcm-pilot
- **delta-sync.ps1** (dry run unless -Apply) - 
- **gei-batch.ps1** - 
- **graft-onto-target.py** - TO-treasury-installer: adds the Finastra commits that tcm-pilot doesn't have yet on top of tcm-pilot's existing (LFS-rewritten, 18 Oct) history, so every branch can move forward without a force push.
- **migrate-empty.ps1** - 
- **migrate-new-repos-20261106.ps1** - Migrates the 14 repos created in fin-tcm since 2 Nov (nightly report: NOT_IN_TARGET) to tcm-pilot, then gives them the same setup as earlier batches: LFS objects, team + direct-collaborator access, rulesets/branch protection, autolinks.
- **nightly-sync.ps1** (read-only) - Nightly fin-tcm -> tcm-pilot repository sync + report (scheduled task "Teciem nightly repo sync"). 1. snapshot branches/tags of both orgs (git ls-remote)        2. compare
- **register-nightly-sync.ps1** - Registers the Windows scheduled task "Teciem nightly repo sync" for the current user: daily at 01:00, runs C:\kon-migration\scripts\nightly-sync.ps1 (max 8 h, no overlapping runs). Runs while you are logged on
- **sync-to-target.ps1** - 
- **to-treasury-installer-refresh.ps1** - TO-treasury-installer resync (ui/core = 1.1 GB, kept in LFS in tcm-pilot). Same method as 26 Oct, in a fresh folder: 1. clone Finastra (all branches as local heads + tags + any LFS objects)

## 02-large-files-git-lfs

_Repositories with files over GitHub's size limit: move those files to Git LFS (history rewrite), copy and verify LFS objects, author e-mail mapping for KON-kplus-front._

- **kon-catchup.ps1** - 
- **kon-push.ps1** - 
- **kon-rewrite.ps1** - Moves blobs >100MB into LFS on a copy of the clone. The original clone is never modified.
- **kon-verify.ps1** (read-only) - Verifies the LFS rewrite lost nothing. Read-only on both repos.
- **lfs-audit.ps1** - 
- **lfs-check-target.ps1** (read-only) - 
- **lfs-copy.ps1** - 
- **lfs-copy-objects.ps1** - 
- **lfs-copy-ri.ps1** - 14 Nov 2026 (cutover night, GIT-020B/019B follow-up). pr-preload.ps1 pushes only the LFS objects its own rewrite created; LFS objects the repo ALREADY had in fin-tcm are not in GitHub's export/import, so a <repo>-ri / <repo>-pr2
- **lfs-rewrite.ps1** - 
- **lfs-verify.ps1** (read-only) - 
- **rewrite-resync.ps1** - 
- **verify-lfs-copies.ps1** (read-only) - 14 Nov 2026 - GIT-019C: verify the LFS copies (<repo>-pr2) before their swap (GIT-019D). Read-only on fin-tcm; on tcm-pilot it only ADDS missing LFS objects (fetched from fin-tcm) - never changes refs.
- **verify-rewritten.ps1** (read-only) - 

## 03-freeze-and-read-only

_Make platforms read-only for cutover and control exceptions: GitHub org rulesets and migration bypass, preserving Finastra refs, Azure DevOps freeze and short pull-request windows._

- **def116-impact.ps1** - 
- **def116-restore-grants.ps1** (dry run unless -Apply) - 10 Nov 2026 (Gareth: "restore"): add to tcm-pilot the team->repo grants that fin-tcm has and tcm-pilot lacks (DEF-116 prep). Input grant-gaps.csv. Only adds/raises to the fin-tcm permission; never lowers or removes. Base permission NOT c...
- **enforce-admins-restore.ps1** - Safety net for delta-sync.ps1: switches "include administrators" back ON for every branch in C:\kon-migration\rules\classic-bypass-branches.csv (all had it on before the sync bypass). Safe to run any time.
- **git007-blocked-refs-20261114.ps1** (read-only) - 14 Nov 2026 (Gareth: "5. bypass"). Pushes the 6 GIT-007 refs that repo rules / classic protection refused, then puts every rule back exactly as it was. Backups in C:\kon-migration\corrective-sync\blocked-20261114\.
- **git007-blocked-refs-aika-20261114.ps1** - 14 Nov 2026 (Gareth: "5. bypass" - this ref was skipped earlier because the repo was swapped at the time). Pushes AI-kondor-assistant refs/heads/feature/ka_qa_per_env_db (refused by repo ruleset 27263428: no force-push) with a
- **preserve-finastra-refs.ps1** (dry run unless -Apply) - 15 Nov 2026 (Gareth: every repo PASS for Patrick/Samar; no Teciem work may be overwritten). Additive only. For refs where tcm-pilot holds Teciem commits Finastra never had (DIFFERENT): the Finastra version is pushed NEXT TO it as
- **preserve-refs-bypass.ps1** - 15 Nov 2026 (Gareth: "yes to 1" - temporary bypass on repo rulesets for the additive fin-tcm-kept pushes). For each repo: back up its own (repo-level) rulesets, add the migration-sync team as an always-bypass actor, re-run the
- **preserve-refs-chunked.ps1** - 15 Nov 2026 - KON-kondor-enablement: Finastra branch versions are >2 GB in one push (GitHub limit). Same purpose and approval as preserve-refs-bypass.ps1 (Gareth "yes to 1"): adds refs/heads/fin-tcm-kept/<branch> only, moving it forward
- **protected-push-20261108.ps1** (dry run unless -Apply) - One-off (approved by Gareth 2026-11-08: "bypass the protected ones"). Brings the branches that branch protection or rulesets refused (nightly sync + corrective sync) in tcm-pilot into line with fin-tcm. KQ-qarc is excluded on purpose
- **readonly-ruleset.ps1** (dry run unless -Apply) - Makes every repo of an org read-only until cutover (Lukasz Garstecki's request, approved by Gareth 2026-11-09). Two org rulesets - all branches, all tags - with the rules "restrict creations", "restrict updates", "restrict deletions".
- **rules-inventory.ps1** (read-only) - Read-only: inventories org rulesets, repo rulesets and classic branch protection rules in both orgs (GraphQL,
- **rules-sync.ps1** (dry run unless -Apply) - 
- **sync-bypass-add.ps1** - Lets the nightly sync update protected branches in tcm-pilot until cutover: adds "Organization admin" as a bypass actor on each repository ruleset that blocked the sync (list: C:\kon-migration\rules\sync-blocking-rulesets.csv).
- **sync-bypass-restore.ps1** - Undo for sync-bypass-add.ps1 (run at cutover): puts every backed-up ruleset's bypass list back exactly as it was before, from C:\kon-migration\rules\bypass-backup\*.json. Run by the org owner.

## 04-access-teams-identities

_Who has access: teams and team nesting, direct collaborators, admin grants, service accounts, Finastra-to-Teciem account matching, placeholder (mannequin) linking, Copilot seats._

- **admin-coverage.py** (read-only) - 14 Nov 2026 - read-only: which held direct-admin grants are already covered in tcm-pilot because the person is a member of a team that has ADMIN on that repo. Input: admin-grants-for-owners CSV + tracksheet access CSV (team permissions).
- **archive-access-mirror.ps1** (dry run unless -Apply) - 
- **build-entra-brief.ps1** - Fills entra-brief-template.html with the current data and writes entra-brief.html (UTF-8 in and out).
- **def213-databases-rebuild.ps1** - 12 Nov 2026 (Gareth: "rebuild databases"). DEF-213: the tcm-staging Treasury/databases feed was deleted and purged 16:0x CET; Azure DevOps keeps the name reserved for a while. Retry the copy (which creates the feed) every 5 min
- **direct-collab-apply.ps1** (dry run unless -Apply) - 
- **direct-collab-compare.ps1** (read-only) - Read-only: compares DIRECT repository collaborators (people added to a repo, not through a team) in every repo.
- **direct-collab-copy.ps1** (dry run unless -Apply) - 14 Nov 2026 (Gareth: "copy direct collaborators"). Gives every fin-tcm direct collaborator who has a Teciem account the same repository permission on the same-named tcm-pilot repo. Only adds or raises; never lowers or removes. People with
- **fuzzy-person.py** (read-only) - 15 Nov 2026 - read-only: fuzzy-match name parts against every Teciem GitHub enterprise account (login + display name, accents ignored). Usage: fuzzy-person.py <name part> [<name part> ...]
- **mannequin-grant-reclaim-20261111.ps1** - Grant approved by Gareth 2026-11-11 ("2. Grant"): add Randolph-Reyes_tciem and SVC-tcm-tfc-app-1_tciem to tcm-pilot (role: member - no team access), then reclaim their mannequins (randolph-reyes_finastra, SVC-tcm-tfc-app-1_finastra), which
- **match-unmapped-members.py** (read-only) - 15 Nov 2026 (DEF-220) - read-only: for every fin-tcm member with no Teciem login in the name mapping, look for a Teciem enterprise account by NAME (accents ignored, word order ignored, surname may differ). Writes candidates to review;
- **new-repos-access.ps1** (dry run unless -Apply) - 
- **repo-access.py** (read-only) - 14 Nov 2026 - read-only access data for the tracksheet: per repo, the teams with access (slug:permission) and the number of direct collaborators. Teams via the org's team list (each team's repositories + permission), collaborators
- **svc-access-mirror.ps1** (dry run unless -Apply) - 
- **svc-jenkins-apps-teams.ps1** (dry run unless -Apply) - Gives svc-jenkins-apps-2/3/4 the same tcm-pilot team memberships as svc-jenkins-apps-1 (service account request; accounts created in Entra by Vlad, 3 Nov 2026). Adding to a team also adds
- **team-compare.ps1** (read-only) - Read-only: compares all teams (incl. secret), members, team roles, team->repo permissions and org owner roles.
- **team-fix.ps1** (dry run unless -Apply) - held for a human decision - never changed by this script
- **team-nesting-restore.ps1** (dry run unless -Apply) - 

## 05-repo-settings-releases-secrets

_Repository content around the code: releases and assets, Actions secrets/variables/environments, autolinks, projects, workflows, code scanning results._

- **autolinks-copy-missing.ps1** (dry run unless -Apply) - 
- **autolinks-repoint.ps1** (dry run unless -Apply) - 
- **code-scanning-copy-from-old.ps1** (dry run unless -Apply) - 16 Nov 2026 (DEF-249; Gareth: "go"). Finastra's code scanning API now returns 403, so the results are copied from the previous tcm-pilot copy (<repo>-old, which received them on 30 Oct) to the rebuilt <repo>:
- **code-scanning-dismissal-window.ps1** - Re-copies code scanning dismissals fin-tcm -> tcm-pilot inside a short window where delegated alert dismissal is switched off on config 287096 ("Prevent direct alert dismissals - Custom").
- **code-scanning-fill-default.ps1** (dry run unless -Apply) - 
- **code-scanning-loose-match.ps1** - 
- **code-scanning-migrate.ps1** (dry run unless -Apply) - 
- **gh-actions-inventory.ps1** (read-only) - Read-only. Inventories, in both orgs: org secrets + variables (and which repos they're shared with), per-repo
- **projects-copy.ps1** (dry run unless -Apply) - 
- **release-assets-resume.ps1** - Completes a release that release-sync.ps1 created but whose asset upload was cut off (11 Nov: ARC-comparison-engine ibfs-latest, 34 of 49 assets uploaded before "connection closed"). Adds only the assets missing in tcm-pilot (by name);
- **release-gap.ps1** (read-only) - Read-only. Compares GitHub releases fin-tcm vs tcm-pilot for every live repo (DEF-186). The nightly sync copies tags, not releases, so releases created after the import are missing; GEI also mangled some release notes (lost "}" etc.).
- **release-sync.ps1** (dry run unless -Apply) - DEF-186: copies GitHub releases fin-tcm -> tcm-pilot (the nightly sync copies tags, not releases; GEI also damaged some notes). Input: release-gap.ps1 output. Per finding:
- **secrets-copy.ps1** - 
- **secrets-copy-all.ps1** - 
- **vars-envs-copy.ps1** (dry run unless -Apply) - 
- **workflows-register.ps1** (dry run unless -Apply) - 

## 06-pull-requests

_Pull requests that the import could not bring: find gaps, recreate them, recover ones whose reference was lost, copy their original discussion into tcm-pilot as archive comments._

- **open-pr-gap.ps1** (read-only) - Read-only. Counts the OPEN pull requests in fin-tcm that tcm-pilot does not have, because they were opened after the repo was imported into tcm-pilot (the nightly sync copies branches and tags, not PRs). These are what the proposed cutov...
- **opics-programmers-pr-refresh.ps1** (read-only) - Refresh of tcm-pilot/OPICS-programmers-pr (approved by Gareth 2026-11-10: "refresh OPICS-programmers"). pr-copy-check found 1 new commit on master in fin-tcm since the copy was made (8 Nov). Steps:
- **pr-activity-since-import.ps1** (read-only) - Read-only. For every live repo: which PRs in fin-tcm changed after the repo was imported into tcm-pilot (the nightly sync copies branches and tags, not PRs). Answers Lukasz Garstecki's question (10 Nov): how many repos would need a full
- **pr-archive-build.ps1** (read-only) - 
- **pr-archive-comments.py** (dry run unless -Apply) - 15 Nov 2026 (DEF-233/240, Samar's QA P1; Gareth: "ok 1 and 2"). For PRs recreated in tcm-pilot ("Migrated from fin-tcm PR #N" in the body), copies the original discussion from Finastra GitHub (fin-tcm) into the tcm-pilot PR as archive
- **pr-copy-check.ps1** (read-only) - Read-only nightly check of the PR-preserving copies (<repo>-pr in tcm-pilot) of the repos rewritten for large files. The nightly sync skips these repos, so this says whether fin-tcm has moved on since each copy was made:
- **pr-count-methods.py** (read-only) - 15 Nov 2026 - read-only: PR count of one repo in both orgs, measured three ways (GraphQL totalCount, REST list with pagination, search API) plus PR numbers. Usage: pr-count-methods.py <repo>
- **pr-duplicates.py** (read-only) - 15 Nov 2026 - read-only: in a tcm-pilot repo, finds PRs recreated by pr-recreate ("Migrated from fin-tcm PR #N") whose original #N ALSO exists in the same repo (imported by GitHub) -> duplicate. Prints both, with state + title.
- **pr-export.ps1** (read-only) - Read-only export of every pull request in a repo: PR metadata + reviews (GraphQL, 100 per page),
- **pr-gap-recheck.py** (read-only) - 15 Nov 2026 - read-only: live PR counts fin-tcm vs tcm-pilot (GraphQL totalCount, all states) for a list of repos, next to the tracksheet status. Usage: pr-gap-recheck.py <csv with Repo column> <out.csv>
- **pr-head-commit-check.py** (read-only) - 15 Nov 2026 - read-only re-check of the 371 "not copyable" PRs (DEF-247, Christophe Curay questioned "lost their code"). For each: does the PR's head commit (and merge commit) still exist in fin-tcm, even though refs/pull/N/head is gone?
- **pr-missing-reviews-archive.py** (dry run unless -Apply) - 16 Nov 2026 (DEF-280 / DEF-107; Gareth: "2. ok"). KON-kplus-front was imported with its history rewritten for large files; the import dropped reviews and review comments it could not attach to the rewritten commits (e.g. #39043: 27 revie...
- **pr-numbers-diff.py** (read-only) - Which PR numbers fin-tcm has that a tcm-pilot copy lacks, and what they have in common (read-only).
- **pr-open-recreate.ps1** (dry run unless -Apply) - 
- **pr-recover-orphaned.ps1** (dry run unless -Apply) - 16 Nov 2026 - recreate the 108 PRs whose PR reference (refs/pull/N/head) is gone in fin-tcm but whose head commit is still available (pr-gaps\pr-head-commit-check.csv). Repos were rewritten for files > 100 MB (Git LFS), so tcm-pilot
- **pr-recreate.ps1** (dry run unless -Apply) - GIT-020: recreate in the target org the PRs that fin-tcm got after each repo's import (the nightly / final syncs copy branches and tags, not PRs). Approved design (CUTOVER-STEPS GIT-020, Gareth 10 Nov incl. closed/merged, DEF-114/DEF-138).
- **pr-recreate-rehearsal.ps1** - GIT-020 rehearsal (11 Nov): waits for the 4 test copies (tcm-pilot -> tcm-pilot-test/<repo>-git020, queued 00:21 CET), then runs pr-recreate.ps1 -Apply against them and times it. Test org only.
- **pr-stats-compare.ps1** (read-only) - Read-only: compares every PR of fin-tcm/<Repo> with <TargetOrg>/<Target> (state, review / comment / review-thread counts). Re-check of pr-preload's verify stage; stops (instead of counting the rest as different) if a page cannot be read.
- **taas-tms-pr-import.ps1** (read-only) - TAAS-tms in tcm-pilot has all branches but 0 of its 192 PRs (the first import carried the code only). Approved by Gareth 2026-11-09: re-import it from fin-tcm with GitHub Enterprise Importer as tcm-pilot/TAAS-tms-pr (PRs, reviews, commen...
- **verify-archive-comments.py** (read-only) - 16 Nov 2026 - read-only: every open recreated PR whose original had discussion (Samar's open_recreated_detail.csv) must have an "Archived discussion from Finastra GitHub" comment in tcm-pilot.

## 07-reimport-swap-cleanup

_Re-import a repository with its full pull-request history (commit IDs unchanged), check it, swap it in place of the live repository, carry over branches, and clean up branches deleted in Finastra._

- **add_missing_reviews.py** - Adds back the reviews GitHub's export drops ("Body required for pull request reviews that are comments or requesting changes"): "changes requested" reviews with no text. The importer needs a body, so each gets a short placeholder.
- **add_missing_users.py** - DEF-106 (12 Nov 2026): GitHub's org export leaves out of users_*.json the unclaimed placeholder accounts (from the 2023 Bitbucket import) that authored PRs, reviews and comments; the importer then gives their
- **check_refs.py** (read-only) - Read-only: checks every ref of the original export against the rewritten repo, case-sensitively. Expected new value = commit-map[old commit] (tags compared by the commit they point to).
- **extra-branches-delete.ps1** (dry run unless -Apply) - 16 Nov 2026 (DEF-067/086/261/262/265; Gareth: "1. ok"). Deletes in tcm-pilot the branches that Finastra deleted after migration (list: branch-cleanup\extra-branches-20261116-1551.csv). Per repo:
- **extra-branches-list.ps1** (read-only) - 16 Nov 2026 (DEF-261/262/265; Gareth: "OK to all" - list first, for review). READ-ONLY. Branches present in tcm-pilot but not in fin-tcm (= deleted in Finastra after migration; delta syncs never delete).
- **fix_refs.py** - Fixes ref names after git-filter-repo on Windows (case-insensitive filesystem merged/renamed some branches, and refs/remotes/origin/* were turned into branches). Rebuilds the ref list from the ORIGINAL export, case-exact:
- **gql_changes_requested.py** - 14 Nov 2026 (cutover night): GraphQL fetch of the CHANGES_REQUESTED reviews of every PR in a repo, for add_missing_reviews.py. REST needs one call per PR (5,000/h shared by every run on the VM - the review step of the
- **kplus-mailmap-rebuild.ps1** - 15 Nov 2026 (Gareth: Lukasz wants his email mapping applied to KON-kplus-front for commit search). Builds a NEW copy tcm-pilot/KON-kplus-front-pr2 whose commits carry Teciem e-mails (Lukasz's v08 "Transformation list").
- **lfs-copy-between-repos.ps1** - 16 Nov 2026 (DEF-286, CRITICAL): copy every Git LFS object referenced by any branch/tag of tcm-pilot/<Repo> from tcm-pilot/<From> (e.g. ARC-almonde-old, archived - read only) into tcm-pilot/<Repo>. Additive: uploads objects only, no git ...
- **mailmap_from_xlsx.py** - 15 Nov 2026 - builds a git .mailmap (email-only: "<new> <old>") from Lukasz Garstecki's mapping workbook, sheet "Transformation list" (A = commit email in Finastra GitHub, B = Teciem e-mail). stdlib only.
- **pr-preload.ps1** (read-only) - PR-preserving import of a large-file repo (approved by Gareth 2026-11-06: preload under a temporary name). Generalised from C:\kon-migration\kplus-front-pr-remap (KON-kplus-front -> tcm-pilot-test/KON-kplus-front-pr, 5 Nov).
- **pr-preload-closed-20261111.ps1** - PR pre-load (approved by Gareth 2026-11-11, "1. yes"): recreate in tcm-pilot, ahead of cutover, the PRs created in fin-tcm after each repo's import that are already MERGED or CLOSED there (they no longer change). Open + stale PRs and any...
- **pr-preload-to-pilot.ps1** (read-only) - Builds a PR-preserving copy <Repo>-pr in tcm-pilot with pr-preload.ps1 while tcm-pilot is read-only (org rulesets "Migration read-only until cutover"). The long stages (export, extract, rewrite, remap, archive) run with nothing changed;
- **reimport-rehearsal.ps1** - PR method rehearsal (approved by Gareth 2026-11-10): times a full GEI re-import (code + all PRs, reviews, comments, same numbers) of a sample of the 311 repos with PR changes since import, so the cutover option "re-import the 311 repos" ...
- **remap_pr_shas.py** - Step 4: rewrites commit ids in the exported PR data using git-filter-repo's commit-map (old -> new). Input:  export dir (JSON files from the fin-tcm migration archive), commit-map file.
- **repo-swap.ps1** (dry run unless -Apply) - GIT-019D / GIT-020D (written 14 Nov 2026 overnight; approved by Gareth to write + rehearse in tcm-pilot-test ONLY - a run against tcm-pilot needs his explicit go). Swaps a rebuilt copy into place:
- **run-batch.ps1** - Runs pr-preload.ps1 for several repos one after the other (one at a time: disk space). A repo that stops is logged and the batch moves on. Summary: C:\kon-migration\pr-preload\batch.log
- **run-list.ps1** (read-only) - 13 Nov 2026 (cutover, GIT-019B / GIT-020B; Gareth: "yes 1"). Runs pr-preload.ps1 for a list of repos, N at a time, each into a NEW repo <repo>-<Suffix> in tcm-pilot and a NEW work folder (never reuses an earlier run's state).
- **swap-checked.ps1** - 16 Nov 2026 - check-then-swap for re-imported copies <repo>-pr2 (Gareth approved the swaps for tonight's re-imports). Per repo, STOPS (no swap) at the first failed check:
- **swap-precheck.ps1** (read-only) - 16 Nov 2026 - READ-ONLY. Before swapping <repo>-<Suffix> (copy of fin-tcm) over the live tcm-pilot/<repo>: lists every branch/tag of the live repo whose commits are NOT in the copy (= work done in tcm-pilot only, which the swap would lea...

## 08-validation-reporting-handover

_Compare Finastra and Teciem (branches, tags, PRs, access, LFS), build the migration tracksheet, inventories and the BAU handover document; health checks of the migration VM._

- **bau-doc.py** (read-only) - 16 Nov 2026 - builds the BAU handover document (HTML, opens in Word) from the inventory CSVs in C:\kon-migration\bau-pack\
- **bau-inventory.py** (read-only) - 16 Nov 2026 - BAU handover pack (Vamsi Thenneti's request). READ-ONLY inventory of a GitHub org into CSV/JSON: org-settings.json, org-runners.csv, org-rulesets.csv, members.csv, teams.csv, team-members.csv,
- **build-tracksheet.py** (read-only) - 14 Nov 2026 - GitHub migration validation tracksheet (fin-tcm -> tcm-pilot), requested by Samar Roy. One row per fin-tcm repo: migration route, source vs target per metric, status per check, overall status.
- **disk-watchdog.ps1** - 
- **probe-github.ps1** (read-only) - 
- **refs-compare.ps1** (read-only) - Read-only: compares the ls-remote dumps of both orgs, per repo, branch and tag.
- **refs-dump.ps1** (read-only) - 
- **repo-metrics.py** (read-only) - 14 Nov 2026 - read-only metrics per repo for the GitHub tracksheet: PRs (open/merged/closed), releases, archived, default branch, size, LFS-tracked flag not available via API. 25 repos per GraphQL query.
- **samar-monitor.ps1** (read-only) - Read-only progress check for tonight (14 Nov 2026), for Samar while Gareth is out. Changes nothing. Needs a GitHub token that can read fin-tcm and tcm-pilot (classic PAT with repo + read:org, SSO-authorised).
- **search-index-dupes.py** (read-only) - 15 Nov 2026 - read-only: lists every PR GitHub's SEARCH INDEX returns for a repo (sliced by created month so each slice stays under the 1,000-result search cap), then compares with the real PR list (REST). Shows whether the search
- **tracksheet-refresh.ps1** (read-only) - 14 Nov 2026 - hourly refresh of the GitHub validation tracksheet (Smartsheet 7889214613180292 + Excel copy) until the GitHub Go/No-Go. Re-reads PR/release/size/teams/collaborators for both orgs (read-only, ~10-15 min); the code column
- **tracksheet-smartsheet.ps1** - 14 Nov 2026 (Gareth: "create smartsheet. Share it with me first"). Creates (first run) or refreshes the live GitHub validation tracksheet in Gareth's Smartsheet Home (private to him; not in any workspace, not shared).
- **verify-and-push.ps1** - 
- **verify-remote.ps1** (read-only) - 14 Nov 2026 - GIT-020C for copies built on another VM (Samar's): no local run.log, so everything is read from GitHub. Per repo: PR numbers fin-tcm vs copy vs current repo (GraphQL), and every branch/tag commit fin-tcm vs copy (ls-remote).
- **verify-ri.ps1** (read-only) - 14 Nov 2026 (GIT-020C / GIT-019C). For every finished copy under C:\kon-migration\pr-preload\cutover-20261113 that is not yet in C:\kon-migration\swap\git-020c-verify.csv: refs + PR-identity result from its own verify stage, plus a

## 09-azure-devops

_Azure DevOps (TreasuryCapitalMarkets -> tcm-staging): pull-request recreation, permissions, feeds, freeze._

- **ado-active-pr-recreate.ps1** (dry run unless -Apply) - 15 Nov 2026 (Gareth: "ok fix it" - DEF-244/DEF-125/DEF-134). Recreates in tcm-staging every pull request that is still ACTIVE in Finastra's TreasuryCapitalMarkets org (ADO cannot import PR history between orgs). Same project/repo names,
- **ado-feed-permissions-sync.ps1** (dry run unless -Apply) - 12 Nov 2026 (Gareth: "grant feed permissions"). Mirrors feed permissions from TreasuryCapitalMarkets to tcm-staging. Identities are mapped by name: groups "[<org or project>]\<group>", project build service "<project> Build Service",
- **ado-feed-views-sync.ps1** (dry run unless -Apply) - 12 Nov 2026 (Dariusz Dyjak: promotions to the Release view missing in tcm-staging feeds). Copies feed view promotions (Release / Prerelease) from TreasuryCapitalMarkets to tcm-staging for package
- **ado-freeze.ps1** (dry run unless -Apply) - 13 Nov 2026 (Gareth, after Samar asked us to freeze Azure DevOps). Makes the Git repos of the in-scope TreasuryCapitalMarkets projects read-only by adding Deny entries; it never removes or lowers anything.
- **ado-freeze-target.ps1** (dry run unless -Apply) - 14 Nov 2026 (Samar via Gareth: "make tcm-staging read-only - ensure nobody will change"). Same mechanism as ado-freeze.ps1 (which froze TreasuryCapitalMarkets), pointed at tcm-staging: adds Deny entries for Contribute (4),
- **ado-history-pr-recreate.ps1** (dry run unless -Apply) - 15 Nov 2026 (Gareth: DEF-246 - recreate ADO PR history like DEF-244, test first). Recreates COMPLETED and ABANDONED pull requests of a Finastra (TreasuryCapitalMarkets) repo in a tcm-staging repo, as records with the original title,
- **ado-pr-window.ps1** - 15 Nov 2026 (Gareth: "yes and fix" - DEF-244). tcm-staging is frozen (Deny entries from ado-freeze-target.ps1). To recreate the 64 active Finastra PRs, this opens ONLY the PullRequestContribute bit (16384) in the existing Deny entries
- **ado-validate-counts.ps1** (read-only) - 13 Nov 2026 - ADO-011 count comparison, TreasuryCapitalMarkets vs tcm-staging, for the 9 in-scope projects. Read-only. Repos/refs come from ado-nightly-sync.ps1 -DryRun; this script adds repos, work items, pipelines,
- **probe-ado.ps1** (read-only) - Read-only probe of everything an Azure DevOps project/org holds, source vs target, per project (matched by name).

## 10-test-org-rehearsals

_Rehearsals and access set-up in the test organisation tcm-pilot-test before doing the same in production._

- **test-org-access-20261109.ps1** - Access for 3 repos copied into tcm-pilot-test on 9 Nov 2026 (approved by Gareth: "grant"). OPICS-opicsdevops               SaiYaswanth Chavan: same access as OPICS-opics4plus in tcm-pilot-test (teams + direct)
- **test-org-access-cristian-20261109.ps1** - 9 Nov 2026, approved by Gareth ("grant"): Cristian Ilie asked for 18 repos in tcm-pilot-test to test commits, PRs and merges. Adds Cristian-Ilie_tciem as a direct collaborator with WRITE (push) on each of them - matching the write teams
- **test-org-access-def198-20261111.ps1** - DEF-198 (approved by Gareth 2026-11-11: "grant", scope as proposed: write on the Kondor repos, not admin). Gives Octavian-Humita_tciem, Ioan-Acristei_tciem, Ion-Ciubotaru_tciem write (push) on every KON-* repo in tcm-pilot-test.
- **test-org-copy.ps1** - 
- **test-org-gei.ps1** - 
- **test-org-grants-20261103.ps1** - tcm-pilot-test access requests of 3 Nov 2026. Safe to re-run (repos still importing are reported and skipped). - Jason Gibbons + Sebastian Alin Macovei: org members, admin on SPH-sophis (Jason's request, write-access testing)
- **test-org-infra-access.ps1** - Gives the DevOps Infra team access to the Jenkins repositories in tcm-pilot-test (Huy-Chu Kuoy's request, 26 Oct 2026). Creates team "devops-infra-test" once, adds the members of buil-tcm-devops-infra (= mailing list TCM-DevOps-Infra)
- **test-org-kondor-access.ps1** - Gives the Kondor DevOps team access to their repositories in tcm-pilot-test (Paul Jouet's integration test). Creates team "kondor-devops-test" once, adds the members of kon-tcm-devops-run (= mailing list TCM-DevOps-Kondor)
- **test-org-lfs-copy.ps1** - 
- **test-org-opics-access.ps1** - Gives R&D access to OPICS-opics4plus in tcm-pilot-test (Vijay Kumar's request, 3 Nov 2026). Creates OPICS_W / OPICS_R in the test org with the same members as in tcm-pilot, and grants them
- **test-org-summit-access.ps1** - Gives the Summit DevOps team access to their repositories in tcm-pilot-test (Soukaina Lourhaoui's request, 26 Oct 2026). Creates team "summit-devops-test" once, adds the people below and grants the team admin on every repo of the list

## 11-defect-log-smartsheet

_Reading the defect log (Smartsheet) and posting investigations, resolutions and status updates._

- **open-defects-check.ps1** (read-only) - Read-only status check for open defects that can be verified by script (fin-tcm vs tcm-pilot).
- **post-20261109-evening.ps1** - 9 Nov 2026 evening: comments on DEF-072/106/107/163/164 after the KON-kplus-front trial results (Piotr, Christophe). Comments only; statuses and resolutions are not changed. Run with -DryRun first.
- **post-20261109-late.ps1** - 9 Nov 2026 late: DEF-099 retest result and findings on DEF-114/138/140/143. Comments only; no status change. Run with -DryRun first.
- **post-20261109-night.ps1** - 9 Nov 2026 night (Gareth: "fix as many as we can and update the smartsheet"). Comments on DEF-067/086/099/114/116/136/137/138/139; status -> "Ready for Retest" on DEF-067 and DEF-086 only.
- **post-20261109-pr-copies.ps1** - 9 Nov 2026 (Gareth: "post them"): comments on DEF-045/083/093/110 and resolutions on DEF-083/110 - the PR-preserving (-pr) copy approach. Statuses are not changed. Run with -DryRun first.
- **post-20261109-retest.ps1** - 9 Nov 2026 (Gareth: "update the status that are ready for retest"): DEF-140 and DEF-143 -> Status "Ready for Retest", plus their 11/9 comments. Only these two rows; nothing else changed. Run with -DryRun first.
- **post-20261110.ps1** - 10 Nov 2026 (Gareth: "verify and update the smartsheet" after Vlad's Entra fixes). Comments on DEF-136/137/139/116; status -> "Ready for Retest" on DEF-139 only (DEF-136/137 already Ready for Retest). Run with -DryRun first.
- **post-20261110-def171-114-138.ps1** - 10 Nov 2026 (Gareth: "update pls"): comments on DEF-171 (Advanced Security findings) and DEF-114 / DEF-138 (deferral reason brought up to date with the 10 Nov PR plan). Comments column only - statuses and Resolutions are not changed. Run...
- **post-20261110-triage.ps1** (read-only) - 10 Nov 2026 (Gareth: "browse the smartsheet and fix what we can"): findings / fixes on the new and open GitHub + ADO defects. Comments column only - statuses and Resolutions are not changed. Run with -DryRun first.
- **post-20261111.ps1** - 11 Nov 2026 (Gareth: "3. OK 4. OK", "2 grant"): comments on DEF-186 / 187 / 196 / 207 / 198, and the plain-text password removed from the DEF-162 description. Statuses are not changed. Run with -DryRun first.
- **post-20261111-def055.ps1** - 11 Nov 2026 (Gareth: "post in DEF-055"). Comment only - status not changed. Run with -DryRun first.
- **post-20261111-def067.ps1** - 11 Nov 2026 (Gareth: "post"). Comment only - status (Deferred) not changed. Run with -DryRun first.
- **post-20261111-def074.ps1** - 11 Nov 2026 (Gareth: "ok post"). Comment only - status (Deferred) not changed. Run with -DryRun first.
- **post-20261111-def085-086-092.ps1** - 11 Nov 2026 (Gareth: "comment as well" on DEF-085, DEF-086, DEF-092). Comments only - statuses not changed. -DryRun first.
- **post-20261111-def100.ps1** - 11 Nov 2026 (Gareth: "post"). Comment only - status not changed. Run with -DryRun first.
- **post-20261111-def101.ps1** - 11 Nov 2026 (Gareth: "post"). Comment only - status not changed. Run with -DryRun first.
- **post-20261111-def106.ps1** - 11 Nov 2026 (Gareth: "ok go"). Comment only - status not changed. Run with -DryRun first.
- **post-20261112-def036-resolution.ps1** - 12 Nov 2026 (Gareth: "post"). Sets the empty Resolution cell of DEF-036 (Alexandra Vate asked). Nothing else changed.
- **post-20261112-def055.ps1** - 12 Nov 2026 (Gareth: "post"). DEF-055 comment + Status -> Ready for Retest. Run with -DryRun first.
- **post-20261114-def225-226.ps1** - 14 Nov 2026 (Gareth: "post"). DEF-225 comment (status unchanged: depends on Teciem IT); DEF-226 comment + Status -> Ready for Retest.
- **post-20261115-fixed-at-cutover.ps1** (dry run unless -Apply) - 15 Nov 2026 (Gareth: "ok let us start" - item 2). Resolution text for defects fixed by the cutover work (status -> Ready for Retest) plus DEF-243/245 (known limitation, status unchanged). Dry run unless -Apply.
- **post-20261115-new-defects.ps1** (dry run unless -Apply) - 15 Nov 2026 (Gareth: "list all new defects today ... post the resolution to smartsheet"). Writes the Resolution column of the 10 GitHub defects reported on 15 Nov. Status is NOT changed. Dry run unless -Apply.
- **smartsheet-comment.ps1** - Appends a dated line to the "Comments" column of one or more rows in the Defect Log Smartsheet. Usage: .\smartsheet-comment.ps1 -Updates @{ 'DEF-013' = 'text'; 'DEF-014' = 'text' } [-DryRun]
- **sweep-diff.py** (read-only) - Hourly defect sweep: read the live defect log, diff against sweep-state.json, print new/changed defects, save state. Read-only on Smartsheet. Token read from pats.txt, never printed.
- **team-settings-diff.ps1** (read-only) - DEF-013 / DEF-014 / DEF-118 (read-only): compares every team in fin-tcm with tcm-pilot (matched by slug): display name (capitals), description, privacy, parent, and code review assignment settings.
- **team-settings-fix.ps1** (dry run unless -Apply) - DEF-013 / DEF-014 / DEF-118: restores tcm-pilot team display names, descriptions and code review assignment to match fin-tcm, from team-settings-diff.csv. Dry run unless -Apply.

## 12-batch-runners

_Small wrappers that run the scripts above for a list of repositories in the background._

- **kplus-reapply-access.ps1** - 15 Nov 2026 - after the KON-kplus-front swap GitHub briefly locks the new repo. Waits for the lock to clear, then copies teams, direct collaborators and repo rulesets from the previous live repo (KON-kplus-front-old2) onto KON-kplus-front.
- **kplus-wait-unlock.ps1** - 
- **msi-reimport.ps1** - 
- **run-all-20261116.ps1** (dry run unless -Apply) - 16 Nov (Gareth: "OK to all"; Ana-Maria Q3): archive the original discussion for ALL recreated PRs (closed/merged too), so it stays readable when Finastra access ends. Idempotent: PRs already archived (the 410 open ones) are skipped.
- **run-cristian-20261116.ps1** (dry run unless -Apply) - 16 Nov (Gareth: "OK to all"; Ana-Maria Q3): archive the original discussion for ALL recreated PRs (closed/merged too), so it stays readable when Finastra access ends. Idempotent: PRs already archived (the 410 open ones) are skipped.
- **run-fcbo-ptp-20261116.ps1** - 16 Nov 2026 (DEF-114; Gareth: "1 and 2"). PR-preserving copies <repo>-pr2 with unchanged commit IDs, 3 at a time. Nothing live is touched.
- **run-go-20261117.ps1** - 
- **run-inventory.ps1** - 
- **run-open-20261115.ps1** (dry run unless -Apply) - 
- **run-patrick-8-20261116.ps1** - 16 Nov 2026 (DEF-114; Gareth: "1 and 2"). PR-preserving copies <repo>-pr2 with unchanged commit IDs, 3 at a time. Nothing live is touched.
- **run-retry-20261115.ps1** (dry run unless -Apply) - 
- **run-retry2-20261116.ps1** (dry run unless -Apply) - 
- **run-sum-summit-20261116.ps1** (dry run unless -Apply) - 
- **run-top25-20261116.ps1** - 16 Nov 2026 (DEF-114; Gareth: "1 and 2"). PR-preserving copies <repo>-pr2 with unchanged commit IDs, 3 at a time. Nothing live is touched.

