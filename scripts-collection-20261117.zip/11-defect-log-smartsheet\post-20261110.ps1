# 10 Nov 2026 (Gareth: "verify and update the smartsheet" after Vlad's Entra fixes). Comments on DEF-136/137/139/116;
# status -> "Ready for Retest" on DEF-139 only (DEF-136/137 already Ready for Retest). Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-136' = 'Verified after Vlad''s Entra ID fix: the account Sumitkumar-Das_tciem exists in the Teciem enterprise (name "Sumit Kumar Das"). Correction to the 11/9 comment: the account had already been created on 24 Sep; it was only missing from the organisations, and the sign-in error was the Entra assignment, now fixed. Retest: Sumitkumar signs in at github.com/tcm-pilot. He is not yet a member of tcm-pilot (he had no fin-tcm account, so there is no team list to copy) - to see the Kondor repositories he must be added to the right Kondor team(s); waiting for which team(s).'
  'DEF-137' = 'Verified after Vlad''s Entra ID provisioning change: 784 of the 788 tcm-pilot members now show "First Last" (e.g. "Leon Kemna", "Christophe Curay"). The other 4 are suspended accounts that are no longer provisioned, so they keep the old format. Ion Ciubotaru shows "Ciubotaru Ion" because his first and last name are the other way round in Entra ID (same as his login, see DEF-139); Teciem IT can correct his record. Ready for retest by Leon.'
  'DEF-139' = 'Fixed 10 Nov: Ion-Ciubotaru_tciem added to tcm-pilot and to his 14 fin-tcm teams as member (fabcom, buil, folm_w, fnx_w, kon_w, mch_w, risk_r, risk_w, solint_w, tcmlib_w, tcmrep_w, to_w, copilot, kondor-risk-limits); through the child teams he is also in kon, mch, risk, to etc. as in fin-tcm. Ready for retest by Leon (still: which team showed "4 vs 3"?).'
  'DEF-116' = 'Progress 10 Nov: before switching the base permission, team access was compared for every team and repository in both organisations. 604 team grants that fin-tcm has were missing in tcm-pilot (hidden today by the base "Read"), e.g. protivity read on 560 repos and the Jenkins CI team buil-bm-ci-jenkins write on 23 repos. 602 have been added so tcm-pilot matches fin-tcm; the other 2 belong to enterprise team ent:alm (no members in tcm-pilot). The switch to "No permission" is on hold until it is confirmed what 9 accounts that are in no team need (they would lose all access): SVC-CVBACKUP_tciem and 8 people with no fin-tcm account.'
}
$statusTo = @{ 'DEF-139' = 'Ready for Retest' }
$sheetId = 3761521504348036
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$ssAuth = @{ Authorization = "Bearer $tok" }
$sheet = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sheetId" -Headers $ssAuth
$idCol = ($sheet.columns | Where-Object title -eq 'Defect ID').id; $stCol = ($sheet.columns | Where-Object title -eq 'Status')
$rows = foreach ($defect in $statusTo.Keys) {
  if (@($stCol.options).Count -and @($stCol.options) -notcontains $statusTo[$defect]) { throw "bad status $($statusTo[$defect])" }
  $row = $sheet.rows | Where-Object { ($_.cells | Where-Object columnId -eq $idCol).displayValue -eq $defect }
  if (-not $row) { Write-Warning "$defect not found"; continue }
  "--- $defect status: '$(($row.cells | Where-Object columnId -eq $stCol.id).displayValue)' -> '$($statusTo[$defect])'" | Out-Host
  @{ id = $row.id; cells = @(@{ columnId = $stCol.id; value = $statusTo[$defect] }) }
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
if ($DryRun -or -not $rows) { return }
$res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sheetId/rows" -Headers $ssAuth -ContentType 'application/json; charset=utf-8' `
       -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @($rows) -Depth 6)))
"status rows updated: $(@($res.result).Count) (resultCode $($res.resultCode))"
