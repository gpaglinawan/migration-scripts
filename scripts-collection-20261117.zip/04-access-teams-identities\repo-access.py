# 14 Nov 2026 - read-only access data for the tracksheet: per repo, the teams with access (slug:permission) and the
# number of direct collaborators. Teams via the org's team list (each team's repositories + permission), collaborators
# via batched repository queries (25 per call). Usage: python -I repo-access.py <org> <repos.txt> <out.csv>
import sys, os, json, csv, time, urllib.request
org, listfile, out = sys.argv[1], sys.argv[2], sys.argv[3]
tok = os.environ['GH_SRC_PAT' if org == 'fin-tcm' else 'GH_TGT_PAT']
def gql(q, v=None):
    for a in range(8):
        try:
            req = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v or {}}).encode(), headers={'Authorization': f'Bearer {tok}', 'Content-Type': 'application/json'})
            d = json.load(urllib.request.urlopen(req, timeout=120))
            if any(e.get('type') == 'RATE_LIMITED' for e in d.get('errors') or []): time.sleep(60); continue
            return d.get('data') or {}
        except Exception: time.sleep(10 * (a + 1))
    return {}
teams = {}   # repo -> {slug: perm}
after = None
while True:
    d = gql('query($o:String!,$a:String){ organization(login:$o){ teams(first:20, after:$a){ pageInfo{hasNextPage endCursor} nodes{ slug repositories(first:100){ pageInfo{hasNextPage endCursor} edges{ permission node{ name } } } } } } }', {'o': org, 'a': after})
    t = d['organization']['teams']
    for n in t['nodes']:
        edges, rp = n['repositories']['edges'], n['repositories']['pageInfo']
        while rp['hasNextPage']:
            dd = gql('query($o:String!,$s:String!,$a:String){ organization(login:$o){ team(slug:$s){ repositories(first:100, after:$a){ pageInfo{hasNextPage endCursor} edges{ permission node{ name } } } } } }', {'o': org, 's': n['slug'], 'a': rp['endCursor']})
            r = dd['organization']['team']['repositories']; edges += r['edges']; rp = r['pageInfo']
        for e in edges: teams.setdefault(e['node']['name'].lower(), {})[n['slug']] = e['permission']
    if not t['pageInfo']['hasNextPage']: break
    after = t['pageInfo']['endCursor']
print(f'{org}: teams read; repos with team access {len(teams)}', flush=True)
repos = [l.strip() for l in open(listfile, encoding='utf-8-sig') if l.strip()]
coll = {}
for i in range(0, len(repos), 25):
    chunk = repos[i:i + 25]
    q = '{' + ' '.join(f'r{j}:repository(owner:"{org}",name:{json.dumps(n)}){{ collaborators(affiliation:DIRECT, first:100){{ totalCount edges{{ permission node{{ login }} }} }} }}' for j, n in enumerate(chunk)) + '}'
    d = gql(q)
    for j, n in enumerate(chunk):
        r = d.get(f'r{j}')
        if r and r.get('collaborators'): coll[n] = (r['collaborators']['totalCount'], ';'.join(f"{(e.get('node') or {}).get('login', 'ghost')}:{e['permission']}" for e in (r['collaborators'].get('edges') or []) if e))
        else: coll[n] = ('', '')
# 15 Nov: the batched GraphQL query can return fewer edges than totalCount (AI-kondor-assistant: 26 of 41) - re-read those via REST
PERM = {'admin': 'ADMIN', 'maintain': 'MAINTAIN', 'push': 'WRITE', 'triage': 'TRIAGE', 'pull': 'READ'}
def rest_collabs(n):
    res, page = [], 1
    while True:
        for a in range(5):
            try:
                req = urllib.request.Request(f'https://api.github.com/repos/{org}/{n}/collaborators?affiliation=direct&per_page=100&page={page}', headers={'Authorization': f'Bearer {tok}', 'Accept': 'application/vnd.github+json'})
                batch = json.load(urllib.request.urlopen(req, timeout=60)); break
            except Exception: time.sleep(5 * (a + 1))
        else: return None
        for c in batch:
            p = c.get('permissions') or {}
            res.append(f"{c['login']}:{next((PERM[k] for k in ('admin', 'maintain', 'push', 'triage', 'pull') if p.get(k)), 'READ')}")
        if len(batch) < 100: return res
        page += 1
short = 0
for n, (cnt, logins) in list(coll.items()):
    if cnt != '' and int(cnt) > len([x for x in logins.split(';') if x]):
        r = rest_collabs(n)
        if r is not None: coll[n] = (cnt, ';'.join(r)); short += 1
print(f'{org}: re-read {short} repos whose collaborator list came back short', flush=True)
with open(out, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['Repo', 'Teams', 'TeamCount', 'DirectCollaborators', 'CollaboratorLogins'])
    for n in repos:
        t = teams.get(n.lower(), {}); c = coll.get(n, ('', '')); w.writerow([n, ';'.join(f'{k}:{v}' for k, v in sorted(t.items())), len(t), c[0], c[1]])
print(f'done {len(repos)} -> {out}')
