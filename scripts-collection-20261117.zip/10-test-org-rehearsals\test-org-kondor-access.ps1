# Gives the Kondor DevOps team access to their repositories in tcm-pilot-test (Paul Jouet's integration test).
# Creates team "kondor-devops-test" once, adds the members of kon-tcm-devops-run (= mailing list TCM-DevOps-Kondor)
# and grants the team admin on every repo of the list that has already been copied. Safe to re-run.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$org = "tcm-pilot-test"; $team = "kondor-devops-test"
# the 15 members of distribution list TCM-DevOps-Kondor (26 Oct 2026)
$members = 'Paul-Jouet_tciem','rafal-prasal_tciem','huychu-kuoy_tciem','Marcin-Karaczewski_tciem','Lukasz-Cymanowski_tciem',
           'Dariusz-Dyjak_tciem','Adrian-Stankiewicz_tciem','NIZAR-SLAMASEFI_tciem','Lukasz-Kruczek_tciem','Wesley-VianadeSouza_tciem',
           'Andreea-Tanase1_tciem','Uriel-Cidor_tciem','Anuradha-Ede_tciem','RazvanMihai-Trifu_tciem','MihaiLaurentiu-Stefan_tciem'
$repos = @(Get-Content C:\kon-migration\kondor-integration-repos.txt) + 'KON-reusable-actions'

try { $null = Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$team" -Headers $h }
catch { Invoke-RestMethod -Method POST "https://api.github.com/orgs/$org/teams" -Headers $h -ContentType application/json -Body (@{ name = $team; description = "Kondor DevOps - divestment integration test (TCM-DevOps-Kondor)"; privacy = "closed" } | ConvertTo-Json) | Out-Null; "team $team created" }
foreach ($m in $members) { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$team/memberships/$m" -Headers $h -ContentType application/json -Body '{"role":"member"}' | Out-Null }
# keep the team equal to the list: remove anyone not on it (except the token owner, who GitHub adds as creator)
foreach ($x in (Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$team/members?per_page=100" -Headers $h)) {
  if ($members -notcontains $x.login -and $x.login -ne 'Gareth-Cabrera_tciem') { Invoke-RestMethod -Method DELETE "https://api.github.com/orgs/$org/teams/$team/memberships/$($x.login)" -Headers $h | Out-Null; "removed $($x.login) (not on the list)" }
}
"members: $($members.Count)"
$done = 0; $later = @()
foreach ($r in $repos) {
  try { $null = Invoke-RestMethod "https://api.github.com/repos/$org/$r" -Headers $h } catch { $later += $r; continue }
  # a repo that GEI is still importing exists but is locked: count it as not ready yet
  try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$team/repos/$org/$r" -Headers $h -ContentType application/json -Body '{"permission":"admin"}' | Out-Null; $done++ }
  catch { if ("$($_.ErrorDetails.Message)" -match 'locked') { $later += "$r (importing)" } else { "  $r : $($_.ErrorDetails.Message)" } }
}
"team has admin on $done repos; not ready yet ($($later.Count)): $($later -join ', ')"
