# 15 Nov 2026 (Gareth: "list all new defects today ... post the resolution to smartsheet").
# Writes the Resolution column of the 10 GitHub defects reported on 15 Nov. Status is NOT changed. Dry run unless -Apply.
param([switch]$Apply)
$ErrorActionPreference = 'Stop'
$res = [ordered]@{
  'DEF-233' = 'Known, fixes itself tonight. Recreated PRs link back to their original in Finastra GitHub under the name fin-tcm-old, which is the name Finastra''s org gets in tonight''s org rename (runbook GIT-013, after the Go). Until the rename the links return 404. Retest Mon 16 Nov.'
  'DEF-240' = 'Known, fixes itself tonight. Same cause as DEF-233: the links point to fin-tcm-old, which exists once Finastra renames its org tonight (GIT-013). Retest Mon 16 Nov.'
  'DEF-234' = 'Not used. The -ri repos are copies from a re-import that was rolled back on 14 Nov, so the original repos (with their original commit IDs) were kept. The -ri copies are not part of the migration. Plan: archive them (read-only) now and delete them after hypercare - pending approval.'
  'DEF-236' = 'Not used. SUMQA-Jenkins_scripts-ri, SUMQA-flauirunner-ri, SUMTF-QA-AgenticAI-Skills-ri and SUMTF-v99.x-ri are copies from the re-import that was rolled back on 14 Nov; the original repos are the migrated ones. Plan: archive the -ri copies now and delete them after hypercare - pending approval. Same as DEF-234.'
  'DEF-235' = 'Known GitHub limitation, no fix possible. PRs that GitHub''s import could not bring were recreated through the API under the migration account, which is why they show Gareth Cabrera as creator. GitHub does not allow setting another author, the merged state or the original number on a new PR. Each recreated PR starts with "Migrated from fin-tcm PR #N by <original author>" and links to the original. Commit author links: commits made under @finastra/@misys addresses cannot link to Teciem accounts, which only own @teciem addresses, without rewriting history (changes every commit ID). Done only for KON-kplus-front, whose commit IDs had to change anyway.'
  'DEF-238' = 'Known GitHub limitation, no fix possible. ARC-almonde PRs that the import could not bring were recreated through the API: GitHub gives them the next free number (e.g. original #9696 becomes #9694 in tcm-pilot), shows merged PRs as closed, uses temporary branch names and shows the migration account as creator. Each recreated PR names the original number and author and links to the original in Finastra GitHub. Code and history are complete.'
  'DEF-237' = 'Not a migration gap. All 39,534 copyable PRs are in tcm-pilot/KON-kplus-front (251 open). The repo was swapped in on 15 Nov 15:00 CET with the Teciem e-mail mapping and GitHub is re-indexing it for search; the PR list page reads from that index (11,408 of 39,534 indexed at 18:46 CET, climbing). Direct PR links work. 18 PRs cannot be copied because their code no longer exists in Finastra GitHub (list sent to Lukasz Garstecki and Christophe Curay). Retest Mon 16 Nov.'
  'DEF-239' = 'By design at cutover. Admin rights given to individuals in fin-tcm were not copied automatically; all 995 such grants are held for the repo owners / team leads to confirm. Action: Summit team lead confirms this person''s admin access; the migration team grants it the same day.'
  'DEF-241' = 'By design at cutover. Individual admin rights on SUM-Summit and SUM-summit-helm-charts were held for owner confirmation (995 grants held in total). Action: Summit team lead confirms; the migration team grants admin the same day.'
  'DEF-242' = 'By design at cutover. Individual admin rights on the PTP (FCBO-*) repos were held for owner confirmation (995 grants held in total). Action: PTP team lead confirms; the migration team grants admin on the listed repos the same day.'
}
$sid = '3761521504348036'
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$hd = @{ Authorization = "Bearer $tok" }
$sh = Invoke-RestMethod "https://api.smartsheet.com/2.0/sheets/$sid" -Headers $hd
$cid = @{}; $sh.columns | ForEach-Object { $cid[$_.title] = $_.id }
$upd = foreach ($k in $res.Keys) {
  $row = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $cid['Defect ID']).value -eq $k }
  if (-not $row) { Write-Warning "$k not found"; continue }
  $cur = ($row.cells | Where-Object columnId -eq $cid['Resolution']).value
  if ($cur) { Write-Warning "$k already has a Resolution - will be replaced: $cur" }
  "{0}: {1}" -f $k, $res[$k] | Write-Output
  @{ id = $row.id; cells = @(@{ columnId = $cid['Resolution']; value = $res[$k] }) }
}
$upd = @($upd | Where-Object { $_ -is [hashtable] })
if (-not $Apply) { "DRY RUN: would update the Resolution of $($upd.Count) rows (status unchanged)"; return }
$body = ConvertTo-Json -Depth 6 @($upd)
$r = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sid/rows" -Headers $hd -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
"posted: $($r.result.Count) rows updated (message: $($r.message))"
