param(
  [string]$Repo = "kon-kplus-front",
  [string]$Org = "fin-tcm",
  [string]$Out = "C:\kon-migration\pr-archive"
)
# Read-only export of every pull request in a repo: PR metadata + reviews (GraphQL, 100 per page),
# review (line) comments and conversation comments (REST, repo-wide streams). Resumable: pages already on disk are skipped.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$dir = Join-Path $Out $Repo; New-Item -ItemType Directory -Force (Join-Path $dir "prs"), (Join-Path $dir "review-comments"), (Join-Path $dir "issue-comments") | Out-Null
$log = Join-Path $dir "export.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Call($scr) {
  for ($try = 1; $try -le 8; $try++) {
    try { return & $scr }
    catch {
      $code = $_.Exception.Response.StatusCode.value__
      $wait = if ($code -in 403, 429) { 120 } else { 20 * $try }
      Log "  retry $try after error $code $($_.Exception.Message) - waiting ${wait}s"; Start-Sleep $wait
    }
  }
  throw "giving up after 8 attempts"
}
$utf8 = New-Object Text.UTF8Encoding $false

# 1. pull requests + reviews
$q = @'
query($c:String){ rateLimit{remaining resetAt} repository(owner:"OWNER", name:"REPO"){ pullRequests(first:50, after:$c, orderBy:{field:CREATED_AT, direction:ASC}){ totalCount pageInfo{hasNextPage endCursor}
  nodes{ number title body state isDraft createdAt updatedAt closedAt mergedAt url author{login} mergedBy{login}
    baseRefName headRefName baseRefOid headRefOid isCrossRepository additions deletions changedFiles
    commits{totalCount} labels(first:10){nodes{name}} assignees(first:5){nodes{login}} milestone{title}
    reviews(first:15){totalCount nodes{ databaseId author{login} state body submittedAt }} } } } }
'@ -creplace 'OWNER', $Org -creplace 'REPO', $Repo
$cursor = $null; $page = 0; $state = Join-Path $dir "prs\cursor.txt"
# [IO.File] rather than Get-Content: Get-Content strings carry PSPath etc., which ConvertTo-Json would send as an object
if (Test-Path $state) { $saved = [IO.File]::ReadAllLines($state); $page = [int]$saved[0]; $cursor = [string]$saved[1].Trim(); Log "resuming PR export after page $page" }
do {
  # some pages hold PRs so large that GitHub times out (502/504): retry with smaller pages, down to one PR
  $r = $null
  foreach ($size in 50, 50, 10, 2, 1) {
    $qs = $q -creplace 'first:50, after', "first:$size, after"
    try { $r = Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hdr -ContentType application/json -Body (@{ query = $qs; variables = @{ c = $cursor } } | ConvertTo-Json -Depth 5); break }
    catch { Log "  page of $size failed ($($_.Exception.Response.StatusCode.value__)) - retrying smaller"; Start-Sleep 20 }
  }
  if (-not $r) { $r = Call { Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers $hdr -ContentType application/json -Body (@{ query = ($q -creplace 'first:50, after', 'first:1, after'); variables = @{ c = $cursor } } | ConvertTo-Json -Depth 5) } }
  if ($r.errors -or -not $r.data) {
    $bad = 1 + [int]$bad; Log "  GraphQL empty/error response ($bad): $(($r.errors | ConvertTo-Json -Compress -Depth 5))"
    if ($bad -ge 6) { throw "GraphQL query failed 6 times - stopping (re-run resumes)" }; Start-Sleep (30 * $bad); continue
  }
  $bad = 0
  $pg = $r.data.repository.pullRequests; $page++
  [IO.File]::WriteAllText((Join-Path $dir ("prs\page-{0:D4}.json" -f $page)), ($pg.nodes | ConvertTo-Json -Depth 12 -Compress), $utf8)
  $cursor = $pg.pageInfo.endCursor; @($page, $cursor) | Set-Content $state -Encoding ascii
  $got = [int]$got + @($pg.nodes).Count
  if ($page % 20 -eq 0) { Log ("  PRs: page {0} ({1:N0} this run, {2:N0} in repo), rate limit left {3}" -f $page, $got, $pg.totalCount, $r.data.rateLimit.remaining) }
  if ($r.data.rateLimit.remaining -lt 200) { $w = [Math]::Max(60, ([datetime]$r.data.rateLimit.resetAt - (Get-Date).ToUniversalTime()).TotalSeconds + 30); Log "  rate limit low, sleeping $([int]$w)s"; Start-Sleep ([int]$w) }
} while ($bad -or $pg.pageInfo.hasNextPage)
Log "PRs done: $page pages"

# 2. repo-wide comment streams (REST, ascending by creation)
foreach ($kind in @(@{ Name = "review-comments"; Url = "https://api.github.com/repos/$Org/$Repo/pulls/comments?sort=created&direction=asc&per_page=100" },
                    @{ Name = "issue-comments";  Url = "https://api.github.com/repos/$Org/$Repo/issues/comments?sort=created&direction=asc&per_page=100" })) {
  $p = 1; while (Test-Path (Join-Path $dir ("{0}\page-{1:D4}.json" -f $kind.Name, $p))) { $p++ }
  do {
    $resp = Call { Invoke-WebRequest -UseBasicParsing "$($kind.Url)&page=$p" -Headers $hdr }
    # follow GitHub's Link header: item counting is unreliable (PS 5.1 ConvertFrom-Json emits an array as ONE object)
    $more = "$($resp.Headers.Link)" -match 'rel="next"'
    if ($resp.Content.Length -gt 2) { [IO.File]::WriteAllText((Join-Path $dir ("{0}\page-{1:D4}.json" -f $kind.Name, $p)), $resp.Content, $utf8) }
    if ($p % 50 -eq 0) { Log "  $($kind.Name): page $p" }
    $p++
  } while ($more)
  Log "$($kind.Name) done: $($p - 1) pages"
}
Log "=== export complete ==="
