# 15 Nov 2026 - read-only re-check of the 371 "not copyable" PRs (DEF-247, Christophe Curay questioned "lost their code").
# For each: does the PR's head commit (and merge commit) still exist in fin-tcm, even though refs/pull/N/head is gone?
# Input C:\kon-migration\pr-gaps\pr-unfetchable-evidence.csv ; output pr-head-commit-check.csv
import csv, json, os, urllib.request, urllib.error, time
S = os.environ['GH_SRC_PAT']
def get(url):
    for a in range(5):
        try:
            r = urllib.request.Request(url, headers={'Authorization': f'Bearer {S}', 'Accept': 'application/vnd.github+json'})
            return json.load(urllib.request.urlopen(r, timeout=60))
        except urllib.error.HTTPError as e:
            if e.code in (404, 422): return None
            if e.code in (403, 429, 502): time.sleep(20 * (a + 1)); continue
            raise
rows = list(csv.DictReader(open(r'C:\kon-migration\pr-gaps\pr-unfetchable-evidence.csv', encoding='utf-8-sig')))
out = []
for r in rows:
    pr = get(f"https://api.github.com/repos/fin-tcm/{r['Repo']}/pulls/{r['PR']}")
    head = (pr or {}).get('head', {}).get('sha'); merge = (pr or {}).get('merge_commit_sha')
    h_ok = bool(head and get(f"https://api.github.com/repos/fin-tcm/{r['Repo']}/commits/{head}"))
    m_ok = bool(merge and get(f"https://api.github.com/repos/fin-tcm/{r['Repo']}/commits/{merge}"))
    out.append({'Repo': r['Repo'], 'PR': r['PR'], 'State': r['State'], 'HeadSha': head or '', 'HeadCommitExists': h_ok,
                'MergeSha': merge or '', 'MergeCommitExists': m_ok, 'Merged': bool((pr or {}).get('merged'))})
with open(r'C:\kon-migration\pr-gaps\pr-head-commit-check.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
from collections import Counter, defaultdict
by = defaultdict(Counter)
for o in out: by[o['Repo']]['total'] += 1; by[o['Repo']]['head exists'] += o['HeadCommitExists']; by[o['Repo']]['merge exists'] += o['MergeCommitExists']
print(f"checked {len(out)}: head commit still exists {sum(o['HeadCommitExists'] for o in out)}, merge commit exists {sum(o['MergeCommitExists'] for o in out)}, neither {sum(not o['HeadCommitExists'] and not o['MergeCommitExists'] for o in out)}")
for repo, c in sorted(by.items(), key=lambda x: -x[1]['total']): print(f"  {repo:32} {c['total']:4}  head exists {c['head exists']:4}  merge exists {c['merge exists']:4}")
