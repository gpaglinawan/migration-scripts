# Read-only nightly check of the PR-preserving copies (<repo>-pr in tcm-pilot) of the repos rewritten for large files.
# The nightly sync skips these repos, so this says whether fin-tcm has moved on since each copy was made:
#   refs: every fin-tcm branch/tag, mapped through the rewrite's commit-map, must point at the same commit in the copy.
#         NEW_COMMITS = fin-tcm has commits the copy does not have (pushed after the copy); MISSING = ref not in the copy;
#         EXTRA = ref only in the copy (deleted in fin-tcm since).
#   PRs:  PRs updated in fin-tcm (new, commented, reviewed, merged, closed) since the copy's export started.
# A repo with any of these needs a refresh before cutover. Nothing is changed anywhere.
# Run: .\pr-copy-check.ps1 [-Out <folder>]    Called by nightly-sync.ps1, which adds the result to the morning report.
param([string]$Out = "C:\kon-migration\pr-copy-check\$(Get-Date -Format yyyy-MM-dd)",
      [string[]]$Repos = @('SFX-netcore-common', 'FCBO-fusion-detect-core', 'MAFTP-fpp-fusioncapital', 'MAFTP-fpp-vaas-che', 'OPICS-programmers',
                           'FWK-utfinstaller', 'TO-treasury-installer', 'RISK-cmr', 'FCGC-pricing-analytics'))
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Out | Out-Null
$env:GIT_TERMINAL_PROMPT = '0'
# nightly-sync calls this in the same process right after delta-sync.ps1, which leaves GIT_CONFIG_COUNT/KEY_0/VALUE_0
# set to an extraheader: with our own -c extraheader git would then send two Authorization headers and ls-remote fails
Remove-Item env:GIT_CONFIG_COUNT, env:GIT_CONFIG_KEY_0, env:GIT_CONFIG_VALUE_0 -ErrorAction SilentlyContinue
function Get-Hdr($tok) { "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$tok")) }
# branch/tag -> commit (annotated tags resolved to the commit they point at)
function Get-Refs($url, $tok) {
  $raw = @(git -c "http.https://github.com/.extraheader=$(Get-Hdr $tok)" ls-remote --heads --tags $url 2>$null)
  if ($LASTEXITCODE) { return $null }
  $m = @{}; $peeled = @{}
  foreach ($l in $raw) { $p = $l -split "`t"; if ($p[1] -like '*^{}') { $peeled[$p[1].Substring(0, $p[1].Length - 3)] = $p[0] } else { $m[$p[1]] = $p[0] } }
  foreach ($k in @($peeled.Keys)) { $m[$k] = $peeled[$k] }
  $m
}
function Invoke-Gql($tok, $q) {
  for ($try = 1; ; $try++) {
    try { $r = Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body (@{ query = $q } | ConvertTo-Json) -ContentType 'application/json'; if ($r.errors) { throw ($r.errors | ConvertTo-Json -Compress) }; return $r.data }
    catch { if ($try -ge 4) { throw }; Start-Sleep (10 * $try) }
  }
}

$rows = foreach ($r in $Repos) {
  $work = "C:\kon-migration\pr-preload\$r"; $note = @()
  $state = try { Get-Content "$work\state.json" -Raw | ConvertFrom-Json } catch { $null }
  if (-not $state -or -not $state.exportStarted -or -not (Test-Path "$work\commit-map")) {
    [pscustomobject]@{ Repo = $r; Status = 'NO_COPY_INFO'; NewCommits = ''; Missing = ''; Extra = ''; PrsUpdated = ''; Detail = 'state.json or commit-map missing'; CopiedAt = '' }; continue }
  $since = ([datetime]$state.exportStarted).ToUniversalTime()   # state times are VM local time (CET)
  $map = @{}
  foreach ($line in [IO.File]::ReadLines("$work\commit-map")) { $p = $line.Split(' ', [StringSplitOptions]::RemoveEmptyEntries); if ($p.Count -eq 2 -and $p[0].Length -eq 40) { $map[$p[0]] = $p[1] } }
  $src = Get-Refs "https://github.com/fin-tcm/$r.git" $env:GH_SRC_PAT
  $tgt = Get-Refs "https://github.com/tcm-pilot/$r-pr.git" $env:GH_TGT_PAT
  if ($null -eq $src -or $null -eq $tgt) {
    [pscustomobject]@{ Repo = $r; Status = 'CHECK_FAILED'; NewCommits = ''; Missing = ''; Extra = ''; PrsUpdated = ''; Detail = 'could not list refs'; CopiedAt = $state.exportStarted }; continue }
  $newC = @(); $miss = @(); $diff = @()
  foreach ($k in $src.Keys) {
    $want = $map[$src[$k]]
    if (-not $want) { $newC += $k }                       # commit not in the copy: pushed after it was made
    elseif (-not $tgt.ContainsKey($k)) { $miss += $k }
    elseif ($tgt[$k] -ne $want) { $diff += $k }            # moved to another commit the copy already has
  }
  $extra = @($tgt.Keys | Where-Object { -not $src.ContainsKey($_) })
  # PRs touched since the export (sorted newest first: stop at the first older one)
  $prs = @(); $ok = $true
  try {
    $d = Invoke-Gql $env:GH_SRC_PAT "{ repository(owner:`"fin-tcm`", name:`"$r`") { pullRequests(first:50, orderBy:{field:UPDATED_AT, direction:DESC}, states:[OPEN,MERGED,CLOSED]) { nodes { number updatedAt } } } }"
    $prs = @($d.repository.pullRequests.nodes | Where-Object { ([datetime]$_.updatedAt).ToUniversalTime() -gt $since })
  } catch { $ok = $false; $note += 'PR query failed' }
  $changed = $newC.Count + $miss.Count + $diff.Count + $extra.Count + $prs.Count
  if ($newC) { $note += 'new commits: ' + (($newC | Select-Object -First 3) -join ' ') }
  if ($miss) { $note += 'missing: ' + (($miss | Select-Object -First 3) -join ' ') }
  if ($diff) { $note += 'moved: ' + (($diff | Select-Object -First 3) -join ' ') }
  if ($extra) { $note += 'deleted in fin-tcm: ' + (($extra | Select-Object -First 3) -join ' ') }
  if ($prs) { $note += 'PRs: #' + (($prs | Select-Object -First 10 | ForEach-Object number) -join ' #') }
  [pscustomobject]@{ Repo = $r; Status = $(if (-not $ok) { 'CHECK_FAILED' } elseif ($changed) { 'NEEDS_REFRESH' } else { 'UP_TO_DATE' })
    NewCommits = $newC.Count; Missing = $miss.Count + $diff.Count; Extra = $extra.Count; PrsUpdated = $prs.Count; Detail = ($note -join '; '); CopiedAt = $state.exportStarted }
}
$rows | Export-Csv "$Out\pr-copy-check.csv" -NoTypeInformation -Encoding utf8
$md = @('## PR-preserving copies of the large-file repos (<repo>-pr)', '',
        'Not touched by the nightly sync. Checked against fin-tcm since each copy was made.', '',
        '| Repo | Status | Copied (CET) | New commits | Missing/moved refs | Deleted in fin-tcm | PRs updated | Detail |', '|---|---|---|---|---|---|---|---|')
$md += $rows | ForEach-Object { "| $($_.Repo) | $($_.Status) | $($_.CopiedAt -replace 'T',' ') | $($_.NewCommits) | $($_.Missing) | $($_.Extra) | $($_.PrsUpdated) | $($_.Detail -replace '\|','/') |" }
$md += '', "UP_TO_DATE: $(@($rows | Where-Object Status -eq 'UP_TO_DATE').Count) of $($rows.Count). NEEDS_REFRESH means the copy must be refreshed before cutover (re-run its preload)."
$md | Set-Content "$Out\pr-copy-check.md" -Encoding utf8
$md
