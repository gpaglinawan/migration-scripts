# 15 Nov 2026 - read-only: PR count of one repo in both orgs, measured three ways (GraphQL totalCount, REST list with
# pagination, search API) plus PR numbers. Usage: pr-count-methods.py <repo>
import json, os, sys, urllib.request
repo = sys.argv[1]
def call(url, tok, body=None):
    r = urllib.request.Request(url, data=json.dumps(body).encode() if body else None,
                               headers={'Authorization': f'Bearer {tok}', 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json'})
    return json.load(urllib.request.urlopen(r, timeout=120))
res = {}
for org, tok in (('fin-tcm', os.environ['GH_SRC_PAT']), ('tcm-pilot', os.environ['GH_TGT_PAT'])):
    gq = call('https://api.github.com/graphql', tok, {'query': f'{{ repository(owner:"{org}", name:"{repo}") {{ pullRequests {{ totalCount }} }} }}'})['data']['repository']['pullRequests']['totalCount']
    nums, page = set(), 1
    while True:
        batch = call(f'https://api.github.com/repos/{org}/{repo}/pulls?state=all&per_page=100&page={page}', tok)
        nums |= {p['number'] for p in batch}
        if len(batch) < 100: break
        page += 1
    se = call(f'https://api.github.com/search/issues?q=repo:{org}/{repo}+is:pr&per_page=1', tok)['total_count']
    res[org] = nums
    print(f'{org:10} GraphQL totalCount {gq:6}   REST listed {len(nums):6}   search API {se:6}   highest PR number {max(nums) if nums else 0}')
print(f'fin-tcm PRs (REST listed) missing in tcm-pilot by number: {len(res["fin-tcm"] - res["tcm-pilot"])}')
