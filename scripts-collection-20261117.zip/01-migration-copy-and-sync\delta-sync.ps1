param(
  [string]$SrcOrg   = "fin-tcm",
  [string]$TgtOrg   = "tcm-pilot",
  [string]$Summary  = "C:\kon-migration\refs\compare-summary.csv",
  [string[]]$Statuses = @("OUT_OF_SYNC", "DEFAULT_BRANCH_DIFFERS"),
  [string[]]$Exclude  = @("KON-kplus-front", "FCGC-pricing-analytics", "RISK-cmr", "OPICS-programmers", "KON-doc-kondor-archive"),
  [string]$Work     = "C:\kon-migration\sync",
  [string]$ClassicBypass = "C:\kon-migration\rules\classic-bypass-branches.csv",
  [switch]$Apply
)
# Brings existing tcm-pilot repos up to date with fin-tcm WITHOUT force: creates missing branches/tags,
# fast-forwards outdated branches, copies LFS objects first, sets the default branch to match the source.
# Branches that diverged in the target (someone committed there) are rejected by git and reported, never overwritten.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT"))
$tgtHdr = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$apiT = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = $srcHdr; $env:GIT_TERMINAL_PROMPT = "0"
function As-Source { $env:GIT_CONFIG_VALUE_0 = $srcHdr }
function As-Target { $env:GIT_CONFIG_VALUE_0 = $tgtHdr }

New-Item -ItemType Directory -Force $Work | Out-Null
$log = Join-Path $Work "sync.log"; $resFile = Join-Path $Work "sync-results.csv"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

$classic = @(); if (Test-Path $ClassicBypass) { $classic = @(Import-Csv $ClassicBypass) }
$rows = @(Import-Csv $Summary | Where-Object { $_.Status -in $Statuses -and $_.Repo -notin $Exclude })
$done = @{}; if (Test-Path $resFile) { Import-Csv $resFile | Where-Object { $_.Result -like 'OK*' } | ForEach-Object { $done[$_.Repo] = $true } }
$results = New-Object System.Collections.ArrayList
if (Test-Path $resFile) { Import-Csv $resFile | Where-Object { $done[$_.Repo] } | ForEach-Object { [void]$results.Add($_) } }
Log "=== delta sync $SrcOrg -> $TgtOrg : $($rows.Count) repos ($($done.Count) already OK) mode=$(if($Apply){'APPLY'}else{'DRY-RUN'}) ==="

foreach ($row in $rows) {
  $name = $row.Repo
  if ($done[$name]) { continue }
  if (-not $Apply) { Log ("would sync {0}: missing br={1} outdated br={2} missing tags={3} default {4}->{5}" -f $name, $row.MissingBranches, $row.StaleBranches, $row.MissingTags, $row.TgtDefault, $row.SrcDefault); continue }
  $dir = Join-Path $Work "$name.git"
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  git init --bare -q --ref-format=reftable $dir
  git -C $dir config remote.origin.url "https://github.com/$SrcOrg/$name.git"
  git -C $dir config remote.origin.fetch "+refs/heads/*:refs/heads/*"
  git -C $dir config --add remote.origin.fetch "+refs/tags/*:refs/tags/*"
  As-Source
  git -C $dir fetch -q origin 2>$null
  if ($LASTEXITCODE -ne 0) { Log "FETCH FAILED $name"; [void]$results.Add([pscustomobject]@{ Repo=$name; Result="FAILED fetch" }); continue }
  git -C $dir config lfs.url "https://github.com/$SrcOrg/$name.git/info/lfs"
  $lfsOids = @(git -C $dir lfs ls-files --all --long 2>$null | ForEach-Object { if ($_ -match '^([0-9a-f]{64})\s') { $Matches[1] } } | Sort-Object -Unique)
  if ($lfsOids.Count) { git -C $dir lfs fetch --all origin 2>&1 | Out-Null }
  As-Target
  $lfsNote = ""
  if ($lfsOids.Count) {
    $present = @(Get-ChildItem (Join-Path $dir "lfs\objects") -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object Name)
    # in batches: thousands of ids on one command line exceed the Windows limit and the push silently never runs
    for ($i = 0; $i -lt $present.Count; $i += 200) {
      $chunk = $present[$i..([Math]::Min($i + 199, $present.Count - 1))]
      # lfs.url is set to the SOURCE for the fetch and would override the push target - point it at the target here
      git -C $dir -c "lfs.url=https://github.com/$TgtOrg/$name.git/info/lfs" -c lfs.allowincompletepush=true lfs push --object-id "https://github.com/$TgtOrg/$name.git" @chunk 2>&1 | Out-Null }
    $lfsNote = " lfs=$($present.Count)/$($lfsOids.Count)"
  }
  # classic protection with "include administrators": switched off for the push only, then back on and checked
  $toggled = @()
  foreach ($c in @($classic | Where-Object { $_.Repo -eq $name })) {
    $ea = "https://api.github.com/repos/$TgtOrg/$name/branches/$($c.Branch)/protection/enforce_admins"
    try { if ((Invoke-RestMethod $ea -Headers $apiT).enabled) { Invoke-RestMethod -Method DELETE $ea -Headers $apiT | Out-Null; $toggled += $c.Branch } } catch { Log "  enforce_admins off FAILED $name/$($c.Branch)" }
  }
  try { $out = git -C $dir push --porcelain "https://github.com/$TgtOrg/$name.git" "refs/heads/*:refs/heads/*" "refs/tags/*:refs/tags/*" 2>&1 | ForEach-Object { "$_" } }
  finally {
    foreach ($b in $toggled) {
      $ea = "https://api.github.com/repos/$TgtOrg/$name/branches/$b/protection/enforce_admins"
      try { Invoke-RestMethod -Method POST $ea -Headers $apiT | Out-Null } catch {}
      $ok = try { (Invoke-RestMethod $ea -Headers $apiT).enabled } catch { $false }
      if ($ok) { Log "  $name/$b protection bypassed for the push, restored" } else { Log "  WARNING $name/$b enforce_admins NOT restored - run enforce-admins-restore.ps1" }
    }
  }
  $updated = @($out | Where-Object { $_ -match '^[ *+]\t' }).Count
  $rejected = @($out | Where-Object { $_ -match '^!\t' })
  $errs = @($out | Where-Object { $_ -match 'remote: error|GH001|exceeds|large files' } | Select-Object -First 3)
  if ($rejected.Count) { $rejected | ForEach-Object { "$name`t$_" } | Add-Content (Join-Path $Work "rejected-refs.txt") -Encoding utf8 }
  # default branch
  $defNote = ""
  if ($row.SrcDefault -and $row.SrcDefault -ne $row.TgtDefault) {
    try { Invoke-RestMethod -Method PATCH "https://api.github.com/repos/$TgtOrg/$name" -Headers $apiT -Body (@{ default_branch = $row.SrcDefault } | ConvertTo-Json) -ContentType application/json | Out-Null; $defNote = " default->$($row.SrcDefault)" }
    catch { $defNote = " default-branch FAILED" }
  }
  $res = if ($errs.Count) { "ERROR " + ($errs -join ' | ') } elseif ($rejected.Count) { "PARTIAL $($rejected.Count) refs diverged in target (not overwritten)" } else { "OK" }
  Log ("{0,-40} {1}  updated={2}{3}{4}" -f $name, $res, $updated, $lfsNote, $defNote)
  [void]$results.Add([pscustomobject]@{ Repo=$name; Result=$res; RefsUpdated=$updated; Rejected=$rejected.Count; Lfs=$lfsNote.Trim(); Default=$defNote.Trim() })
  $results | Export-Csv $resFile -NoTypeInformation -Encoding utf8
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
}
if ($Apply) { $results | Export-Csv $resFile -NoTypeInformation -Encoding utf8 }
Log ("=== done: " + (($results | Group-Object { ($_.Result -split ' ')[0] } | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' ') + " ===")
