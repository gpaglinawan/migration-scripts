﻿# 14 Nov 2026 (Samar via Gareth: "make tcm-staging read-only - ensure nobody will change"). Same mechanism as
# ado-freeze.ps1 (which froze TreasuryCapitalMarkets), pointed at tcm-staging: adds Deny entries for Contribute (4),
# Force push (8), Create branch (16), Create tag (32), Manage notes (64), Contribute to PRs (16384) on the Git repos of
# the 9 in-scope projects; never removes or lowers anything; read access untouched.
# NOT denied: [tcm-staging]\Project Collection Administrators and \Project Collection Service Accounts - the migration
# account must still be able to sync (e.g. treasury-pipeline / aws-devops-api-service once Finastra ALM freezes them).
# Before any change the permission tree is saved; -Rollback <dir> restores every touched entry exactly.
# Usage: .\ado-freeze-target.ps1  (dry run)  |  -Apply  |  -Rollback C:\kon-migration\ado-freeze-target\<stamp>
param([switch]$Apply, [string]$Rollback,
      [string[]]$Projects = @('Treasury','PipelineTemplate','SelfServicePortal','Pegazus','Jenkins','Opics','FusionRisk_QA','Fusion Invest','Terraform'),
      [string]$Root = 'C:\kon-migration\ado-freeze-target',
      # 16 Nov (Gareth: "5. ok"): -Mask 256 denies Create repository too (a new repo's creator gets rights on it, which the freeze did not cover)
      [int]$Mask = (4 + 8 + 16 + 32 + 64 + 16384),
      [string[]]$ExcludeDescriptors = @())   # 16 Nov: extra exempt descriptors (the Create-repository ACEs carry the collection groups in another form)
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hs = @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT")) }
$o = 'https://dev.azure.com/tcm-staging'
$ns = '2e9eb7ed-3c0a-47d4-87c1-0ffdd275fd87'   # Git Repositories
$mask = $Mask

function Set-Ace($token, $descriptor, $allow, $deny, [bool]$merge) {
  $body = @{ token = $token; merge = $merge; accessControlEntries = @(@{ descriptor = $descriptor; allow = $allow; deny = $deny; extendedInfo = @{} }) } | ConvertTo-Json -Depth 5
  $null = Invoke-RestMethod -Method Post "$o/_apis/accesscontrolentries/$ns`?api-version=7.1" -Headers $hs -ContentType 'application/json' -Body $body
}

if ($Rollback) {
  foreach ($t in (Import-Csv (Join-Path $Rollback 'touched.csv'))) {
    try {
      if ($t.HadAce -eq 'True') { Set-Ace $t.Token $t.Descriptor ([int]$t.OrigAllow) ([int]$t.OrigDeny) $false; $res = 'restored' }
      else { $null = Invoke-RestMethod -Method Delete "$o/_apis/accesscontrolentries/$ns`?token=$([uri]::EscapeDataString($t.Token))&descriptors=$([uri]::EscapeDataString($t.Descriptor))&api-version=7.1" -Headers $hs; $res = 'removed (had none)' }
    } catch { $res = "FAILED: $($_.Exception.Message)" }
    "{0}  {1}  {2}" -f $res, $t.Project, $t.Token
  }
  return
}

$dir = Join-Path $Root (Get-Date -Format yyyyMMdd-HHmm); New-Item -ItemType Directory -Force $dir | Out-Null
$keep = @(foreach ($n in '[tcm-staging]\Project Collection Administrators', '[tcm-staging]\Project Collection Service Accounts') {
  ((Invoke-RestMethod "https://vssps.dev.azure.com/tcm-staging/_apis/identities?searchFilter=General&filterValue=$([uri]::EscapeDataString($n))&api-version=7.1" -Headers $hs).value | Where-Object providerDisplayName -eq $n | Select-Object -First 1).descriptor })
if ($keep.Count -ne 2 -or ($keep | Where-Object { -not $_ })) { throw "could not resolve the two exempt collection groups - stopping" }
$keep = @($keep) + @($ExcludeDescriptors)
$projs = @((Invoke-RestMethod "$o/_apis/projects?api-version=7.1&`$top=500" -Headers $hs).value | Where-Object { $_.name -in $Projects })
$rootAcl = @((Invoke-RestMethod "$o/_apis/accesscontrollists/$ns`?token=repoV2&recurse=false&api-version=7.1" -Headers $hs).value)
$rootAcl | ConvertTo-Json -Depth 8 | Out-File "$dir\acl-root.json" -Encoding utf8
$orgWide = @($rootAcl | ForEach-Object { $_.acesDictionary.PSObject.Properties.Value } | Where-Object { ($_.allow -band $mask) -and $_.descriptor -notin $keep })
$plan = foreach ($p in $projs) {
  $acls = @((Invoke-RestMethod "$o/_apis/accesscontrollists/$ns`?token=repoV2/$($p.id)&recurse=true&api-version=7.1" -Headers $hs).value)
  $acls | ConvertTo-Json -Depth 8 | Out-File "$dir\acl-$($p.name -replace '[^A-Za-z0-9_-]', '_').json" -Encoding utf8
  $byToken = @{}; foreach ($a in $acls) { $byToken[$a.token] = $a.acesDictionary }
  $want = @{}
  foreach ($a in $acls) { foreach ($e in $a.acesDictionary.PSObject.Properties.Value) { if (($e.allow -band $mask) -and $e.descriptor -notin $keep) { $want["$($a.token)|$($e.descriptor)"] = $true } } }
  foreach ($e in $orgWide) { $want["repoV2/$($p.id)|$($e.descriptor)"] = $true }
  foreach ($k in $want.Keys) {
    $token, $desc = $k -split '\|', 2
    $cur = if ($byToken[$token]) { $byToken[$token].PSObject.Properties[$desc].Value } else { $null }
    if ($cur -and (($cur.deny -band $mask) -eq $mask)) { continue }
    [pscustomobject]@{ Project = $p.name; Token = $token; Descriptor = $desc; HadAce = [bool]$cur; OrigAllow = [int]$cur.allow; OrigDeny = [int]$cur.deny; Action = if ($Apply) { 'DENY' } else { 'would deny' } }
  }
}
$todo = @($plan | Where-Object { $_.Descriptor })
if ($Apply) {
  $todo | Export-Csv "$dir\touched.csv" -NoTypeInformation -Encoding utf8   # written BEFORE changing anything
  foreach ($t in $todo) { try { Set-Ace $t.Token $t.Descriptor 0 $mask $true } catch { $t.Action = "FAILED: $($_.Exception.Message)" } }
}
$plan | Export-Csv "$dir\plan.csv" -NoTypeInformation -Encoding utf8
$plan | Group-Object Project | ForEach-Object { "{0,-20} entries: {1,4}   {2}" -f $_.Name, @($_.Group | Where-Object Descriptor).Count, (($_.Group.Action | Sort-Object -Unique) -join '; ') }
if ($Apply) { "rollback: .\ado-freeze-target.ps1 -Rollback $dir" }
"backup and plan: $dir"
