param(
  [string[]]$Repos = @(),               # default: every repo that exists in both orgs
  [int]$Part = 1, [int]$Of = 1,         # split the repo list across machines: -Part 1 -Of 2 on VM 1, -Part 2 -Of 2 on VM 2
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out    = "C:\lfs-audit",
  [switch]$Copy                         # without it: report only. With it: copies LFS objects missing in Teciem (needs write on tcm-pilot)
)
# Finds every Git LFS object referenced anywhere in each Finastra repo's history and asks the Teciem LFS server whether it has it.
# With -Copy, objects Teciem lacks are streamed Finastra -> Teciem through the LFS API (download, upload, verify).
# Only LFS storage is written; branches, tags and commits are never touched.
# Fetches only blobs <= 1 KB (LFS pointers are ~130 bytes), so even multi-GB repos clone small.
# Needs: Git for Windows 2.45+, env GH_SRC_PAT (read on fin-tcm), GH_TGT_PAT (read on tcm-pilot; write if -Copy).
# Resumable: repos already in results.csv are skipped.
$ErrorActionPreference = "Continue"
if (-not $env:GH_SRC_PAT -or -not $env:GH_TGT_PAT) { throw "set `$env:GH_SRC_PAT and `$env:GH_TGT_PAT first" }
function Basic($p) { [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$p")) }
$srcHdr = "AUTHORIZATION: basic $(Basic $env:GH_SRC_PAT)"
$env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = $srcHdr
$env:GIT_TERMINAL_PROMPT = "0"; $env:GIT_NO_LAZY_FETCH = "1"   # never pull the big blobs we filtered out
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "lfs-audit.log"; $resFile = Join-Path $Out "results.csv"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }

if (-not $Repos) {
  function Names($org, $pat) { $h = @{ Authorization = "Bearer $pat" }; $n = @(); $p = 1
    do { $r = Invoke-RestMethod "https://api.github.com/orgs/$org/repos?type=all&per_page=100&page=$p" -Headers $h; $n += @($r | ForEach-Object name); $p++ } while (@($r).Count -eq 100); $n }
  $tgtNames = Names $TgtOrg $env:GH_TGT_PAT
  $Repos = @(Names $SrcOrg $env:GH_SRC_PAT | Where-Object { $_ -in $tgtNames } | Sort-Object)
}
$Repos = @(for ($i = 0; $i -lt $Repos.Count; $i++) { if ($i % $Of -eq $Part - 1) { $Repos[$i] } })
$done = @{}; if (Test-Path $resFile) { Import-Csv $resFile | ForEach-Object { $done[$_.Repo] = $true } }
Log "=== LFS audit part $Part of $Of : $($Repos.Count) repos ($(@($Repos | Where-Object { $done[$_] }).Count) already done) mode=$(if($Copy){'COPY'}else{'REPORT'}) ==="

function Batch($org, $repo, $pat, $op, $objs) {   # LFS batch API, 100 objects per call
  $h = @{ Authorization = "Basic $(Basic $pat)"; Accept = "application/vnd.git-lfs+json" }; $res = @()
  for ($i = 0; $i -lt $objs.Count; $i += 100) {
    $chunk = @($objs[$i..([Math]::Min($i + 99, $objs.Count - 1))])
    $body = @{ operation = $op; transfers = @("basic"); objects = @($chunk | ForEach-Object { @{ oid = $_.oid; size = [long]$_.size } }) } | ConvertTo-Json -Depth 4
    for ($a = 1; ; $a++) {
      try { $res += @((Invoke-RestMethod -Method POST "https://github.com/$org/$repo.git/info/lfs/objects/batch" -Headers $h -Body $body -ContentType "application/vnd.git-lfs+json").objects); break }
      catch { if ($a -ge 3) { throw }; Start-Sleep (10 * $a) } }
  }
  $res
}
function Hdrs($action) { $h = @{}; if ($action.header) { $action.header.PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value } }; $h }

foreach ($repo in $Repos) {
  if ($done[$repo]) { continue }
  $dir = Join-Path $Out "work\$repo.git"
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  git init --bare -q --ref-format=reftable $dir; git -C $dir config core.longpaths true
  git -C $dir fetch -q --filter=blob:limit=1k --no-tags "https://github.com/$SrcOrg/$repo.git" "+refs/heads/*:refs/heads/*" "+refs/tags/*:refs/tags/*" 2>$null
  if ($LASTEXITCODE -ne 0) { Log "FETCH FAILED $repo"; [pscustomobject]@{ Repo=$repo; Status='fetch-failed'; Objects=0; InTeciem=0; MissingInTeciem=0; NotOnFinastra=0; Copied=0; CopyFailed=0; GB=0 } | Export-Csv $resFile -Append -NoTypeInformation -Encoding utf8; continue }
  # every small blob in history whose content is an LFS pointer
  $ptrs = @{}
  $small = @(git -C $dir cat-file --batch-all-objects --batch-check="%(objecttype) %(objectname) %(objectsize)" | ForEach-Object { $f = $_ -split ' '; if ($f[0] -eq 'blob' -and [int]$f[2] -lt 1024 -and [int]$f[2] -gt 40) { $f[1] } })
  if ($small.Count) {
    $txt = ($small | git -C $dir cat-file --batch) -join "`n"
    foreach ($m in [regex]::Matches($txt, 'version https://git-lfs\.github\.com/spec/v1\noid sha256:([0-9a-f]{64})\nsize (\d+)')) { $ptrs[$m.Groups[1].Value] = [long]$m.Groups[2].Value }
  }
  Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
  $row = [ordered]@{ Repo=$repo; Status='no-lfs'; Objects=$ptrs.Count; InTeciem=0; MissingInTeciem=0; NotOnFinastra=0; Copied=0; CopyFailed=0; GB=[math]::Round((($ptrs.Values | Measure-Object -Sum).Sum)/1GB, 2) }
  if ($ptrs.Count) {
    $objs = @($ptrs.Keys | ForEach-Object { @{ oid = $_; size = $ptrs[$_] } })
    $tgt = Batch $TgtOrg $repo $env:GH_TGT_PAT "download" $objs
    $missing = @($tgt | Where-Object { -not $_.actions } | ForEach-Object { @{ oid = $_.oid; size = [long]$_.size } })
    $row.InTeciem = $objs.Count - $missing.Count; $row.MissingInTeciem = $missing.Count
    $missing | ForEach-Object { "$($_.oid) $($_.size)" } | Set-Content (Join-Path $Out "$repo-missing.txt") -Encoding ascii
    if ($missing.Count) {
      $src = Batch $SrcOrg $repo $env:GH_SRC_PAT "download" $missing
      $avail = @($src | Where-Object { $_.actions.download })
      $row.NotOnFinastra = $missing.Count - $avail.Count     # referenced but never uploaded in Finastra - nothing to copy
      if ($Copy -and $avail.Count) {
        $up = @{}; Batch $TgtOrg $repo $env:GH_TGT_PAT "upload" @($avail | ForEach-Object { @{ oid = $_.oid; size = [long]$_.size } }) | ForEach-Object { $up[$_.oid] = $_ }
        $tmp = Join-Path $Out "work\lfs.tmp"
        foreach ($o in $avail) {
          try {
            $d = $o.actions.download; Invoke-WebRequest -UseBasicParsing $d.href -Headers (Hdrs $d) -OutFile $tmp | Out-Null
            if ((Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower() -ne $o.oid) { throw "downloaded content does not match oid" }
            $u = $up[$o.oid].actions
            if ($u.upload) {   # no upload action = Teciem already has it
              Invoke-WebRequest -UseBasicParsing -Method PUT $u.upload.href -Headers (Hdrs $u.upload) -InFile $tmp -ContentType "application/octet-stream" | Out-Null
              if ($u.verify) { Invoke-RestMethod -Method POST $u.verify.href -Headers (Hdrs $u.verify) -Body (@{ oid = $o.oid; size = [long]$o.size } | ConvertTo-Json) -ContentType "application/vnd.git-lfs+json" | Out-Null }
            }
            $row.Copied++
          } catch { $row.CopyFailed++; Add-Content (Join-Path $Out "$repo-copy-errors.txt") "$($o.oid) $($_.Exception.Message)" -Encoding utf8 }
        }
        Remove-Item $tmp -ErrorAction SilentlyContinue
      }
    }
    $row.Status = if ($row.MissingInTeciem -eq 0) { 'complete' } elseif ($row.Copied -and $row.Copied + $row.NotOnFinastra -eq $row.MissingInTeciem) { 'copied' } elseif ($row.MissingInTeciem -eq $row.NotOnFinastra) { 'missing-on-finastra-too' } else { 'MISSING-IN-TECIEM' }
  }
  if ($ptrs.Count) { Log ("{0,-24} {1}  objects={2} ({3} GB) in-teciem={4} missing={5} not-on-finastra={6} copied={7} failed={8}" -f $row.Status, $repo, $row.Objects, $row.GB, $row.InTeciem, $row.MissingInTeciem, $row.NotOnFinastra, $row.Copied, $row.CopyFailed) }
  [pscustomobject]$row | Export-Csv $resFile -Append -NoTypeInformation -Encoding utf8
}
Log ("=== done: " + ((Import-Csv $resFile | Group-Object Status | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ' ') + " ===")
