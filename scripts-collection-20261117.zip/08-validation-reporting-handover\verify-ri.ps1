# 14 Nov 2026 (GIT-020C / GIT-019C). For every finished copy under C:\kon-migration\pr-preload\cutover-20261113 that is
# not yet in C:\kon-migration\swap\git-020c-verify.csv: refs + PR-identity result from its own verify stage, plus a
# GraphQL count of PR numbers in fin-tcm vs the copy vs the current repo. Read-only.
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$py = 'C:\kon-migration\tools\python\python.exe'; $diff = 'C:\kon-migration\scripts\pr-numbers-diff.py'
$out = 'C:\kon-migration\swap\git-020c-verify.csv'
$have = @{}; if (Test-Path $out) { Import-Csv $out | ForEach-Object { $have[$_.Copy] = 1 } }
foreach ($d in Get-ChildItem C:\kon-migration\pr-preload\cutover-20261113 -Directory) {
  $l = Join-Path $d.FullName 'run.log'; if (-not (Test-Path $l) -or $have[$d.Name]) { continue }
  $lg = Get-Content $l; if (-not ($lg | Select-String 'stopped after cleanup')) { continue }
  $repo = $d.Name -replace '-(ri|pr2)$', ''
  $refs = (($lg | Select-String 'refs: rewritten').Line -replace '.*refs: rewritten (\d+), in target (\d+), missing (\d+), different (\d+).*', '$2/$1 (missing $3, different $4)') | Select-Object -Last 1
  $ident = (($lg | Select-String 'PRs identical').Line -replace '.*threads\): ', '') | Select-Object -Last 1
  $cp = (& $py -I $diff "fin-tcm/$repo" "tcm-pilot/$($d.Name)" 2>$null | Select-Object -First 1) -replace '.*: (\d+) PRs; .*: (\d+); missing (\d+)', '$1|$2|$3'
  $cu = (& $py -I $diff "fin-tcm/$repo" "tcm-pilot/$repo" 2>$null | Select-Object -First 1) -replace '.*: (\d+) PRs; .*: (\d+); missing (\d+)', '$2'
  $a = $cp -split '\|'
  $v = if ($a.Count -lt 3) { 'CHECK: count failed' } elseif ($a[2] -eq '0') { 'READY (all PRs) after LFS check' } else { "CHECK: $($a[2]) PRs missing" }
  [pscustomobject]@{ Repo = $repo; Copy = $d.Name; SrcPRs = $a[0]; CopyPRs = $a[1]; CurrentPRs = $cu; Refs = $refs; PRsIdentical = $ident; LFS = 'to check'; Verdict = $v; Time = (Get-Date).ToString('s') } |
    Tee-Object -Variable row | Export-Csv $out -NoTypeInformation -Encoding utf8 -Append
  "{0,-34} PRs {1}/{2} (current {3})  refs {4}  identical {5}  -> {6}" -f $d.Name, $a[1], $a[0], $cu, $refs, $ident, $v
}
