# 11 Nov 2026 (Gareth: "3. OK 4. OK", "2 grant"): comments on DEF-186 / 187 / 196 / 207 / 198, and the plain-text
# password removed from the DEF-162 description. Statuses are not changed. Run with -DryRun first.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$comments = @{
  'DEF-186' = 'Fixed 10-11 Nov: 123 missing releases created in tcm-pilot with their asset files (largest: ARC-comparison-engine ibfs-latest, 49 files / 2.7 GB) and the notes of 11 damaged releases re-copied from fin-tcm. Not changed: the repos replaced at cutover (their new copies already hold all releases). SEK-microservices-initializer tag 1.0.2 arrived with the 11 Nov sync. Still to come: SUM-summit-web-services 4.1.4 / 4.1.5 releases (tags arrived today, releases added today) and FT-athene v6201.1137.00.5050 (tag comes with the next sync). Releases made in fin-tcm up to the freeze are copied again at cutover. Ready for retest.'
  'DEF-187' = 'Nightly sync resumed 11 Nov: SEK-microservices-initializer, FNX-val-configuration and VAL-input-gateway are now in sync with fin-tcm. VAL-criteria-tables branch feature/KTAC-29275-payload-extraction was rewritten in fin-tcm (diverged), so it cannot be fast-forwarded - it is set to the fin-tcm state in the final sync at cutover (GIT-005). Ready for retest.'
  'DEF-196' = 'Cause: the GitHub for Jira app is not yet connected to the Teciem GitHub organisation, so Jira cannot create branches or show development info. Same root as DEF-026 / DEF-117. Plan: connect it right after the organisation rename at cutover (tcm-pilot becomes fin-tcm, GIT-025), so links use the final name; needs a Jira admin and a GitHub org owner. The development history (branches, commits, PRs) is backfilled by the app after it is connected.'
  'DEF-207' = 'Finding: the sign-on page text "Single sign-on to Treasury Capital Markets" is not migrated data - it most likely comes from the GitHub enterprise''s display name or the name of the Entra ID enterprise application used for sign-on. To be changed by the Teciem enterprise owner / Entra admin (Vlad); to confirm which of the two shows on that page.'
  'DEF-198' = 'Done 11 Nov (approved by Gareth): Octavian Humita, Ioan Acristei and Ion Ciubotaru have write access on all 23 KON-* repositories in tcm-pilot-test (they were already members of the org). Admin was not given; if a specific setting is needed, tell us which and we will set it. Ready for retest.'
  'DEF-162' = 'A password that was written in plain text in this defect''s description was removed from the description on 11 Nov. If it is a real password, please change it.'
}
$tok = Get-Content C:\development\pats.txt | Where-Object { $_ -match '^\s*SMARTSHEET[ _]TOKEN\s*=\s*"?([^"\s]+)"?' } | ForEach-Object { $Matches[1] } | Select-Object -First 1
$h = @{ Authorization = "Bearer $tok" }; $sheetId = 3761521504348036
$r = Invoke-WebRequest "https://api.smartsheet.com/2.0/sheets/$sheetId" -Headers $h -UseBasicParsing
$sh = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()) | ConvertFrom-Json
$idc = ($sh.columns | Where-Object title -eq 'Defect ID').id; $dc = ($sh.columns | Where-Object title -eq 'Defect Description').id
$row = $sh.rows | Where-Object { ($_.cells | Where-Object columnId -eq $idc).displayValue -eq 'DEF-162' }
$desc = "$(($row.cells | Where-Object columnId -eq $dc).value)"
$n = ([regex]::Matches($desc, [regex]::Escape('HelloParis787!'))).Count
"--- DEF-162 description: $n occurrence(s) of the password to replace with [password removed]" | Out-Host
if (-not $DryRun -and $n) {
  $new = $desc.Replace('HelloParis787!', '[password removed]')
  $body = ConvertTo-Json @(@{ id = $row.id; cells = @(@{ columnId = $dc; value = $new }) }) -Depth 6
  $res = Invoke-RestMethod -Method PUT "https://api.smartsheet.com/2.0/sheets/$sheetId/rows" -Headers $h -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($body))
  "DEF-162 description updated (resultCode $($res.resultCode))" | Out-Host
}
& C:\development\defects\smartsheet-comment.ps1 -Updates $comments -DryRun:$DryRun
