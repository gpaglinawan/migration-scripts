# GIT-020 rehearsal (11 Nov): waits for the 4 test copies (tcm-pilot -> tcm-pilot-test/<repo>-git020, queued 00:21 CET),
# then runs pr-recreate.ps1 -Apply against them and times it. Test org only.
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ids = 'RM_kgDaACQwODVkMTg3Yi01ZWM4LTRlNTItYWQ5ZS0xMGZhMzM5MTY4OTQ','RM_kgDaACQyNjBjOTI3NS02MWUwLTRiNzUtYTJmZi1mYTk4MWE5NzkyMDY','RM_kgDaACQ1ZmM2MWVhYi00ZjhhLTRlMGUtYjQyMy04YjRiNmYzMDllMTY','RM_kgDaACRhYmY5ZDA1Yy0zMjRmLTQ3OTktOTkyNi1mYzgzZTBmNjA4MTE'
$q = '{ ' + (($ids | ForEach-Object -Begin { $i = 0 } -Process { "m$i" + ': node(id:"' + $_ + '") { ... on Migration { repositoryName state failureReason } }'; $i++ }) -join ' ') + ' }'
do { Start-Sleep 60
  $st = @((Invoke-RestMethod -Method POST https://api.github.com/graphql -Headers @{ Authorization = "Bearer $env:GH_TGT_PAT" } -ContentType application/json -Body (@{ query = $q } | ConvertTo-Json)).data.PSObject.Properties.Value)
} while (@($st | Where-Object { $_.state -notin 'SUCCEEDED', 'FAILED' }).Count)
$st | ForEach-Object { "copy $($_.repositoryName): $($_.state) $($_.failureReason)" }
$ok = @($st | Where-Object state -eq 'SUCCEEDED' | ForEach-Object { $_.repositoryName -replace '-git020$', '' })
$t0 = Get-Date
& C:\kon-migration\scripts\pr-recreate.ps1 -Repos $ok -TargetOrg tcm-pilot-test -TargetSuffix '-git020' -Work C:\kon-migration\pr-recreate\rehearsal-20261111 -Apply
"rehearsal wall clock: {0:N1} min" -f ((Get-Date) - $t0).TotalMinutes
