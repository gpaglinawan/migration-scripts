﻿# 12 Nov 2026 (Dariusz Dyjak: promotions to the Release view missing in tcm-staging feeds).
# Copies feed view promotions (Release / Prerelease) from TreasuryCapitalMarkets to tcm-staging for package
# versions that exist in both. Additive only: adds a view to a version, never removes one, never touches packages
# or feeds. Universal Packages only (the only type with promotions on 12 Nov). Dry run unless -Apply.
# Usage: .\ado-feed-views-sync.ps1 [-Apply]
param([switch]$Apply, [string]$Src = 'TreasuryCapitalMarkets', [string]$Tgt = 'tcm-staging',
      [string]$Out = "C:\kon-migration\feeds-tmp\feed-views-sync-$(Get-Date -Format yyyyMMdd-HHmm).csv")
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_SOURCE_PAT|AZDO_PAT|AZDO_PKG_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-AuthHeader($p) { @{ Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$p")) } }
$hs = Get-AuthHeader $env:AZDO_SOURCE_PAT; $ht = Get-AuthHeader $env:AZDO_PAT; $hw = Get-AuthHeader $env:AZDO_PKG_PAT  # packaging write token
function Get-Versions($org, $hd) {
  $res = @{}
  foreach ($f in (Invoke-RestMethod "https://feeds.dev.azure.com/$org/_apis/packaging/feeds?api-version=7.1" -Headers $hd).value) {
    $base = if ($f.project) { "https://feeds.dev.azure.com/$org/$($f.project.id)" } else { "https://feeds.dev.azure.com/$org" }
    $skip = 0
    do {
      $p = @((Invoke-RestMethod "$base/_apis/packaging/feeds/$($f.id)/packages?api-version=7.1&includeAllVersions=true&`$top=1000&`$skip=$skip" -Headers $hd).value)
      foreach ($pk in $p) { foreach ($v in $pk.versions) {
        $res["$($f.name)|$($pk.name)|$($v.version)".ToLower()] = [pscustomobject]@{ Feed = $f.name; Project = $f.project.name; Type = $pk.protocolType; Package = $pk.name; Version = $v.version; Views = @($v.views.name) } } }
      $skip += 1000
    } while ($p.Count -eq 1000)
  }
  $res
}
$sv = Get-Versions $Src $hs; $tv = Get-Versions $Tgt $ht
$log = foreach ($k in $sv.Keys) {
  $s = $sv[$k]
  foreach ($view in @($s.Views | Where-Object { $_ -in 'Release', 'Prerelease' })) {
    $row = [pscustomobject]@{ Feed = $s.Feed; Package = $s.Package; Version = $s.Version; View = $view; Result = '' }
    $t = $tv[$k]
    if (-not $t) { $row.Result = 'SKIPPED: version not in target' }
    elseif ($t.Views -contains $view) { $row.Result = 'already promoted' }
    elseif ($s.Type -ne 'UPack') { $row.Result = "SKIPPED: type $($s.Type) not handled" }
    elseif (-not $Apply) { $row.Result = 'would promote' }
    else {
      $proj = if ($t.Project) { "/$([uri]::EscapeDataString($t.Project))" } else { '' }
      $url = "https://pkgs.dev.azure.com/$Tgt$proj/_apis/packaging/feeds/$([uri]::EscapeDataString($t.Feed))/upack/packages/$([uri]::EscapeDataString($t.Package))/versions/$([uri]::EscapeDataString($t.Version))?api-version=7.1-preview.1"
      $body = @{ views = @{ op = 'add'; path = '/views/-'; value = $view } } | ConvertTo-Json -Depth 4
      try { $null = Invoke-RestMethod -Method Patch $url -Headers $hw -ContentType 'application/json' -Body $body; $row.Result = 'PROMOTED' }
      catch { $row.Result = "FAILED: $($_.Exception.Message)" }
    }
    $row
  }
}
$log | Sort-Object Feed, Package, Version, View | Export-Csv $Out -NoTypeInformation -Encoding utf8
$log | Group-Object Result | ForEach-Object { "{0,-40} {1}" -f $_.Name, $_.Count }
"detail: $Out"

