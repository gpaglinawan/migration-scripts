﻿param(
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Refs   = "C:\kon-migration\refs"
)
# Read-only: compares the ls-remote dumps of both orgs, per repo, branch and tag.
# Repos are matched by name, case-insensitive.
$ErrorActionPreference = "Continue"
function Load($file) { $m = @{}; if (Test-Path $file) { foreach ($l in [IO.File]::ReadAllLines($file)) { $p = $l -split "`t"; if ($p.Count -eq 2) { $m[$p[1]] = $p[0] } } }; $m }
$sRepos = Import-Csv (Join-Path $Refs "$SrcOrg-repos.csv"); $tRepos = Import-Csv (Join-Path $Refs "$TgtOrg-repos.csv")
$tIdx = @{}; foreach ($r in $tRepos) { $tIdx[$r.Name.ToLower()] = $r }

# result of pr-copy-check.ps1 when it ran just before this compare (nightly: <night>\pr-copy-check next to <night>\after)
$prCopy = @{}; $pcF = Join-Path (Split-Path $Refs) 'pr-copy-check\pr-copy-check.csv'
if (Test-Path $pcF) { Import-Csv $pcF | ForEach-Object { $prCopy[$_.Repo.ToLower()] = $_.Status } }
$summary = New-Object System.Collections.ArrayList
$detail  = New-Object System.Collections.ArrayList
foreach ($s in $sRepos) {
  $t = $tIdx[$s.Name.ToLower()]
  if (-not $t) { [void]$summary.Add([pscustomobject]@{Repo=$s.Name; Status='NOT_IN_TARGET'; SrcBranches=''; SrcTags=''; MissingBranches=''; StaleBranches=''; MissingTags=''; DiffTags=''; ExtraInTarget=''; SrcDefault=$s.Default; TgtDefault=''; Archived=$s.Archived}); continue }
  $sf = Join-Path $Refs "$SrcOrg\$($s.Name).txt"; $tf = Join-Path $Refs "$TgtOrg\$($t.Name).txt"
  $sErr = (Test-Path $sf) -and ((Get-Content $sf -TotalCount 1) -like 'ERROR*'); $tErr = (Test-Path $tf) -and ((Get-Content $tf -TotalCount 1) -like 'ERROR*')
  if ($sErr -or $tErr) { [void]$summary.Add([pscustomobject]@{Repo=$s.Name; Status=$(if($sErr){'SOURCE_READ_ERROR'}else{'TARGET_READ_ERROR'}); SrcDefault=$s.Default; TgtDefault=$t.Default; Archived=$s.Archived}); continue }
  $SrcRefs = Load $sf; $TgtRefs = Load $tf
  $mb=0; $sb=0; $mt=0; $dt=0; $ex=0
  foreach ($ref in $SrcRefs.Keys) {
    if (-not $TgtRefs.ContainsKey($ref)) { if ($ref -like 'refs/heads/*') { $mb++ } else { $mt++ }; [void]$detail.Add([pscustomobject]@{Repo=$s.Name; Ref=$ref; Issue='MISSING'; Src=$SrcRefs[$ref]; Tgt=''}) }
    elseif ($TgtRefs[$ref] -ne $SrcRefs[$ref]) { if ($ref -like 'refs/heads/*') { $sb++ } else { $dt++ }; [void]$detail.Add([pscustomobject]@{Repo=$s.Name; Ref=$ref; Issue='DIFFERENT'; Src=$SrcRefs[$ref]; Tgt=$TgtRefs[$ref]}) }
  }
  foreach ($ref in $TgtRefs.Keys) { if (-not $SrcRefs.ContainsKey($ref)) { $ex++; [void]$detail.Add([pscustomobject]@{Repo=$s.Name; Ref=$ref; Issue='EXTRA_IN_TARGET'; Src=''; Tgt=$TgtRefs[$ref]}) } }
  $nb = @($SrcRefs.Keys | Where-Object { $_ -like 'refs/heads/*' }).Count
  # empty on both sides: nothing to sync, the default-branch name is only a setting (GitHub won't point it at a missing branch)
  $status = if ($SrcRefs.Count -eq 0 -and $TgtRefs.Count -eq 0) { 'IN_SYNC' } elseif ($SrcRefs.Count -gt 0 -and $TgtRefs.Count -eq 0) { 'TARGET_EMPTY' } elseif ($mb+$sb+$mt+$dt -eq 0 -and $s.Default -eq $t.Default) { 'IN_SYNC' } elseif ($mb+$sb+$mt+$dt -eq 0) { 'DEFAULT_BRANCH_DIFFERS' } else { 'OUT_OF_SYNC' }
  # repo rewritten for large files: in sync if Finastra still has exactly the refs whose rewrite was last pushed (rewrite-resync.ps1)
  $stF = "C:\kon-migration\resync\state\$($s.Name).txt"
  if ($status -ne 'IN_SYNC' -and (Test-Path $stF)) { $rec = Load $stF
    if ($rec.Count -eq $SrcRefs.Count -and -not @($SrcRefs.Keys | Where-Object { $rec[$_] -ne $SrcRefs[$_] }).Count) { $status = 'IN_SYNC_REWRITTEN' } }
  # repo with a PR-preserving copy (<repo>-pr, which replaces it at cutover): in sync if tonight's pr-copy-check.ps1
  # found the copy UP_TO_DATE (every Finastra branch/tag maps through the rewrite to the same commit in the copy)
  if ($status -notin 'IN_SYNC', 'IN_SYNC_REWRITTEN' -and $prCopy[$s.Name.ToLower()] -eq 'UP_TO_DATE') { $status = 'IN_SYNC_REWRITTEN' }
  [void]$summary.Add([pscustomobject]@{Repo=$s.Name; Status=$status; SrcBranches=$nb; SrcTags=$SrcRefs.Count-$nb; MissingBranches=$mb; StaleBranches=$sb; MissingTags=$mt; DiffTags=$dt; ExtraInTarget=$ex; SrcDefault=$s.Default; TgtDefault=$t.Default; Archived=$s.Archived})
}
$summary | Sort-Object Status, Repo | Export-Csv (Join-Path $Refs "compare-summary.csv") -NoTypeInformation -Encoding utf8
$detail  | Export-Csv (Join-Path $Refs "compare-detail.csv") -NoTypeInformation -Encoding utf8
"source repos: $($sRepos.Count)   target repos: $($tRepos.Count)"
$summary | Group-Object Status | Sort-Object Name | ForEach-Object { "{0,-24} {1}" -f $_.Name, $_.Count }
"refs: missing branches=$(($summary | Measure-Object MissingBranches -Sum).Sum) stale branches=$(($summary | Measure-Object StaleBranches -Sum).Sum) missing tags=$(($summary | Measure-Object MissingTags -Sum).Sum) different tags=$(($summary | Measure-Object DiffTags -Sum).Sum)"

