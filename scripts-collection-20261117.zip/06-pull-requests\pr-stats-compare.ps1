# Read-only: compares every PR of fin-tcm/<Repo> with <TargetOrg>/<Target> (state, review / comment / review-thread counts).
# Re-check of pr-preload's verify stage; stops (instead of counting the rest as different) if a page cannot be read.
param([string]$Repo = 'KON-kplus-front', [string]$TargetOrg = 'tcm-pilot', [string]$Target = 'KON-kplus-front-pr', [string]$Out = "C:\kon-migration\pr-preload\KON-kplus-front-cutover\pr-compare-$(Get-Date -Format yyyyMMdd-HHmm).csv")
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-Stats($owner, $name, $tok) {
  $all = @{}; $cursor = $null
  do {
    $after = if ($cursor) { ", after:`"$cursor`"" } else { '' }
    $q = "{ repository(owner:`"$owner`", name:`"$name`") { pullRequests(first:50$after){ pageInfo{hasNextPage endCursor} nodes { number state reviews{totalCount} comments{totalCount} reviewThreads{totalCount} } } } }"
    $page = $null
    for ($try = 1; $try -le 8 -and -not $page; $try++) {
      try { $r = Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -ContentType application/json -Body (@{ query = $q } | ConvertTo-Json)
            if ($r.data.repository.pullRequests) { $page = $r.data.repository.pullRequests } else { throw "no data: $($r.errors.message)" } }
      catch { Write-Host "  $owner page after $($all.Count) PRs, try $try failed: $($_.Exception.Message)"; Start-Sleep (20 * $try) } }
    if (-not $page) { throw "$owner/$name : stopped after $($all.Count) PRs - page could not be read" }
    foreach ($n in $page.nodes) { $all[[int]$n.number] = "$($n.state) rev=$($n.reviews.totalCount) com=$($n.comments.totalCount) thr=$($n.reviewThreads.totalCount)" }
    $cursor = $page.pageInfo.endCursor
  } while ($page.pageInfo.hasNextPage)
  $all }
$a = Get-Stats 'fin-tcm' $Repo $env:GH_SRC_PAT; Write-Host "fin-tcm: $($a.Count) PRs"
$b = Get-Stats $TargetOrg $Target $env:GH_TGT_PAT; Write-Host "$TargetOrg : $($b.Count) PRs"
$rows = foreach ($n in ($a.Keys | Sort-Object)) { $x = $a[$n]; $y = $b[$n]
  [pscustomobject]@{ PR = $n; FinTcm = $x; Target = $(if ($null -ne $y) { $y } else { 'MISSING' }); Same = ($x -eq $y) } }
$rows | Export-Csv $Out -NoTypeInformation -Encoding utf8
$same = @($rows | Where-Object Same).Count; $miss = @($rows | Where-Object Target -eq 'MISSING').Count
$st = @($rows | Where-Object { -not $_.Same -and $_.Target -ne 'MISSING' -and ($_.FinTcm -split ' ')[0] -ne ($_.Target -split ' ')[0] }).Count
"RESULT: fin-tcm $($a.Count) PRs, target $($b.Count); identical $same; missing $miss; different state $st; other differences $($a.Count - $same - $miss - $st)"
"file: $Out"
