# Safety net for delta-sync.ps1: switches "include administrators" back ON for every branch in
# C:\kon-migration\rules\classic-bypass-branches.csv (all had it on before the sync bypass). Safe to run any time.
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
foreach ($c in (Import-Csv C:\kon-migration\rules\classic-bypass-branches.csv)) {
  $ea = "https://api.github.com/repos/tcm-pilot/$($c.Repo)/branches/$($c.Branch)/protection/enforce_admins"
  try { if (-not (Invoke-RestMethod $ea -Headers $h).enabled) { Invoke-RestMethod -Method POST $ea -Headers $h | Out-Null; "{0}/{1}: re-enabled" -f $c.Repo, $c.Branch } else { "{0}/{1}: ok" -f $c.Repo, $c.Branch } }
  catch { "{0}/{1}: FAILED {2}" -f $c.Repo, $c.Branch, $_.Exception.Message }
}
