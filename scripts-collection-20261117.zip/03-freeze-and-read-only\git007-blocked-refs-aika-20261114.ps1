# 14 Nov 2026 (Gareth: "5. bypass" - this ref was skipped earlier because the repo was swapped at the time).
# Pushes AI-kondor-assistant refs/heads/feature/ka_qa_per_env_db (refused by repo ruleset 27263428: no force-push) with a
# temporary migration-team bypass on that ruleset, then restores the ruleset exactly. Lease-guarded; old commit backed up.
$ErrorActionPreference = 'Stop'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $A = 'https://api.github.com'
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'
$repo = 'AI-kondor-assistant'; $ref = 'refs/heads/feature/ka_qa_per_env_db'; $rsId = 25038335; $migTeam = 20591252
$bk = 'C:\kon-migration\corrective-sync\blocked-aika-20261114'; New-Item -ItemType Directory -Force $bk | Out-Null
$log = "$bk\run.log"; function Write-RunLog($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; Write-Output $l; Add-Content $log $l -Encoding utf8 }
$orig = Invoke-RestMethod "$A/repos/tcm-pilot/$repo/rulesets/$rsId" -Headers $gh; $orig | ConvertTo-Json -Depth 12 | Out-File "$bk\ruleset-$rsId.json" -Encoding utf8
$origBy = @($orig.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } })
try {
  $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$repo/rulesets/$rsId" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = @($origBy + @(@{ actor_id = $migTeam; actor_type = 'Team'; bypass_mode = 'always' })) } | ConvertTo-Json -Depth 6)
  Write-RunLog "opened ruleset $rsId (migration team bypass added)"
  $ErrorActionPreference = 'Continue'
  $d = "$bk\$repo.git"; if (-not (Test-Path $d)) { git init --bare -q $d }
  $old = ((git -c "http.extraHeader=Authorization: Basic $tb" ls-remote "https://github.com/tcm-pilot/$repo.git" $ref) -split "`t")[0]
  git -C $d -c "http.extraHeader=Authorization: Basic $tb" fetch -q "https://github.com/tcm-pilot/$repo.git" "+$($ref):refs/backup/$($ref -replace '^refs/','')" 2>&1 | Out-Null
  git -C $d bundle create -q "$bk\$repo-before.bundle" --all 2>&1 | Out-Null
  git -C $d -c "http.extraHeader=Authorization: Basic $sb" fetch -q "https://github.com/fin-tcm/$repo.git" "+$($ref):$ref" 2>&1 | Out-Null
  $o = @(git -C $d -c "http.extraHeader=Authorization: Basic $tb" push --porcelain "--force-with-lease=$($ref):$old" "https://github.com/tcm-pilot/$repo.git" "+$($ref):$ref" 2>&1 | ForEach-Object { "$_" })
  $now = ((git -c "http.extraHeader=Authorization: Basic $tb" ls-remote "https://github.com/tcm-pilot/$repo.git" $ref) -split "`t")[0]; $want = git -C $d rev-parse $ref
  Write-RunLog "$repo $ref : $(if ($now -eq $want) { 'now matches fin-tcm' } else { 'NOT updated: ' + (($o | Where-Object { $_ -match '^!|remote: - ' }) -join ' ') })"
}
finally {
  try { $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$repo/rulesets/$rsId" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = $origBy } | ConvertTo-Json -Depth 6); Write-RunLog "restored ruleset $rsId" }
  catch { Write-RunLog "!! RESTORE FAILED ruleset $rsId : $($_.Exception.Message)" }
}
