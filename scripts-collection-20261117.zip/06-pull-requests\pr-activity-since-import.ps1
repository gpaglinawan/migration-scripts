# Read-only. For every live repo: which PRs in fin-tcm changed after the repo was imported into tcm-pilot (the nightly sync
# copies branches and tags, not PRs). Answers Lukasz Garstecki's question (10 Nov): how many repos would need a full
# re-migration (from scratch, with GEI) to have every recent PR exactly as in fin-tcm?
#   Missing  = PR created in fin-tcm after the import (not in tcm-pilot at all), split by its state now
#   Stale    = PR existed at import but was merged / closed / reopened since (wrong state in tcm-pilot)
# Same skips as open-pr-gap.ps1 (KON-kplus-front, the 9 -pr repos, TAAS-tms: handled separately).
# Output: C:\kon-migration\pr-activity\<date>\per-repo.csv + summary.md
param([string]$Refs = (Get-ChildItem C:\kon-migration\nightly -Directory | Where-Object Name -match '^\d{4}-\d\d-\d\d$' | Sort-Object Name | Select-Object -Last 1).FullName + '\after',
      [string]$Out = "C:\kon-migration\pr-activity\$(Get-Date -Format yyyy-MM-dd)", [int]$Batch = 10)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
New-Item -ItemType Directory -Force $Out | Out-Null
$logFile = "$Out\run.log"; function Write-Log($msg) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
function Invoke-Gql($tok, $query) {
  for ($try = 1; ; $try++) {
    try { $resp = Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body (@{ query = $query } | ConvertTo-Json) -ContentType 'application/json'
          if ($resp.errors -and -not $resp.data) { throw ($resp.errors | ConvertTo-Json -Compress) }; return $resp.data }
    catch { if ($try -ge 5) { Write-Log "  GraphQL failed: $($_.Exception.Message)"; return $null }; Start-Sleep (15 * $try) }
  }
}
$prFields = 'number createdAt updatedAt state mergedAt closedAt'
$skip = 'KON-kplus-front', 'SFX-netcore-common', 'FCBO-fusion-detect-core', 'MAFTP-fpp-fusioncapital', 'MAFTP-fpp-vaas-che', 'OPICS-programmers',
        'FWK-utfinstaller', 'TO-treasury-installer', 'RISK-cmr', 'FCGC-pricing-analytics', 'TAAS-tms'
$srcRepos = Import-Csv "$Refs\fin-tcm-repos.csv"; $tgtIdx = @{}; Import-Csv "$Refs\tcm-pilot-repos.csv" | ForEach-Object { $tgtIdx[$_.Name.ToLower()] = $_ }
$todo = @($srcRepos | Where-Object { $_.Archived -ne 'True' -and $tgtIdx[$_.Name.ToLower()] -and $_.Name -notin $skip } | ForEach-Object { $_.Name })
Write-Log "=== PR activity since import: $($todo.Count) repos (repo list from $Refs)"

$perRepo = New-Object System.Collections.ArrayList
for ($i = 0; $i -lt $todo.Count; $i += $Batch) {
  $chunk = @($todo[$i..([Math]::Min($i + $Batch, $todo.Count) - 1)])
  $qt = '{ ' + (($chunk | ForEach-Object -Begin { $n = 0 } -Process { "r$n" + ': repository(owner:"tcm-pilot", name:"' + $_ + '") { createdAt }'; $n++ }) -join ' ') + ' }'
  $tgtData = Invoke-Gql $env:GH_TGT_PAT $qt
  $qs = '{ ' + (($chunk | ForEach-Object -Begin { $n = 0 } -Process { "r$n" + ': repository(owner:"fin-tcm", name:"' + $_ + '") { diskUsage pullRequests(first:100, orderBy:{field:UPDATED_AT, direction:DESC}) { totalCount pageInfo { hasNextPage endCursor } nodes { ' + $prFields + ' } } }'; $n++ }) -join ' ') + ' }'
  $srcData = Invoke-Gql $env:GH_SRC_PAT $qs
  for ($k = 0; $k -lt $chunk.Count; $k++) {
    $repo = $chunk[$k]; $imported = $tgtData."r$k".createdAt; $src = $srcData."r$k"
    if (-not $imported -or -not $src) { Write-Log "  $repo : no data"; continue }
    $importedAt = ([datetime]$imported).ToUniversalTime()
    $nodes = @($src.pullRequests.nodes); $cursor = $src.pullRequests.pageInfo.endCursor; $more = $src.pullRequests.pageInfo.hasNextPage
    while ($more -and $nodes.Count -and ([datetime]$nodes[-1].updatedAt).ToUniversalTime() -gt $importedAt) {
      $page = (Invoke-Gql $env:GH_SRC_PAT ('{ repository(owner:"fin-tcm", name:"' + $repo + '") { pullRequests(first:100, after:"' + $cursor + '", orderBy:{field:UPDATED_AT, direction:DESC}) { pageInfo { hasNextPage endCursor } nodes { ' + $prFields + ' } } } }')).repository.pullRequests
      if (-not $page) { break }; $nodes += @($page.nodes); $cursor = $page.pageInfo.endCursor; $more = $page.pageInfo.hasNextPage
    }
    $after = { param($t) $t -and ([datetime]$t).ToUniversalTime() -gt $importedAt }
    $missing = @($nodes | Where-Object { & $after $_.createdAt })
    $stale = @($nodes | Where-Object { -not (& $after $_.createdAt) -and ((& $after $_.mergedAt) -or (& $after $_.closedAt) -or ($_.state -eq 'OPEN' -and (& $after $_.updatedAt) -and $false)) })
    [void]$perRepo.Add([pscustomobject]@{ Repo = $repo; Imported = $imported; DiskMB = [Math]::Round($src.diskUsage / 1024, 1); PrsTotal = $src.pullRequests.totalCount
      MissingOpen = @($missing | Where-Object state -eq 'OPEN').Count; MissingMerged = @($missing | Where-Object state -eq 'MERGED').Count; MissingClosed = @($missing | Where-Object state -eq 'CLOSED').Count
      StaleState = $stale.Count })
  }
  if (($i / $Batch) % 20 -eq 0) { Write-Log "  $([Math]::Min($i + $Batch, $todo.Count))/$($todo.Count) repos" }
}
$perRepo | Export-Csv "$Out\per-repo.csv" -NoTypeInformation -Encoding utf8
$active = @($perRepo | Where-Object { $_.MissingOpen + $_.MissingMerged + $_.MissingClosed + $_.StaleState -gt 0 })
$sum = { param($col) ($perRepo | Measure-Object $col -Sum).Sum }
$md = @("# PR activity in fin-tcm since each repo's import into tcm-pilot - $(Get-Date -Format 'yyyy-MM-dd HH:mm') CET", '',
  "Repos checked: $($perRepo.Count) (archived, KON-kplus-front, the 9 -pr repos and TAAS-tms excluded).", '',
  "- **Repos with any PR change since import: $($active.Count)** (would need a full re-migration to match fin-tcm exactly); their size: $([Math]::Round(($active | Measure-Object DiskMB -Sum).Sum / 1024, 1)) GB, $(($active | Measure-Object PrsTotal -Sum).Sum) PRs in total",
  "- PRs created since import, not in tcm-pilot: open $(& $sum MissingOpen), merged $(& $sum MissingMerged), closed $(& $sum MissingClosed)",
  "- PRs that existed at import but were merged/closed since (wrong state in tcm-pilot): $(& $sum StaleState)",
  "- Repos with no PR change since import: $($perRepo.Count - $active.Count) (already complete in tcm-pilot)", '',
  '| Repo | Missing open | Missing merged | Missing closed | Stale state | PRs total | Size MB |', '|---|---|---|---|---|---|---|')
$md += $active | Sort-Object { $_.MissingOpen + $_.MissingMerged + $_.MissingClosed + $_.StaleState } -Descending | Select-Object -First 40 | ForEach-Object { "| $($_.Repo) | $($_.MissingOpen) | $($_.MissingMerged) | $($_.MissingClosed) | $($_.StaleState) | $($_.PrsTotal) | $($_.DiskMB) |" }
$md += '', "Detail: $Out\per-repo.csv"
$md | Set-Content "$Out\summary.md" -Encoding utf8
Write-Log "=== done: $($active.Count) of $($perRepo.Count) repos have PR changes since import"
