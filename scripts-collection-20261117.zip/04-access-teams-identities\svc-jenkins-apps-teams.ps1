# Gives svc-jenkins-apps-2/3/4 the same tcm-pilot team memberships as svc-jenkins-apps-1
# (service account request; accounts created in Entra by Vlad, 3 Nov 2026). Adding to a team also adds
# the account to the org. Membership role copied as is (member/maintainer). Safe to re-run.
param([switch]$Apply)
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$h = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json" }
$org = 'tcm-pilot'; $ref = 'svc-jenkins-apps-1_tciem'
$new = 'svc-jenkins-apps-2_tciem', 'svc-jenkins-apps-3_tciem', 'svc-jenkins-apps-4_tciem'

$teams = @(); $page = 1
do { $r = @(Invoke-RestMethod "https://api.github.com/orgs/$org/teams?per_page=100&page=$page" -Headers $h | ForEach-Object { $_ }); $teams += $r; $page++ } while ($r.Count -eq 100)
$refTeams = foreach ($t in $teams) {
  try { $m = Invoke-RestMethod "https://api.github.com/orgs/$org/teams/$($t.slug)/memberships/$ref" -Headers $h; if ($m.state -eq 'active') { [pscustomobject]@{ Slug = $t.slug; Role = $m.role } } } catch {}
}
"$ref is in $(@($refTeams).Count) teams: $(($refTeams | ForEach-Object { "$($_.Slug)($($_.Role))" }) -join ', ')"
if (-not $Apply) { "PLAN only - run with -Apply"; return }

foreach ($u in $new) {
  $ok = 0; $bad = @()
  foreach ($t in $refTeams) {
    try { Invoke-RestMethod -Method PUT "https://api.github.com/orgs/$org/teams/$($t.Slug)/memberships/$u" -Headers $h -ContentType application/json -Body (@{ role = $t.Role } | ConvertTo-Json) | Out-Null; $ok++ }
    catch { $bad += "$($t.Slug): $($_.ErrorDetails.Message)" }
  }
  "$u : added to $ok/$(@($refTeams).Count) teams"; $bad | ForEach-Object { "  failed $_" }
}
