# 15 Nov 2026 (Gareth: "yes to 1" - temporary bypass on repo rulesets for the additive fin-tcm-kept pushes).
# For each repo: back up its own (repo-level) rulesets, add the migration-sync team as an always-bypass actor, re-run the
# FAILED rows of preserved-refs.csv for that repo (push only, never overwrite: fin-tcm-kept/* names or missing refs),
# then restore every ruleset's bypass list exactly (finally block).
param([Parameter(Mandatory)][string[]]$Repos)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $A = 'https://api.github.com'
$sb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_SRC_PAT")); $tb = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'; $migTeam = 20591252
$bk = "C:\kon-migration\rules\repo-ruleset-backup-$(Get-Date -Format yyyyMMdd-HHmm)"; New-Item -ItemType Directory -Force $bk | Out-Null
$log = 'C:\kon-migration\nightly\cutover-20261113.log'
$csv = 'C:\kon-migration\refs\preserved-refs.csv'
foreach ($repo in $Repos) {
  $todo = @(Import-Csv $csv | Where-Object { $_.Repo -eq $repo } | Group-Object KeptAs | ForEach-Object { $_.Group[-1] } | Where-Object { $_.Result -ne 'PUSHED' })
  if (-not $todo.Count) { "$repo : nothing to push"; continue }
  $sets = @(Invoke-RestMethod "$A/repos/tcm-pilot/$repo/rulesets?includes_parents=false" -Headers $gh | ForEach-Object { $_ } | ForEach-Object { Invoke-RestMethod "$A/repos/tcm-pilot/$repo/rulesets/$($_.id)" -Headers $gh })
  $sets | ConvertTo-Json -Depth 20 | Out-File "$bk\$repo.json" -Encoding utf8
  $orig = @{}; foreach ($s in $sets) { $orig[$s.id] = @($s.bypass_actors | Where-Object { $_ } | ForEach-Object { @{ actor_id = $_.actor_id; actor_type = $_.actor_type; bypass_mode = $_.bypass_mode } }) }
  try {
    foreach ($s in $sets) { $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$repo/rulesets/$($s.id)" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = @($orig[$s.id] + @(@{ actor_id = $migTeam; actor_type = 'Team'; bypass_mode = 'always' })) } | ConvertTo-Json -Depth 6) }
    Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') $repo : migration-sync bypass added to $($sets.Count) repo ruleset(s) (backup $bk)" -Encoding utf8
    $d = "C:\kon-migration\refs\preserve-work\$repo.git"; if (-not (Test-Path $d)) { git init --bare -q $d }
    foreach ($r in $todo) {
      $ref = $r.Ref; $dest = $r.KeptAs
      git -C $d -c "http.extraHeader=Authorization: Basic $sb" fetch -q "https://github.com/fin-tcm/$repo.git" "+$($ref):refs/src/$($ref -replace '^refs/','')" 2>&1 | Out-Null
      $sha = git -C $d rev-parse "refs/src/$($ref -replace '^refs/','')" 2>$null
      $exists = ((git -c "http.extraHeader=Authorization: Basic $tb" ls-remote "https://github.com/tcm-pilot/$repo.git" $dest) -split "`t")[0]
      if ($exists -and $exists -ne $sha) { $res = "FAILED: $dest already exists with another commit - left alone" }
      elseif ($exists -eq $sha) { $res = 'PUSHED' }
      else {
        $o = @(git -C $d -c "http.extraHeader=Authorization: Basic $tb" push --porcelain "https://github.com/tcm-pilot/$repo.git" "$($sha):$dest" 2>&1 | ForEach-Object { "$_" })
        $now = ((git -c "http.extraHeader=Authorization: Basic $tb" ls-remote "https://github.com/tcm-pilot/$repo.git" $dest) -split "`t")[0]
        $res = if ($now -eq $sha) { 'PUSHED' } else { 'FAILED: ' + (($o | Where-Object { $_ -match '^!|remote: [-a-zA-Z]' } | Select-Object -First 3) -join ' | ') }
      }
      [pscustomobject]@{ Repo = $repo; Ref = $ref; Issue = $r.Issue; FinastraCommit = $r.FinastraCommit; TeciemCommit = $r.TeciemCommit; KeptAs = $dest; Result = $res; At = (Get-Date -Format 'yyyy-MM-dd HH:mm') } | Export-Csv $csv -Append -NoTypeInformation -Encoding utf8
      "{0,-24} {1} : {2}" -f $repo, $dest, $res
    }
  } finally {
    foreach ($s in $sets) {
      try { $null = Invoke-RestMethod -Method Put "$A/repos/tcm-pilot/$repo/rulesets/$($s.id)" -Headers $gh -ContentType application/json -Body (@{ bypass_actors = $orig[$s.id] } | ConvertTo-Json -Depth 6) }
      catch { Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') !! RESTORE FAILED $repo ruleset $($s.id): $($_.Exception.Message)" -Encoding utf8; "!! RESTORE FAILED $repo $($s.id)" }
    }
    Add-Content $log "$(Get-Date -Format 'yyyy-MM-dd HH:mm') $repo : repo ruleset bypass lists restored" -Encoding utf8
  }
}
