﻿# Builds a PR-preserving copy <Repo>-pr in tcm-pilot with pr-preload.ps1 while tcm-pilot is read-only (org rulesets
# "Migration read-only until cutover"). The long stages (export, extract, rewrite, remap, archive) run with nothing changed;
# only for import .. cleanup is <Repo>-pr excluded from the read-only rulesets, and the exclusion is removed in a finally
# block, so the new copy is read-only like every other repo. GitHub gives the new repo no team access - teams are copied at
# the swap (GIT-022, rename: <repo> -> <repo>-old, <repo>-pr -> <repo>).
# First use: KON-kplus-front, approved by Gareth 2026-11-10 ("starts ASAP", swap by rename) - about 33 h (rehearsal 8-9 Nov).
#   .\pr-preload-to-pilot.ps1 -Repo KON-kplus-front -Work C:\kon-migration\pr-preload\KON-kplus-front-cutover
param([Parameter(Mandatory)][string]$Repo, [string]$TargetName = "$Repo-pr", [string]$Work = "C:\kon-migration\pr-preload\$Repo-cutover", [string[]]$PathRename = @(), [switch]$DropNullGitlinks)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$ghAuth = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$target = $TargetName  # 12 Nov: -TargetName (<repo>-pr2 for GIT-019B, <repo>-ri for GIT-020B)
New-Item -ItemType Directory -Force $Work | Out-Null
$logFile = Join-Path $Work 'wrapper.log'
function Write-Log($msg) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $msg; Write-Output $line; Add-Content $logFile $line -Encoding utf8 }
$preArgs = @{ Repo = $Repo; TargetOrg = 'tcm-pilot'; TargetName = $target; Work = $Work }
if ($PathRename) { $preArgs.PathRename = $PathRename }; if ($DropNullGitlinks) { $preArgs.DropNullGitlinks = $true }
function Invoke-Preload($stopAfter) {
  $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'C:\kon-migration\scripts\pr-preload\pr-preload.ps1', '-StopAfter', $stopAfter)
  foreach ($k in $preArgs.Keys) { if ($preArgs[$k] -is [bool]) { $argList += "-$k" } elseif ($preArgs[$k] -is [array]) { $argList += "-$k"; $argList += ($preArgs[$k] -join ',') } else { $argList += "-$k"; $argList += $preArgs[$k] } }
  & powershell @argList | Out-Null; $LASTEXITCODE }
Write-Log "=== $Repo -> tcm-pilot/$target (work $Work) ==="
$exists = try { $null = Invoke-RestMethod "https://api.github.com/repos/tcm-pilot/$target" -Headers $ghAuth; $true } catch { $false }
$st = if (Test-Path "$Work\state.json") { Get-Content "$Work\state.json" -Raw | ConvertFrom-Json } else { $null }
if ($exists -and -not $st.done_import) { Write-Log "STOP: tcm-pilot/$target already exists and this work folder did not create it"; exit 1 }

# 1. export .. archive: nothing changed in tcm-pilot
$t0 = Get-Date
$rc = Invoke-Preload 'archive'
Write-Log ("  stages export..archive: exit {0} after {1:N1} h" -f $rc, ((Get-Date) - $t0).TotalHours)
if ($rc -ne 0) { Write-Log "STOP: preload stopped before import - see $Work\run.log"; exit 1 }

# 2. import .. cleanup with only <Repo>-pr excluded from the read-only rulesets
$rulesets = @(Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets?per_page=100" -Headers $ghAuth | ForEach-Object { $_ } | Where-Object { $_.name -like 'Migration read-only until cutover*' })
$saved = @{}
function Set-Exclude($rs, $list) {
  $full = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
  $cond = @{ ref_name = @{ include = @($full.conditions.ref_name.include); exclude = @($full.conditions.ref_name.exclude | Where-Object { $_ }) }
             repository_name = @{ include = @($full.conditions.repository_name.include); exclude = @($list); protected = [bool]$full.conditions.repository_name.protected } }
  Invoke-RestMethod -Method PUT "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth -ContentType application/json -Body (@{ conditions = $cond } | ConvertTo-Json -Depth 6) | Out-Null
  @((Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth).conditions.repository_name.exclude) }
try {
  foreach ($rs in $rulesets) {
    $full = Invoke-RestMethod "https://api.github.com/orgs/tcm-pilot/rulesets/$($rs.id)" -Headers $ghAuth
    $saved[$rs.id] = @($full.conditions.repository_name.exclude | Where-Object { $_ })
    $now = Set-Exclude $rs (@($saved[$rs.id] + $target | Select-Object -Unique)); Write-Log "  read-only ruleset $($rs.id): $target excluded for the import (excluded now: $($now -join ','))" }
  $t1 = Get-Date
  $rc = Invoke-Preload 'cleanup'
  Write-Log ("  stages import..cleanup: exit {0} after {1:N1} h" -f $rc, ((Get-Date) - $t1).TotalHours)
}
finally {
  foreach ($rs in $rulesets) {
    try { $now = Set-Exclude $rs $saved[$rs.id]; Write-Log ("  read-only ruleset {0} restored: excluded [{1}] {2}" -f $rs.id, ($now -join ','), $(if ($now -contains $target) { '!! STILL EXCLUDED - CHECK' } else { '(ok)' })) }
    catch { Write-Log "  !! could not restore ruleset $($rs.id): $($_.Exception.Message) - run readonly-ruleset.ps1 -Org tcm-pilot -Apply" } }
}
$st = if (Test-Path "$Work\state.json") { Get-Content "$Work\state.json" -Raw | ConvertFrom-Json } else { $null }
Write-Log ("=== done after {0:N1} h: PRs {1}/{2} (identical {3})" -f ((Get-Date) - $t0).TotalHours, $st.prTarget, $st.prSource, $st.prIdentical)


