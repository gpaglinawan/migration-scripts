param(
  [Parameter(Mandatory)][string]$Repo,
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Work = "C:\kon-migration\lfscheck"
)
# Proves LFS completeness from the TARGET side: fetches all branches+tags from the target, then downloads every LFS
# object referenced anywhere in that history from the target's LFS store. Objects that fail are fetched from the
# source and uploaded to the target, then re-checked. Read-only on the source.
$ErrorActionPreference = "Continue"
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function As($pat) { $env:GIT_CONFIG_COUNT = "1"; $env:GIT_CONFIG_KEY_0 = "http.https://github.com/.extraheader"; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$pat")); $env:GIT_TERMINAL_PROMPT = "0" }
$dir = Join-Path $Work "$Repo.git"; Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
git init --bare -q --ref-format=reftable $dir
git -C $dir config remote.origin.url "https://github.com/$TgtOrg/$Repo.git"
git -C $dir config remote.origin.fetch "+refs/heads/*:refs/heads/*"
git -C $dir config --add remote.origin.fetch "+refs/tags/*:refs/tags/*"
As $env:GH_TGT_PAT
git -C $dir fetch -q origin
"target refs: $(@(git -C $dir for-each-ref).Count)"
$oids = @(git -C $dir lfs ls-files --all --long 2>$null | ForEach-Object { if ($_ -match '^([0-9a-f]{64})\s') { $Matches[1] } } | Sort-Object -Unique)
"LFS objects referenced in target history: $($oids.Count)"
git -C $dir config lfs.url "https://github.com/$TgtOrg/$Repo.git/info/lfs"
git -C $dir lfs fetch --all origin 2>&1 | Out-Null
$lfsDir = Join-Path $dir "lfs\objects"
function Missing { @($oids | Where-Object { -not (Test-Path (Join-Path $lfsDir "$($_.Substring(0,2))\$($_.Substring(2,2))\$_")) }) }
$miss = Missing
"downloadable from TARGET: $($oids.Count - $miss.Count) of $($oids.Count)"
if ($miss.Count) {
  "fetching $($miss.Count) missing objects from SOURCE and uploading to target..."
  As $env:GH_SRC_PAT
  git -C $dir config lfs.url "https://github.com/$SrcOrg/$Repo.git/info/lfs"
  git -C $dir lfs fetch --all "https://github.com/$SrcOrg/$Repo.git" 2>&1 | Out-Null
  $have = @($miss | Where-Object { Test-Path (Join-Path $lfsDir "$($_.Substring(0,2))\$($_.Substring(2,2))\$_") })
  "  available on source: $($have.Count) of $($miss.Count)"
  if ($have.Count) { As $env:GH_TGT_PAT; git -C $dir lfs push --object-id "https://github.com/$TgtOrg/$Repo.git" @have 2>&1 | Select-Object -Last 2 }
  $miss | Where-Object { $_ -notin $have } | Out-File (Join-Path $Work "$Repo-lfs-missing-on-source.txt") -Encoding utf8
  # re-check from target in a clean LFS store
  Remove-Item $lfsDir -Recurse -Force -ErrorAction SilentlyContinue
  As $env:GH_TGT_PAT; git -C $dir config lfs.url "https://github.com/$TgtOrg/$Repo.git/info/lfs"
  git -C $dir lfs fetch --all origin 2>&1 | Out-Null
  $miss = Missing
  "after repair, downloadable from TARGET: $($oids.Count - $miss.Count) of $($oids.Count)"
}
Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
"RESULT $Repo : $(if ($miss.Count) { "INCOMPLETE - $($miss.Count) objects missing (see $Repo-lfs-missing-on-source.txt)" } else { 'COMPLETE - every LFS object in every branch and tag downloads from the target' })"
