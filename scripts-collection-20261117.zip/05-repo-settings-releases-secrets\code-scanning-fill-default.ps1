param(
  [string[]]$Repos = @("SPH-sophis","TO-treasury-installer","TO-pgz-reports","THIRD-idakdb","RISK-fusion-risk","OPICS-opics4plus"),
  [string]$SrcOrg = "fin-tcm",
  [string]$TgtOrg = "tcm-pilot",
  [string]$Out = "C:\kon-migration\code-scanning-default-fill",
  [switch]$Apply
)
# Fills code scanning gaps on the DEFAULT branch (what the Security tab shows): for every tool/category whose latest
# source analysis on the default branch has no counterpart in the target, download the SARIF with curl (streams to
# disk, retries - the PowerShell download failed on large SARIFs) and upload it to the target at the same commit.
# If the commit isn't in the target (history rewritten for LFS), the rewritten twin is found by author date + message.
$ErrorActionPreference = "Continue"
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(\w+)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$srcHdr = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
$tgtHdr = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
New-Item -ItemType Directory -Force $Out | Out-Null
$log = Join-Path $Out "fill.log"
function Log($m) { $line = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $line; Add-Content -Path $log -Value $line -Encoding utf8 }
function Paged($uri, $hdr) { $acc = New-Object Collections.ArrayList; $page = 1; do { $n = 0; try { $res = Invoke-RestMethod "$uri$(if($uri -match '\?'){'&'}else{'?'})per_page=100&page=$page" -Headers $hdr; foreach ($x in $res) { if ($x) { [void]$acc.Add($x); $n++ } } } catch { break }; $page++ } while ($n -eq 100); $acc }
Log "=== default-branch fill: $($Repos -join ', ')  mode=$(if($Apply){'APPLY'}else{'PLAN'}) ==="

foreach ($repo in $Repos) {
  $s = "https://api.github.com/repos/$SrcOrg/$repo"; $t = "https://api.github.com/repos/$TgtOrg/$repo"
  $db = (Invoke-RestMethod $s -Headers $srcHdr).default_branch; $ref = "refs/heads/$db"
  $sa = @(Paged "$s/code-scanning/analyses?ref=$ref" $srcHdr); $ta = @(Paged "$t/code-scanning/analyses?ref=$ref" $tgtHdr)
  $have = @{}; foreach ($x in $ta) { $have["$($x.tool.name)|$($x.category)"] = $true }
  $groups = @($sa | Group-Object { "$($_.tool.name)|$($_.category)" })
  $todo = @($groups | Where-Object { -not $have[$_.Name] })
  Log "$repo ($ref): $($groups.Count) categories in source, $($todo.Count) missing in target"
  foreach ($g in $todo) {
    # newest analysis first; fall back to older ones when the commit isn't in the target (not synced yet / history
    # rewritten) or the source analysis can't be downloaded ("could not be processed")
    $picked = $null; $sha = $null; $file = $null; $tries = 0
    foreach ($a in @($g.Group | Sort-Object { [datetime]$_.created_at } -Descending)) {
      if ($tries -ge 15) { break }; $tries++
      $label = "$($a.tool.name) [$($a.category)] @ $($a.commit_sha.Substring(0,10)) ($($a.created_at))"
      $sha = $a.commit_sha
      try { Invoke-RestMethod "$t/commits/$sha" -Headers $tgtHdr | Out-Null }
      catch {
        $sc = Invoke-RestMethod "$s/commits/$sha" -Headers $srcHdr
        $twin = @(Paged "$t/commits?sha=$([uri]::EscapeDataString($db))&since=$($sc.commit.committer.date)&until=$($sc.commit.committer.date)" $tgtHdr | Where-Object { $_.commit.message -eq $sc.commit.message } | Select-Object -First 1)
        if (-not $twin.Count) { Log "  $repo : $label - commit not in target - trying an older analysis"; continue }
        $sha = $twin[0].sha; Log "  $repo : $label - using rewritten commit $($sha.Substring(0,10))"
      }
      $file = Join-Path $Out "$repo-$($a.id).sarif"
      & curl.exe -sS --fail --retry 3 --retry-delay 30 --max-time 3600 -H "Authorization: Bearer $env:GH_SRC_PAT" -H "Accept: application/sarif+json" -o $file "$s/code-scanning/analyses/$($a.id)" 2>&1 | ForEach-Object { Log "    curl: $_" }
      if (-not (Test-Path $file) -or (Get-Item $file).Length -lt 100) { Log "  $repo : $label - download failed - trying an older analysis"; continue }
      $picked = $a; break
    }
    if (-not $picked) { Log "  $repo : $($g.Name) - no usable analysis found - skipped"; continue }
    $a = $picked
    $bytes = [IO.File]::ReadAllBytes($file); $ms = New-Object IO.MemoryStream
    $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Compress); $gz.Write($bytes, 0, $bytes.Length); $gz.Close()
    $gzBytes = $ms.ToArray()
    Log ("  {0} : {1} - downloaded {2:N1} MB, gzip {3:N1} MB" -f $repo, $label, ($bytes.Length / 1MB), ($gzBytes.Length / 1MB))
    if ($gzBytes.Length -gt 10MB) { Log "  $repo : $label - gzip over the 10 MB upload limit - needs splitting, skipped"; continue }
    if (-not $Apply) { Log "  $repo : $label - would upload"; continue }
    $body = @{ commit_sha = $sha; ref = $ref; sarif = [Convert]::ToBase64String($gzBytes); tool_name = $a.tool.name } | ConvertTo-Json
    try {
      $u = Invoke-RestMethod -Method POST "$t/code-scanning/sarifs" -Headers $tgtHdr -Body $body -ContentType application/json
      $st = "pending"; for ($i = 0; $i -lt 40 -and $st -eq "pending"; $i++) { Start-Sleep 15; try { $st = (Invoke-RestMethod "$t/code-scanning/sarifs/$($u.id)" -Headers $tgtHdr).processing_status } catch {} }
      Log "  $repo : $label - uploaded $($u.id), processing: $st"
    } catch { Log "  $repo : $label - upload FAILED $($_.Exception.Response.StatusCode.value__) $($_.ErrorDetails.Message)" }
  }
}
Log "=== done ==="
