param(
  [double]$MinFreeGB = 40,      # start cleaning below this
  [double]$TargetFreeGB = 60,   # clean until at least this much is free
  [int]$IntervalSec = 300,
  [string]$Log = "C:\kon-migration\disk-watchdog.log"
)
# Keeps C: from filling up while the migration jobs run. Deletes ONLY data that is already pushed+verified or
# regenerable, in tiers, and only while free space is below $MinFreeGB. kon-kplus-front data is never touched
# until its push has verified (push.log "mismatched/missing=0").
$finished = 'FCGC-pricing-analytics', 'RISK-cmr', 'OPICS-programmers', 'KON-doc-kondor-archive'
function Free { (Get-PSDrive C).Free / 1GB }
function Log($m) { $line = "[{0:yyyy-MM-dd HH:mm:ss}] {1}" -f (Get-Date), $m; Add-Content -Path $Log -Value $line -Encoding utf8 }
function Remove-Tracked($path) {
  if (-not (Test-Path $path)) { return }
  $gb = (Get-ChildItem $path -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1GB
  Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue
  Log ("deleted {0} ({1:N2} GB) -> free {2:N1} GB" -f $path, $gb, (Free))
}
function Kon-Pushed { $p = "C:\kon-migration\push-kon-kplus-front\push.log"; (Test-Path $p) -and (Select-String -Path $p -Pattern 'mismatched/missing=0' -Quiet) }

Log ("watchdog started: clean below $MinFreeGB GB until $TargetFreeGB GB free (now {0:N1} GB)" -f (Free))
while ($true) {
  if ((Free) -lt $MinFreeGB) {
    Log ("LOW DISK: {0:N1} GB free - cleaning" -f (Free))
    $tiers = @(
      # 1. regenerable reports / leftovers
      @('C:\kon-migration\kon-bigfiles\all-objects.txt', 'C:\kon-migration\kon-bigfiles\rev-objects.txt', 'C:\kon-migration\kon-bigfiles\after-sizes.txt', 'C:\kon-migration\smoketest', 'C:\kon-migration\sync-dryrun', 'C:\kon-migration\feeds-test', 'C:\kon-migration\tools\artifacttool.zip', 'C:\kon-migration\tools\py312-embed.zip') +
        @(Get-ChildItem C:\kon-migration\bigfiles-* -Recurse -Include orig-objects.txt, after-sizes.txt -ErrorAction SilentlyContinue | ForEach-Object FullName),
      # 2. rewritten copies of finished repos (pushed + verified)
      @($finished | ForEach-Object { "C:\kon-migration\$_-lfs.git" }),
      # 3. originals of finished repos (Finastra still has them)
      @($finished | ForEach-Object { "C:\kon-migration\$_.git" }),
      # 4. kon-kplus-front only after its push verified
      @($(if (Kon-Pushed) { 'C:\kon-migration\kon-kplus-front-lfs.git', 'C:\kon-migration\kon-kplus-front.git' }))
    )
    foreach ($tier in $tiers) {
      foreach ($p in $tier) { if ($p -and (Free) -lt $TargetFreeGB) { Remove-Tracked $p } }
      if ((Free) -ge $TargetFreeGB) { break }
    }
    if ((Free) -lt $MinFreeGB) { Log ("STILL LOW after cleanup: {0:N1} GB free - nothing else safe to delete" -f (Free)) }
  }
  Start-Sleep $IntervalSec
}
