# DEF-392: re-add pull requests to a Teciem org project (fin-tcm) that the Finastra project (fin-tcm-old) had, matched by repo + PR number
# (re-imported repos keep the numbers), and copy the single-select Status value. Additive only. Usage: project-items-restore.py <src#> <tgt#> [--apply]
import json, re, sys, urllib.request
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
src_no, tgt_no = int(sys.argv[1]), int(sys.argv[2]); APPLY = '--apply' in sys.argv
tok = {}
for l in open(r'C:\development\pats.txt', encoding='utf-8-sig'):
    m = re.match(r'^\s*\$env:(GH_TGT_PAT|GH_SRC_PAT)\s*=\s*"?([^"\s]+)"?\s*$', l)
    if m: tok[m.group(1)] = m.group(2)
def gql(q, t, v=None):
    r = json.load(urllib.request.urlopen(urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q, 'variables': v or {}}).encode(), headers={'Authorization': 'Bearer ' + t}), timeout=120))
    if r.get('errors'): raise SystemExit(str(r['errors'])[:400])
    return r['data']
def items(org, no, t):
    out, cur = [], None
    while True:
        d = gql('query($c:String){organization(login:"%s"){projectV2(number:%d){id items(first:100,after:$c){pageInfo{hasNextPage endCursor} nodes{type content{... on PullRequest{number repository{name}} ... on Issue{number repository{name}}} fieldValueByName(name:"Status"){... on ProjectV2ItemFieldSingleSelectValue{name}}}}}}}' % (org, no), t, {'c': cur})['organization']['projectV2']
        out += d['items']['nodes']; pid = d['id']
        if not d['items']['pageInfo']['hasNextPage']: return pid, out
        cur = d['items']['pageInfo']['endCursor']
_, s_items = items('fin-tcm-old', src_no, tok['GH_SRC_PAT'])
pid, t_items = items('fin-tcm', tgt_no, tok['GH_TGT_PAT'])
have = {(i['content']['repository']['name'], i['content']['number']) for i in t_items if i.get('content') and i['content'].get('repository')}
f = gql('{node(id:"%s"){... on ProjectV2{field(name:"Status"){... on ProjectV2SingleSelectField{id options{id name}}}}}}' % pid, tok['GH_TGT_PAT'])['node']['field']
opts = {o['name']: o['id'] for o in (f or {}).get('options', [])}
added = skipped = 0
for i in s_items:
    c = i.get('content') or {}
    if not c.get('repository'): continue
    key = (c['repository']['name'], c['number'])
    if key in have: continue
    kind = 'pullRequest' if i['type'] == 'PULL_REQUEST' else 'issue'
    try: node = gql('{repository(owner:"fin-tcm",name:"%s"){%s(number:%d){id}}}' % (key[0], kind, key[1]), tok['GH_TGT_PAT'])['repository'][kind]['id']
    except SystemExit as e: print('  not found in fin-tcm:', key, str(e)[:80]); skipped += 1; continue
    st = (i.get('fieldValueByName') or {}).get('name')
    if not APPLY: print(f'  would add {key[0]}#{key[1]} status={st}'); added += 1; continue
    it = gql('mutation($p:ID!,$c:ID!){addProjectV2ItemById(input:{projectId:$p,contentId:$c}){item{id}}}', tok['GH_TGT_PAT'], {'p': pid, 'c': node})['addProjectV2ItemById']['item']['id']
    if st and st in opts:
        gql('mutation($p:ID!,$i:ID!,$f:ID!,$o:String!){updateProjectV2ItemFieldValue(input:{projectId:$p,itemId:$i,fieldId:$f,value:{singleSelectOptionId:$o}}){projectV2Item{id}}}', tok['GH_TGT_PAT'], {'p': pid, 'i': it, 'f': f['id'], 'o': opts[st]})
    added += 1
print(f'Finastra items {len(s_items)}, Teciem before {len(t_items)}; {"added" if APPLY else "to add"} {added}, not found {skipped}; status options in Teciem: {", ".join(opts)}')
