# Copilot AI-credit budget report (READ-ONLY): every user's usage against the per-user budget, saved as CSV.
# Tested 18 Nov 2026 against tcm-enterprise. Needs a token with enterprise billing read access (enterprise owner / billing manager;
# classic personal access token - fine-grained tokens are not supported for billing) in the environment variable GH_BILLING_TOKEN.
# Usage:  $env:GH_BILLING_TOKEN = '<token>';  .\copilot-budget-report.ps1 [-OutDir C:\reports]
# Schedule: Windows Task Scheduler, e.g. weekly, action: powershell.exe -NoProfile -File <path>\copilot-budget-report.ps1 -OutDir <folder>
param([string]$Enterprise = 'tcm-enterprise', [string]$OutDir = '.')
$ErrorActionPreference = 'Stop'
if (-not $env:GH_BILLING_TOKEN) { throw 'Set $env:GH_BILLING_TOKEN first' }
$hd  = @{ Authorization = "Bearer $env:GH_BILLING_TOKEN"; Accept = 'application/vnd.github+json' }
$api = "https://api.github.com/enterprises/$Enterprise/settings/billing"

$budgets = (Invoke-RestMethod "$api/budgets?per_page=100" -Headers $hd).budgets
$perUser = $budgets | Where-Object { $_.budget_scope -eq 'multi_user_customer' } | Select-Object -First 1   # the universal per-user budget
$ent     = $budgets | Where-Object { $_.budget_scope -eq 'enterprise' } | Select-Object -First 1
if (-not $perUser) { throw 'No per-user (universal) budget found' }

$rows = @(); $page = 1
do {
  $r = Invoke-RestMethod "$api/budgets/$($perUser.id)/user-states?per_page=100&page=$page" -Headers $hd
  foreach ($u in $r.user_states) {
    $rows += [pscustomobject]@{
      User        = $u.user
      UsedUSD     = [math]::Round([double]$u.consumed_amount, 2)
      LimitUSD    = [double]$u.target_amount
      PercentUsed = if ($u.target_amount) { [math]::Round(100 * $u.consumed_amount / $u.target_amount, 1) } else { $null }
      OwnBudget   = [bool]$u.override_budget_id   # true = the user has an individual budget instead of the universal one
    } }
  $page++
} while ($r.has_next_page)

New-Item -ItemType Directory -Force $OutDir | Out-Null
$stamp = Get-Date -Format yyyy-MM-dd
$file  = Join-Path $OutDir "copilot-budget-usage-$stamp.csv"
$rows | Sort-Object UsedUSD -Descending | Export-Csv $file -NoTypeInformation -Encoding UTF8
$atLimit = @($rows | Where-Object { $_.LimitUSD -and $_.UsedUSD -ge $_.LimitUSD }).Count
"Per-user budget: `$$($perUser.budget_amount) per user. Users with usage this cycle: $($rows.Count); at limit: $atLimit; total used: `$$([math]::Round(($rows | Measure-Object UsedUSD -Sum).Sum, 2))"
if ($ent) { "Enterprise budget: `$$($ent.budget_amount) (counts only paid usage beyond the included credits)" }
"Saved: $file"
