# DEF-106 (12 Nov 2026): GitHub's org export leaves out of users_*.json the unclaimed placeholder accounts
# (from the 2023 Bitbucket import) that authored PRs, reviews and comments; the importer then gives their
# content to "ghost". This adds a users entry for every account the metadata references but the users list
# lacks, so the importer creates a normal placeholder (mannequin) for it, which can be reclaimed later.
# Organisations (organizations_*.json) and bots (bots_*.json, plus "copilot") are never added.
# Only adds a new file users_<next>.json; existing files are not changed. Writes added-users.csv beside it.
# Usage: add_missing_users.py <export dir>
import json, glob, os, re, sys, collections, csv

d = sys.argv[1]
def load(kind):
    out = []
    for f in sorted(glob.glob(os.path.join(d, kind + '_*.json'))):
        out.extend(json.load(open(f, encoding='utf-8')))
    return out

users = {u['url'].lower() for u in load('users')}
skip = {o['url'].lower() for o in load('organizations')} | {b['url'].lower() for b in load('bots')}
skip.add('https://github.com/copilot')
KEYS = {'user', 'actor', 'assignee', 'assignees', 'author', 'requested_reviewer', 'reviewer', 'subject',
        'owner', 'creator', 'closer', 'merged_by'}
pat = re.compile(r'^https://github\.com/([^/]+)$')
refs = collections.Counter(); spelling = {}

def walk(o, key=None):
    if isinstance(o, dict):
        for k, v in o.items(): walk(v, k)
    elif isinstance(o, list):
        for v in o: walk(v, key)
    elif isinstance(o, str) and key in KEYS:
        m = pat.match(o)
        if m:
            refs[o.lower()] += 1; spelling.setdefault(o.lower(), o)

for f in glob.glob(os.path.join(d, '*.json')):
    kind = re.sub(r'_\d+\.json$', '', os.path.basename(f))
    if kind in ('users', 'organizations', 'teams', 'repositories', 'bots', 'schema'): continue
    walk(json.load(open(f, encoding='utf-8')))

missing = sorted((u for u in refs if u not in users and u not in skip), key=lambda u: -refs[u])
new = []
for u in missing:
    url = spelling[u]; login = pat.match(url).group(1)
    new.append({'type': 'user', 'url': url, 'avatar_url': None, 'login': login, 'name': login, 'bio': None,
                'company': None, 'website': None, 'location': None, 'emails': [], 'social_accounts': [],
                'billing_plan': None, 'created_at': '2023-01-01T00:00:00Z'})
if new:
    n = len(glob.glob(os.path.join(d, 'users_*.json'))) + 1
    path = os.path.join(d, 'users_%06d.json' % n)
    if os.path.exists(path): sys.exit('refusing: %s exists' % path)
    json.dump(new, open(path, 'w', encoding='utf-8'))
with open(os.path.join(os.path.dirname(os.path.abspath(d)), 'added-users.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['login', 'references'])
    for u in missing: w.writerow([pat.match(spelling[u]).group(1), refs[u]])
print('users listed %d, referenced %d, added %d (covering %d references), skipped orgs/bots %d'
      % (len(users), len(refs), len(new), sum(refs[u] for u in missing), len([u for u in refs if u in skip])))
