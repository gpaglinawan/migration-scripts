﻿# 19 Nov 2026 (Gareth: option 1). The Terraform project wiki only accepts changes through a pull request (branch policy on wikiMaster).
# Adds the Finastra PR archive pages (built by ado-history-archive.py into C:\kon-migration\ado-history-archive\<project>\PRs-*.md)
# on a branch, opens one PR and completes it as project collection admin (policy bypass, reason recorded). Additive: new pages only.
param([string]$Project = 'Terraform', [switch]$Apply)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT")); $th = @{ Authorization = "Basic $b64" }
$to = 'https://dev.azure.com/TreasuryCapitalMarkets'; $pe = [uri]::EscapeDataString($Project)
$src = "C:\kon-migration\ado-history-archive\$Project"
$wiki = (Invoke-RestMethod "$to/$pe/_apis/wiki/wikis?api-version=7.1" -Headers $th).value | Where-Object type -eq 'projectWiki' | Select-Object -First 1
$repoId = $wiki.repositoryId; $base = ($wiki.versions | Select-Object -First 1).version; if (-not $base) { $base = 'wikiMaster' }
# wiki git naming: spaces -> '-', literal '-' -> %2D
function Get-WikiName($t) { ($t -replace '-', '%2D') -replace ' ', '-' }
$pages = Get-ChildItem $src -Filter 'PRs-*.md'
$names = foreach ($p in $pages) { (Get-Content $p.FullName -TotalCount 1) -replace '^# Finastra pull requests - ', '' }
"$Project wiki repo $repoId base $base; pages: $($pages.Count)"
if (-not $Apply) { $names | Select-Object -First 5 | ForEach-Object { "  /Migration archive/Finastra pull requests/$_ -> Migration-archive/Finastra-pull-requests/$(Get-WikiName $_).md" }; return }

$w = "C:\kon-migration\ado-history-archive\wikigit-$Project"; Remove-Item $w -Recurse -Force -EA SilentlyContinue
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://dev.azure.com/.extraheader'; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $b64"
$url = "$to/$pe/_git/$([uri]::EscapeDataString($wiki.name))"
git clone -q --branch $base $url $w 2>&1 | Out-Null
$br = 'migration/finastra-pr-archive'
git -C $w checkout -q -b $br
$dir = Join-Path $w 'Migration-archive\Finastra-pull-requests'; New-Item -ItemType Directory -Force $dir | Out-Null
if (-not (Test-Path "$w\Migration-archive.md")) { Set-Content "$w\Migration-archive.md" "Read-only material kept from Finastra Azure DevOps during the Teciem migration.`n`n[[_TOSP_]]" -Encoding utf8 }
Set-Content (Join-Path $w 'Migration-archive\Finastra-pull-requests.md') "All pull requests of the Finastra Azure DevOps project $Project, one page per repository (read-only archive, 19 Nov 2026).`n`n[[_TOSP_]]" -Encoding utf8
$i = 0; foreach ($p in $pages) { $n = $names[$i]; $i++; Copy-Item $p.FullName (Join-Path $dir "$(Get-WikiName $n).md") -Force }
git -C $w config core.autocrlf false; git -C $w add -A 2>$null; git -C $w -c user.name='Gareth Cabrera' -c user.email='Gareth.Cabrera@teciem.com' commit -q -m "Archive of Finastra pull requests ($($pages.Count) repositories) - read-only, added during migration"
git -C $w push -q origin $br 2>&1 | Select-Object -Last 2
$env:GIT_CONFIG_COUNT = '0'
$api = "$to/$pe/_apis/git/repositories/$repoId/pullrequests"
$pr = Invoke-RestMethod -Method Post "$api`?api-version=7.1" -Headers $th -ContentType application/json -Body (@{
  sourceRefName = "refs/heads/$br"; targetRefName = "refs/heads/$base"
  title = "Migration archive: Finastra pull requests ($($pages.Count) repositories)"
  description = "Adds read-only pages with all Finastra pull requests of project $Project under Migration archive > Finastra pull requests (Azure DevOps cannot import pull requests). New pages only - no existing page is changed. Approved by Gareth Cabrera (migration lead), defect DEF-246." } | ConvertTo-Json)
"PR !$($pr.pullRequestId) created"
Start-Sleep 5; $pr = Invoke-RestMethod "$api/$($pr.pullRequestId)?api-version=7.1" -Headers $th
$done = Invoke-RestMethod -Method Patch "$api/$($pr.pullRequestId)?api-version=7.1" -Headers $th -ContentType application/json -Body (@{
  status = 'completed'; lastMergeSourceCommit = @{ commitId = $pr.lastMergeSourceCommit.commitId }
  completionOptions = @{ bypassPolicy = $true; bypassReason = 'Migration archive pages only (DEF-246), approved by migration lead'; mergeStrategy = 'noFastForward'; deleteSourceBranch = $true } } | ConvertTo-Json -Depth 4)
"PR !$($done.pullRequestId) status $($done.status)"
