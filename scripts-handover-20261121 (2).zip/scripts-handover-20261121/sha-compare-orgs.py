# Read-only: compare the default-branch tip commit of every repo in Finastra (fin-tcm-old) with the same repo in Teciem (fin-tcm).
# Different tip = history rewritten (e.g. large files moved to LFS) -> old clones cannot be reused. Usage: sha-compare-orgs.py <out.csv>
import json, re, sys, csv, urllib.request, time
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
tok = {}
for l in open(r'C:\development\pats.txt', encoding='utf-8-sig'):
    m = re.match(r'^\s*\$env:(GH_TGT_PAT|GH_SRC_PAT)\s*=\s*"?([^"\s]+)"?\s*$', l)
    if m: tok[m.group(1)] = m.group(2)
def gql(q, t):
    for a in range(5):
        try:
            j = json.load(urllib.request.urlopen(urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q}).encode(), headers={'Authorization': 'Bearer ' + t}), timeout=120))
            if 'data' in j and j['data'] is not None: return j['data']
        except Exception as e: j = {'errors': [str(e)]}
        time.sleep(5 * (a + 1))
    raise SystemExit('graphql failed: ' + str(j.get('errors'))[:300])
def names(org, t):
    out, cur = [], None
    while True:
        after = f',after:"{cur}"' if cur else ''
        d = gql('{organization(login:"%s"){repositories(first:100%s){pageInfo{hasNextPage endCursor} nodes{name isArchived defaultBranchRef{name target{oid}}}}}}' % (org, after), t)['organization']['repositories']
        out += d['nodes']
        if not d['pageInfo']['hasNextPage']: return out
        cur = d['pageInfo']['endCursor']
src = {r['name']: r for r in names('fin-tcm-old', tok['GH_SRC_PAT'])}
tgt = {r['name']: r for r in names('fin-tcm', tok['GH_TGT_PAT'])}
rows = []
for n, s in sorted(src.items()):
    t = tgt.get(n); so = (s['defaultBranchRef'] or {}).get('target', {}).get('oid') if s['defaultBranchRef'] else None
    to = (t['defaultBranchRef'] or {}).get('target', {}).get('oid') if t and t['defaultBranchRef'] else None
    if not t: st = 'not in Teciem'
    elif not so: st = 'empty in Finastra'
    elif so == to: st = 'same commits'
    else: st = 'DIFFERENT'
    rows.append([n, st, (s['defaultBranchRef'] or {}).get('name', '') if s['defaultBranchRef'] else '', so or '', to or ''])
with open(sys.argv[1], 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f); w.writerow(['Repository', 'Result', 'Default branch', 'Finastra tip', 'Teciem tip']); w.writerows(rows)
from collections import Counter
print(f'Finastra repos {len(src)}, Teciem repos {len(tgt)}:', dict(Counter(r[1] for r in rows)))
for r in rows:
    if r[1] == 'DIFFERENT': print('  DIFFERENT', r[0], r[2], r[3][:10], r[4][:10])
