﻿# Read-only: checks every ref of the original export against the rewritten repo, case-sensitively.
# Expected new value = commit-map[old commit] (tags compared by the commit they point to).
import sys, subprocess, collections
orig, new, cmap_path = sys.argv[1], sys.argv[2], sys.argv[3]
def refs(g):
    out = subprocess.run(['git', '-C', g, 'for-each-ref', '--format=%(refname)%09%(objectname)%09%(*objectname)'],
                         capture_output=True, text=True, encoding='utf-8', check=True).stdout
    d = {}
    for l in out.splitlines():
        name, obj, peeled = l.split('\t')
        d[name] = peeled or obj
    return d
cmap = {}
with open(cmap_path, encoding='ascii') as f:
    next(f)
    for l in f:
        a, b = l.split(); cmap[a] = b
o, n = refs(orig), refs(new)
st = collections.Counter(); bad = collections.defaultdict(list)
for name, old in o.items():
    exp = cmap.get(old)
    if name not in n:
        lower = [x for x in n if x.lower() == name.lower()]
        k = 'missing (renamed by case)' if lower else 'missing'
    elif exp is None:
        k = 'old commit not in map'
    elif n[name] == exp:
        k = 'ok'
    else:
        k = 'points to wrong commit'
    st[k] += 1
    if k != 'ok': bad[k].append(name)
extra = [x for x in n if x not in o]
for k, v in st.most_common(): print(f'{v:7}  {k}')
print(f'{len(extra):7}  extra refs in rewritten (not in original)')
for k, v in bad.items():
    print(f'--- {k}:'); [print('   ', x) for x in v[:40]]
print('--- extra:'); [print('   ', x) for x in extra]
