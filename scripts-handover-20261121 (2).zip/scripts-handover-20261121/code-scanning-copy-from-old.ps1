﻿# 16 Nov 2026 (DEF-249; Gareth: "go"). Finastra's code scanning API now returns 403, so the results are copied from the
# previous tcm-pilot copy (<repo>-old, which received them on 30 Oct) to the rebuilt <repo>:
#   upload : each latest branch analysis of <repo>-old as SARIF, commit translated by committer date + author date + message
#   states : dismissals (reason + comment, original author kept in the comment) matched by rule + path + start line
# 18 Nov: -DefaultBranchOnly copies only the default branch's latest analyses (what the Security tab shows)
param([Parameter(Mandatory)][string[]]$Repos, [ValidateSet('upload','states')][string]$Step = 'upload', [switch]$Apply, [switch]$DefaultBranchOnly)
$ErrorActionPreference = 'Continue'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hd = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json'; 'X-GitHub-Api-Version' = '2022-11-28' }
$log = 'C:\kon-migration\code-scanning\copy-from-old-20261118.log'
function Write-Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $l; Add-Content $log $l -Encoding utf8 }
function Get-All($u) { $acc = New-Object System.Collections.ArrayList; $p = 1; do { $n = 0; try { Invoke-RestMethod "$u$(if($u -match '\?'){'&'}else{'?'})per_page=100&page=$p" -Headers $hd -EA Stop | ForEach-Object { $_ } | ForEach-Object { [void]$acc.Add($_); $n++ } } catch { break }; $p++ } while ($n -eq 100); $acc }
foreach ($r in $Repos) {
  $old = "https://api.github.com/repos/fin-tcm/$r-old"; $new = "https://api.github.com/repos/fin-tcm/$r"
  if ($Step -eq 'upload') {
    $an = @(Get-All "$old/code-scanning/analyses" | Where-Object { $_.ref -like 'refs/heads/*' })
    if ($DefaultBranchOnly) { $db = (Invoke-RestMethod $old -Headers $hd).default_branch; $an = @($an | Where-Object { $_.ref -eq "refs/heads/$db" }) }
    $latest = @($an | Group-Object { "$($_.ref)|$($_.tool.name)|$($_.category)" } | ForEach-Object { $_.Group | Sort-Object { [datetime]$_.created_at } -Descending | Select-Object -First 1 })
    Write-Log "$r : $($latest.Count) analyses to copy"
    foreach ($a in $latest) {
      $br = $a.ref -replace '^refs/heads/', ''
      $sc = Invoke-RestMethod "$old/commits/$($a.commit_sha)" -Headers $hd
      $d = [datetime]$sc.commit.committer.date; $since = $d.AddSeconds(-1).ToUniversalTime().ToString('s') + 'Z'; $until = $d.AddSeconds(1).ToUniversalTime().ToString('s') + 'Z'
      $hit = @(Invoke-RestMethod "$new/commits?sha=$([uri]::EscapeDataString($br))&since=$since&until=$until&per_page=100" -Headers $hd -EA SilentlyContinue | ForEach-Object { $_ } | Where-Object { $_.commit.message -eq $sc.commit.message -and $_.commit.author.date -eq $sc.commit.author.date }) | Select-Object -First 1
      if (-not $hit) { Write-Log "$r : $($a.ref) commit $($a.commit_sha.Substring(0,10)) not found in $r - skipped"; continue }
      $file = "C:\kon-migration\code-scanning\sarif\$r-old-$($a.id).sarif"
      $ok = $false
      for ($try = 1; $try -le 5 -and -not $ok; $try++) {   # large downloads drop now and then: retry until the file is complete JSON
        curl.exe -s -L --retry 3 --retry-delay 10 --max-time 1200 -H "Authorization: Bearer $env:GH_TGT_PAT" -H "Accept: application/sarif+json" -o $file "$old/code-scanning/analyses/$($a.id)" 2>$null   # 19 Nov: curl - large SARIF downloads dropped with Invoke-WebRequest
        & C:\kon-migration\tools\python\python.exe -I -c "import json,sys; json.load(open(sys.argv[1],encoding='utf-8-sig'))" $file 2>$null; $ok = ($LASTEXITCODE -eq 0)
        if (-not $ok) { Start-Sleep (10 * $try) }
      }
      if (-not $ok) { Write-Log "$r : download of analysis $($a.id) incomplete after 5 attempts - skipped"; continue }
      if (-not $Apply) { Write-Log "$r : would upload $($a.tool.name) $($a.ref) @ $($hit.sha.Substring(0,10)) ($([int]((Get-Item $file).Length/1KB)) KB)"; continue }
      $bytes = [IO.File]::ReadAllBytes($file); $ms = New-Object IO.MemoryStream
      $gz = New-Object IO.Compression.GZipStream($ms, [IO.Compression.CompressionMode]::Compress); $gz.Write($bytes, 0, $bytes.Length); $gz.Close()
      $body = @{ commit_sha = $hit.sha; ref = $a.ref; sarif = [Convert]::ToBase64String($ms.ToArray()); tool_name = $a.tool.name } | ConvertTo-Json
      try { $u = Invoke-RestMethod -Method Post "$new/code-scanning/sarifs" -Headers $hd -Body $body -ContentType application/json; Write-Log "$r : uploaded $($a.tool.name) $($a.ref) @ $($hit.sha.Substring(0,10)) -> $($u.id)" }
      catch { Write-Log "$r : upload FAILED $($_.ErrorDetails.Message)" }
    }
  } else {
    $idx = @{}; foreach ($ta in (Get-All "$new/code-scanning/alerts?state=open&tool_name=$([uri]::EscapeDataString('CodeQL (Finastra history)'))")) { $l = $ta.most_recent_instance.location; $idx["$($ta.rule.id)|$($l.path)|$($l.start_line)"] = $ta }
    $done = 0; $miss = 0
    foreach ($sa in (Get-All "$old/code-scanning/alerts?state=dismissed")) {
      $l = $sa.most_recent_instance.location; $ta = $idx["$($sa.rule.id)|$($l.path)|$($l.start_line)"]
      if (-not $ta) { $miss++; continue }
      $c = "$($sa.dismissed_comment)"; if (-not $c) { $c = "Dismissed before migration ($($sa.dismissed_at.ToString().Substring(0,10)))" }
      if ($c.Length -gt 280) { $c = $c.Substring(0, 280) }
      if (-not $Apply) { $done++; continue }
      try { $null = Invoke-RestMethod -Method Patch "$new/code-scanning/alerts/$($ta.number)" -Headers $hd -Body (@{ state = 'dismissed'; dismissed_reason = $sa.dismissed_reason; dismissed_comment = $c } | ConvertTo-Json) -ContentType application/json; $done++ }
      catch { Write-Log "$r : dismiss #$($ta.number) FAILED $($_.ErrorDetails.Message)" }
    }
    Write-Log "$r : dismissals $(if($Apply){'applied'}else{'matched'}) $done; no matching open alert $miss"
  }
}
Write-Log "=== $Step done ($(if($Apply){'APPLY'}else{'PLAN'})) ==="
