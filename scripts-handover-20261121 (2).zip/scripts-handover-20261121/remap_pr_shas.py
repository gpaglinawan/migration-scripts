# Step 4: rewrites commit ids in the exported PR data using git-filter-repo's commit-map (old -> new).
# Input:  export dir (JSON files from the fin-tcm migration archive), commit-map file.
# Output: a new dir with the same files; the original export is never modified.
# Structural fields are remapped (PR base/head/merge, review head, review comment and thread commits, PR event commits,
# commit-comment commit + URL). Free text (PR titles/bodies, comment bodies, diff hunks) is left byte-identical, the same
# way the code rewrite keeps commit messages unchanged. Ids with no entry in the map (commits that no longer exist) are
# left as they are and counted.
import json, re, sys, os, glob, shutil, collections
src, cmap_path, dst = sys.argv[1], sys.argv[2], sys.argv[3]

cmap = {}
with open(cmap_path, encoding='ascii') as f:
    next(f)                                    # header: "old new"
    for line in f:
        old, new = line.split()
        cmap[old] = new
print(f'commit-map entries: {len(cmap)}', flush=True)

EXACT = {
    'pull_requests': [('base', 'sha'), ('head', 'sha'), ('merge_commit_sha',)],
    'pull_request_reviews': [('head_sha',)],
    'pull_request_review_comments': [('commit_id',), ('original_commit_id',)],
    'pull_request_review_threads': [('commit_id',), ('original_commit_id',)],
    'issue_events': [('commit_id',), ('after_commit_oid',), ('before_commit_oid',)],
    'commit_comments': [('commit_id',)],
}
URLS = {'commit_comments': ['url'], 'attachments': ['commit_comment']}
HEX = re.compile(r'(?<=/commit/)[0-9a-f]{40}')
stats = collections.Counter()

def remap_value(v, key):
    if not isinstance(v, str) or len(v) != 40: return v
    n = cmap.get(v)
    if n is None:
        stats[key + ' unmapped'] += 1; return v
    stats[key + ' mapped' if n != v else key + ' unchanged'] += 1
    return n

os.makedirs(dst, exist_ok=True)
for entry in os.listdir(src):
    s, d = os.path.join(src, entry), os.path.join(dst, entry)
    if entry.endswith('.json') and entry != 'schema.json':
        kind = re.sub(r'_\d+\.json$', '', entry)
        with open(s, encoding='utf-8') as fh: data = json.load(fh)
        for rec in data:
            for path in EXACT.get(kind, []):
                o = rec
                for p in path[:-1]: o = o.get(p) if isinstance(o, dict) else None
                if isinstance(o, dict) and path[-1] in o:
                    o[path[-1]] = remap_value(o[path[-1]], kind + '.' + '.'.join(path))
            for k in URLS.get(kind, []):
                if isinstance(rec.get(k), str):
                    rec[k] = HEX.sub(lambda m: remap_value(m.group(0), kind + '.' + k), rec[k])
        with open(d, 'w', encoding='utf-8') as fh: json.dump(data, fh, ensure_ascii=False)
    elif entry == 'repositories':
        continue                               # git is replaced by the rewritten repo when the archive is rebuilt
    elif os.path.isdir(s):
        shutil.copytree(s, d, dirs_exist_ok=True)
    else:
        shutil.copy2(s, d)

for k in sorted(stats): print(f'{stats[k]:8}  {k}')
