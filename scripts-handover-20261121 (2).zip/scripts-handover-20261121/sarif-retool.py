# Rewrites a CodeQL SARIF from <repo>-old so GitHub accepts it next to CodeQL default setup: tool name "CodeQL (Finastra history)"
# and a distinct category per run. Usage: sarif-retool.py <in.sarif> <out.sarif>   (prints result count)
import json, sys
d = json.load(open(sys.argv[1], encoding='utf-8-sig'))
n = 0
for i, r in enumerate(d.get('runs', [])):
    drv = r.setdefault('tool', {}).setdefault('driver', {})
    lang = (r.get('automationDetails') or {}).get('id', '') or (r.get('properties') or {}).get('semmle.sourceLanguage', '') or str(i)
    lang = lang.strip('/').replace('language:', '').split('/')[0] or str(i)
    drv['name'] = 'CodeQL (Finastra history)'
    r['automationDetails'] = {'id': f'finastra-history/{lang}/'}
    n += len(r.get('results', []))
json.dump(d, open(sys.argv[2], 'w', encoding='utf-8'))
print(n)
