# 19 Nov 2026 (Gareth: "yes"): recreated ADO PRs link to their original at dev.azure.com/TreasuryCapitalMarkets/..., which since the
# cutover rename is the Teciem org. Point the link (first line of the description only) to the Finastra org's new name.
param([string]$Csv = 'C:\kon-migration\ado-nightly\ado-prs-under-gareth-20261119.csv', [int]$Limit = 0, [switch]$Apply)
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(AZDO_PAT|AZDO_SOURCE_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$th = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_PAT")) }
$sh = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$env:AZDO_SOURCE_PAT")) }
$to = 'https://dev.azure.com/TreasuryCapitalMarkets'; $log = 'C:\kon-migration\ado-nightly\ado-pr-link-fix-20261119.log'
$rows = @(Import-Csv $Csv | Where-Object { $_.Status -eq 'active' }); if ($Limit) { $rows = $rows | Select-Object -First $Limit }
$ok = 0; $skip = 0; $fail = 0
foreach ($r in $rows) {
  $u = "$to/$([uri]::EscapeDataString($r.Project))/_apis/git/repositories/$([uri]::EscapeDataString($r.Repo))/pullrequests/$($r.PR)?api-version=7.1"
  $pr = Invoke-RestMethod $u -Headers $th; $lines = "$($pr.description)" -split "`n"
  if ($lines[0] -notmatch 'https://dev\.azure\.com/TreasuryCapitalMarkets/') { $skip++; continue }
  $lines[0] = $lines[0] -replace 'https://dev\.azure\.com/TreasuryCapitalMarkets/', 'https://dev.azure.com/TreasuryCapitalMarkets-finastra/' -replace 'Migrated from TreasuryCapitalMarkets PR', 'Migrated from Finastra (TreasuryCapitalMarkets-finastra) PR'
  $link = ([regex]::Match($lines[0], 'https://dev\.azure\.com/TreasuryCapitalMarkets-finastra/(?<p>[^/]+)/_git/(?<r>[^/]+)/pullrequest/(?<n>\d+)'))
  $check = try { $o = Invoke-RestMethod "https://dev.azure.com/TreasuryCapitalMarkets-finastra/$($link.Groups['p'].Value)/_apis/git/repositories/$($link.Groups['r'].Value)/pullrequests/$($link.Groups['n'].Value)?api-version=7.1" -Headers $sh; "original !$($o.pullRequestId) by $($o.createdBy.displayName)" } catch { "original NOT FOUND" }
  if (-not $Apply) { "$($r.Project)/$($r.Repo) !$($r.PR): $check | $($lines[0].Substring(0, [Math]::Min(160, $lines[0].Length)))"; continue }
  try { $null = Invoke-RestMethod -Method Patch $u -Headers $th -ContentType application/json -Body (@{ description = ($lines -join "`n") } | ConvertTo-Json); $ok++
        Add-Content $log "$(Get-Date -Format 'HH:mm:ss') $($r.Project)/$($r.Repo) !$($r.PR) link fixed; $check" -Encoding utf8 }
  catch { $fail++; Add-Content $log "$(Get-Date -Format 'HH:mm:ss') $($r.Project)/$($r.Repo) !$($r.PR) FAILED $($_.ErrorDetails.Message)" -Encoding utf8 }
}
"fixed $ok, already OK/other $skip, failed $fail$(if (-not $Apply) { ' (dry run)' })"
