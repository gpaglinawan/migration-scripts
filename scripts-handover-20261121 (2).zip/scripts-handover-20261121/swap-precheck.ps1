﻿# 16 Nov 2026 - READ-ONLY. Before swapping <repo>-<Suffix> (copy of fin-tcm-old) over the live fin-tcm/<repo>: lists every branch/tag
# of the live repo whose commits are NOT in the copy (= work done in fin-tcm only, which the swap would leave in <repo>-old).
# -Live lets you point at the already-swapped old repo (e.g. FCBO-swift-gateway-old).
param([Parameter(Mandatory)][string]$Repo, [string]$Suffix = 'pr2', [string]$Live = $Repo, [string]$Copy = "$Repo-$Suffix")
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'
$env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$w = "C:\kon-migration\swap\precheck\$Repo.git"; Remove-Item $w -Recurse -Force -EA SilentlyContinue; git init --bare -q $w
git -C $w fetch -q --filter=blob:none "https://github.com/fin-tcm/$Copy.git" '+refs/heads/*:refs/copy/heads/*' '+refs/tags/*:refs/copy/tags/*' 2>$null
git -C $w fetch -q --filter=blob:none "https://github.com/fin-tcm/$Live.git" '+refs/heads/*:refs/live/heads/*' '+refs/tags/*:refs/live/tags/*' 2>$null
$rows = foreach ($l in (git -C $w for-each-ref --format='%(refname) %(objectname)' refs/live/)) {
  $ref, $sha = $l -split ' '
  $n = [int](git -C $w rev-list --count $sha --not --glob=refs/copy/ 2>$null)
  if ($n -gt 0) {
    $last = git -C $w log -1 --format='%cI %an: %s' $sha
    [pscustomobject]@{ Ref = $ref -replace '^refs/live/', ''; OnlyInLive = $n; Tip = $sha.Substring(0, 10); Last = $last }
  }
}
$env:GIT_CONFIG_COUNT = '0'
$rows = @($rows)
"$Repo : live refs with commits not in the copy: $($rows.Count)"
$rows | Sort-Object Ref | Format-Table -AutoSize | Out-String -Width 250
$rows | Export-Csv "C:\kon-migration\swap\precheck\$Repo.csv" -NoTypeInformation -Encoding utf8
