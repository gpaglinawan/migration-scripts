# 16 Nov 2026 (DEF-286, CRITICAL): copy every Git LFS object referenced by any branch/tag of tcm-pilot/<Repo> from tcm-pilot/<From>
# (e.g. ARC-almonde-old, archived - read only) into tcm-pilot/<Repo>. Additive: uploads objects only, no git refs change.
# Then checks every referenced object is downloadable from <Repo>.
param([Parameter(Mandatory)][string]$Repo, [Parameter(Mandatory)][string]$From, [string]$Work = "C:\kon-migration\lfs-fix\$Repo")
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $b64"
$log = "$Work.log"; function Write-Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $l; Add-Content $log $l -Encoding utf8 }
New-Item -ItemType Directory -Force $Work | Out-Null
$g = Join-Path $Work 'repo.git'
if (-not (Test-Path $g)) { git clone -q --mirror "https://github.com/tcm-pilot/$Repo.git" $g 2>&1 | Out-Null }
Write-Log "mirror of $Repo ready; fetching all LFS objects from $From ..."
git -C $g lfs fetch --all "https://github.com/tcm-pilot/$From.git" 2>&1 | Select-Object -Last 3 | ForEach-Object { Write-Log "  fetch: $_" }
$n = @(Get-ChildItem (Join-Path $g 'lfs\objects') -Recurse -File -EA SilentlyContinue).Count; Write-Log "  local LFS objects: $n"
Write-Log "pushing all LFS objects to $Repo ..."
git -C $g lfs push --all "https://github.com/tcm-pilot/$Repo.git" 2>&1 | Select-Object -Last 3 | ForEach-Object { Write-Log "  push: $_" }
# verify: every object referenced by any ref must be downloadable from $Repo
$oids = @(git -C $g lfs ls-files --all --long 2>$null | ForEach-Object { ($_ -split ' ')[0] } | Sort-Object -Unique)
$missing = 0; $checked = 0
for ($i = 0; $i -lt $oids.Count; $i += 100) {
  $chunk = $oids[$i..([Math]::Min($i + 99, $oids.Count - 1))]
  $sizes = @{}; foreach ($o in $chunk) { $f = Join-Path $g "lfs\objects\$($o.Substring(0,2))\$($o.Substring(2,2))\$o"; $sizes[$o] = if (Test-Path $f) { (Get-Item $f).Length } else { 0 } }
  $body = @{ operation = 'download'; transfers = @('basic'); objects = @($chunk | ForEach-Object { @{ oid = $_; size = $sizes[$_] } }) } | ConvertTo-Json -Depth 4
  $r = Invoke-RestMethod -Method Post "https://github.com/tcm-pilot/$Repo.git/info/lfs/objects/batch" -Headers @{ Authorization = "Basic $b64"; Accept = 'application/vnd.git-lfs+json' } -ContentType 'application/vnd.git-lfs+json' -Body $body
  $checked += $chunk.Count; $missing += @($r.objects | Where-Object { $_.error }).Count
}
$env:GIT_CONFIG_COUNT = '0'
Write-Log "=== verify: LFS objects referenced $($oids.Count), checked $checked, missing in $Repo $missing ==="
