# 20 Nov 2026 (Gareth: "ok"): for copies made with GitHub's direct importer (gh gei), which have no pr-preload run.log.
# Compares fin-tcm/<repo>-<Suffix> with fin-tcm-old/<repo> (PR counts by state, every branch/tag commit) and writes the result
# in the run.log format swap-checked.ps1 reads (C:\kon-migration\pr-preload\<copy>-<Stamp>\run.log). Read-only on GitHub.
param([Parameter(Mandatory)][string[]]$Repos, [string]$Suffix = 'geitest', [string]$Stamp = '20261120')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT|GH_SRC_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
function Get-PrCounts($org, $name, $tok) {
  $q = "{`"query`":`"{repository(owner:\`"$org\`",name:\`"$name\`"){o:pullRequests(states:OPEN){totalCount} m:pullRequests(states:MERGED){totalCount} c:pullRequests(states:CLOSED){totalCount}}}`"}"
  $d = (Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers @{ Authorization = "Bearer $tok" } -Body $q).data.repository; @($d.o.totalCount, $d.m.totalCount, $d.c.totalCount) }
function Get-Refs($url, $tok) {
  $env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'
  $env:GIT_CONFIG_VALUE_0 = 'AUTHORIZATION: basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$tok"))
  $h = @{}; git ls-remote $url 'refs/heads/*' 'refs/tags/*' 2>$null | ForEach-Object { $p = $_ -split "`t"; $h[$p[1]] = $p[0] }; $env:GIT_CONFIG_COUNT = '0'; $h }
foreach ($r in $Repos) {
  $copy = "$r-$Suffix"; $dir = "C:\kon-migration\pr-preload\$copy-$Stamp"; New-Item -ItemType Directory -Force $dir | Out-Null
  $s = Get-PrCounts 'fin-tcm-old' $r $env:GH_SRC_PAT; $c = Get-PrCounts 'fin-tcm' $copy $env:GH_TGT_PAT
  $fr = Get-Refs "https://github.com/fin-tcm-old/$r.git" $env:GH_SRC_PAT; $cr = Get-Refs "https://github.com/fin-tcm/$copy.git" $env:GH_TGT_PAT
  $missing = @($fr.Keys | Where-Object { -not $cr.ContainsKey($_) }).Count; $diff = @($fr.Keys | Where-Object { $cr.ContainsKey($_) -and $cr[$_] -ne $fr[$_] }).Count
  $now = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
  $lines = @("[$now] === $r -> fin-tcm/$copy (GitHub direct import, checked by direct-copy-check.ps1) ===",
    ("[$now]   {0,-45} open {1,5} merged {2,6} closed {3,6}" -f "fin-tcm-old/$r", $s[0], $s[1], $s[2]),
    ("[$now]   {0,-45} open {1,5} merged {2,6} closed {3,6}" -f "fin-tcm/$copy", $c[0], $c[1], $c[2]),
    "[$now]   refs: rewritten $($fr.Count), in target $($fr.Count - $missing), missing $missing, different $diff")
  if ($fr.Count) { $lines += "[$now] === stopped after cleanup as asked ===" }
  Set-Content "$dir\run.log" $lines -Encoding utf8
  "$r : PRs Finastra $($s -join '/') copy $($c -join '/'); refs $($fr.Count), missing $missing, different $diff"
}
