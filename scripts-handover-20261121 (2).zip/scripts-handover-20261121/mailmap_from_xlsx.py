# 15 Nov 2026 - builds a git .mailmap (email-only: "<new> <old>") from Lukasz Garstecki's mapping workbook,
# sheet "Transformation list" (A = commit email in Finastra GitHub, B = Teciem e-mail). stdlib only.
# Usage: mailmap_from_xlsx.py <xlsx> <out mailmap>
import sys, zipfile, re, xml.etree.ElementTree as ET
ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main', 'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
z = zipfile.ZipFile(sys.argv[1])
ss = [''.join(t.text or '' for t in si.iter('{%s}t' % ns['m'])) for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si', ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
wb = ET.fromstring(z.read('xl/workbook.xml')); rels = {r.get('Id'): r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
sheet = next(s for s in wb.find('m:sheets', ns) if s.get('name') == 'Transformation list')
root = ET.fromstring(z.read('xl/' + rels[sheet.get('{%s}id' % ns['r'])].lstrip('/').replace('xl/', '')))
def val(c):
    v = c.find('m:v', ns); t = c.get('t')
    if t == 's' and v is not None: return ss[int(v.text)]
    if t == 'inlineStr': return ''.join(x.text or '' for x in c.iter('{%s}t' % ns['m']))
    return v.text if v is not None else ''
EMAIL = re.compile(r'^[^\s<>@]+@[^\s<>@]+$')
pairs, bad, seen = [], [], {}
for row in root.findall('.//m:sheetData/m:row', ns)[1:]:
    cells = {re.match(r'[A-Z]+', c.get('r')).group(0): val(c).strip() for c in row.findall('m:c', ns)}
    old, new = cells.get('A', ''), cells.get('B', '')
    if not old and not new: continue
    if not (EMAIL.match(old) and EMAIL.match(new)): bad.append((row.get('r'), old, new)); continue
    k = old.lower()
    if k in seen and seen[k] != new.lower(): bad.append((row.get('r'), old, f'{new} (conflicts with {seen[k]})')); continue
    if k in seen: continue
    seen[k] = new.lower(); pairs.append((old, new))
with open(sys.argv[2], 'w', encoding='utf-8', newline='\n') as f:
    for old, new in pairs: f.write(f'<{new}> <{old}>\n')
print(f'mappings: {len(pairs)}  skipped: {len(bad)}  distinct new emails: {len(set(n.lower() for _, n in pairs))}')
for b in bad[:20]: print('  skipped row', b)
