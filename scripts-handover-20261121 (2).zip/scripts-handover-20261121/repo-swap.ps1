﻿# GIT-019D / GIT-020D (written 14 Nov 2026 overnight; approved by Gareth to write + rehearse in tcm-pilot-test ONLY -
# a run against fin-tcm needs his explicit go). Swaps a rebuilt copy into place:
#   <repo>  -> <repo>-old  (kept, archived at the end)        <repo>-<Suffix> -> <repo>
# and copies onto the new <repo> what the import cannot bring: repo settings, topics, custom properties, teams,
# direct collaborators, branch protection rules (GraphQL, by pattern), repository rulesets, webhooks, autolinks,
# deploy keys, Actions permissions / variables, environments (+ their variables and branch policies), security settings.
# Secret VALUES cannot be read anywhere (Actions, Dependabot, environment secrets, webhook secrets): their NAMES are
# listed in <Out>\<repo>\owner-actions.csv for the owner to re-enter.
# Migration-only changes are NOT copied: rulesets are taken from the pre-bypass backup (rules\bypass-backup) when one
# exists, and "include administrators" is copied as it was before the sync bypass (rules\classic-bypass-branches.csv).
# Everything read from the old repo is saved to <Out>\<repo>\before.json first. Dry run unless -Apply.
# -Rollback puts the names back (<repo> -> <repo>-<Suffix>, <repo>-old -> <repo>, old unarchived).
# Usage: .\repo-swap.ps1 -Org tcm-pilot-test -Repos swaptest-a -Suffix ri            (dry run)
#        .\repo-swap.ps1 -Org tcm-pilot-test -Repos swaptest-a -Suffix ri -Apply
#        .\repo-swap.ps1 -Org tcm-pilot-test -Repos swaptest-a -Suffix ri -Rollback -Apply
param([Parameter(Mandatory)][string]$Org, [Parameter(Mandatory)][string[]]$Repos, [Parameter(Mandatory)][string]$Suffix,
      [switch]$Apply, [switch]$Rollback, [switch]$NoArchive, [string]$OldSuffix = 'old',   # 15 Nov: 'old2' when <repo>-old is already taken by an earlier swap
      [string]$Out = "C:\kon-migration\swap\$(Get-Date -Format yyyyMMdd-HHmm)",
      # 16 Nov: finish a swap whose renames are already done - reload <ResumeFrom>\<repo>\before.json and apply steps 3+ only
      [string]$ResumeFrom)
$ErrorActionPreference = 'Stop'
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$gh = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json'; 'X-GitHub-Api-Version' = '2022-11-28' }
$api = 'https://api.github.com'
New-Item -ItemType Directory -Force $Out | Out-Null
$logFile = Join-Path $Out 'swap.log'
function Write-SwapLog($m) { $l = "[{0:HH:mm:ss}] {1}{2}" -f (Get-Date), $(if ($Apply) { '' } else { 'DRY ' }), $m; Write-Output $l; Add-Content $logFile $l -Encoding utf8 }
function Get-Api($path) { Invoke-RestMethod "$api$path" -Headers $gh }
function Get-All($path) { $res = @(); $p = 1; do { $sep = if ($path -match '\?') { '&' } else { '?' }; $page = @(Invoke-RestMethod "$api$path$($sep)per_page=100&page=$p" -Headers $gh | ForEach-Object { $_ }); $res += $page; $p++ } while ($page.Count -eq 100); $res }
function Get-Try($path) { try { Get-Api $path } catch { $null } }
function Send-Api($method, $path, $body) {
  if (-not $Apply) { return $null }
  $json = if ($null -ne $body) { $body | ConvertTo-Json -Depth 12 } else { $null }
  if ($json) { Invoke-RestMethod -Method $method "$api$path" -Headers $gh -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json)) }
  else { Invoke-RestMethod -Method $method "$api$path" -Headers $gh }
}
function Invoke-Gql($q, $vars) { $r = Invoke-RestMethod -Method Post "$api/graphql" -Headers $gh -ContentType 'application/json' -Body (@{ query = $q; variables = $vars } | ConvertTo-Json -Depth 12); if ($r.errors) { throw ($r.errors | ConvertTo-Json -Compress -Depth 5) }; $r.data }
$classicBypass = @(); if (Test-Path C:\kon-migration\rules\classic-bypass-branches.csv) { $classicBypass = @(Import-Csv C:\kon-migration\rules\classic-bypass-branches.csv) }

foreach ($repo in $Repos) {
  $copy = "$repo-$Suffix"; $old = "$repo-$OldSuffix"; $dir = Join-Path $Out $repo; New-Item -ItemType Directory -Force $dir | Out-Null
  $actions = New-Object System.Collections.ArrayList
  function Add-OwnerAction($what, $name, $note) { [void]$actions.Add([pscustomobject]@{ Repo = $repo; What = $what; Name = $name; Note = $note }) }
  $step = { param($label, [scriptblock]$do) try { & $do; Write-SwapLog "  ok   $label" } catch { Write-SwapLog "  FAIL $label : $($_.Exception.Message) $($_.ErrorDetails.Message)" } }

  if ($Rollback) {
    Write-SwapLog "=== ROLLBACK $Org/$repo ($repo -> $copy, $old -> $repo)"
    if (-not (Get-Try "/repos/$Org/$old")) { Write-SwapLog "  STOP: $old not found"; continue }
    & $step "unarchive $old" { Send-Api PATCH "/repos/$Org/$old" @{ archived = $false } | Out-Null }
    & $step "rename $repo -> $copy" { Send-Api PATCH "/repos/$Org/$repo" @{ name = $copy } | Out-Null }
    & $step "rename $old -> $repo" { Send-Api PATCH "/repos/$Org/$old" @{ name = $repo } | Out-Null }
    continue
  }

  # bpq for resume
  $bpq = 'query($o:String!,$n:String!){ repository(owner:$o,name:$n){ id branchProtectionRules(first:100){ nodes { pattern requiresApprovingReviews requiredApprovingReviewCount dismissesStaleReviews requiresCodeOwnerReviews requireLastPushApproval requiresStatusChecks requiresStrictStatusChecks requiredStatusCheckContexts isAdminEnforced requiresLinearHistory allowsForcePushes allowsDeletions requiresConversationResolution requiresCommitSignatures restrictsPushes restrictsReviewDismissals blocksCreations lockBranch lockAllowsFetchAndMerge requiresDeployments requiredDeploymentEnvironments
      pushAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } }
      reviewDismissalAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } }
      bypassPullRequestAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } }
      bypassForcePushAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } } } } } }'
  if ($ResumeFrom) {
    Write-SwapLog "=== RESUME $Org/$repo (settings from $ResumeFrom\$repo\before.json; renames already done)"
    if (-not (Get-Try "/repos/$Org/$old") -or -not (Get-Try "/repos/$Org/$repo")) { Write-SwapLog "  STOP: $repo or $old not found"; continue }
    $b = Get-Content (Join-Path $ResumeFrom "$repo\before.json") -Raw | ConvertFrom-Json; Copy-Item (Join-Path $ResumeFrom "$repo\before.json") $dir -Force
    $t = $repo
  } else {
  Write-SwapLog "=== SWAP $Org/$copy -> $repo (old -> $old)"
  $o = Get-Try "/repos/$Org/$repo"; $c = Get-Try "/repos/$Org/$copy"
  if (-not $o) { Write-SwapLog "  STOP: $repo not found"; continue }
  if (-not $c) { Write-SwapLog "  STOP: $copy not found"; continue }
  if ($o.name -ne $repo) { Write-SwapLog "  STOP: $repo redirects to $($o.name) (already swapped?)"; continue }
  if (Get-Try "/repos/$Org/$old") { Write-SwapLog "  STOP: $old already exists"; continue }

  # ---- 1. read everything from the old repo (saved before any change)
  $b = [ordered]@{ repo = $o }
  $b.topics = (Get-Try "/repos/$Org/$repo/topics").names
  $b.properties = @(Get-Try "/repos/$Org/$repo/properties/values")
  $b.teams = @(Get-All "/repos/$Org/$repo/teams")
  $b.collaborators = @(Get-All "/repos/$Org/$repo/collaborators?affiliation=direct")
  $b.invitations = @(Get-All "/repos/$Org/$repo/invitations")
  $b.hooks = @(Get-All "/repos/$Org/$repo/hooks")
  $b.autolinks = @(Get-All "/repos/$Org/$repo/autolinks")
  $b.keys = @(Get-All "/repos/$Org/$repo/keys")
  $b.rulesets = @(Get-All "/repos/$Org/$repo/rulesets?includes_parents=false" | ForEach-Object { Get-Api "/repos/$Org/$repo/rulesets/$($_.id)" })
  $b.actionsPermissions = Get-Try "/repos/$Org/$repo/actions/permissions"
  $b.actionsSelected = if ($b.actionsPermissions.allowed_actions -eq 'selected') { Get-Try "/repos/$Org/$repo/actions/permissions/selected-actions" } else { $null }
  $b.actionsWorkflow = Get-Try "/repos/$Org/$repo/actions/permissions/workflow"
  $b.variables = @((Get-Try "/repos/$Org/$repo/actions/variables?per_page=100").variables)
  $b.secrets = @((Get-Try "/repos/$Org/$repo/actions/secrets?per_page=100").secrets)
  $b.dependabotSecrets = @((Get-Try "/repos/$Org/$repo/dependabot/secrets?per_page=100").secrets)
  $b.environments = @(@((Get-Try "/repos/$Org/$repo/environments?per_page=100").environments) | Where-Object { $_ } | ForEach-Object {
    $e = [uri]::EscapeDataString($_.name)
    [pscustomobject]@{ env = $_; variables = @((Get-Try "/repos/$Org/$repo/environments/$e/variables?per_page=100").variables); secrets = @((Get-Try "/repos/$Org/$repo/environments/$e/secrets?per_page=100").secrets)
                       branchPolicies = @(@((Get-Try "/repos/$Org/$repo/environments/$e/deployment-branch-policies?per_page=100").branch_policies) | Where-Object { $_ }) } })
  $b.vulnerabilityAlerts = [bool](try { Invoke-WebRequest -UseBasicParsing "$api/repos/$Org/$repo/vulnerability-alerts" -Headers $gh | Out-Null; $true } catch { $false })
  $b.codeScanningDefault = Get-Try "/repos/$Org/$repo/code-scanning/default-setup"
  $bpq = 'query($o:String!,$n:String!){ repository(owner:$o,name:$n){ id branchProtectionRules(first:100){ nodes { pattern requiresApprovingReviews requiredApprovingReviewCount dismissesStaleReviews requiresCodeOwnerReviews requireLastPushApproval requiresStatusChecks requiresStrictStatusChecks requiredStatusCheckContexts isAdminEnforced requiresLinearHistory allowsForcePushes allowsDeletions requiresConversationResolution requiresCommitSignatures restrictsPushes restrictsReviewDismissals blocksCreations lockBranch lockAllowsFetchAndMerge requiresDeployments requiredDeploymentEnvironments
      pushAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } }
      reviewDismissalAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } }
      bypassPullRequestAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } }
      bypassForcePushAllowances(first:100){ nodes { actor { __typename ... on User { id } ... on Team { id } ... on App { id } } } } } } } }'
  $b.branchProtection = @((Invoke-Gql $bpq @{ o = $Org; n = $repo }).repository.branchProtectionRules.nodes)
  $b | ConvertTo-Json -Depth 15 | Out-File (Join-Path $dir 'before.json') -Encoding utf8
  Write-SwapLog ("  read: teams {0}, collaborators {1}, branch rules {2}, rulesets {3}, webhooks {4}, autolinks {5}, keys {6}, variables {7}, secrets {8}, environments {9}" -f `
    $b.teams.Count, $b.collaborators.Count, $b.branchProtection.Count, $b.rulesets.Count, $b.hooks.Count, $b.autolinks.Count, $b.keys.Count, $b.variables.Count, $b.secrets.Count, $b.environments.Count)

  # ---- 2. renames (16 Nov: an archived copy cannot be renamed - unarchive it first, and stop before touching the
  #      live repo if that fails; if the second rename fails, put the live repo's name back at once)
  if ($Apply -and $c.archived) {
    try { Send-Api PATCH "/repos/$Org/$copy" @{ archived = $false } | Out-Null; Start-Sleep 5; Write-SwapLog "  ok   unarchive $copy" } catch { Write-SwapLog "  STOP: could not unarchive $copy - nothing renamed"; continue }
  }
  & $step "rename $repo -> $old" { Send-Api PATCH "/repos/$Org/$repo" @{ name = $old } | Out-Null }
  try { if ($Apply) { Send-Api PATCH "/repos/$Org/$copy" @{ name = $repo } | Out-Null }; Write-SwapLog "  ok   rename $copy -> $repo" }
  catch { Write-SwapLog "  FAIL rename $copy -> $repo : $($_.Exception.Message) - putting $old back to $repo"; try { Send-Api PATCH "/repos/$Org/$old" @{ name = $repo } | Out-Null; Write-SwapLog "  ok   restored $repo" } catch { Write-SwapLog "  FAIL restore: $($_.Exception.Message)" }; continue }
  $t = if ($Apply) { $repo } else { $copy }   # dry run reads the copy under its current name
  }

  # ---- 3. settings
  $keys = 'description','homepage','visibility','has_issues','has_projects','has_wiki','has_discussions','allow_squash_merge','allow_merge_commit','allow_rebase_merge',
          'allow_auto_merge','delete_branch_on_merge','allow_update_branch','squash_merge_commit_title','squash_merge_commit_message','merge_commit_title','merge_commit_message',
          'web_commit_signoff_required','is_template'   # allow_forking left out: orgs that forbid forking reject the whole PATCH
  $set = @{}; foreach ($k in $keys) { if ($null -ne $o.$k) { $set[$k] = $o.$k } }
  if ($o.visibility -eq 'public') { $set.visibility = 'private' }   # never make anything public
  & $step "settings ($($set.Count))" { Send-Api PATCH "/repos/$Org/$t" $set | Out-Null }
  & $step "default branch $($o.default_branch)" { Send-Api PATCH "/repos/$Org/$t" @{ default_branch = $o.default_branch } | Out-Null }
  if ($o.security_and_analysis) {
    $sa = @{}; foreach ($p in $o.security_and_analysis.PSObject.Properties) { if ($p.Value.status) { $sa[$p.Name] = @{ status = $p.Value.status } } }
    & $step "security settings" { Send-Api PATCH "/repos/$Org/$t" @{ security_and_analysis = $sa } | Out-Null } }
  if ($b.vulnerabilityAlerts) { & $step "Dependabot alerts on" { Send-Api PUT "/repos/$Org/$t/vulnerability-alerts" $null | Out-Null } }
  if ($b.topics) { & $step "topics ($($b.topics.Count))" { Send-Api PUT "/repos/$Org/$t/topics" @{ names = @($b.topics) } | Out-Null } }
  $props = @($b.properties | Where-Object { $null -ne $_.value })
  if ($props) { & $step "custom properties ($($props.Count))" { Send-Api PATCH "/repos/$Org/$t/properties/values" @{ properties = @($props | ForEach-Object { @{ property_name = $_.property_name; value = $_.value } }) } | Out-Null } }

  # ---- 4. access
  foreach ($tm in $b.teams) { $perm = if ($tm.role_name) { $tm.role_name } else { $tm.permission }
    & $step "team $($tm.slug): $perm" { Send-Api PUT "/orgs/$Org/teams/$($tm.slug)/repos/$Org/$t" @{ permission = $perm } | Out-Null } }
  foreach ($u in $b.collaborators) { $perm = if ($u.role_name) { $u.role_name } else { 'push' }
    & $step "collaborator $($u.login): $perm" { Send-Api PUT "/repos/$Org/$t/collaborators/$($u.login)" @{ permission = $perm } | Out-Null } }
  foreach ($i in $b.invitations) { Add-OwnerAction 'pending invitation' $i.invitee.login "re-invite ($($i.permissions))" }

  # ---- 5. branch protection rules (by pattern) and rulesets
  $existing = @()
  if ($Apply) { $existing = @((Invoke-Gql $bpq @{ o = $Org; n = $t }).repository.branchProtectionRules.nodes.pattern) }
  $newId = if ($Apply) { (Get-Api "/repos/$Org/$t").node_id } else { $c.node_id }
  foreach ($r in $b.branchProtection) {
    if ($r.pattern -in $existing) { Write-SwapLog "  skip branch rule '$($r.pattern)' (already on the copy)"; continue }
    $ids = { param($n) $l = New-Object System.Collections.Generic.List[string]; foreach ($x in @($n.nodes)) { if ($x.actor.id) { $l.Add([string]$x.actor.id) } }; ,$l.ToArray() }
    $admin = $r.isAdminEnforced; if ($classicBypass | Where-Object { $_.Repo -eq $repo -and $_.Branch -eq $r.pattern }) { $admin = $true }   # as before the sync bypass
    $in = @{ repositoryId = $newId; pattern = $r.pattern; requiresApprovingReviews = $r.requiresApprovingReviews; requiredApprovingReviewCount = $r.requiredApprovingReviewCount
             dismissesStaleReviews = $r.dismissesStaleReviews; requiresCodeOwnerReviews = $r.requiresCodeOwnerReviews; requireLastPushApproval = $r.requireLastPushApproval
             requiresStatusChecks = $r.requiresStatusChecks; requiresStrictStatusChecks = $r.requiresStrictStatusChecks; requiredStatusCheckContexts = @($r.requiredStatusCheckContexts)
             isAdminEnforced = $admin; requiresLinearHistory = $r.requiresLinearHistory; allowsForcePushes = $r.allowsForcePushes; allowsDeletions = $r.allowsDeletions
             requiresConversationResolution = $r.requiresConversationResolution; requiresCommitSignatures = $r.requiresCommitSignatures; restrictsPushes = $r.restrictsPushes
             restrictsReviewDismissals = $r.restrictsReviewDismissals; blocksCreations = $r.blocksCreations; lockBranch = $r.lockBranch; lockAllowsFetchAndMerge = $r.lockAllowsFetchAndMerge
             requiresDeployments = $r.requiresDeployments; requiredDeploymentEnvironments = @($r.requiredDeploymentEnvironments)
             pushActorIds = (& $ids $r.pushAllowances); reviewDismissalActorIds = (& $ids $r.reviewDismissalAllowances)
             bypassPullRequestActorIds = (& $ids $r.bypassPullRequestAllowances); bypassForcePushActorIds = (& $ids $r.bypassForcePushAllowances) }
    & $step "branch rule '$($r.pattern)'" { if ($Apply) { $null = Invoke-Gql 'mutation($i:CreateBranchProtectionRuleInput!){ createBranchProtectionRule(input:$i){ branchProtectionRule { id } } }' @{ i = $in } } } }
  foreach ($rs in $b.rulesets) {
    $bk = "C:\kon-migration\rules\bypass-backup\$repo-$($rs.id).json"
    $src = if (Test-Path $bk) { Get-Content $bk -Raw | ConvertFrom-Json } else { $rs }   # pre-migration-bypass definition
    $body = @{ name = $src.name; target = $src.target; enforcement = $src.enforcement; conditions = $src.conditions; rules = @($src.rules); bypass_actors = @($src.bypass_actors | Where-Object { $_ }) }
    & $step "ruleset '$($src.name)'$(if (Test-Path $bk) { ' (pre-bypass version)' })" { Send-Api POST "/repos/$Org/$t/rulesets" $body | Out-Null } }

  # ---- 6. integrations
  foreach ($h in $b.hooks) { $cfg = @{ url = $h.config.url; content_type = $h.config.content_type; insecure_ssl = $h.config.insecure_ssl }
    if ($h.config.secret) { Add-OwnerAction 'webhook secret' $h.config.url 're-enter the secret on the new webhook (copied without it)' }
    & $step "webhook $($h.config.url)" { Send-Api POST "/repos/$Org/$t/hooks" @{ name = 'web'; active = $h.active; events = @($h.events); config = $cfg } | Out-Null } }
  # 17 Nov: the import brings the source's autolinks (Finastra Jira); an existing prefix with another URL is replaced by the old repo's one
  $have = @{}; if ($Apply) { foreach ($x in @(Get-All "/repos/$Org/$t/autolinks")) { $have[$x.key_prefix] = $x } }
  foreach ($a in $b.autolinks) {
    $e = $have[$a.key_prefix]
    if ($e -and $e.url_template -eq $a.url_template) { Write-SwapLog "  skip autolink $($a.key_prefix) (already identical)"; continue }
    & $step "autolink $($a.key_prefix)$(if ($e) { ' (replacing ' + $e.url_template + ')' })" {
      if ($e) { Send-Api DELETE "/repos/$Org/$t/autolinks/$($e.id)" $null | Out-Null }
      Send-Api POST "/repos/$Org/$t/autolinks" @{ key_prefix = $a.key_prefix; url_template = $a.url_template; is_alphanumeric = $a.is_alphanumeric } | Out-Null } }
  foreach ($k in $b.keys) { & $step "deploy key $($k.title)" { Send-Api POST "/repos/$Org/$t/keys" @{ title = $k.title; key = $k.key; read_only = $k.read_only } | Out-Null } }

  # ---- 7. Actions
  if ($b.actionsPermissions) {
    $ap = @{ enabled = $b.actionsPermissions.enabled }; if ($b.actionsPermissions.allowed_actions) { $ap.allowed_actions = $b.actionsPermissions.allowed_actions }   # null when the org decides
    & $step "Actions permissions" { Send-Api PUT "/repos/$Org/$t/actions/permissions" $ap | Out-Null }
    if ($b.actionsSelected) { & $step "Actions selected list" { Send-Api PUT "/repos/$Org/$t/actions/permissions/selected-actions" $b.actionsSelected | Out-Null } }
    if ($b.actionsWorkflow) { & $step "workflow token permissions" { Send-Api PUT "/repos/$Org/$t/actions/permissions/workflow" @{ default_workflow_permissions = $b.actionsWorkflow.default_workflow_permissions; can_approve_pull_request_reviews = $b.actionsWorkflow.can_approve_pull_request_reviews } | Out-Null } } }
  $orgActions = Get-Try "/orgs/$Org/actions/permissions"
  if ($orgActions.enabled_repositories -eq 'selected') {
    $sel = @(Get-All "/orgs/$Org/actions/permissions/repositories" | ForEach-Object { $_.repositories } | Where-Object { $_ })
    if ($sel.name -contains $old -or ($sel.name -contains $repo -and -not $Apply)) { & $step "org Actions: add repo to selected list" { Send-Api PUT "/orgs/$Org/actions/permissions/repositories/$((Get-Api "/repos/$Org/$t").id)" $null | Out-Null } } }
  foreach ($v in $b.variables) { & $step "Actions variable $($v.name)" { Send-Api POST "/repos/$Org/$t/actions/variables" @{ name = $v.name; value = $v.value } | Out-Null } }
  foreach ($s in $b.secrets) { Add-OwnerAction 'Actions secret' $s.name 're-enter value' }
  foreach ($s in $b.dependabotSecrets) { Add-OwnerAction 'Dependabot secret' $s.name 're-enter value' }
  foreach ($e in $b.environments) {
    $en = [uri]::EscapeDataString($e.env.name)
    $rev = @($e.env.protection_rules | Where-Object type -eq 'required_reviewers' | ForEach-Object { $_.reviewers } | ForEach-Object { @{ type = $_.type; id = $_.reviewer.id } })
    $wt = ($e.env.protection_rules | Where-Object type -eq 'wait_timer' | Select-Object -First 1).wait_timer
    $psr = ($e.env.protection_rules | Where-Object type -eq 'required_reviewers' | Select-Object -First 1).prevent_self_review
    $body = @{ deployment_branch_policy = $e.env.deployment_branch_policy }; if ($rev) { $body.reviewers = $rev }; if ($wt) { $body.wait_timer = $wt }; if ($null -ne $psr) { $body.prevent_self_review = $psr }
    & $step "environment $($e.env.name)" { Send-Api PUT "/repos/$Org/$t/environments/$en" $body | Out-Null }
    foreach ($bp in $e.branchPolicies) { & $step "  branch policy $($bp.name)" { Send-Api POST "/repos/$Org/$t/environments/$en/deployment-branch-policies" @{ name = $bp.name; type = $(if ($bp.type) { $bp.type } else { 'branch' }) } | Out-Null } }
    foreach ($v in $e.variables) { & $step "  env variable $($v.name)" { Send-Api POST "/repos/$Org/$t/environments/$en/variables" @{ name = $v.name; value = $v.value } | Out-Null } }
    foreach ($s in $e.secrets) { Add-OwnerAction "environment secret ($($e.env.name))" $s.name 're-enter value' } }
  if ($b.codeScanningDefault.state -eq 'configured') { & $step "code scanning default setup" { Send-Api PATCH "/repos/$Org/$t/code-scanning/default-setup" @{ state = 'configured'; query_suite = $b.codeScanningDefault.query_suite } | Out-Null } }

  # ---- 8. archive the old repo, check
  if (-not $NoArchive) { & $step "archive $old" { Send-Api PATCH "/repos/$Org/$old" @{ archived = $true } | Out-Null } }
  if ($Apply) {
    $n = Get-Api "/repos/$Org/$repo"
    $prs = (Invoke-Gql 'query($o:String!,$n:String!){ repository(owner:$o,name:$n){ pullRequests { totalCount } } }' @{ o = $Org; n = $repo }).repository.pullRequests.totalCount
    Write-SwapLog ("  check: {0} -> id {1} (was copy id {2}), default {3}, PRs {4}, clone {5}" -f $repo, $n.id, $c.id, $n.default_branch, $prs, $n.clone_url) }
  $actions | Export-Csv (Join-Path $dir 'owner-actions.csv') -NoTypeInformation -Encoding utf8
  Write-SwapLog "  owner actions: $($actions.Count) (secrets / webhook secrets to re-enter) -> $dir\owner-actions.csv"
}
Write-SwapLog "=== done; log $logFile"
