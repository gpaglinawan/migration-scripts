﻿# 17 Nov 2026 (Gareth: option 1 - copy secrets for every swapped repo; shareable with Samar).
# Copies Actions secret VALUES (repo secrets + environment secrets) from one fin-tcm repo to another, e.g. from <repo>-old
# (the repository before a swap) to <repo>, or from <repo> to <repo>-pr2 BEFORE a swap. Values cannot be read through the API,
# so a one-time workflow in the SOURCE repo pipes each secret into `gh secret set` for the target. Values are never printed.
#   - the workflow lives alone on a temporary ORPHAN branch (the repo's own workflows are not in that commit, so they don't run)
#   - the target token is staged as a temporary secret in the source repo and deleted afterwards, with the branch
#   - an archived source is unarchived for the run and archived again afterwards
#   - environment secrets: one job per environment (environment must exist in the target; a job that waits for an approval
#     or is blocked by a deployment branch policy is reported, not forced)
#   - Dependabot secrets cannot be read by workflows: reported as owner action
# Dry run unless -Apply. Usage: .\secrets-transfer.ps1 -Pairs 'ARC-almonde-old=>ARC-almonde','idp-old=>idp' [-Apply]
# -Branch: temporary branch name; if a repo ruleset restricts branch names (e.g. FNX repos: feat|fix|chore/ABC-123/name), use a matching name such as 'chore/MIG-1/secrets-transfer'
param([Parameter(Mandatory)][string[]]$Pairs, [string]$Org = 'fin-tcm', [switch]$Apply, [int]$TimeoutMin = 20, [string]$Branch = 'migration-secrets-transfer')
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$hd = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$TokenSecret = 'MIGRATION_TARGET_TOKEN'
$out = 'C:\kon-migration\swap\secrets'; New-Item -ItemType Directory -Force $out | Out-Null
$log = Join-Path $out "secrets-transfer-$(Get-Date -Format yyyyMMdd).log"
function Write-Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $l; Add-Content $log $l -Encoding utf8 }
function Api($m, $u, $b) { if ($null -ne $b) { Invoke-RestMethod -Method $m -Uri "https://api.github.com$u" -Headers $hd -ContentType application/json -Body ($b | ConvertTo-Json -Depth 10 -Compress) } else { Invoke-RestMethod -Method $m -Uri "https://api.github.com$u" -Headers $hd } }
function Try-Api($m, $u, $b) { try { Api $m $u $b } catch { $null } }
foreach ($pair in $Pairs) {
  $src, $tgt = $pair -split '=>'; $src = $src.Trim(); $tgt = $tgt.Trim()
  Write-Log "=== $Org/$src -> $Org/$tgt $(if ($Apply) { '' } else { '(dry run)' })"
  $repoSec = @((Try-Api GET "/repos/$Org/$src/actions/secrets?per_page=100" $null).secrets | Where-Object { $_ -and $_.name -ne $TokenSecret }).name
  $envs = @((Try-Api GET "/repos/$Org/$src/environments?per_page=100" $null).environments | Where-Object { $_ })
  $envSec = @{}; foreach ($e in $envs) { $n = @((Try-Api GET "/repos/$Org/$src/environments/$([uri]::EscapeDataString($e.name))/secrets?per_page=100" $null).secrets | Where-Object { $_ }).name; if ($n) { $envSec[$e.name] = $n } }
  $dep = @((Try-Api GET "/repos/$Org/$src/dependabot/secrets?per_page=100" $null).secrets | Where-Object { $_ }).name
  $tgtEnvs = @((Try-Api GET "/repos/$Org/$tgt/environments?per_page=100" $null).environments | Where-Object { $_ }).name
  Write-Log "  repo secrets: $($repoSec.Count) [$($repoSec -join ', ')]; environment secrets: $(($envSec.GetEnumerator() | ForEach-Object { "$($_.Key):$($_.Value -join '/')" }) -join '; ')"
  if ($dep) { Write-Log "  OWNER ACTION: Dependabot secrets cannot be copied by a workflow - re-enter in $tgt : $($dep -join ', ')" }
  $missingEnv = @($envSec.Keys | Where-Object { $_ -notin $tgtEnvs }); if ($missingEnv) { Write-Log "  NOTE: environments missing in target (created now): $($missingEnv -join ', ')" }
  if (-not $repoSec.Count -and -not $envSec.Count) { Write-Log '  nothing to copy'; continue }
  if (-not $Apply) { continue }
  foreach ($e in $missingEnv) { $null = Api PUT "/repos/$Org/$tgt/environments/$([uri]::EscapeDataString($e))" @{} }
  $s = Api GET "/repos/$Org/$src" $null; $wasArchived = $s.archived
  if ($wasArchived) { $null = Api PATCH "/repos/$Org/$src" @{ archived = $false }; Start-Sleep 5; Write-Log "  unarchived $src for the run" }
  # repo-swap disables Actions on <repo>-old: enable for the run, restore the original setting afterwards
  $act = Api GET "/repos/$Org/$src/actions/permissions" $null
  if (-not $act.enabled) { $null = Api PUT "/repos/$Org/$src/actions/permissions" @{ enabled = $true; allowed_actions = 'all' }; Write-Log "  Actions enabled on $src for the run" }
  $started = (Get-Date).ToUniversalTime()
  try {
    $env:GH_TOKEN = $env:GH_TGT_PAT
    gh secret set $TokenSecret --repo "$Org/$src" --body $env:GH_TGT_PAT 2>&1 | Out-Null
    if ($LASTEXITCODE) { throw 'could not stage the token secret' }
    $jobs = New-Object System.Collections.ArrayList
    $copy = { param($names, $envFlag, $indent) $e = ($names | ForEach-Object { "$indent    S_$($_ -replace '[^A-Za-z0-9_]','_'): `${{ secrets.$_ }}" }) -join "`n"
      $loop = ($names | ForEach-Object { "$indent    if [ -n `"`${S_$($_ -replace '[^A-Za-z0-9_]','_'):-}`" ]; then printf '%s' `"`$S_$($_ -replace '[^A-Za-z0-9_]','_')`" | gh secret set '$_' --repo '$Org/$tgt'$envFlag; echo 'copied: $_'; else echo 'empty or unreadable: $_'; fi" }) -join "`n"
      "$indent  env:`n$indent    GH_TOKEN: `${{ secrets.$TokenSecret }}`n$e`n$indent  run: |`n$indent    set -uo pipefail`n$loop" }
    if ($repoSec.Count) { [void]$jobs.Add("  repo:`n    runs-on: ubuntu-latest`n    steps:`n      - name: repo secrets`n" + (& $copy $repoSec '' '      ')) }
    $i = 0; foreach ($k in $envSec.Keys) { $i++; [void]$jobs.Add("  env${i}:`n    runs-on: ubuntu-latest`n    environment: '$k'`n    steps:`n      - name: environment $k`n" + (& $copy $envSec[$k] " --env '$k'" '      ')) }
    $yml = "name: one-time migration secrets transfer`non: push`npermissions: {}`njobs:`n" + ($jobs -join "`n")
    $blob = Api POST "/repos/$Org/$src/git/blobs" @{ content = $yml; encoding = 'utf-8' }
    $tree = Api POST "/repos/$Org/$src/git/trees" @{ tree = @(@{ path = '.github/workflows/migration-secrets-transfer.yml'; mode = '100644'; type = 'blob'; sha = $blob.sha }) }
    $cm = Api POST "/repos/$Org/$src/git/commits" @{ message = "one-time secrets transfer to $tgt (temporary branch, deleted after the run)"; tree = $tree.sha; parents = @() }
    $null = Api POST "/repos/$Org/$src/git/refs" @{ ref = "refs/heads/$Branch"; sha = $cm.sha }
    Write-Log '  workflow started'
    $deadline = (Get-Date).AddMinutes($TimeoutMin); $run = $null
    while ((Get-Date) -lt $deadline) { Start-Sleep 15; $run = @((Try-Api GET "/repos/$Org/$src/actions/runs?branch=$([uri]::EscapeDataString($Branch))&per_page=5" $null).workflow_runs | Where-Object { $_ }) | Select-Object -First 1
      if ($run -and $run.status -eq 'completed') { break }
      if ($run -and $run.status -eq 'waiting') { Write-Log '  run is waiting for an environment approval - approve it in the source repo or cancel'; } }
    if (-not $run -or $run.status -ne 'completed') { Write-Log "  TIMEOUT: run not completed ($($run.status)) - $($run.html_url)" }
    else {
      $got = @((Try-Api GET "/repos/$Org/$tgt/actions/secrets?per_page=100" $null).secrets | Where-Object { $_ -and [datetime]$_.updated_at -ge $started.AddMinutes(-1) }).name
      $miss = @($repoSec | Where-Object { $_ -notin $got })
      $envRes = foreach ($k in $envSec.Keys) { $ge = @((Try-Api GET "/repos/$Org/$tgt/environments/$([uri]::EscapeDataString($k))/secrets?per_page=100" $null).secrets | Where-Object { $_ -and [datetime]$_.updated_at -ge $started.AddMinutes(-1) }).name; "${k}: $(@($envSec[$k] | Where-Object { $_ -in $ge }).Count)/$($envSec[$k].Count)" }
      Write-Log "  run $($run.conclusion): repo secrets copied $($repoSec.Count - $miss.Count)/$($repoSec.Count)$(if ($miss) { ' MISSING: ' + ($miss -join ',') }); environments: $($envRes -join '; ')"
    }
  } catch { Write-Log "  FAILED: $($_.Exception.Message) $($_.ErrorDetails.Message)" }
  finally {
    $env:GH_TOKEN = $env:GH_TGT_PAT
    gh secret delete $TokenSecret --repo "$Org/$src" 2>&1 | Out-Null
    $null = Try-Api DELETE "/repos/$Org/$src/git/refs/heads/$Branch" $null
    Remove-Item Env:GH_TOKEN -EA SilentlyContinue
    if (-not $act.enabled) { $null = Try-Api PUT "/repos/$Org/$src/actions/permissions" @{ enabled = $false }; Write-Log "  Actions disabled again on $src" }
    if ($wasArchived) { Start-Sleep 3; $null = Try-Api PATCH "/repos/$Org/$src" @{ archived = $true }; Write-Log "  re-archived $src" }
    Write-Log '  cleanup: token secret deleted, temporary branch removed'
  }
}
