﻿# Fixes ref names after git-filter-repo on Windows (case-insensitive filesystem merged/renamed some branches, and
# refs/remotes/origin/* were turned into branches). Rebuilds the ref list from the ORIGINAL export, case-exact:
#   every original ref whose commit is in the commit-map -> its new commit; refs not in the original are dropped.
# Writes everything into packed-refs (a single file, so case is kept) and removes loose ref files. Backup first.
import sys, os, subprocess, shutil, time
orig, new, cmap_path = sys.argv[1], sys.argv[2], sys.argv[3]
def git(g, *a, inp=None):
    return subprocess.run(['git', '-C', g, *a], input=inp, capture_output=True, text=True, encoding='utf-8', check=True).stdout
cmap = {}
with open(cmap_path, encoding='ascii') as f:
    next(f)
    for l in f:
        a, b = l.split(); cmap[a] = b
git(new, 'pack-refs', '--all', '--prune')
pr = os.path.join(new, 'packed-refs')
shutil.copy2(pr, pr + '.bak-' + time.strftime('%Y%m%d-%H%M%S'))
# current rewritten refs (case as stored in packed-refs), with tag objects
cur = {}
for l in git(new, 'for-each-ref', '--format=%(refname)%09%(objectname)%09%(objecttype)%09%(*objectname)').splitlines():
    name, obj, typ, peeled = l.split('\t'); cur[name] = (obj, typ, peeled)
out = {}; kept = fixed = dropped = 0; skipped = []
for l in git(orig, 'for-each-ref', '--format=%(refname)%09%(objectname)%09%(objecttype)').splitlines():
    name, obj, typ = l.split('\t')
    if typ == 'commit':
        if obj in cmap:
            out[name] = (cmap[obj], None)
            if name in cur and cur[name][0] == cmap[obj]: kept += 1
            else: fixed += 1
        elif name in cur:
            out[name] = (cur[name][0], cur[name][2] or None); kept += 1      # e.g. notes/svn map, kept as rewritten
        else:
            skipped.append(name)
    else:                                                                    # annotated tags: keep the rewritten tag object
        if name in cur:
            out[name] = (cur[name][0], cur[name][2] or None); kept += 1
        else:
            skipped.append(name)
dropped = len([n for n in cur if n not in out])
lines = ['# pack-refs with: peeled fully-peeled sorted \n']
for name in sorted(out, key=lambda s: s.encode()):
    sha, peeled = out[name]
    lines.append(f'{sha} {name}\n')
    if peeled: lines.append(f'^{peeled}\n')
with open(pr, 'w', encoding='utf-8', newline='\n') as f: f.writelines(lines)
# no loose refs may remain (they would override packed entries, possibly with the wrong case)
loose = [os.path.join(r, x) for r, _, fs in os.walk(os.path.join(new, 'refs')) for x in fs]
print(f'refs written {len(out)}: unchanged {kept}, fixed {fixed}; dropped {dropped} not in original; '
      f'not recreated {len(skipped)}; loose ref files left {len(loose)}')
for s in skipped: print('  not recreated (commits never rewritten):', s)
