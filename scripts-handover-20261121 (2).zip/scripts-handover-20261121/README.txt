﻿Migration scripts - current versions (21 Nov 2026). Org names: Teciem = fin-tcm, Finastra = fin-tcm-old.
Tokens are read from C:\development\pats.txt (GH_TGT_PAT, GH_SRC_PAT, AZDO_PAT, AZDO_SOURCE_PAT). Python: C:\kon-migration\tools\python\python.exe -I
The pr-preload helper .py files must sit next to pr-preload.ps1 (C:\kon-migration\scripts\pr-preload\).

RE-IMPORT + SWAP (fix PR authors / ghost):
 1 pr-preload.ps1 -Repo <repo> -TargetName <repo>-pr5 -KeepCommitIds -Work C:\kon-migration\pr-preload\<repo>-pr5-<yyyyMMdd>
     if GitHub's import fails ("Clone Source"): gh gei migrate-repo ... --target-repo <repo>-geitest, then direct-copy-check.ps1 -Repos <repo> -Suffix geitest
 2 secrets-transfer.ps1 -Pairs '<repo>=><repo>-pr5' [-Apply]   (FNX repos: -Branch 'chore/MIG-1/secrets-transfer'; copy must be unarchived)
 3 swap-checked.ps1 -Repos <repo> -Suffix pr5 -Stamp <yyyyMMdd>   (checks, repo-swap.ps1 -Apply, carry-over; options -WaivePrCount -AllowLiveOnlyPrs -AllowLfsMissing)
 4 verify-swap.ps1 -Repos <repo>   -> C:\kon-migration\swap\verify\<repo>.txt

OTHER:
 code-scanning-copy-from-old.ps1 + sarif-retool.py  CodeQL results from <repo>-old as "CodeQL (Finastra history)" (-DefaultBranchOnly; steps upload, states)
 pr-map-repo.py <repo> <out.csv>                     PR number map Teciem <-> Finastra
 sha-compare-orgs.py <out.csv>                       default-branch commit comparison for all repos
 project-items-restore.py <src#> <tgt#> [--apply]   re-add PRs to an org project after re-imports
 copilot-budget-report.ps1                           Copilot per-user budget CSV (read-only)
 ado-history-archive.py <project> [--apply]          ADO work item history attachments + PR wiki pages
 ado-wiki-archive-pr.ps1 -Project <p> [-Apply]       same pages via a wiki PR when the wiki needs PRs
 ado-pr-link-fix.ps1 [-Apply]                        repoint recreated ADO PR links to TreasuryCapitalMarkets-finastra
