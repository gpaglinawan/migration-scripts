# Adds back the reviews GitHub's export drops ("Body required for pull request reviews that are comments or requesting
# changes"): "changes requested" reviews with no text. The importer needs a body, so each gets a short placeholder.
# Generalised from kplus-front-pr-remap/add_missing_reviews.py: works for any repo, fetches the review list of every PR
# in the export (Finastra REST, GET only). Writes ONE new pull_request_reviews_NNNNNN.json (next free number) into the
# remapped export dir and missing-reviews.csv next to it; existing export files are never changed. Re-runnable: the
# name of its own file is kept in added-reviews-file.txt and that file is replaced.
# Usage: python -I add_missing_reviews.py <export-remapped dir> <commit-map> <owner/repo>
import json, glob, os, sys, csv, time, re, urllib.request, urllib.error, collections
from concurrent.futures import ThreadPoolExecutor
sys.stdout.reconfigure(encoding='utf-8')
exp, cmap_path, REPO = sys.argv[1], sys.argv[2], sys.argv[3]
BODY = '_Changes requested (no comment text in Finastra; placeholder added during migration)._'
TOKEN = os.environ['GH_SRC_PAT']
marker = os.path.join(os.path.dirname(exp), 'added-reviews-file.txt')
own = None
if os.path.exists(marker):
    with open(marker, encoding='utf-8') as f: own = os.path.join(exp, f.read().strip())
def numbered():
    return sorted(f for f in glob.glob(os.path.join(exp, 'pull_request_reviews_*.json')) if f != own)
if own is None:
    nums = [int(re.search(r'_(\d+)\.json$', f).group(1)) for f in numbered()]
    own = os.path.join(exp, 'pull_request_reviews_%06d.json' % ((max(nums) if nums else 0) + 1))
def load(files):
    for f in files:
        with open(f, encoding='utf-8') as fh: yield from json.load(fh)
rid = lambda u: int(u.rsplit('-', 1)[1])
have = {rid(r['url']) for r in load(numbered())}
prs = {int(p['url'].rsplit('/', 1)[1]): p for p in load(sorted(glob.glob(os.path.join(exp, 'pull_requests_*.json'))))}
print(f'export: {len(have)} reviews, {len(prs)} PRs; own file {os.path.basename(own)}', flush=True)
cmap = {}
with open(cmap_path, encoding='ascii') as f:
    next(f)
    for line in f:
        o, n = line.split(); cmap[o] = n

def get(url):
    for attempt in range(8):
        req = urllib.request.Request(url, headers={'Authorization': f'Bearer {TOKEN}', 'Accept': 'application/vnd.github+json'})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r), r.headers.get('Link', '')
        except urllib.error.HTTPError as e:
            if e.code == 404: return None, ''
            if e.code in (403, 429) and (e.headers.get('X-RateLimit-Remaining') == '0' or e.headers.get('Retry-After')):
                wait = int(e.headers.get('Retry-After') or max(5, int(e.headers.get('X-RateLimit-Reset', time.time() + 60)) - int(time.time()) + 5))
                print(f'  rate limit: waiting {wait}s', flush=True); time.sleep(wait); continue
            time.sleep(5 * (attempt + 1))
        except Exception:
            time.sleep(5 * (attempt + 1))
    raise RuntimeError('failed: ' + url)
def reviews(n):
    out, url = [], f'https://api.github.com/repos/{REPO}/pulls/{n}/reviews?per_page=100'
    while url:
        page, link = get(url)
        if page is None: return n, None
        out += page; url = None
        for part in link.split(','):
            if 'rel="next"' in part: url = part[part.find('<') + 1:part.find('>')]
    return n, out

found, failed, done = {}, [], 0
# 14 Nov 2026 (cutover): read the reviews through GraphQL, 100 PRs per call, instead of one REST call per PR (the
# re-imports were stalled on the shared 5,000/h REST limit). Checked against the REST result of 8 Nov for
# FCGC-pricing-analytics: 1108/1108 reviews and authors identical. The REST path stays as fallback (MR_USE_REST=1).
if os.environ.get('MR_USE_REST') == '1':
    with ThreadPoolExecutor(4) as ex:
        allrv = dict(ex.map(reviews, sorted(prs)))
else:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from gql_changes_requested import changes_requested
    allrv = changes_requested(TOKEN, REPO)
for n in sorted(prs):
    rv = allrv.get(n)
    if rv is None: failed.append(n); continue
    for r in rv:
        if r['id'] not in have and r['state'] == 'CHANGES_REQUESTED' and not (r.get('body') or '').strip():
            found[r['id']] = (n, r)
recs, rows, stats = [], [], collections.Counter()
for i in sorted(found):
    n, r = found[i]; login = (r.get('user') or {}).get('login') or 'ghost'
    sha, at = r.get('commit_id'), r.get('submitted_at')
    new = cmap.get(sha) if sha else None
    if new: sha = new; stats['commit: remapped'] += 1
    else:
        # the reviewed commit is gone (force-pushed away) or unknown: the importer rejects a review on a missing commit,
        # so attach it to the PR's head commit (already remapped in this export)
        sha = prs[n]['head']['sha']; stats['commit: PR head (reviewed commit gone)'] += 1
    pr_url = f'https://github.com/{REPO}/pull/{n}'
    recs.append({'type': 'pull_request_review', 'url': f'{pr_url}/files#pullrequestreview-{i}', 'pull_request': pr_url,
                 'user': f'https://github.com/{login}', 'body': BODY, 'head_sha': sha, 'formatter': 'markdown',
                 'state': 30, 'reactions': [], 'created_at': at, 'submitted_at': at})
    rows.append([n, i, login, at, sha])
if recs:
    with open(own, 'w', encoding='utf-8') as f: json.dump(recs, f)
    with open(marker, 'w', encoding='utf-8') as f: f.write(os.path.basename(own))
elif os.path.exists(own): os.remove(own)
with open(os.path.join(os.path.dirname(exp), 'missing-reviews.csv'), 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f); w.writerow(['pr', 'review_id', 'user', 'submitted_at', 'head_sha_new']); w.writerows(rows)
print(f'added {len(recs)} reviews')
for k, v in sorted(stats.items()): print(f'  {k}: {v}')
print(f'PRs that could not be fetched: {len(failed)} {failed[:20]}')
