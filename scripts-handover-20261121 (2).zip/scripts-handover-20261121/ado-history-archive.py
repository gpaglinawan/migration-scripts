# DEF-125/127/134 (Gareth 18 Nov: "Fix DEF-125 and 127"). Read-only archive of Finastra ADO history in the Teciem org:
#   work items: each migrated work item gets an attached HTML file with its full Finastra revision history (fields, comments)
#   pull requests: one wiki page per repository with every Finastra PR (status, author, dates, reviewers + votes, discussion,
#                  linked work items); each Teciem work item that had PR links gets a hyperlink to its PRs on that page
# Source TreasuryCapitalMarkets-finastra (AZDO_SOURCE_PAT, read-only), target TreasuryCapitalMarkets (AZDO_PAT).
# Usage: ado-history-archive.py <project> [--apply]      (without --apply: builds every file locally and prints the plan)
import base64, html, json, os, re, sys, urllib.parse, urllib.request, collections
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
proj = sys.argv[1]; APPLY = '--apply' in sys.argv
SRC, TGT = 'https://dev.azure.com/TreasuryCapitalMarkets-finastra', 'https://dev.azure.com/TreasuryCapitalMarkets'
tok = {}
for l in open(r'C:\development\pats.txt', encoding='utf-8-sig'):
    m = re.match(r'^\s*\$env:(AZDO_SOURCE_PAT|AZDO_PAT)\s*=\s*"?([^"\s]+)"?\s*$', l)
    if m: tok[m.group(1)] = m.group(2)
def hdr(k, ct='application/json'): return {'Authorization': 'Basic ' + base64.b64encode((':' + tok[k]).encode()).decode(), 'Content-Type': ct}
def call(url, k, m='GET', body=None, ct='application/json', raw=False):
    data = body if isinstance(body, (bytes, type(None))) else json.dumps(body).encode()
    r = urllib.request.urlopen(urllib.request.Request(url, data=data, method=m, headers=hdr(k, ct)), timeout=300)
    return r.read() if raw else json.loads(r.read() or b'null')
S = lambda u, **kw: call(SRC + u, 'AZDO_SOURCE_PAT', **kw)
T = lambda u, **kw: call(TGT + u, 'AZDO_PAT', **kw)
P = urllib.parse.quote(proj)
out = os.path.join(r'C:\kon-migration\ado-history-archive', proj); os.makedirs(out, exist_ok=True)
log = open(os.path.join(out, 'run.log'), 'a', encoding='utf-8')
def say(m): print(m); log.write(m + '\n'); log.flush()
esc = lambda x: html.escape(str(x if x is not None else ''))
def who(v): return v.get('displayName', '') if isinstance(v, dict) else (v or '')

# ---- work items: map Finastra -> Teciem by (type, title); duplicates paired in id order
def wis(fn, base):
    ids = [w['id'] for w in fn(f'/{P}/_apis/wit/wiql?api-version=7.1', m='POST', body={'query': f"Select [System.Id] From WorkItems Where [System.TeamProject] = '{proj}' Order By [System.Id]"})['workItems']]
    res = []
    for i in range(0, len(ids), 200):
        res += fn(f'/_apis/wit/workitems?ids={",".join(map(str, ids[i:i+200]))}&fields=System.Id,System.Title,System.WorkItemType,System.CreatedDate&api-version=7.1')['value']
    return res
sw, tw = wis(S, SRC), wis(T, TGT)
key = lambda w: (w['fields']['System.WorkItemType'], w['fields']['System.Title'].strip())
sg, tg = collections.defaultdict(list), collections.defaultdict(list)
for w in sw: sg[key(w)].append(w['id'])
for w in tw: tg[key(w)].append(w['id'])
pairs, unmatched = {}, []
for k, ss in sg.items():
    tt = tg.get(k, [])
    if len(tt) == len(ss): pairs.update(zip(sorted(ss), sorted(tt)))
    else: unmatched += [(k, ss, tt)]
say(f'== {proj}: work items Finastra {len(sw)}, Teciem {len(tw)}, matched {len(pairs)}, unmatched groups {len(unmatched)}')
for k, ss, tt in unmatched: say(f'   UNMATCHED {k[0]} "{k[1][:60]}": Finastra {ss} Teciem {tt}')
json.dump({str(a): b for a, b in pairs.items()}, open(os.path.join(out, 'workitem-map.json'), 'w'), indent=1)

SKIPF = {'System.Rev', 'System.AuthorizedDate', 'System.RevisedDate', 'System.Watermark', 'System.PersonId', 'System.AuthorizedAs', 'System.ChangedDate', 'System.ChangedBy'}
def wi_history(sid):
    ups = S(f'/_apis/wit/workitems/{sid}/updates?api-version=7.1')['value']
    rows = []
    for u in ups:
        ch = []
        for f, d in (u.get('fields') or {}).items():
            if f in SKIPF: continue
            o, n = d.get('oldValue'), d.get('newValue')
            if f == 'System.History': ch.append(('Comment', '', n)); continue
            ch.append((f.split('.')[-1], who(o) if isinstance(o, dict) else o, who(n) if isinstance(n, dict) else n))
        for rel in (u.get('relations') or {}).get('added', []) or []: ch.append(('Link added', '', f"{rel.get('rel')} {rel.get('url')}"))
        for rel in (u.get('relations') or {}).get('removed', []) or []: ch.append(('Link removed', f"{rel.get('rel')} {rel.get('url')}", ''))
        if ch: rows.append((u.get('rev'), (u.get('fields', {}).get('System.ChangedDate') or {}).get('newValue') or u.get('revisedDate', ''), who(u.get('revisedBy')), ch))
    cur = S(f'/_apis/wit/workitems/{sid}?api-version=7.1')
    h = [f'<html><head><meta charset="utf-8"><title>Finastra history of work item {sid}</title><style>body{{font-family:Segoe UI,Arial;font-size:13px}}td,th{{border:1px solid #ccc;padding:4px;vertical-align:top}}table{{border-collapse:collapse}}</style></head><body>',
         f'<h2>Finastra revision history - work item {sid}: {esc(cur["fields"]["System.Title"])}</h2>',
         f'<p>Read-only copy of the full history from Finastra Azure DevOps ({esc(SRC)}/{esc(proj)}, work item {sid}), {len(rows)} revisions with changes. Created {esc(cur["fields"].get("System.CreatedDate"))} by {esc(who(cur["fields"].get("System.CreatedBy")))}. Attached during the Teciem migration because Azure DevOps cannot import history.</p>',
         '<table><tr><th>Rev</th><th>Date (UTC)</th><th>Changed by</th><th>Field</th><th>Old value</th><th>New value</th></tr>']
    for rev, dt, by, ch in rows:
        for i, (f, o, n) in enumerate(ch):
            h.append(f'<tr>{"<td rowspan=%d>%s</td><td rowspan=%d>%s</td><td rowspan=%d>%s</td>" % (len(ch), esc(rev), len(ch), esc(dt), len(ch), esc(by)) if i == 0 else ""}<td>{esc(f)}</td><td>{o if f == "Comment" else esc(o)}</td><td>{n if f == "Comment" else esc(n)}</td></tr>')
    h.append('</table></body></html>')
    return '\n'.join(h), len(rows)

ATT_NAME = lambda sid: f'Finastra-history-workitem-{sid}.html'
done = att = 0
for sid, tid in sorted(pairs.items()):
    doc, n = wi_history(sid)
    fn = os.path.join(out, ATT_NAME(sid)); open(fn, 'w', encoding='utf-8').write(doc)
    if not APPLY: done += 1; continue
    tw_ = T(f'/_apis/wit/workitems/{tid}?$expand=relations&api-version=7.1')
    if any(r.get('rel') == 'AttachedFile' and (r.get('attributes') or {}).get('name') == ATT_NAME(sid) for r in tw_.get('relations') or []): done += 1; continue
    a = T(f'/{P}/_apis/wit/attachments?fileName={urllib.parse.quote(ATT_NAME(sid))}&api-version=7.1', m='POST', body=doc.encode('utf-8'), ct='application/octet-stream')
    T(f'/_apis/wit/workitems/{tid}?api-version=7.1', m='PATCH', ct='application/json-patch+json', body=[{'op': 'add', 'path': '/relations/-', 'value': {'rel': 'AttachedFile', 'url': a['url'], 'attributes': {'comment': f'Full revision history from Finastra (work item {sid}, {n} revisions) - read-only copy'}}}])
    done += 1; att += 1
say(f'work items: history files {done} ({"attached " + str(att) if APPLY else "dry run - local files only"}) in {out}')

# ---- pull requests: one wiki page per repository + hyperlinks on the linked work items
repos = S(f'/{P}/_apis/git/repositories?api-version=7.1')['value']
wiki = None
if APPLY:
    wk = [w for w in T(f'/{P}/_apis/wiki/wikis?api-version=7.1')['value'] if w['type'] == 'projectWiki']
    wiki = wk[0] if wk else T(f'/{P}/_apis/wiki/wikis?api-version=7.1', m='POST', body={'name': f'{proj}.wiki', 'projectId': T(f'/_apis/projects/{P}?api-version=7.1')['id'], 'type': 'projectWiki'})
wi_links = collections.defaultdict(list)
VOTE = {10: 'approved', 5: 'approved with suggestions', 0: 'no vote', -5: 'waiting for author', -10: 'rejected'}
total = 0
def repo_prs(rp):
    try: return repo_archive(rp)
    except urllib.error.HTTPError as e: say(f'   {rp["name"]}: SKIPPED - Finastra API {e.code}'); return 0
def repo_archive(rp):
    global total
    if rp.get('isDisabled'): return 0
    prs, skip = [], 0
    while True:
        b = S(f'/{P}/_apis/git/repositories/{rp["id"]}/pullrequests?searchCriteria.status=all&$top=200&$skip={skip}&api-version=7.1')['value']
        prs += b; skip += 200
        if len(b) < 200: break
    if not prs: return 0
    md = [f'# Finastra pull requests - {rp["name"]}', '',
          f'Read-only archive of all {len(prs)} pull requests of repository **{rp["name"]}** from Finastra Azure DevOps ({SRC}/{proj}). Azure DevOps cannot import pull requests, so they are kept here as written during the Teciem migration (18 Nov 2026). Code and merge commits are in the repository unchanged.', '']
    for pr in sorted(prs, key=lambda x: -x['pullRequestId']):
        n = pr['pullRequestId']
        th = S(f'/{P}/_apis/git/repositories/{rp["id"]}/pullRequests/{n}/threads?api-version=7.1')['value']
        wl = S(f'/{P}/_apis/git/repositories/{rp["id"]}/pullRequests/{n}/workitems?api-version=7.1')['value']
        md += [f'## !{n} {pr["title"]}', '',
               f'- **Status:** {pr["status"]}{" (merged " + pr.get("closedDate","")[:10] + ")" if pr["status"] == "completed" else ""}',
               f'- **Author:** {who(pr.get("createdBy"))} - created {pr.get("creationDate","")[:16].replace("T"," ")} UTC',
               f'- **Branches:** {pr.get("sourceRefName","").replace("refs/heads/","")} -> {pr.get("targetRefName","").replace("refs/heads/","")}',
               f'- **Reviewers:** ' + (', '.join(f'{r.get("displayName")} ({VOTE.get(r.get("vote"), r.get("vote"))})' for r in pr.get('reviewers', [])) or 'none'),
               f'- **Linked work items (Finastra ids):** ' + (', '.join(f'{w["id"]} (now {pairs.get(int(w["id"]), "?")})' for w in wl) or 'none')]
        if pr.get('description'): md += ['', '> ' + pr['description'].replace('\n', '\n> ')]
        cm = [(t, c) for t in th for c in t.get('comments', []) if c.get('commentType') == 'text' and c.get('content')]
        if cm:
            md += ['', '**Discussion:**', '']
            for t, c in cm:
                loc = (t.get('threadContext') or {}).get('filePath')
                md += [f'- {c.get("publishedDate","")[:16].replace("T"," ")} **{who(c.get("author"))}**{" on " + loc if loc else ""}: ' + c['content'].replace('\n', ' ')]
        md += ['']
        for w in wl: wi_links[pairs.get(int(w['id']))].append((rp['name'], n, pr['title']))
    page = f'/Migration archive/Finastra pull requests/{rp["name"]}'
    fn = os.path.join(out, f'PRs-{re.sub(r"[^A-Za-z0-9_.-]", "_", rp["name"])}.md'); open(fn, 'w', encoding='utf-8').write('\n'.join(md))
    total += len(prs)
    if APPLY:
        for part in ['/Migration archive', '/Migration archive/Finastra pull requests']:
            try: T(f'/{P}/_apis/wiki/wikis/{wiki["id"]}/pages?path={urllib.parse.quote(part)}&api-version=7.1', m='PUT', body={'content': '[[_TOSP_]]'})
            except urllib.error.HTTPError: pass
        try: T(f'/{P}/_apis/wiki/wikis/{wiki["id"]}/pages?path={urllib.parse.quote(page)}&api-version=7.1', m='PUT', body={'content': '\n'.join(md)})
        except urllib.error.HTTPError as e: say(f'   wiki page {rp["name"]}: {e.code} (exists already?) - not overwritten')
    say(f'   {rp["name"]}: {len(prs)} PRs -> {"wiki " + page if APPLY else fn}')
    return len(prs)
for rp in repos: repo_prs(rp)
say(f'pull requests: {total} archived; work items with PR links: {len([k for k in wi_links if k])}')
if APPLY and wiki:
    base = wiki['remoteUrl']
    for tid, lst in wi_links.items():
        if not tid: continue
        w = T(f'/_apis/wit/workitems/{tid}?$expand=relations&api-version=7.1')
        have = {r.get('url') for r in w.get('relations') or []}
        ops = []
        for repo, n, title in lst:
            url = f'{base}?pagePath={urllib.parse.quote("/Migration archive/Finastra pull requests/" + repo)}'
            if url in have: continue
            have.add(url); ops.append({'op': 'add', 'path': '/relations/-', 'value': {'rel': 'Hyperlink', 'url': url, 'attributes': {'comment': f'Finastra pull request !{n} ({repo}): {title[:120]} - archived'}}})
        if ops: T(f'/_apis/wit/workitems/{tid}?api-version=7.1', m='PATCH', ct='application/json-patch+json', body=ops)
    say('work item PR links added')
say('=== done ' + ('(APPLY)' if APPLY else '(dry run)'))
