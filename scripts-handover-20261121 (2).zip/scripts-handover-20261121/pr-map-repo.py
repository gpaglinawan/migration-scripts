﻿# Read-only: full PR mapping Teciem (fin-tcm, was tcm-pilot) <-> Finastra (fin-tcm-old) for one repo. Usage: pr-map-repo.py <repo> <out.csv>
# Imported PRs keep their number (checked by title); recreated PRs are mapped via recreated-pr-number-map.csv.
import json, sys, csv, re, urllib.request
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
repo, out = sys.argv[1], sys.argv[2]
tok = {}
for l in open(r'C:\development\pats.txt', encoding='utf-8-sig'):
    m = re.match(r'^\s*\$env:(GH_TGT_PAT|GH_SRC_PAT)\s*=\s*"?([^"\s]+)"?\s*$', l)
    if m: tok[m.group(1)] = m.group(2)
def prs(org, t):
    res, cur = {}, None
    while True:
        after = f',after:"{cur}"' if cur else ''
        q = '{repository(owner:"%s",name:"%s"){pullRequests(first:100%s){pageInfo{hasNextPage endCursor} nodes{number title state createdAt author{login}}}}}' % (org, repo, after)
        for attempt in range(5):
            r = urllib.request.Request('https://api.github.com/graphql', data=json.dumps({'query': q}).encode(), headers={'Authorization': 'Bearer ' + t})
            try: j = json.load(urllib.request.urlopen(r, timeout=120))
            except Exception as e: j = {'errors': [str(e)]}
            if j.get('data') and j['data'].get('repository'): break
            print(org, 'retry', attempt + 1, str(j.get('errors'))[:200]); import time; time.sleep(10 * (attempt + 1))
        else: raise SystemExit(f'{org}: GraphQL kept failing')
        d = j['data']['repository']['pullRequests']
        for n in d['nodes']: res[n['number']] = n
        if not d['pageInfo']['hasNextPage']: return res
        cur = d['pageInfo']['endCursor']
SRC, TGT = (sys.argv[3], sys.argv[4]) if len(sys.argv) > 4 else ('fin-tcm-old', 'fin-tcm')   # 18 Nov: orgs renamed (Finastra fin-tcm -> fin-tcm-old, Teciem tcm-pilot -> fin-tcm)
src = prs(SRC, tok['GH_SRC_PAT']); tgt = prs(TGT, tok['GH_TGT_PAT'])
rec = {}   # tcm-pilot number -> Finastra number
for r in csv.DictReader(open(r'C:\kon-migration\pr-gaps\recreated-pr-number-map.csv', encoding='utf-8-sig')):
    if r['Repo'] == repo: rec[int(r['tcm-pilot PR'])] = int(r['Finastra PR'])
rows, used = [], set()
for n, p in sorted(tgt.items()):
    if n in rec: f, how = rec[n], 'recreated (number changed)'
    elif n in src and src[n]['title'].strip() == p['title'].strip(): f, how = n, 'imported (same number)'
    elif n in src: f, how = n, 'imported (same number; title or state changed in Finastra after the import)'
    else: f, how = None, 'only in Teciem'
    s = src.get(f) if f else None
    if f: used.add(f)
    rows.append([n, f or '', how, p['state'], s['state'] if s else '', (p['author'] or {}).get('login', 'ghost'), (s['author'] or {}).get('login', 'ghost') if s else '',
                 p['title'], f'https://github.com/{TGT}/{repo}/pull/{n}', f'https://github.com/{SRC}/{repo}/pull/{f}' if f else ''])
for f, s in sorted(src.items()):
    if f not in used: rows.append(['', f, 'only in Finastra', '', s['state'], '', (s['author'] or {}).get('login', 'ghost'), s['title'], '', f'https://github.com/{SRC}/{repo}/pull/{f}'])
with open(out, 'w', newline='', encoding='utf-8-sig') as fh:
    w = csv.writer(fh); w.writerow(['Teciem PR', 'Finastra PR', 'How', 'Teciem state', 'Finastra state', 'Teciem author', 'Finastra author', 'Title', 'Teciem link', 'Finastra link']); w.writerows(rows)
from collections import Counter
print(f'{SRC} {len(src)} {TGT} {len(tgt)}', dict(Counter(r[2] for r in rows)))


