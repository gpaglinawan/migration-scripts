﻿# 16 Nov 2026 - check-then-swap for re-imported copies <repo>-pr2 (Gareth approved the swaps for tonight's re-imports).
# Per repo, STOPS (no swap) at the first failed check:
#   1 copy verified against fin-tcm-old (pr-preload run.log): PR totals equal (or copy >= live), refs: different 0, missing 0
#   2 LFS: every LFS object referenced by any ref of the copy is downloadable from the copy; if not, copy them in from the live
#     repo and re-check (DEF-286 lesson)
#   3 pre-check: live branches whose commits are not in the copy (carried over after the swap)
#   4 repo-swap.ps1 -Apply      5 carry over branches      6 verify: nothing left behind, teams + collaborators identical
param([Parameter(Mandatory)][string[]]$Repos, [string]$Suffix = 'pr2', [string]$Stamp = '20261116',
      [string[]]$WaivePrCount = @(),
      [string[]]$AllowLfsMissing = @(),   # 18 Nov (Gareth OK): KON-kplus-back - allowed only if every LFS object missing in the copy is also missing in the live repo
      [string[]]$AllowLiveOnlyPrs = @())   # 17 Nov (Gareth: "both Ok for two"): repos where PRs opened in fin-tcm (Thomas's test PRs, Matthieu's in KON-karma_webportal) may stay in -old   # 17 Nov (Gareth: go): SUM-summit - copy 3 short of fin-tcm-old (export gap, also absent in live); only a closed Dependabot PR stays in -old
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_TGT_PAT|GH_SRC_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT")); $t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }
$log = "C:\kon-migration\swap\swap-checked-$(Get-Date -Format yyyyMMdd).log"
function Write-Log($m) { $l = "[{0:HH:mm:ss}] {1}" -f (Get-Date), $m; $l; Add-Content $log $l -Encoding utf8; Add-Content C:\kon-migration\nightly\cutover-20261113.log ("$(Get-Date -Format 'yyyy-MM-dd HH:mm') swap-checked: $m") -Encoding utf8 }
function Get-LfsMissing($repo, $g) {
  $oids = @(git -C $g lfs ls-files --all --long 2>$null | ForEach-Object { ($_ -split ' ')[0] } | Sort-Object -Unique); $miss = @()
  for ($i = 0; $i -lt $oids.Count; $i += 100) {
    $chunk = $oids[$i..([Math]::Min($i + 99, $oids.Count - 1))]
    $body = @{ operation = 'download'; transfers = @('basic'); objects = @($chunk | ForEach-Object { @{ oid = $_; size = 1 } }) } | ConvertTo-Json -Depth 4
    $r = Invoke-RestMethod -Method Post "https://github.com/fin-tcm/$repo.git/info/lfs/objects/batch" -Headers @{ Authorization = "Basic $b64"; Accept = 'application/vnd.git-lfs+json' } -ContentType 'application/vnd.git-lfs+json' -Body $body
    $miss += @($r.objects | Where-Object { $_.error.message -match 'does not exist' } | ForEach-Object oid)
  }
  @{ Total = $oids.Count; Missing = $miss }
}
foreach ($repo in $Repos) {
  $copy = "$repo-$Suffix"; $run = "C:\kon-migration\pr-preload\$copy-$Stamp\run.log"
  $l = Get-Content $run -EA SilentlyContinue
  if (-not ($l -match '=== stopped after cleanup')) { Write-Log "$repo : copy not finished - skipped"; continue }
  $src = ($l | Select-String "(fin-tcm-old|fin-tcm)/$([regex]::Escape($repo))\s+open\s+(\d+)\s+merged\s+(\d+)\s+closed\s+(\d+)" | Select-Object -Last 1).Matches
  $dst = ($l | Select-String "(fin-tcm|tcm-pilot)/$([regex]::Escape($copy))\s+open\s+(\d+)\s+merged\s+(\d+)\s+closed\s+(\d+)" | Select-Object -Last 1).Matches
  $refs = ($l | Select-String 'refs: rewritten (\d+), in target (\d+), missing (\d+), different (\d+)' | Select-Object -Last 1).Matches
  if (-not $src -or -not $dst -or -not $refs) { Write-Log "$repo : verification lines missing in run.log - NOT swapped"; continue }
  $s = ($src[0].Groups[2..4] | ForEach-Object { [int]$_.Value } | Measure-Object -Sum).Sum; $d = ($dst[0].Groups[2..4] | ForEach-Object { [int]$_.Value } | Measure-Object -Sum).Sum
  $gql = "{`"query`":`"{repository(owner:\`"fin-tcm\`",name:\`"$repo\`"){pullRequests{totalCount}}}`"}"
  $live = (Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers $t -Body $gql).data.repository.pullRequests.totalCount
  if ([int]$refs[0].Groups[3].Value -or [int]$refs[0].Groups[4].Value) { Write-Log "$repo : refs missing/different in copy - NOT swapped"; continue }
  if ($d -lt $s -and $d -lt $live -and $repo -notin $WaivePrCount) { Write-Log "$repo : copy has $d PRs, fin-tcm-old $s, live $live - NOT swapped"; continue }
  # 17 Nov: PRs opened by people directly in fin-tcm (not bots) that the copy does not have would stay only in <repo>-old - stop for review
  $hum = & C:\kon-migration\tools\python\python.exe -I C:\kon-migration\scripts\live-only-prs.py --pre $repo $Suffix 2>&1 | Select-Object -Last 1
  if ($hum -notmatch '^HUMAN_ONLY=0') {
    if ($repo -in $AllowLiveOnlyPrs) { Write-Log "$repo : live repo has PRs by people that the copy lacks ($hum) - accepted (Gareth OK), they stay in $repo-old" }
    else { Write-Log "$repo : live repo has PRs by people that the copy lacks ($hum) - NOT swapped"; continue } }
  # LFS
  $g = "C:\kon-migration\swap\lfscheck\$repo.git"; Remove-Item $g -Recurse -Force -EA SilentlyContinue
  $env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $b64"; $env:GIT_LFS_SKIP_SMUDGE = '1'
  git clone -q --mirror "https://github.com/fin-tcm/$copy.git" $g 2>&1 | Out-Null
  $lf = Get-LfsMissing $copy $g
  if ($lf.Missing.Count) {
    Write-Log "$repo : copy is missing $($lf.Missing.Count) of $($lf.Total) LFS objects - copying from the live repo"
    $c = Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$copy" -Headers $t
    if ($c.archived) { $null = Invoke-RestMethod -Method Patch "https://api.github.com/repos/fin-tcm/$copy" -Headers $t -ContentType application/json -Body '{"archived":false}'; Start-Sleep 5 }
    git -C $g lfs fetch --all "https://github.com/fin-tcm/$repo.git" 2>&1 | Out-Null
    git -C $g lfs push --all "https://github.com/fin-tcm/$copy.git" 2>&1 | Out-Null
    $lf = Get-LfsMissing $copy $g
    if ($lf.Missing.Count -and $repo -in $AllowLfsMissing) {
      $liveMiss = (Get-LfsMissing $repo $g).Missing
      $extra = @($lf.Missing | Where-Object { $_ -notin $liveMiss })
      if (-not $extra.Count) { Write-Log "$repo : $($lf.Missing.Count) LFS object(s) missing in the copy, also missing in the live repo ($($lf.Missing -join ',')) - accepted (Gareth OK)"; $lf.Missing = @() }
      else { Write-Log "$repo : $($extra.Count) LFS object(s) missing in the copy but present in live - NOT swapped" } }
    if ($lf.Missing.Count) { $env:GIT_CONFIG_COUNT = '0'; Write-Log "$repo : still $($lf.Missing.Count) LFS objects missing - NOT swapped"; continue }
  }
  $env:GIT_CONFIG_COUNT = '0'; Remove-Item $g -Recurse -Force -EA SilentlyContinue
  # pre-check, swap, carry-over, verify
  & C:\kon-migration\scripts\swap-precheck.ps1 -Repo $repo -Suffix $Suffix | Out-Null
  $pc = @(Import-Csv "C:\kon-migration\swap\precheck\$repo.csv" -EA SilentlyContinue)
  $sw = & C:\kon-migration\scripts\repo-swap.ps1 -Org fin-tcm -Repos $repo -Suffix $Suffix -Apply 2>&1 | ForEach-Object { "$_" }
  if (-not ($sw -match 'check: ')) { Write-Log "$repo : SWAP DID NOT COMPLETE - check swap log: $(($sw | Where-Object { $_ -match 'STOP|FAIL rename' }) -join ' | ')"; continue }
  if ($pc.Count) {
    $w = "C:\kon-migration\swap\precheck\carry-$repo.git"; Remove-Item $w -Recurse -Force -EA SilentlyContinue; git init --bare -q $w
    $env:GIT_CONFIG_COUNT = '1'
    foreach ($x in $pc) { $ref = "refs/$($x.Ref)"; git -C $w fetch -q "https://github.com/fin-tcm/$repo-old.git" "+$($ref):$ref" 2>&1 | Out-Null; git -C $w push -q "https://github.com/fin-tcm/$repo.git" "$($ref):$ref" 2>&1 | Out-Null }
    $env:GIT_CONFIG_COUNT = '0'
  }
  $left = (& C:\kon-migration\scripts\swap-precheck.ps1 -Repo $repo -Live "$repo-old" -Copy $repo 2>&1 | Select-Object -First 1) -replace '^.*: ', ''
  $tf = { param($x) (Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$x/teams?per_page=100" -Headers $t | ForEach-Object { $_ } | ForEach-Object { "$($_.slug)=$($_.permission)" } | Sort-Object) -join ',' }
  $cf = { param($x) $a = @(); $p = 1; do { $k = 0; Invoke-RestMethod "https://api.github.com/repos/fin-tcm/$x/collaborators?affiliation=direct&per_page=100&page=$p" -Headers $t | ForEach-Object { $_ } | ForEach-Object { $a += "$($_.login)=$($_.role_name)"; $k++ }; $p++ } while ($k -eq 100); ($a | Sort-Object) -join ',' }
  $teamsOk = (& $tf $repo) -eq (& $tf "$repo-old"); $colOk = (& $cf $repo) -eq (& $cf "$repo-old")
  $own = @(Get-ChildItem C:\kon-migration\swap -Recurse -Filter owner-actions.csv | Where-Object { $_.Directory.Name -eq $repo } | Sort-Object LastWriteTime | Select-Object -Last 1 | ForEach-Object { Import-Csv $_.FullName })
  Write-Log ("$repo : SWAPPED. PRs fin-tcm-old $s / copy $d (live before $live); LFS objects $($lf.Total) all downloadable; branches carried over $($pc.Count); left behind $left; teams same $teamsOk; collaborators same $colOk" + $(if ($own.Count) { "; OWNER ACTION: re-enter $(($own | ForEach-Object { "$($_.What) $($_.Name)" }) -join ', ')" } else { '' }))
}
