# 14 Nov 2026 (cutover night): GraphQL fetch of the CHANGES_REQUESTED reviews of every PR in a repo, for
# add_missing_reviews.py. REST needs one call per PR (5,000/h shared by every run on the VM - the review step of the
# re-imports was waiting on the rate limit); GraphQL gets 100 PRs per call (~11 points, separate 5,000-point budget).
# Returns {pr_number: [review dicts shaped like the REST fields add_missing_reviews.py uses]}.
import json, time, urllib.request, urllib.error
Q = '''query($o:String!,$n:String!,$after:String){ rateLimit { remaining resetAt }
 repository(owner:$o,name:$n){ pullRequests(first:100, after:$after){ pageInfo{ hasNextPage endCursor }
  nodes { number reviews(first:10, states:[CHANGES_REQUESTED]){ totalCount nodes { databaseId body state submittedAt author{ login } commit{ oid } } } } } } }'''
QPR = '''query($o:String!,$n:String!,$num:Int!,$after:String){ rateLimit { remaining resetAt }
 repository(owner:$o,name:$n){ pullRequest(number:$num){ reviews(first:100, after:$after, states:[CHANGES_REQUESTED]){ pageInfo{ hasNextPage endCursor }
  nodes { databaseId body state submittedAt author{ login } commit{ oid } } } } } }'''

def _post(token, query, variables):
    body = json.dumps({'query': query, 'variables': variables}).encode()
    for attempt in range(10):
        req = urllib.request.Request('https://api.github.com/graphql', data=body, headers={'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                d = json.load(r)
            errs = d.get('errors') or []
            if any(e.get('type') == 'RATE_LIMITED' for e in errs):
                raise urllib.error.HTTPError('', 403, 'rate limited', {}, None)
            if errs and not d.get('data'):
                raise RuntimeError(json.dumps(errs)[:300])
            rl = (d.get('data') or {}).get('rateLimit') or {}
            if rl.get('remaining', 1000) < 50:   # pause before the budget runs out
                reset = time.mktime(time.strptime(rl['resetAt'], '%Y-%m-%dT%H:%M:%SZ')) - time.timezone
                wait = max(5, int(reset - time.time()) + 5); print(f'  graphql budget low: waiting {wait}s', flush=True); time.sleep(wait)
            return d['data']
        except urllib.error.HTTPError as e:
            wait = int((e.headers or {}).get('Retry-After') or 60 * (attempt + 1)); print(f'  graphql {e.code}: waiting {wait}s', flush=True); time.sleep(wait)
        except Exception as e:
            print(f'  graphql error ({e}); retry', flush=True); time.sleep(10 * (attempt + 1))
    raise RuntimeError('graphql failed')

def _shape(n):
    return {'id': n['databaseId'], 'state': n['state'], 'body': n['body'] or '', 'submitted_at': n['submittedAt'],
            'user': {'login': (n.get('author') or {}).get('login')} if n.get('author') else None, 'commit_id': (n.get('commit') or {}).get('oid')}

def changes_requested(token, repo):
    owner, name = repo.split('/', 1); out, after, pages = {}, None, 0
    while True:
        d = _post(token, Q, {'o': owner, 'n': name, 'after': after})
        conn = d['repository']['pullRequests']; pages += 1
        for pr in conn['nodes']:
            rv = pr['reviews']; revs = [_shape(x) for x in rv['nodes']]
            if rv['totalCount'] > len(revs):   # rare: more than 10 - page through this PR alone
                revs, a2 = [], None
                while True:
                    p = _post(token, QPR, {'o': owner, 'n': name, 'num': pr['number'], 'after': a2})['repository']['pullRequest']['reviews']
                    revs += [_shape(x) for x in p['nodes']]
                    if not p['pageInfo']['hasNextPage']: break
                    a2 = p['pageInfo']['endCursor']
            out[pr['number']] = revs
        if pages % 20 == 0: print(f'  graphql: {len(out)} PRs read', flush=True)
        if not conn['pageInfo']['hasNextPage']: return out
        after = conn['pageInfo']['endCursor']
