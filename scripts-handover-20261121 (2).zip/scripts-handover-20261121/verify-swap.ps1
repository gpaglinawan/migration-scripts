﻿# 17 Nov 2026 - READ-ONLY full verification of a swapped repository (fin-tcm/<repo> = re-imported copy, <repo>-old = previous).
#   PRs vs fin-tcm-old and -old; PR authors (Gareth / ghost / placeholders); branches and people's PRs left only in -old;
#   teams and direct collaborators vs fin-tcm-old (mapped to Teciem accounts); every repo setting vs -old (incl. autolinks); LFS downloads.
# Usage: .\verify-swap.ps1 -Repos ARC-test[,...]     Output: C:\kon-migration\swap\verify\<repo>.txt + summary line
param([Parameter(Mandatory)][string[]]$Repos)
$ErrorActionPreference = 'Continue'
$env:Path = [Environment]::GetEnvironmentVariable('Path','User') + ';' + [Environment]::GetEnvironmentVariable('Path','Machine')
Get-Content C:\development\pats.txt | ForEach-Object { if ($_ -match '^\s*\$env:(GH_SRC_PAT|GH_TGT_PAT)\s*=\s*"?([^"\s]+)"?\s*$') { Set-Item "env:$($Matches[1])" $Matches[2] } }
$t = @{ Authorization = "Bearer $env:GH_TGT_PAT"; Accept = 'application/vnd.github+json' }; $s = @{ Authorization = "Bearer $env:GH_SRC_PAT"; Accept = 'application/vnd.github+json' }
$b64 = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("x-access-token:$env:GH_TGT_PAT"))
$map = @{}; Import-Csv C:\kon-migration\rules\member-names-20261111.csv | Where-Object Tgt | ForEach-Object { $map[$_.Src.ToLower()] = $_.Tgt }
$norm = @{ 'pull' = 'read'; 'push' = 'write'; 'triage' = 'triage'; 'maintain' = 'maintain'; 'admin' = 'admin' }
$migr = 'gareth-cabrera_tciem', 'samar-roy_tciem'
$outDir = 'C:\kon-migration\swap\verify'; New-Item -ItemType Directory -Force $outDir | Out-Null
function Get-Api($u, $h) { try { Invoke-RestMethod $u -Headers $h -EA Stop } catch { $null } }
function Get-All($u, $h) { $a = @(); $p = 1; do { $k = 0; $r = Get-Api "$u$(if($u -match '\?'){'&'}else{'?'})per_page=100&page=$p" $h; if ($r -is [System.Collections.IDictionary] -or $r.PSObject.Properties['total_count']) { return $r }; foreach ($x in @($r)) { if ($x) { $a += $x; $k++ } }; $p++ } while ($k -eq 100); $a }
function Get-PrInfo($org, $n, $h) {
  $q = 'query($o:String!,$n:String!,$c:String){repository(owner:$o,name:$n){pullRequests(first:100,after:$c){pageInfo{hasNextPage endCursor} nodes{number title state createdAt author{login} body}}}}'
  $all = @(); $c = $null
  do { $d = (Invoke-RestMethod -Method Post https://api.github.com/graphql -Headers $h -Body (@{ query = $q; variables = @{ o = $org; n = $n; c = $c } } | ConvertTo-Json -Compress)).data.repository.pullRequests
       $all += $d.nodes; $c = $d.pageInfo.endCursor } while ($d.pageInfo.hasNextPage)
  $all }
foreach ($r in $Repos) {
  $L = New-Object System.Collections.ArrayList; $issues = New-Object System.Collections.ArrayList
  function Note($m) { [void]$L.Add($m) }; function Bad($m) { [void]$issues.Add($m); [void]$L.Add("  !! $m") }
  Note "=== $r  (verified $(Get-Date -Format 'yyyy-MM-dd HH:mm'))"
  $n = Get-Api "https://api.github.com/repos/fin-tcm/$r" $t; $o = Get-Api "https://api.github.com/repos/fin-tcm/$r-old" $t
  if (-not $n -or -not $o) { Bad "repo or $r-old not found"; $L | Set-Content "$outDir\$r.txt"; "$r : CHECK FAILED - repo or -old not found"; continue }
  Note "repo: created $($n.created_at) archived=$($n.archived) default=$($n.default_branch) | -old archived=$($o.archived)"
  if ($n.archived) { Bad 'new repo is archived' }; if (-not $o.archived) { Bad '-old is not archived' }
  if (Get-Api "https://api.github.com/repos/fin-tcm/$r-pr2" $t) { Bad "$r-pr2 still exists" }
  # PRs
  $fp = @(Get-PrInfo 'fin-tcm-old' $r $s); $np = @(Get-PrInfo 'fin-tcm' $r $t); $op = @(Get-PrInfo 'fin-tcm' "$r-old" $t)
  $cnt = { param($x) "total $($x.Count) (open $(@($x | Where-Object state -eq 'OPEN').Count), merged $(@($x | Where-Object state -eq 'MERGED').Count), closed $(@($x | Where-Object state -eq 'CLOSED').Count))" }
  Note "PRs fin-tcm-old: $(& $cnt $fp)"; Note "PRs new:     $(& $cnt $np)"; Note "PRs -old:    $(& $cnt $op)"
  if (@($np | Where-Object state -eq 'MERGED').Count -lt @($fp | Where-Object state -eq 'MERGED').Count) { Bad 'fewer merged PRs than fin-tcm-old' }
  $au = $np | Group-Object { $l = if ($_.author) { $_.author.login } else { 'ghost' }; if ($l -eq 'Gareth-Cabrera_tciem') { 'Gareth' } elseif ($l -like '*_tciem') { '_tciem' } elseif ($l -eq 'ghost') { 'ghost' } elseif ($l -like '*_finastra') { '_finastra placeholder' } else { "other($l)" } }
  Note "PR authors (new): $(($au | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ', ')"
  if ($au | Where-Object Name -eq 'Gareth') { Bad 'PRs still under Gareth' }
  $nk = @{}; $np | ForEach-Object { $nk["$($_.title)|$($_.createdAt)"] = 1 }
  $lost = @($op | Where-Object { ($_.body -notmatch '^\s*>?\s*Migrated from fin-tcm') -and -not $nk["$($_.title)|$($_.createdAt)"] })
  $lostPeople = @($lost | Where-Object { $_.author -and $_.author.login -notin 'dependabot', 'Copilot', 'github-actions' })
  Note "PRs only in -old: $($lost.Count) (by people: $($lostPeople.Count)) $(($lostPeople | Select-Object -First 5 | ForEach-Object { "#$($_.number) $($_.author.login) $($_.state)" }) -join '; ')"
  # branches left behind
  $left = (& C:\kon-migration\scripts\swap-precheck.ps1 -Repo $r -Live "$r-old" -Copy $r 2>&1 | Select-Object -First 1) -replace '^.*: ', ''
  Note "branches with commits only in -old: $left"; if ("$left" -ne '0') { Bad "$left branch(es) left behind in -old" }
  # access vs fin-tcm-old
  $ft = @(Get-All "https://api.github.com/repos/fin-tcm-old/$r/teams" $s | ForEach-Object { "$($_.slug)=$($norm[$_.permission])" } | Sort-Object)
  $tt = @(Get-All "https://api.github.com/repos/fin-tcm/$r/teams" $t | ForEach-Object { "$($_.slug)=$($norm[$_.permission])" } | Sort-Object)
  $td = @(Compare-Object $ft $tt); Note "teams: fin-tcm-old $($ft.Count), fin-tcm $($tt.Count), differences $($td.Count) $(($td | ForEach-Object { "$($_.InputObject)$(if($_.SideIndicator -eq '<='){'(only Finastra)'}else{'(only Teciem)'})" }) -join ', ')"
  if ($td.Count) { Bad 'teams differ from fin-tcm-old' }
  $fc = @(Get-All "https://api.github.com/repos/fin-tcm-old/$r/collaborators?affiliation=direct" $s); $tc = @{}; Get-All "https://api.github.com/repos/fin-tcm/$r/collaborators?affiliation=direct" $t | ForEach-Object { $tc[$_.login.ToLower()] = $_.role_name }
  $miss = @(); $wrong = @(); $noacc = @()
  foreach ($c in $fc) { $m = $map[$c.login.ToLower()]; if (-not $m) { $noacc += $c.login; continue }; $now = $tc[$m.ToLower()]; if (-not $now) { $miss += "$m=$($c.role_name)" } elseif ($now -ne $c.role_name) { $wrong += "$m $($c.role_name)->$now" } }
  $extra = @($tc.Keys | Where-Object { $k = $_; ($k -notin $migr) -and -not ($fc | Where-Object { $map[$_.login.ToLower()] -and $map[$_.login.ToLower()].ToLower() -eq $k }) } | ForEach-Object { "$_=$($tc[$_])" })
  $mig = @($tc.Keys | Where-Object { $_ -in $migr } | ForEach-Object { "$_=$($tc[$_])" })
  Note "collaborators: fin-tcm-old $($fc.Count), matched $($fc.Count - $miss.Count - $wrong.Count - $noacc.Count), missing $($miss.Count) $($miss -join ','), different role $($wrong.Count) $($wrong -join ','), no Teciem account $($noacc.Count), extra $($extra.Count) $($extra -join ','), migration accounts: $($mig -join ', ')"
  if ($miss.Count -or $wrong.Count -or $extra.Count) { Bad 'direct collaborators differ from fin-tcm-old' }
  # settings vs -old
  $snap = { param($x) $rp = Get-Api "https://api.github.com/repos/fin-tcm/$x" $t
    [ordered]@{ 'merge/visibility settings' = ($rp | Select-Object visibility, has_issues, has_projects, has_wiki, allow_squash_merge, allow_merge_commit, allow_rebase_merge, allow_auto_merge, delete_branch_on_merge, allow_update_branch, web_commit_signoff_required, default_branch | ConvertTo-Json -Compress)
      'description/topics' = "$($rp.description)|$(($rp.topics | Sort-Object) -join ',')"
      'repo rulesets' = ((Get-All "https://api.github.com/repos/fin-tcm/$x/rulesets?includes_parents=false" $t | ForEach-Object { "$($_.name)/$($_.enforcement)" }) | Sort-Object) -join ','
      'webhooks' = ((Get-All "https://api.github.com/repos/fin-tcm/$x/hooks" $t | ForEach-Object { "$($_.config.url)/$($_.active)" }) | Sort-Object) -join ','
      'autolinks' = ((Get-All "https://api.github.com/repos/fin-tcm/$x/autolinks" $t | ForEach-Object { "$($_.key_prefix)->$($_.url_template)" }) | Sort-Object) -join ','
      'deploy keys' = ((Get-All "https://api.github.com/repos/fin-tcm/$x/keys" $t | ForEach-Object { $_.title }) | Sort-Object) -join ','
      'Actions permissions' = ((Get-Api "https://api.github.com/repos/fin-tcm/$x/actions/permissions" $t) | ConvertTo-Json -Compress)
      'Actions secrets (names)' = (((Get-Api "https://api.github.com/repos/fin-tcm/$x/actions/secrets" $t).secrets.name) | Sort-Object) -join ','
      'Actions variables' = (((Get-Api "https://api.github.com/repos/fin-tcm/$x/actions/variables" $t).variables | ForEach-Object { "$($_.name)=$($_.value)" }) | Sort-Object) -join ','
      'environments' = (((Get-Api "https://api.github.com/repos/fin-tcm/$x/environments" $t).environments.name) | Sort-Object) -join ',' } }
  $ns = & $snap $r; $os = & $snap "$r-old"
  foreach ($k in $ns.Keys) { if ("$($ns[$k])" -eq "$($os[$k])") { Note "setting ${k}: same" } else { Bad "setting $k differs | new: $($ns[$k]) | -old: $($os[$k])" } }
  if ($ns['Actions secrets (names)'] -ne '') { Note "  note: Actions secret values cannot be copied - owners re-enter: $($ns['Actions secrets (names)'])" }
  # LFS
  $g = "C:\kon-migration\swap\verify\lfs-$r.git"; Remove-Item $g -Recurse -Force -EA SilentlyContinue
  $env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_LFS_SKIP_SMUDGE = '1'; $env:GIT_CONFIG_COUNT = '1'; $env:GIT_CONFIG_KEY_0 = 'http.https://github.com/.extraheader'; $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: basic $b64"
  git clone -q --mirror "https://github.com/fin-tcm/$r.git" $g 2>&1 | Out-Null
  $oids = @(git -C $g lfs ls-files --all --long 2>$null | ForEach-Object { ($_ -split ' ')[0] } | Sort-Object -Unique); $lm = 0
  for ($i = 0; $i -lt $oids.Count; $i += 100) { $ch = $oids[$i..([Math]::Min($i + 99, $oids.Count - 1))]
    $body = @{ operation = 'download'; transfers = @('basic'); objects = @($ch | ForEach-Object { @{ oid = $_; size = 1 } }) } | ConvertTo-Json -Depth 4
    $res = Invoke-RestMethod -Method Post "https://github.com/fin-tcm/$r.git/info/lfs/objects/batch" -Headers @{ Authorization = "Basic $b64"; Accept = 'application/vnd.git-lfs+json' } -ContentType 'application/vnd.git-lfs+json' -Body $body
    $lm += @($res.objects | Where-Object { $_.error.message -match 'does not exist' }).Count }
  $env:GIT_CONFIG_COUNT = '0'; Remove-Item $g -Recurse -Force -EA SilentlyContinue
  Note "LFS objects: $($oids.Count), missing $lm"; if ($lm) { Bad "$lm LFS objects missing" }
  $L | Set-Content "$outDir\$r.txt" -Encoding utf8
  "$r : $(if ($issues.Count) { 'ISSUES: ' + ($issues -join ' | ') } else { 'ALL CHECKS PASSED' })  (detail $outDir\$r.txt)"
}
